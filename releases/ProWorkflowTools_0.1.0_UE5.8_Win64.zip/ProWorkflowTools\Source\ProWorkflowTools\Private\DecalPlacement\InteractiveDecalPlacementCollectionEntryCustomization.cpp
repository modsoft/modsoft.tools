// Copyright © 2026 Trey McNair. All rights reserved.

#include "InteractiveDecalPlacementCollectionEntryCustomization.h"

#include "DetailCategoryBuilder.h"
#include "DetailLayoutBuilder.h"
#include "DetailWidgetRow.h"
#include "IDetailChildrenBuilder.h"
#include "IDetailPropertyRow.h"
#include "InteractiveDecalPlacementCollectionUtils.h"
#include "PropertyHandle.h"
#include "ProWorkflowToolsSettings.h"
#include "Widgets/Input/SComboBox.h"
#include "Widgets/Text/STextBlock.h"

#define LOCTEXT_NAMESPACE "InteractiveDecalCollectionEntryCustomization"

TSharedRef<IDetailCustomization> FProWorkflowToolsSettingsCustomization::MakeInstance()
{
	return MakeShared<FProWorkflowToolsSettingsCustomization>();
}

void FProWorkflowToolsSettingsCustomization::CustomizeDetails(IDetailLayoutBuilder& DetailBuilder)
{
	UProWorkflowToolsUserSettings* UserSettings = GetMutableDefault<UProWorkflowToolsUserSettings>();
	UserSettings->ImportProjectCollectionEntriesIfNeeded();

	TArray<TWeakObjectPtr<UObject>> Objects;
	DetailBuilder.GetObjectsBeingCustomized(Objects);
	const TWeakObjectPtr<UProWorkflowToolsSettings> ProjectSettings =
		Objects.Num() > 0 ? Cast<UProWorkflowToolsSettings>(Objects[0].Get()) : nullptr;

	IDetailCategoryBuilder& Category = DetailBuilder.EditCategory(TEXT("Decal Placement"));

	// Rows keep their order of addition and the remaining defaults follow, so the enable toggle
	// is placed first and the per-user collections directly under it.
	Category.AddProperty(DetailBuilder.GetProperty(GET_MEMBER_NAME_CHECKED(UProWorkflowToolsSettings, bEnableInteractiveDecalPlacement)));

	TArray<UObject*> ExternalObjects;
	ExternalObjects.Add(UserSettings);
	const TAttribute<bool> CollectionsEnabled = TAttribute<bool>::CreateLambda([ProjectSettings]()
	{
		return ProjectSettings.IsValid() && ProjectSettings->bEnableInteractiveDecalPlacement;
	});
	if (IDetailPropertyRow* const Row = Category.AddExternalObjectProperty(
		ExternalObjects,
		GET_MEMBER_NAME_CHECKED(UProWorkflowToolsUserSettings, CollectionEntries)))
	{
		Row->EditCondition(CollectionsEnabled, FOnBooleanValueChanged());
	}
}

namespace InteractiveDecalCollectionEntryCustomization
{
	static void RefreshCollectionOptions(TArray<TSharedPtr<FName>>& OutOptions)
	{
		OutOptions.Reset();
		TArray<FName> CollectionNames;
		InteractiveDecalPlacement::GetAllCollectionNames(CollectionNames);
		for (const FName& CollectionName : CollectionNames)
		{
			OutOptions.Add(MakeShared<FName>(CollectionName));
		}
	}
}

TSharedRef<IPropertyTypeCustomization> FInteractiveDecalCollectionEntryCustomization::MakeInstance()
{
	return MakeShared<FInteractiveDecalCollectionEntryCustomization>();
}

void FInteractiveDecalCollectionEntryCustomization::CustomizeHeader(TSharedRef<IPropertyHandle> StructPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& StructCustomizationUtils)
{
	HeaderRow.NameContent()[StructPropertyHandle->CreatePropertyNameWidget()];
}

void FInteractiveDecalCollectionEntryCustomization::CustomizeChildren(TSharedRef<IPropertyHandle> StructPropertyHandle, IDetailChildrenBuilder& StructBuilder, IPropertyTypeCustomizationUtils& StructCustomizationUtils)
{
	uint32 NumChildren = 0;
	StructPropertyHandle->GetNumChildren(NumChildren);

	TSharedPtr<IPropertyHandle> CollectionNameHandle;

	for (uint32 ChildIndex = 0; ChildIndex < NumChildren; ++ChildIndex)
	{
		TSharedPtr<IPropertyHandle> ChildHandle = StructPropertyHandle->GetChildHandle(ChildIndex);
		if (!ChildHandle.IsValid())
		{
			continue;
		}

		const FName PropertyName = ChildHandle->GetProperty() ? ChildHandle->GetProperty()->GetFName() : NAME_None;
		if (PropertyName == GET_MEMBER_NAME_CHECKED(FInteractiveDecalCollectionEntry, CollectionName))
		{
			CollectionNameHandle = ChildHandle;
		}
		else
		{
			StructBuilder.AddProperty(ChildHandle.ToSharedRef());
		}
	}

	if (CollectionNameHandle.IsValid())
	{
		TSharedRef<TArray<TSharedPtr<FName>>> Options = MakeShared<TArray<TSharedPtr<FName>>>();
		InteractiveDecalCollectionEntryCustomization::RefreshCollectionOptions(*Options);

		StructBuilder.AddCustomRow(LOCTEXT("CollectionNameRow", "Collection"))
		.NameContent()
		[
			CollectionNameHandle->CreatePropertyNameWidget()
		]
		.ValueContent()
		.MinDesiredWidth(250.0f)
		[
			SNew(SComboBox<TSharedPtr<FName>>)
			.OptionsSource(&Options.Get())
			.OnComboBoxOpening_Lambda([Options]()
			{
				InteractiveDecalCollectionEntryCustomization::RefreshCollectionOptions(*Options);
			})
			.OnGenerateWidget_Lambda([](TSharedPtr<FName> Item)
			{
				return SNew(STextBlock).Text(FText::FromName(Item.IsValid() ? *Item : NAME_None));
			})
			.OnSelectionChanged_Lambda([CollectionNameHandle](TSharedPtr<FName> Item, ESelectInfo::Type)
			{
				if (Item.IsValid())
				{
					CollectionNameHandle->SetValue(*Item);
				}
			})
			[
				SNew(STextBlock)
				.Text_Lambda([CollectionNameHandle]()
				{
					FName CurrentName = NAME_None;
					CollectionNameHandle->GetValue(CurrentName);
					return FText::FromName(CurrentName);
				})
			]
		];
	}
}

#undef LOCTEXT_NAMESPACE

