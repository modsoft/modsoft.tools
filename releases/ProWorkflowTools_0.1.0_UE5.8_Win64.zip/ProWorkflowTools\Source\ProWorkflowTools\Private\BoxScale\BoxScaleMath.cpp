// Copyright © 2026 Trey McNair. All rights reserved.

#include "BoxScale/BoxScaleMath.h"

FVector BoxScaleMath::GetSiteWorldPosition(const FBoxScaleSite& Site, const FVector& LocalCenter, const FVector& LocalExtent, const FTransform& Transform)
{
	const FVector ScaledExtent = LocalExtent * Transform.GetScale3D().GetAbs();
	FVector LocalOffset = FVector::ZeroVector;
	for (int32 Axis = 0; Axis < 3; ++Axis)
	{
		LocalOffset[Axis] = ScaledExtent[Axis] * static_cast<double>(Site.Get(Axis));
	}
	return Transform.TransformPosition(LocalCenter) + Transform.GetRotation().RotateVector(LocalOffset);
}

FVector BoxScaleMath::GetLocalAnchorPoint(const FBoxScaleSite& DragSite, const FVector& LocalCenter, const FVector& LocalExtent, const FVector& StartScale)
{
	FVector LocalAnchor = LocalCenter;
	for (int32 Axis = 0; Axis < 3; ++Axis)
	{
		const int8 SiteSign = DragSite.Get(Axis);
		if (SiteSign == 0)
		{
			continue;
		}
		const double ScaleSign = (StartScale[Axis] < 0.0) ? -1.0 : 1.0;
		LocalAnchor[Axis] -= LocalExtent[Axis] * static_cast<double>(SiteSign) * ScaleSign;
	}
	return LocalAnchor;
}

bool BoxScaleMath::IsAxisCollapsed(const FVector& ScaledExtent, const int32 Axis)
{
	return ScaledExtent[Axis] <= UE_KINDA_SMALL_NUMBER;
}

bool BoxScaleMath::IsAxisFlat(const FVector& ScaledExtent, const int32 Axis, const float FlatAxisRatio)
{
	if (IsAxisCollapsed(ScaledExtent, Axis))
	{
		return true;
	}

	const double Longest = ScaledExtent.GetMax();
	return FlatAxisRatio > 0.0f
		&& Longest > UE_KINDA_SMALL_NUMBER
		&& ScaledExtent[Axis] < static_cast<double>(FlatAxisRatio) * Longest;
}

bool BoxScaleMath::ShouldDrawSite(
	const FBoxScaleSite& Site,
	const FVector& ScaledExtent,
	const bool bShowFaceHandles,
	const bool bShowEdgeHandles,
	const bool bShowCornerHandles,
	const float FlatAxisRatio)
{
	const int32 FreeAxes = Site.NumFreeAxes();
	if ((FreeAxes == 1 && !bShowFaceHandles)
		|| (FreeAxes == 2 && !bShowEdgeHandles)
		|| (FreeAxes == 3 && !bShowCornerHandles))
	{
		return false;
	}

	for (int32 Axis = 0; Axis < 3; ++Axis)
	{
		if (Site.Get(Axis) != 0 && IsAxisFlat(ScaledExtent, Axis, FlatAxisRatio))
		{
			return false;
		}
	}
	return true;
}

bool BoxScaleMath::MakeDragFrame(const FBoxScaleSite& Site, const FBox& LocalBounds, const FTransform& Transform, const float FlatAxisRatio, FBoxScaleDragFrame& OutFrame)
{
	if (!Site.IsValid())
	{
		return false;
	}

	FBoxScaleDragFrame Frame;
	Frame.Site = Site;
	LocalBounds.GetCenterAndExtents(Frame.LocalCenter, Frame.LocalExtent);
	Frame.StartScale = Transform.GetScale3D();
	Frame.Rotation = Transform.GetRotation();

	const FVector ScaledExtent = Frame.LocalExtent * Frame.StartScale.GetAbs();
	int32 ScalableAxes = 0;
	for (int32 Axis = 0; Axis < 3; ++Axis)
	{
		FVector LocalAxis = FVector::ZeroVector;
		LocalAxis[Axis] = 1.0;
		Frame.AxisWorld[Axis] = Frame.Rotation.RotateVector(LocalAxis);
		Frame.bAxisFlat[Axis] = IsAxisFlat(ScaledExtent, Axis, FlatAxisRatio);
		if (Site.Get(Axis) != 0 && !Frame.bAxisFlat[Axis])
		{
			++ScalableAxes;
		}
	}
	if (ScalableAxes == 0)
	{
		return false;
	}

	Frame.HandleStartWorld = GetSiteWorldPosition(Site, Frame.LocalCenter, Frame.LocalExtent, Transform);
	Frame.AnchorWorld = GetSiteWorldPosition(Site.Opposite(), Frame.LocalCenter, Frame.LocalExtent, Transform);
	Frame.CenterWorld = Transform.TransformPosition(Frame.LocalCenter);

	for (int32 Axis = 0; Axis < 3; ++Axis)
	{
		if (Site.Get(Axis) == 0)
		{
			continue;
		}
		const double SignedSpan = FVector::DotProduct(Frame.HandleStartWorld - Frame.AnchorWorld, Frame.AxisWorld[Axis])
			* static_cast<double>(Site.Get(Axis));
		Frame.StartSpan[Axis] = FMath::Max(FMath::Abs(SignedSpan), MinDragSpan)
			* FMath::Sign(SignedSpan != 0.0 ? SignedSpan : 1.0);
	}

	OutFrame = Frame;
	return true;
}

namespace
{
	/** One factor from the handle's travel along the fixed point -> handle line. Never flips. */
	FVector SolveUniformScale(const FBoxScaleDragFrame& Frame, const FVector& HandleWorld, const FVector& FixedWorld, const double ScaleSnapStep)
	{
		const FVector Ray = Frame.HandleStartWorld - FixedWorld;
		const double RayLengthSq = Ray.SizeSquared();
		if (RayLengthSq <= UE_SMALL_NUMBER)
		{
			return Frame.StartScale;
		}

		const double MinFactor = BoxScaleMath::MinDragSpan / FMath::Sqrt(RayLengthSq);
		double Factor = FMath::Max(FVector::DotProduct(HandleWorld - FixedWorld, Ray) / RayLengthSq, MinFactor);
		if (ScaleSnapStep > 0.0)
		{
			Factor = FMath::Max(FMath::GridSnap(Factor, ScaleSnapStep), ScaleSnapStep);
		}
		return Frame.StartScale * Factor;
	}

	/** Each free, non-flat axis follows the handle on its own. */
	FVector SolvePerAxisScale(const FBoxScaleDragFrame& Frame, const FVector& HandleWorld, const FVector& FixedWorld, const bool bFromCenter, const double ScaleSnapStep)
	{
		FVector Scale = Frame.StartScale;
		for (int32 Axis = 0; Axis < 3; ++Axis)
		{
			if (Frame.Site.Get(Axis) == 0 || Frame.bAxisFlat[Axis] || FMath::IsNearlyZero(Frame.StartSpan[Axis]))
			{
				continue;
			}

			// Center mode measures half the box. Double it so the same full-span ratio applies.
			double NewSpan = FVector::DotProduct(HandleWorld - FixedWorld, Frame.AxisWorld[Axis])
				* static_cast<double>(Frame.Site.Get(Axis));
			if (bFromCenter)
			{
				NewSpan *= 2.0;
			}
			if (FMath::Abs(NewSpan) < BoxScaleMath::MinDragSpan)
			{
				NewSpan = (NewSpan < 0.0) ? -BoxScaleMath::MinDragSpan : BoxScaleMath::MinDragSpan;
			}

			Scale[Axis] = Frame.StartScale[Axis] * (NewSpan / Frame.StartSpan[Axis]);
			if (ScaleSnapStep > 0.0)
			{
				Scale[Axis] = FMath::GridSnap(Scale[Axis], ScaleSnapStep);
				if (FMath::IsNearlyZero(Scale[Axis]))
				{
					Scale[Axis] = (Frame.StartScale[Axis] < 0.0) ? -ScaleSnapStep : ScaleSnapStep;
				}
			}
		}
		return Scale;
	}
}

FBoxScaleSolve BoxScaleMath::SolveDrag(const FBoxScaleDragFrame& Frame, const FVector& HandleWorld, const bool bFromCenter, const bool bUniform, const double ScaleSnapStep)
{
	const FVector FixedWorld = bFromCenter ? Frame.CenterWorld : Frame.AnchorWorld;

	FBoxScaleSolve Solve;
	Solve.Scale = bUniform
		? SolveUniformScale(Frame, HandleWorld, FixedWorld, ScaleSnapStep)
		: SolvePerAxisScale(Frame, HandleWorld, FixedWorld, bFromCenter, ScaleSnapStep);

	const FVector LocalFixed = bFromCenter
		? Frame.LocalCenter
		: GetLocalAnchorPoint(Frame.Site, Frame.LocalCenter, Frame.LocalExtent, Frame.StartScale);
	Solve.Location = FixedWorld - Frame.Rotation.RotateVector(LocalFixed * Solve.Scale);
	return Solve;
}
