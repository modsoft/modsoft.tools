// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "Framework/Commands/UIAction.h"
#include "Modules/ModuleInterface.h"
#include "Modules/ModuleManager.h"
#include "SelectSimilar/MarqueeSelectSimilarFilter.h"
#include "UObject/StrongObjectPtr.h"
#include "UObject/WeakObjectPtr.h"

class AActor;
class FUICommandInfo;
class ILevelEditor;
class UMaterialInterface;
class FSuperGroupsFeature;
class FInteractiveDecalPlacementFeature;

/** Viewport tools that each own the HUD. Entering one exits the others. */
enum class EProWorkflowViewportTool : uint8
{
	GridPaint,
	DecalPlacement,
	BoxScale
};

/**
 * Level editor module: DCC selection, box scale, grid paint, material clipboard,
 * groups, decals, duplicate helpers, show-last-hidden.
 */
class FProWorkflowToolsModule : public IModuleInterface
{
public:
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

	static FProWorkflowToolsModule* GetPtr()
	{
		return FModuleManager::GetModulePtr<FProWorkflowToolsModule>("ProWorkflowTools");
	}

	bool IsBoxScaleEnabled() const { return bBoxScaleEnabled; }
	bool IsDccControlsEnabled() const;
	bool IsDuplicateInPlaceEnabled() const;
	bool IsMaterialClipboardToolEnabled() const;
	bool IsGridPaintEnabled() const;

	/** Deactivate every viewport tool except Incoming. Incoming is not started here. */
	void ReleaseViewportToolsExcept(EProWorkflowViewportTool Incoming);

	const FMarqueeSelectSimilarFilter& GetMarqueeFilter() const { return MarqueeFilter; }
	void SnapshotMarqueeFilterForDrag();

	/** Single-slot material clipboard shared by the Material Clipboard Tool (pick/apply). */
	UMaterialInterface* GetPickedMaterial() const;
	void SetPickedMaterial(UMaterialInterface* InMaterial);

private:
	void DuplicateWithLastAction();
	bool CanDuplicateWithLastAction() const;
	void ToggleBoxScale();
	void ToggleGridPaint();
	bool IsGridPaintActive() const;
	void ShowLastHidden();
	bool CanShowLastHidden() const;

	void ResetHiddenActorHistory();
	void PushHiddenBatch(TArray<TWeakObjectPtr<AActor>>&& Batch);

	/**
	 * The hide history is recorded by the hide commands themselves. The engine has no
	 * visibility-changed delegate, so Hide Selected and its toggle/hierarchy variants are
	 * decorated on the global level editor command list: the engine's own action is kept
	 * and run from a wrapper that diffs editor visibility around it.
	 */
	struct FWrappedHideCommand
	{
		TSharedPtr<const FUICommandInfo> Command;
		FUIAction EngineAction;
	};
	void WrapHideCommands();
	void UnwrapHideCommands();
	void ExecuteWrappedHide(int32 WrappedIndex);
	void VerifyHideCommandOwnership(const TCHAR* When) const;

	/** Re-anchor Duplicate with Last Transform when the set of selected actors changes. */
	void UpdateSessionAnchors();
	/** Record the current transforms of LastSelectionSet as the session start. */
	void AnchorSelectionHere();

	void OnEditorSelectionChanged(UObject* NewSelection);
	void OnMapOpened(const FString& Filename, bool bAsTemplate);
	void OnPostUndoRedo();

	void BindEditorDelegates();
	void OnLevelEditorCreated(TSharedPtr<ILevelEditor> InLevelEditor);
	void UpdateWorkflowModeActivation();
	bool IsWorkflowModeNeeded() const;
	void UpdateMarqueeFilterFromSelection();
	void MaybeShowWelcomeSplash();
	void OpenWelcomeSplash();
	void RegisterToolbar();
	void RegisterToolbarMenus();
	void UnregisterToolbar();
	void RegisterSettings();
	void UnregisterSettings();
	void OnSettingsChanged(UObject* Settings, struct FPropertyChangedEvent& PropertyChangedEvent);

	/** Transform delta: rot/trans via FTransform; scale separate. */
	struct FTransformActionDelta
	{
		FTransform TransformDelta = FTransform::Identity;
		FVector ScaleMultiplier = FVector::OneVector;

		void SetFromMovement(const FTransform& Start, const FTransform& End);
		void ApplyTo(FTransform& InOutTransform) const;

		bool IsNearlyIdentity() const
		{
			return TransformDelta.Equals(FTransform::Identity) && ScaleMultiplier.Equals(FVector::OneVector);
		}

	private:
		static FTransform StripScale(const FTransform& InTransform);
		static FVector ComputeScaleRatio(const FTransform& Start, const FTransform& End);
	};

	/** Net transform the selection has taken since it was selected, or unset if it has not moved. */
	TOptional<FTransformActionDelta> ComputeSessionDelta() const;

	/** Cursor readout after Shift+D: the replayed move / rotate / scale, or that there was none. */
	void ShowDuplicateWithLastReadout(const FVector& CentroidMove) const;

	TOptional<FTransformActionDelta> ReplayDelta;

	/** Where each selected actor sat when it entered the current selection. */
	TMap<TWeakObjectPtr<AActor>, FTransform> SessionStartTransforms;
	TSet<TWeakObjectPtr<AActor>> LastSelectionSet;

	TArray<FWrappedHideCommand> WrappedHideCommands;

	bool bBoxScaleEnabled = false;
	FMarqueeSelectSimilarFilter MarqueeFilter;
	TStrongObjectPtr<UMaterialInterface> PickedMaterial;

	/** Hide batches; last entry is most recent (unhide last). */
	TArray<TArray<TWeakObjectPtr<AActor>>> LastHiddenBatches;

	TUniquePtr<FSuperGroupsFeature> SuperGroupsFeature;
	TUniquePtr<FInteractiveDecalPlacementFeature> DecalPlacementFeature;

	FDelegateHandle EditorPreExitHandle;
	FDelegateHandle SelectionChangedHandle;
	FDelegateHandle SettingsChangedHandle;
	FDelegateHandle MapOpenedHandle;
	FDelegateHandle PostUndoRedoHandle;
};

