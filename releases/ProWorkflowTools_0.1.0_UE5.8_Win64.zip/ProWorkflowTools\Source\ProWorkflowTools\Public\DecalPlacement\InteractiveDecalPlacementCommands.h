// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "Framework/Commands/Commands.h"
#include "Styling/AppStyle.h"

/** Level-editor commands for the Interactive Decal Placement plugin. */
class FInteractiveDecalPlacementCommands : public TCommands<FInteractiveDecalPlacementCommands>
{
public:
	FInteractiveDecalPlacementCommands()
		: TCommands<FInteractiveDecalPlacementCommands>(
			TEXT("InteractiveDecalPlacement"),
			NSLOCTEXT("InteractiveDecalPlacement", "CommandsContext", "Interactive Decal Placement"),
			TEXT("LevelEditor"),
			FAppStyle::GetAppStyleSetName())
	{
	}

	virtual void RegisterCommands() override;

	/** Begin placement: Content Browser decal if one is selected, otherwise configured collections. */
	TSharedPtr<FUICommandInfo> StartPlacement;
};

