// Copyright © 2026 Trey McNair. All rights reserved.

#include "Welcome/SProWorkflowWelcomeSplash.h"

#include "Brushes/SlateDynamicImageBrush.h"
#include "Brushes/SlateRoundedBoxBrush.h"
#include "DecalPlacement/InteractiveDecalPlacementCollectionUtils.h"
#include "DecalPlacement/InteractiveDecalPlacementCommands.h"
#include "Framework/Application/SlateApplication.h"
#include "Framework/Commands/InputChord.h"
#include "Framework/Commands/UICommandInfo.h"
#include "Framework/Docking/TabManager.h"
#include "GenericPlatform/GenericApplication.h"
#include "HAL/PlatformApplicationMisc.h"
#include "IImageWrapper.h"
#include "IImageWrapperModule.h"
#include "ISettingsModule.h"
#include "Interfaces/IPluginManager.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "Modules/ModuleManager.h"
#include "ProWorkflowToolsCommands.h"
#include "ProWorkflowToolsEngineVersion.h"
#include "ProWorkflowToolsSettings.h"
#include "ProWorkflowToolsStyle.h"
#if PWT_UE_5_8_OR_LATER
#include "SAssetSearchBox.h"
#include "Types/ISlateMetaData.h"
#include "Widgets/Docking/SDockTab.h"
#endif
#include "Styling/AppStyle.h"
#include "Styling/CoreStyle.h"
#include "Styling/StyleColors.h"
#include "Welcome/ProWorkflowPlaceholderSetup.h"
#include "Widgets/Images/SImage.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SCheckBox.h"
#include "Widgets/Input/SHyperlink.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Layout/SScaleBox.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Widgets/Layout/SSeparator.h"
#include "Widgets/Layout/SWrapBox.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/SOverlay.h"
#include "Widgets/SWindow.h"
#include "Widgets/Text/STextBlock.h"

#define LOCTEXT_NAMESPACE "ProWorkflowWelcomeSplash"

namespace ProWorkflowWelcomeSplashPrivate
{
	constexpr float IconColumnWidth = 20.0f;
	constexpr float IconColumnGap = 8.0f;
	/** Descriptions and footnotes align with the title text, past the icon column. */
	constexpr float BodyIndent = IconColumnWidth + IconColumnGap;
	constexpr float ToggleColumnWidth = 56.0f;
	constexpr float SectionGap = 18.0f;
	constexpr float RowGap = 12.0f;

	const FVector2D DefaultWindowSize(640.0, 680.0);
	const FLinearColor BrandBlue(0.0f, 0.55f, 0.9f, 1.0f);
	const FLinearColor BannerBlack(0.04f, 0.04f, 0.04f, 1.0f);

	/** Pixel size of a PNG on disk, so the brush always matches the asset's aspect. */
	TOptional<FVector2D> ReadPngDimensions(const FString& Path)
	{
		TArray<uint8> Bytes;
		if (!FFileHelper::LoadFileToArray(Bytes, *Path))
		{
			return TOptional<FVector2D>();
		}

		IImageWrapperModule& ImageWrapperModule = FModuleManager::LoadModuleChecked<IImageWrapperModule>("ImageWrapper");
		const TSharedPtr<IImageWrapper> Wrapper = ImageWrapperModule.CreateImageWrapper(EImageFormat::PNG);
		if (!Wrapper.IsValid() || !Wrapper->SetCompressed(Bytes.GetData(), Bytes.Num()))
		{
			return TOptional<FVector2D>();
		}

		return FVector2D(Wrapper->GetWidth(), Wrapper->GetHeight());
	}

	/** Saved geometry is only reused when the top-left still lands on a connected monitor. */
	bool IsSavedPositionOnScreen(const FVector2D& LogicalPosition)
	{
		if (LogicalPosition.IsZero())
		{
			return false;
		}

		// SWindow scales a ScreenPosition by the DPI at that point; mirror it before testing.
		const float DPIScale = FPlatformApplicationMisc::GetDPIScaleFactorAtPoint(
			static_cast<float>(LogicalPosition.X), static_cast<float>(LogicalPosition.Y));
		const FVector2D ScreenPosition = LogicalPosition * DPIScale;

		FDisplayMetrics Metrics;
		FDisplayMetrics::RebuildDisplayMetrics(Metrics);
		for (const FMonitorInfo& Monitor : Metrics.MonitorInfo)
		{
			const FPlatformRect& Area = Monitor.WorkArea;
			if (ScreenPosition.X >= Area.Left && ScreenPosition.X < Area.Right
				&& ScreenPosition.Y >= Area.Top && ScreenPosition.Y < Area.Bottom)
			{
				return true;
			}
		}
		return false;
	}
}

TWeakPtr<SWindow> SProWorkflowWelcomeSplash::ActiveWindow;

void SProWorkflowWelcomeSplash::LoadBannerBrush()
{
	BannerBrush.Reset();
	VersionText = FText::GetEmpty();

	const TSharedPtr<IPlugin> Plugin = IPluginManager::Get().FindPlugin(TEXT("ProWorkflowTools"));
	if (!Plugin.IsValid())
	{
		return;
	}

	const FString& VersionName = Plugin->GetDescriptor().VersionName;
	if (!VersionName.IsEmpty())
	{
		VersionText = FText::Format(LOCTEXT("VersionFormat", "v{0}"), FText::FromString(VersionName));
	}

	// Dynamic brush loads PNG from disk; FSlateImageBrush only resolves style-set resources.
	FString SplashPath = FPaths::ConvertRelativePathToFull(
		Plugin->GetBaseDir() / TEXT("Resources") / TEXT("ProWorkflowTools_splash.png"));
	FPaths::NormalizeFilename(SplashPath);

	const TOptional<FVector2D> ImageSize = ProWorkflowWelcomeSplashPrivate::ReadPngDimensions(SplashPath);
	if (!ImageSize.IsSet() || ImageSize->X <= 0.0 || ImageSize->Y <= 0.0)
	{
		return;
	}

	BannerBrush = MakeShareable(new FSlateDynamicImageBrush(FName(*SplashPath), ImageSize.GetValue()));
}

TSharedRef<SWidget> SProWorkflowWelcomeSplash::BuildBannerWidget()
{
	using namespace ProWorkflowWelcomeSplashPrivate;

	TSharedRef<SWidget> Graphic = SNullWidget::NullWidget;
	if (BannerBrush.IsValid())
	{
		// Edge-to-edge banner: fit the panel width, keep the image's aspect, no cropping.
		Graphic = SNew(SScaleBox)
			.Stretch(EStretch::ScaleToFitX)
			.StretchDirection(EStretchDirection::Both)
			.HAlign(HAlign_Fill)
			.VAlign(VAlign_Center)
			[
				SNew(SImage)
				.Image(BannerBrush.Get())
			];
	}
	else
	{
		Graphic = SNew(SBox)
			.Padding(FMargin(16.0f, 14.0f))
			[
				SNew(STextBlock)
				.Text(LOCTEXT("Title", "Pro Workflow Tools"))
				.Font(FCoreStyle::GetDefaultFontStyle("Bold", 18))
			];
	}

	// Version and tagline live in the banner's empty right half instead of a paragraph below.
	return SNew(SOverlay)
		+ SOverlay::Slot()
		[
			SNew(SBorder)
			.BorderImage(FCoreStyle::Get().GetBrush("GenericWhiteBox"))
			.BorderBackgroundColor(BannerBlack)
			.Padding(0.0f)
			[
				Graphic
			]
		]
		+ SOverlay::Slot()
		.HAlign(HAlign_Right)
		.VAlign(VAlign_Center)
		.Padding(0.0f, 0.0f, 16.0f, 0.0f)
		[
			SNew(SVerticalBox)
			+ SVerticalBox::Slot()
			.AutoHeight()
			.HAlign(HAlign_Right)
			[
				SNew(STextBlock)
				.Text(VersionText)
				.Font(FCoreStyle::GetDefaultFontStyle("Bold", 10))
				.ColorAndOpacity(FLinearColor(0.92f, 0.93f, 0.95f, 1.0f))
				.Visibility(VersionText.IsEmpty() ? EVisibility::Collapsed : EVisibility::HitTestInvisible)
			]
			+ SVerticalBox::Slot()
			.AutoHeight()
			.HAlign(HAlign_Right)
			[
				SNew(STextBlock)
				.Text(LOCTEXT("Tagline", "Hotkey-driven level editor tools"))
				.Font(FCoreStyle::GetDefaultFontStyle("Regular", 9))
				.ColorAndOpacity(FLinearColor(0.62f, 0.65f, 0.7f, 1.0f))
				.Visibility(EVisibility::HitTestInvisible)
			]
		];
}

TSharedRef<SWidget> SProWorkflowWelcomeSplash::BuildSectionHeader(const FText& Title) const
{
	return SNew(SVerticalBox)
		+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(0.0f, 0.0f, 0.0f, 4.0f)
		[
			SNew(STextBlock)
			.Text(Title)
			.TransformPolicy(ETextTransformPolicy::ToUpper)
			.Font(FCoreStyle::GetDefaultFontStyle("Bold", 8))
			.ColorAndOpacity(FSlateColor::UseSubduedForeground())
		]
		+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(0.0f, 0.0f, 0.0f, 10.0f)
		[
			SNew(SSeparator)
		];
}

TSharedRef<SWidget> SProWorkflowWelcomeSplash::BuildHotkeyChip(TFunction<FText()> HotkeyText, TFunction<void()> OnClicked) const
{
	// Chip text: monospace so chords line up across rows; "Unbound" reads as absent, not a key.
	const TSharedRef<TFunction<FText()>> SharedText = MakeShared<TFunction<FText()>>(MoveTemp(HotkeyText));
	auto IsUnbound = [SharedText]()
	{
		return (*SharedText)().EqualTo(LOCTEXT("ChordUnbound", "Unbound"));
	};

	return SNew(SButton)
		.ButtonStyle(&ChipButtonStyle)
		.ContentPadding(FMargin(10.0f, 3.0f))
		.ToolTipText(LOCTEXT("ChipTooltip", "Click to change this key"))
		.OnClicked_Lambda([OnClicked]()
		{
			if (OnClicked)
			{
				OnClicked();
			}
			return FReply::Handled();
		})
		[
			SNew(SBox)
			.MinDesiredWidth(72.0f)
			.MaxDesiredWidth(160.0f)
			.HAlign(HAlign_Center)
			[
				SNew(STextBlock)
				.Justification(ETextJustify::Center)
				.Text_Lambda([SharedText]() { return (*SharedText)(); })
				.Font_Lambda([IsUnbound]()
				{
					return IsUnbound()
						? FCoreStyle::GetDefaultFontStyle("Italic", 9)
						: FCoreStyle::GetDefaultFontStyle("Mono", 9);
				})
				.ColorAndOpacity_Lambda([IsUnbound]()
				{
					return IsUnbound() ? FSlateColor::UseSubduedForeground() : FSlateColor::UseForeground();
				})
			]
		];
}

TSharedRef<SWidget> SProWorkflowWelcomeSplash::BuildRow(const FRowSpec& Spec) const
{
	using namespace ProWorkflowWelcomeSplashPrivate;

	const TSharedRef<SHorizontalBox> TitleRow = SNew(SHorizontalBox);

	// Icon column is always reserved so every title and description shares one left edge.
	TitleRow->AddSlot()
		.AutoWidth()
		.VAlign(VAlign_Center)
		.Padding(0.0f, 0.0f, IconColumnGap, 0.0f)
		[
			SNew(SBox)
			.WidthOverride(IconColumnWidth)
			.HeightOverride(IconColumnWidth)
			[
				Spec.IconBrushName.IsNone()
					? SNullWidget::NullWidget
					: StaticCastSharedRef<SWidget>(SNew(SImage).Image(FProWorkflowToolsStyle::Get().GetBrush(Spec.IconBrushName)))
			]
		];

	TitleRow->AddSlot()
		.FillWidth(1.0f)
		.VAlign(VAlign_Center)
		[
			SNew(STextBlock)
			.Text(Spec.Label)
			.Font(FCoreStyle::GetDefaultFontStyle("Bold", 11))
		];

	if (Spec.HotkeyText)
	{
		TitleRow->AddSlot()
			.AutoWidth()
			.VAlign(VAlign_Center)
			.Padding(8.0f, 0.0f, 0.0f, 0.0f)
			[
				BuildHotkeyChip(Spec.HotkeyText, Spec.OnHotkeyClicked)
			];
	}

	// Toggle column is reserved even on rows without one so the chips form a straight column.
	TSharedRef<SWidget> Toggle = SNullWidget::NullWidget;
	if (Spec.Getter && Spec.Setter)
	{
		const TFunction<bool()> Getter = Spec.Getter;
		const TFunction<void(bool)> Setter = Spec.Setter;
		Toggle = SNew(SCheckBox)
			.Style(&FAppStyle::Get(), "ToggleButtonCheckbox")
			.HAlign(HAlign_Center)
			.Padding(FMargin(8.0f, 3.0f))
			.ToolTipText(LOCTEXT("ToggleTooltip", "Enable or disable this feature"))
			.IsChecked_Lambda([Getter]() { return Getter() ? ECheckBoxState::Checked : ECheckBoxState::Unchecked; })
			.OnCheckStateChanged_Lambda([Setter](ECheckBoxState NewState) { Setter(NewState == ECheckBoxState::Checked); })
			[
				SNew(STextBlock)
				.Font(FCoreStyle::GetDefaultFontStyle("Bold", 9))
				.Text_Lambda([Getter]() { return Getter() ? LOCTEXT("ToggleOn", "On") : LOCTEXT("ToggleOff", "Off"); })
			];
	}
	TitleRow->AddSlot()
		.AutoWidth()
		.VAlign(VAlign_Center)
		.HAlign(HAlign_Right)
		.Padding(12.0f, 0.0f, 0.0f, 0.0f)
		[
			SNew(SBox)
			.WidthOverride(ToggleColumnWidth)
			.HAlign(HAlign_Right)
			[
				Toggle
			]
		];

	const TSharedRef<SVerticalBox> Row = SNew(SVerticalBox)
		+ SVerticalBox::Slot()
		.AutoHeight()
		[
			TitleRow
		]
		+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(BodyIndent, 2.0f, 0.0f, 0.0f)
		[
			SNew(STextBlock)
			.AutoWrapText(true)
			.ColorAndOpacity(FSlateColor::UseSubduedForeground())
			.Text(Spec.Description)
		];

	if (Spec.Footnote.IsValid())
	{
		Row->AddSlot()
			.AutoHeight()
			.Padding(BodyIndent, 4.0f, 0.0f, 0.0f)
			[
				Spec.Footnote.ToSharedRef()
			];
	}

	return Row;
}

SProWorkflowWelcomeSplash::FRowSpec SProWorkflowWelcomeSplash::MakeRow(
	const FText& Label,
	const FText& Description,
	const FName Icon,
	bool UProWorkflowToolsSettings::* ToggleMember,
	TSharedPtr<FUICommandInfo> Command,
	FKey UProWorkflowToolsSettings::* HoldKeyMember) const
{
	FRowSpec Spec;
	Spec.Label = Label;
	Spec.Description = Description;
	Spec.IconBrushName = Icon;

	if (ToggleMember)
	{
		Spec.Getter = [ToggleMember]() { return GetDefault<UProWorkflowToolsSettings>()->*ToggleMember; };
		Spec.Setter = [this, ToggleMember](bool bValue) { PersistBoolSetting(ToggleMember, bValue); };
	}

	if (Command.IsValid())
	{
		Spec.HotkeyText = [Command]() { return GetCommandChordText(Command); };
		Spec.OnHotkeyClicked = [this, Command]() { OnOpenKeyboardShortcutsClicked(Command->GetBindingContext()); };
	}
	else if (HoldKeyMember)
	{
		Spec.HotkeyText = [HoldKeyMember]() { return (GetDefault<UProWorkflowToolsSettings>()->*HoldKeyMember).GetDisplayName(); };
		Spec.OnHotkeyClicked = [this]() { OnOpenPluginSettingsClicked(); };
	}

	return Spec;
}

void SProWorkflowWelcomeSplash::Construct(const FArguments& InArgs)
{
	using namespace ProWorkflowWelcomeSplashPrivate;

	// Opt-out is a deliberate choice, never the default: an accidental Close must not hide
	// the splash for good.
	bDontShowAgain = GetDefault<UProWorkflowToolsUserSettings>()->bDontShowWelcomeSplashAgain;

	LoadBannerBrush();

	ChipButtonStyle = FAppStyle::Get().GetWidgetStyle<FButtonStyle>("SimpleButton");
	ChipButtonStyle
		.SetNormal(FSlateRoundedBoxBrush(FStyleColors::Recessed, 4.0f, FStyleColors::InputOutline, 1.0f))
		.SetHovered(FSlateRoundedBoxBrush(FStyleColors::Hover, 4.0f, FStyleColors::InputOutline, 1.0f))
		.SetPressed(FSlateRoundedBoxBrush(FStyleColors::Header, 4.0f, FStyleColors::InputOutline, 1.0f))
		.SetNormalPadding(FMargin(0.0f))
		.SetPressedPadding(FMargin(0.0f));

	const FProWorkflowToolsCommands& Commands = FProWorkflowToolsCommands::Get();

	FRowSpec DecalRow = MakeRow(
		LOCTEXT("DecalLabel", "Interactive Decal Placement"),
		LOCTEXT("DecalDesc", "Intuitively draw decals in the scene with live preview, drag-to-size, scroll through collections of decals, with various modifier hotkeys."),
		FName(TEXT("ProWorkflowTools.Icon.DecalPlacement")),
		&UProWorkflowToolsSettings::bEnableInteractiveDecalPlacement,
		FInteractiveDecalPlacementCommands::Get().StartPlacement);
	DecalRow.Footnote = BuildDecalCollectionHint();

	ChildSlot
	[
		SNew(SBorder)
		.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
		.Padding(0.0f)
		[
			SNew(SVerticalBox)

			+ SVerticalBox::Slot()
			.AutoHeight()
			[
				BuildBannerWidget()
			]

			// Brand rule under the banner, drawn by Slate so it stays crisp at any width.
			+ SVerticalBox::Slot()
			.AutoHeight()
			[
				SNew(SBox)
				.HeightOverride(2.0f)
				[
					SNew(SBorder)
					.BorderImage(FCoreStyle::Get().GetBrush("GenericWhiteBox"))
					.BorderBackgroundColor(BrandBlue)
					.Padding(0.0f)
				]
			]

			+ SVerticalBox::Slot()
			.FillHeight(1.0f)
			.Padding(16.0f, 12.0f, 16.0f, 12.0f)
			[
				SNew(SVerticalBox)

				+ SVerticalBox::Slot()
				.AutoHeight()
				.Padding(0.0f, 0.0f, 0.0f, 12.0f)
				[
					SNew(STextBlock)
					.AutoWrapText(true)
					.ColorAndOpacity(FSlateColor::UseSubduedForeground())
					.Text(LOCTEXT(
						"IntroHint",
						"Thanks for installing Pro Workflow Tools! Enable the features you want and edit their hotkeys. More options and customizations are located in the Plugin Settings."))
				]

				+ SVerticalBox::Slot()
				.FillHeight(1.0f)
				[
					SNew(SScrollBox)
					+ SScrollBox::Slot()
					.Padding(0.0f, 0.0f, 8.0f, 0.0f)
					[
						SNew(SVerticalBox)

						//~ Controls
						+ SVerticalBox::Slot().AutoHeight()
						[
							BuildSectionHeader(LOCTEXT("ControlsHeader", "Controls"))
						]
						+ SVerticalBox::Slot().AutoHeight().Padding(0.0f, 0.0f, 0.0f, SectionGap)
						[
							BuildRow(MakeRow(
								LOCTEXT("DccLabel", "DCC Standard Control Scheme"),
								LOCTEXT("DccDesc", "Toggle-able control scheme for the level editor to mimic DCC standard orbit, selection, and marquee controls"),
								FName(TEXT("ProWorkflowTools.Icon.DCC")),
								&UProWorkflowToolsSettings::bEnableDccViewportControls))
						]

						//~ Tools
						+ SVerticalBox::Slot().AutoHeight()
						[
							BuildSectionHeader(LOCTEXT("ToolsHeader", "Tools"))
						]
						+ SVerticalBox::Slot().AutoHeight().Padding(0.0f, 0.0f, 0.0f, RowGap)
						[
							BuildRow(MakeRow(
								LOCTEXT("ClipboardLabel", "Material Clipboard"),
								LOCTEXT("ClipboardDesc", "A material override clipboard tool to pick, assign, and revert material overrides on assets in the scene."),
								FName(TEXT("ProWorkflowTools.Icon.MaterialClipboard")),
								&UProWorkflowToolsSettings::bEnableMaterialClipboardTool,
								nullptr,
								&UProWorkflowToolsSettings::MaterialClipboardHoldKey))
						]
						+ SVerticalBox::Slot().AutoHeight().Padding(0.0f, 0.0f, 0.0f, RowGap)
						[
							BuildRow(MakeRow(
								LOCTEXT("GridLabel", "Actor Grid Paint"),
								LOCTEXT("GridDesc", "Paint copies of the selected mesh or decal on its modular grid."),
								FName(TEXT("ProWorkflowTools.Icon.GridPaint")),
								&UProWorkflowToolsSettings::bEnableGridPaint,
								Commands.ToggleGridPaint))
						]
						+ SVerticalBox::Slot().AutoHeight().Padding(0.0f, 0.0f, 0.0f, RowGap)
						[
							BuildRow(DecalRow)
						]
						+ SVerticalBox::Slot().AutoHeight().Padding(0.0f, 0.0f, 0.0f, RowGap)
						[
							BuildRow(MakeRow(
								LOCTEXT("BoxScaleLabel", "Bounding Box Scale"),
								LOCTEXT(
									"BoxScaleDesc",
									"A bounding box scale mode similar to Blender's Box Scale. Works with actors and volumes. Drag a face, edge, or corner; Alt scales from the center, V snaps to a vertex."),
								FName(TEXT("ProWorkflowTools.Icon.BoxScale")),
								&UProWorkflowToolsSettings::bEnableBoxScale,
								Commands.ToggleBoxScale))
						]
						+ SVerticalBox::Slot().AutoHeight().Padding(0.0f, 0.0f, 0.0f, SectionGap)
						[
							BuildRow(MakeRow(
								LOCTEXT("LocalScaleLabel", "Per-Actor Origin Scale / Rotate"),
								LOCTEXT(
									"LocalScaleDesc",
									"Hold the modifier with Scale or Rotate to transform each selected actor about its own origin."),
								FName(TEXT("ProWorkflowTools.Icon.LocalOrigin")),
								&UProWorkflowToolsSettings::bEnableLocalScaleModifier,
								nullptr,
								&UProWorkflowToolsSettings::LocalScaleModifierKey))
						]

						//~ Extras
						+ SVerticalBox::Slot().AutoHeight()
						[
							BuildSectionHeader(LOCTEXT("ExtrasHeader", "Extras"))
						]
						+ SVerticalBox::Slot().AutoHeight().Padding(0.0f, 0.0f, 0.0f, RowGap)
						[
							BuildRow(MakeRow(
								LOCTEXT("GroupsLabel", "Super Groups"),
								LOCTEXT("GroupsDesc", "Brings improved UX to groups similar to Level Instance Editing. enter/exit locked groups for isolated editing, smarter Ctrl+G pivots & folders."),
								FName(TEXT("ProWorkflowTools.Icon.SuperGroups")),
								&UProWorkflowToolsSettings::bEnableSuperGroups))
						]
						+ SVerticalBox::Slot().AutoHeight().Padding(0.0f, 0.0f, 0.0f, RowGap)
						[
							BuildRow(MakeRow(
								LOCTEXT("DupLastLabel", "Duplicate with Last Transform"),
								LOCTEXT("DupLastDesc", "Duplicate and reapply the last move/rotate/scale matrix on selection. Similar to Maya's Shift+D Duplicate."),
								FName(TEXT("ProWorkflowTools.Icon.DuplicateWithLast")),
								nullptr,
								Commands.DuplicateWithLastAction))
						]
						+ SVerticalBox::Slot().AutoHeight().Padding(0.0f, 0.0f, 0.0f, RowGap)
						[
							BuildRow(MakeRow(
								LOCTEXT("ShowHiddenLabel", "Show Last Hidden"),
								LOCTEXT("ShowHiddenDesc", "Restore the last Hide set of actors."),
								FName(TEXT("ProWorkflowTools.Icon.ShowLastHidden")),
								nullptr,
								Commands.ShowLastHidden))
						]
						+ SVerticalBox::Slot().AutoHeight().Padding(0.0f, 0.0f, 0.0f, RowGap)
						[
							BuildRow(MakeRow(
								LOCTEXT("DupLabel", "Duplicate In Place"),
								LOCTEXT("DupDesc", "Change's the default Ctrl+D behavior to place copies at the same transform without a grid nudge."),
								FName(TEXT("ProWorkflowTools.Icon.DuplicateInPlace")),
								&UProWorkflowToolsSettings::bDuplicateInPlace))
						]
						+ SVerticalBox::Slot().AutoHeight().Padding(0.0f, 0.0f, 0.0f, 4.0f)
						[
							BuildRow(MakeRow(
								LOCTEXT("ShiftClickLabel", "Allow Re-selecting Actors"),
								LOCTEXT("ShiftClickDesc", "Allow selecting an already selected actor to make it the selection pivot / last selected."),
								FName(TEXT("ProWorkflowTools.Icon.ShiftClick")),
								&UProWorkflowToolsSettings::bShiftClickSetsActiveActor))
						]
					]
				]

				+ SVerticalBox::Slot()
				.AutoHeight()
				.Padding(0.0f, 12.0f, 0.0f, 10.0f)
				[
					SNew(SSeparator)
				]

				+ SVerticalBox::Slot()
				.AutoHeight()
				[
					BuildFooter()
				]
			]
		]
	];
}

TSharedRef<SWidget> SProWorkflowWelcomeSplash::BuildFooter()
{
	// One primary action. Links are secondary; the decal setup link only appears while it is needed.
	return SNew(SHorizontalBox)
		+ SHorizontalBox::Slot()
		.AutoWidth()
		.VAlign(VAlign_Center)
		[
			SNew(SHyperlink)
			.Text(LOCTEXT("DocsLink", "Documentation"))
			.ToolTipText(LOCTEXT("DocsTooltip", "Open plugin documentation."))
			.OnNavigate_Lambda([this]() { OnDocumentationClicked(); })
		]
		+ SHorizontalBox::Slot()
		.AutoWidth()
		.VAlign(VAlign_Center)
		.Padding(14.0f, 0.0f, 0.0f, 0.0f)
		[
			SNew(SHyperlink)
			.Text(LOCTEXT("SettingsLink", "Plugin Settings"))
			.ToolTipText(LOCTEXT("SettingsTooltip", "Open Editor Preferences → Plugins → Pro Workflow Tools."))
			.OnNavigate_Lambda([this]() { OnOpenPluginSettingsClicked(); })
		]
		+ SHorizontalBox::Slot()
		.AutoWidth()
		.VAlign(VAlign_Center)
		.Padding(14.0f, 0.0f, 0.0f, 0.0f)
		[
			SNew(SHyperlink)
			.Text(LOCTEXT("SetupDecalsLink", "Set Up Example Decal Content"))
			.ToolTipText(LOCTEXT(
				"SetupDecalsTooltip",
				"Create an example deferred decal material and a PWF_ExampleDecals collection."))
			.Visibility_Lambda([]()
			{
				return InteractiveDecalPlacement::GetEnabledCollectionEntries().IsEmpty()
					? EVisibility::Visible
					: EVisibility::Collapsed;
			})
			.OnNavigate_Lambda([this]() { OnSetupExampleDecalsClicked(); })
		]
		+ SHorizontalBox::Slot()
		.FillWidth(1.0f)
		[
			SNullWidget::NullWidget
		]
		+ SHorizontalBox::Slot()
		.AutoWidth()
		.VAlign(VAlign_Center)
		.Padding(0.0f, 0.0f, 12.0f, 0.0f)
		[
			SNew(SCheckBox)
			.IsChecked_Lambda([this]()
			{
				return bDontShowAgain ? ECheckBoxState::Checked : ECheckBoxState::Unchecked;
			})
			.OnCheckStateChanged_Lambda([this](ECheckBoxState NewState)
			{
				bDontShowAgain = (NewState == ECheckBoxState::Checked);
				PersistDontShowAgainPreference(bDontShowAgain);
			})
			[
				SNew(STextBlock)
				.Text(LOCTEXT("DontShowAgain", "Don't show on startup"))
			]
		]
		+ SHorizontalBox::Slot()
		.AutoWidth()
		.VAlign(VAlign_Center)
		[
			SNew(SButton)
			.ButtonStyle(&FAppStyle::Get(), "PrimaryButton")
			.TextStyle(&FAppStyle::Get(), "PrimaryButtonText")
			.ContentPadding(FMargin(18.0f, 4.0f))
			.Text(LOCTEXT("CloseButton", "Close"))
			.OnClicked_Lambda([this]()
			{
				OnCloseClicked();
				return FReply::Handled();
			})
		];
}

FText SProWorkflowWelcomeSplash::GetCommandChordText(TSharedPtr<FUICommandInfo> Command)
{
	if (!Command.IsValid())
	{
		return LOCTEXT("ChordUnavailable", "—");
	}

	const TSharedRef<const FInputChord> Chord = Command->GetActiveChord(EMultipleKeyBindingIndex::Primary);
	if (!Chord->IsValidChord())
	{
		return LOCTEXT("ChordUnbound", "Unbound");
	}

	return Chord->GetInputText(/*bLongDisplayName=*/false);
}

TSharedRef<SWidget> SProWorkflowWelcomeSplash::BuildDecalCollectionHint() const
{
	// A hint, not an error: standard warning glyph with subdued text.
	return SNew(SWrapBox)
		.UseAllottedSize(true)
		.Visibility_Lambda([]()
		{
			return InteractiveDecalPlacement::GetEnabledCollectionEntries().IsEmpty()
				? EVisibility::Visible
				: EVisibility::Collapsed;
		})
		+ SWrapBox::Slot()
		.VAlign(VAlign_Center)
		.Padding(0.0f, 0.0f, 6.0f, 0.0f)
		[
			SNew(SImage)
			.Image(FAppStyle::GetBrush("Icons.WarningWithColor"))
		]
		+ SWrapBox::Slot()
		.VAlign(VAlign_Center)
		[
			SNew(STextBlock)
			.ColorAndOpacity(FSlateColor::UseSubduedForeground())
			.Text(LOCTEXT("DecalHintLead", "Needs atleast one  decal collection in "))
		]
		+ SWrapBox::Slot()
		.VAlign(VAlign_Center)
		[
			SNew(SHyperlink)
			.Text(LOCTEXT("DecalHintSettingsLink", "Plugin Settings"))
			.OnNavigate_Lambda([this]() { OnOpenPluginSettingsClicked(); })
		]
		+ SWrapBox::Slot()
		.VAlign(VAlign_Center)
		[
			SNew(STextBlock)
			.ColorAndOpacity(FSlateColor::UseSubduedForeground())
			.Text(LOCTEXT("DecalHintPeriod", "."))
		];
}

void SProWorkflowWelcomeSplash::PersistBoolSetting(bool UProWorkflowToolsSettings::* Member, bool bValue) const
{
	UProWorkflowToolsSettings* Settings = GetMutableDefault<UProWorkflowToolsSettings>();
	if (!Settings || (Settings->*Member) == bValue)
	{
		return;
	}

	Settings->*Member = bValue;
	Settings->NotifyAndPersist();
}

void SProWorkflowWelcomeSplash::PersistDontShowAgainPreference(const bool bDontShowAgain)
{
	UProWorkflowToolsUserSettings* UserSettings = GetMutableDefault<UProWorkflowToolsUserSettings>();
	if (UserSettings->bDontShowWelcomeSplashAgain == bDontShowAgain)
	{
		return;
	}

	UserSettings->bDontShowWelcomeSplashAgain = bDontShowAgain;
	UserSettings->SaveConfig();
}

void SProWorkflowWelcomeSplash::OnCloseClicked()
{
	PersistDontShowAgainPreference();

	if (TSharedPtr<SWindow> Window = ActiveWindow.Pin())
	{
		Window->RequestDestroyWindow();
	}
}

void SProWorkflowWelcomeSplash::OnDocumentationClicked() const
{
	FString DocsURL = TEXT("https://github.com/modsoft/ue-editor-extensions#readme");
	if (const TSharedPtr<IPlugin> Plugin = IPluginManager::Get().FindPlugin(TEXT("ProWorkflowTools")))
	{
		const FString DescriptorDocs = Plugin->GetDescriptor().DocsURL;
		if (!DescriptorDocs.IsEmpty())
		{
			DocsURL = DescriptorDocs;
		}
	}

	FPlatformProcess::LaunchURL(*DocsURL, nullptr, nullptr);
}

void SProWorkflowWelcomeSplash::OnOpenPluginSettingsClicked() const
{
	if (ISettingsModule* SettingsModule = FModuleManager::GetModulePtr<ISettingsModule>("Settings"))
	{
		SettingsModule->ShowViewer(TEXT("Editor"), TEXT("Plugins"), TEXT("ProWorkflowTools"));
	}
}

#if PWT_UE_5_8_OR_LATER
namespace ProWorkflowWelcomeSplashPrivate
{
	TSharedPtr<SWidget> FindWidgetByTag(const TSharedRef<SWidget>& Root, const FName Tag)
	{
		if (const TSharedPtr<FTagMetaData> Meta = Root->GetMetaData<FTagMetaData>(); Meta.IsValid() && Meta->Tag == Tag)
		{
			return Root;
		}

		FChildren* Children = Root->GetChildren();
		for (int32 Index = 0; Index < Children->Num(); ++Index)
		{
			if (TSharedPtr<SWidget> Found = FindWidgetByTag(Children->GetChildAt(Index), Tag))
			{
				return Found;
			}
		}
		return nullptr;
	}
}
#endif

void SProWorkflowWelcomeSplash::OnOpenKeyboardShortcutsClicked(const FName BindingContext) const
{
	ISettingsModule* SettingsModule = FModuleManager::GetModulePtr<ISettingsModule>("Settings");
	if (!SettingsModule)
	{
		return;
	}

#if PWT_UE_5_8_OR_LATER
	// 5.8 gives Keyboard Shortcuts its own tab (InputBindingSettingsViewer) whose rows carry the
	// command's binding context as a search token, so the page can open pre-filtered to this plugin.
	// The search box is the settings editor's SAssetSearchBox, reachable only by its tag.
	SettingsModule->ShowViewer(TEXT("InputBinding"), TEXT("Shortcuts"), TEXT("InputBindings"));

	const TSharedPtr<SDockTab> ShortcutsTab = FGlobalTabmanager::Get()->FindExistingLiveTab(FTabId(TEXT("InputBindingSettings")));
	if (!ShortcutsTab.IsValid())
	{
		return;
	}

	const TSharedPtr<SWidget> SearchWidget =
		ProWorkflowWelcomeSplashPrivate::FindWidgetByTag(ShortcutsTab->GetContent(), TEXT("SettingsEditorSearchBox"));
	if (SearchWidget.IsValid() && SearchWidget->GetType() == TEXT("SAssetSearchBox"))
	{
		// Same text the editor's own "Context" suggestion produces: Context: "<binding context name>".
		StaticCastSharedPtr<SAssetSearchBox>(SearchWidget)->SetText(
			FText::FromString(FString::Printf(TEXT("Context: \"%s\""), *BindingContext.ToString())));
	}
#else
	SettingsModule->ShowViewer(TEXT("Editor"), TEXT("General"), TEXT("InputBindings"));
#endif
}

void SProWorkflowWelcomeSplash::OnSetupExampleDecalsClicked()
{
	const TSharedRef<SWindow> Dialog = SNew(SWindow)
		.Title(LOCTEXT("SetupDecalsDialogTitle", "Set Up Example Decal Content"))
		.ClientSize(FVector2D(480.0f, 280.0f))
		.SupportsMaximize(false)
		.SupportsMinimize(false)
		.SizingRule(ESizingRule::Autosized);

	struct FDialogState
	{
		TSharedPtr<STextBlock> ResultText;
		bool bCreated = false;
	};
	const TSharedRef<FDialogState> State = MakeShared<FDialogState>();

	Dialog->SetContent(
		SNew(SBorder)
		.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
		.Padding(16.0f)
		[
			SNew(SVerticalBox)
			+ SVerticalBox::Slot()
			.AutoHeight()
			.Padding(0.0f, 0.0f, 0.0f, 16.0f)
			[
				SNew(STextBlock)
				.AutoWrapText(true)
				.Text(LOCTEXT(
					"SetupDecalsDialogBody",
					"This will create:\n\n• Deferred decal material /Game/ProWorkflowTools/M_PWF_ExampleDecal\n• Collection PWF_ExampleDecals containing that material (Shared with revision control on, otherwise Local)\n• A Decal Collections entry under Plugin Settings → Decal Placement\n\nExisting assets with those names are reused. Continue?"))
			]
			+ SVerticalBox::Slot()
			.AutoHeight()
			.HAlign(HAlign_Right)
			.Padding(0.0f, 0.0f, 0.0f, 8.0f)
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
				.AutoWidth()
				.Padding(0.0f, 0.0f, 8.0f, 0.0f)
				[
					SNew(SButton)
					.Text(LOCTEXT("SetupDecalsConfirm", "Create"))
					.IsEnabled_Lambda([State]()
					{
						return !State->bCreated;
					})
					.OnClicked_Lambda([State]()
					{
						FText Status;
						const bool bOk = ProWorkflowPlaceholderSetup::EnsureExampleDecalCollection(&Status);
						State->bCreated = bOk;
						if (State->ResultText.IsValid())
						{
							State->ResultText->SetText(Status);
							State->ResultText->SetColorAndOpacity(
								bOk ? FLinearColor(0.45f, 0.9f, 0.5f) : FLinearColor(0.95f, 0.35f, 0.3f));
						}
						return FReply::Handled();
					})
				]
				+ SHorizontalBox::Slot()
				.AutoWidth()
				[
					SNew(SButton)
					.Text_Lambda([State]()
					{
						return State->bCreated
							? LOCTEXT("SetupDecalsClose", "Close")
							: LOCTEXT("SetupDecalsCancel", "Cancel");
					})
					.OnClicked_Lambda([Dialog]()
					{
						Dialog->RequestDestroyWindow();
						return FReply::Handled();
					})
				]
			]
			+ SVerticalBox::Slot()
			.AutoHeight()
			.HAlign(HAlign_Right)
			[
				SAssignNew(State->ResultText, STextBlock)
				.AutoWrapText(true)
				.ColorAndOpacity(FSlateColor::UseSubduedForeground())
			]
		]);

	if (const TSharedPtr<SWindow> Parent = FSlateApplication::Get().FindWidgetWindow(AsShared()))
	{
		FSlateApplication::Get().AddModalWindow(Dialog, Parent);
	}
	else
	{
		FSlateApplication::Get().AddWindow(Dialog, true);
	}
}

void SProWorkflowWelcomeSplash::OpenWindow()
{
	using namespace ProWorkflowWelcomeSplashPrivate;

	if (TSharedPtr<SWindow> Existing = ActiveWindow.Pin())
	{
		Existing->BringToFront();
		return;
	}

	// Geometry is remembered per user; both values are in Slate units, SWindow applies DPI.
	const UProWorkflowToolsUserSettings* UserSettings = GetDefault<UProWorkflowToolsUserSettings>();
	const FVector2D SavedSize = UserSettings->WelcomeSplashWindowSize;
	const FVector2D SavedPosition = UserSettings->WelcomeSplashWindowPosition;
	const bool bUseSavedSize = SavedSize.X >= 520.0 && SavedSize.Y >= 480.0;
	const bool bUseSavedPosition = bUseSavedSize && IsSavedPositionOnScreen(SavedPosition);

	const TSharedRef<SWindow> Window = SNew(SWindow)
		.Title(LOCTEXT("WindowTitle", "Pro Workflow Tools"))
		.ClientSize(bUseSavedSize ? SavedSize : DefaultWindowSize)
		.ScreenPosition(bUseSavedPosition ? SavedPosition : FVector2D::ZeroVector)
		.AutoCenter(bUseSavedPosition ? EAutoCenter::None : EAutoCenter::PreferredWorkArea)
		.MinWidth(520.0f)
		.MinHeight(480.0f)
		.SupportsMaximize(false)
		.SupportsMinimize(false)
		.FocusWhenFirstShown(true)
		.ActivationPolicy(EWindowActivationPolicy::FirstShown)
		.SizingRule(ESizingRule::UserSized);

	const TSharedRef<SProWorkflowWelcomeSplash> Content = SNew(SProWorkflowWelcomeSplash);
	Window->SetContent(Content);
	ActiveWindow = Window;

	// Shared ref keeps content alive through title-bar close (weak pin can expire too early).
	Window->SetOnWindowClosed(FOnWindowClosed::CreateLambda(
		[Content](const TSharedRef<SWindow>& ClosedWindow)
		{
			Content->PersistDontShowAgainPreference();

			const float DPIScale = ClosedWindow->GetDPIScaleFactor();
			UProWorkflowToolsUserSettings* Settings = GetMutableDefault<UProWorkflowToolsUserSettings>();
			Settings->WelcomeSplashWindowSize = FVector2D(ClosedWindow->GetClientSizeInScreen()) / DPIScale;
			Settings->WelcomeSplashWindowPosition = FVector2D(ClosedWindow->GetPositionInScreen()) / DPIScale;
			Settings->SaveConfig();

			ActiveWindow.Reset();
		}));

	// Child of the editor root: stays above the Level Editor, but not over other OS apps
	// (IsTopmostWindow would pin it above Chrome/Discord/etc.).
	if (const TSharedPtr<SWindow> RootWindow = FGlobalTabmanager::Get()->GetRootWindow())
	{
		FSlateApplication::Get().AddWindowAsNativeChild(Window, RootWindow.ToSharedRef(), /*bShowImmediately=*/true);
	}
	else
	{
		FSlateApplication::Get().AddWindow(Window, /*bShowImmediately=*/true);
	}
}

#undef LOCTEXT_NAMESPACE
