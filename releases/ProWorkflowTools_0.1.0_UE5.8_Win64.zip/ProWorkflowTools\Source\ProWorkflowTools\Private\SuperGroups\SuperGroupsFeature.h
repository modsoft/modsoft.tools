// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "UI/ProWorkflowToolHudOverlay.h"

class AActor;
class AGroupActor;
class APlayerController;
class SProWorkflowToolHud;
class UCanvas;
class UProWorkflowToolsSettings;
struct FProWorkflowToolHudModel;

/** Super Groups feature (owned by FProWorkflowToolsModule). */
class FSuperGroupsFeature
{
public:
	void Startup();
	void Shutdown();

private:
	void RegisterMenus();
	void UnregisterMenus();

	/** Bind/unbind group command overrides from the Super Groups enable setting. */
	void ApplyEnabledState();
	void OnSettingsChanged(UObject* Settings, struct FPropertyChangedEvent& PropertyChangedEvent);

	void OverrideGroupCommands();
	void RestoreGroupCommands();

	void OnEnterGroup();
	bool CanEnterSelectedGroup() const;

	void OnExitGroup();
	bool CanExitGroup() const;

	/** Edit bar (Exit Group + editing toggles), shown while inside a group. */
	void OnEditingChanged(bool bEditing);
	FProWorkflowToolHudModel BuildEditHudModel() const;
	TSharedRef<class SWidget> MakeExitGroupButton();

	/** Overrides native Ctrl+G so the created group can adopt the last selected actor's pivot. */
	void OnCreateGroup();
	bool CanCreateGroup() const;

	/** Places the group actor and its contents into a native Outliner folder for a nested layout. */
	void NestGroupInFolder(AGroupActor* Group, AActor* PivotActor) const;

	/** Canvas overlay: draws a pivot marker at each group pivot. */
	void DrawGroupIcons(UCanvas* Canvas, APlayerController* PC);

	/** Empty Actor editor sprite at the group pivot (tinted / sized from settings). */
	void DrawGroupPivotIcon(UCanvas* Canvas, const FVector& WorldLocation, const UProWorkflowToolsSettings& Settings) const;

	/**
	 * Ctrl+D is T3D copy-paste: the engine spawns a new GroupActor and CenterGroupLocation.
	 * Snapshot source pivots on begin and write them back onto the copies.
	 */
	void OnDuplicateActorsBegin();
	void OnDuplicateActorsEnd();

	struct FDuplicatedGroupPivot
	{
		TWeakObjectPtr<AGroupActor> SourceGroup;
		FTransform Pivot;
		int32 DirectMemberCount = 0;
		TArray<FVector> LeafLocations;
	};

	TArray<FDuplicatedGroupPivot> PendingDuplicateGroupPivots;

	FDelegateHandle DebugDrawHandle;
	FDelegateHandle SettingsChangedHandle;
	FDelegateHandle EditingChangedHandle;
	FDelegateHandle DuplicateBeginHandle;
	FDelegateHandle DuplicateEndHandle;

	TProWorkflowToolHudOverlay<SProWorkflowToolHud> EditHud;

	/** True while our Enter/Exit/Ctrl+G mappings are installed on the level editor command list. */
	bool bCommandsOverridden = false;
};

