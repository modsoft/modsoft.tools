// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "InputCoreTypes.h"
#include "UI/ProWorkflowToolHudOverlay.h"
#include "Viewport/WorkflowViewportTool.h"

class FCanvas;
class FEditorViewportClient;
class FSceneView;
class FViewport;
class SProWorkflowToolHud;
class UPrimitiveComponent;
struct FProWorkflowToolHudModel;

/** Click feedback after pick / apply / erase. */
enum class EMaterialClipboardCursorBurst : uint8
{
	None,
	Pick,
	Apply,
	ApplyAll,
	Erase,
	EraseAll
};

/** Hold-key material pick / apply / remove. Driven by FProWorkflowToolsEdMode. */
class FMaterialClipboardTool : public FWorkflowViewportTool
{
public:
	/** A pick/apply/remove press owns the mouse until its release. */
	virtual bool IsExclusive() const override { return bMaterialGestureActive; }

	/** True if consumed. */
	virtual bool InputKey(FEditorViewportClient* ViewportClient, FViewport* Viewport, FKey Key, EInputEvent Event) override;

	/** Hold-key edge and click-feedback clock. Redraws only while feedback plays. */
	virtual EWorkflowToolTickViewport GetTickViewport() const override { return EWorkflowToolTickViewport::Focused; }
	virtual void Tick(FEditorViewportClient* ViewportClient, float DeltaTime) override;

	/** Click feedback, anchored where the click happened, in the viewport that was clicked. */
	virtual void DrawHUD(FEditorViewportClient* ViewportClient, FViewport* Viewport, const FSceneView* View, FCanvas* Canvas) override;

	virtual void Exit() override;

private:
	static void GetHoveredMeshSlot(FViewport* Viewport, UPrimitiveComponent*& OutComponent, int32& OutMaterialIndex);
	static void GatherMaterialTargets(UPrimitiveComponent* HoveredComponent, TArray<UPrimitiveComponent*>& OutTargets);

	void PickMaterialUnderCursor(UPrimitiveComponent* HoveredComponent, int32 HoveredMaterialIndex);
	void ApplyMaterialUnderCursor(UPrimitiveComponent* HoveredComponent, int32 HoveredMaterialIndex, bool bAllSlots);
	void RemoveMaterialUnderCursor(UPrimitiveComponent* HoveredComponent, int32 HoveredMaterialIndex, bool bAllSlots);

	void ShowHudOverlay();
	void HideHudOverlay();
	FProWorkflowToolHudModel BuildHudModel() const;

	void UpdateHoldKeyState(bool bHoldDown);
	void BeginFeedback(EMaterialClipboardCursorBurst Burst, const FText& Label);

	/** Gesture owns the mouse so we consume its release. */
	bool bMaterialGestureActive = false;

	bool bHoldKeyWasDown = false;
	TProWorkflowToolHudOverlay<SProWorkflowToolHud> HudOverlay;

	/** Click anchor, recorded before the action runs. The client pointer is compared, never dereferenced. */
	const FEditorViewportClient* ClickViewportClient = nullptr;
	FIntPoint ClickPixel = FIntPoint::ZeroValue;

	EMaterialClipboardCursorBurst Burst = EMaterialClipboardCursorBurst::None;
	FText BurstLabel;
	/** Set on the first tick after the click, so a hitch from SetMaterial doesn't eat the animation. */
	double BurstStart = -1.0;
};
