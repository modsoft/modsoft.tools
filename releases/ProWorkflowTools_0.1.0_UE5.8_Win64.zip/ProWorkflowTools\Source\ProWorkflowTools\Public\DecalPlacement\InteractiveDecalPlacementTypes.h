// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "CoreMinimal.h"

// FInteractiveDecalCollectionEntry lives in ProWorkflowToolsSettings.h (merged settings page).

/** Runtime placement state machine. */
enum class EInteractiveDecalPlacementState : uint8
{
	Inactive,
	Preview,
	Dragging
};

/** Stable tangent frame captured at anchor time. */
struct FInteractiveDecalTangentFrame
{
	FVector Position = FVector::ZeroVector;
	FVector Normal = FVector::UpVector;
	FVector Tangent = FVector::ForwardVector;
	FVector Bitangent = FVector::RightVector;
};

/** Computed decal transform and size from drag interaction. */
struct FInteractiveDecalPlacementResult
{
	/** Rotation and centre; the footprint is applied as scale from DecalSize when the preview is written. */
	FTransform ActorTransform = FTransform::Identity;
	/** Half-extents in cm (X depth, Y height, Z width), unsigned. */
	FVector DecalSize = FVector(128.0f, 256.0f, 256.0f);
};

