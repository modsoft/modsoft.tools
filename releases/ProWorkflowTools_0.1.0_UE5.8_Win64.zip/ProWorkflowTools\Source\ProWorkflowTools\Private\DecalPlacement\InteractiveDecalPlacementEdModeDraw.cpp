// Copyright © 2026 Trey McNair. All rights reserved.

#include "InteractiveDecalPlacementEdMode.h"
#include "CanvasItem.h"
#include "CanvasTypes.h"
#include "Components/DecalComponent.h"
#include "Editor.h"
#include "EditorModeManager.h"
#include "EditorViewportClient.h"
#include "Engine/Canvas.h"
#include "Engine/DecalActor.h"
#include "InteractiveDecalPlacementMath.h"
#include "ProWorkflowToolsSettings.h"
#include "SceneManagement.h"
#include "SceneView.h"
#include "UI/ViewportCursorLabel.h"
#include "Viewport/ViewportOverlayStyle.h"

#define LOCTEXT_NAMESPACE "InteractiveDecalPlacementEdMode"

namespace InteractiveDecalPlacement::BoundsTicks
{
	using namespace ProWorkflowTools::OverlayStyle;

	/** Fixed world-space L-corner length (cm) — constant across all decal sizes. */
	constexpr float TickLengthCm = 10.0f;
	/** Fixed world-space outset (cm) so ticks sit just outside the decal quad. */
	constexpr float OutsetCm = 2.5f;
	/** Lift (cm) toward the camera along the receive-plane normal to reduce z-fight. */
	constexpr double LiftCm = 1.0;
	/** Preview opacities while hovering / dragging. No idle pulse, so no per-tick Invalidate. */
	constexpr float PreviewTickOpacity = 0.55f;
	constexpr float DragTickOpacity = 0.9f;
	constexpr float PreviewOutlineOpacity = 0.14f;
	constexpr float DragOutlineOpacity = 0.3f;
	constexpr float AnchorDotSizePx = 5.0f;
	/** Scene decal ticks fade out between these view distances. */
	constexpr float SceneFadeStartCm = 3000.0f;
	constexpr float SceneFadeEndCm = 5000.0f;
	/** The stamp flash outline grows outward by this much as it fades. */
	constexpr float StampFlashGrowCm = 6.0f;

	/**
	 * In-plane YZ face corners of the decal receive-plane rectangle, slightly outset and
	 * lifted. Matches UDecalComponent projection: the box is DecalSize in component local
	 * space (Y/Z image plane, X projection) and the component transform supplies the scale,
	 * so decals that carry their footprint in DecalSize, in scale, or both all read correctly.
	 */
	bool GetOutsetInPlaneCorners(
		const ADecalActor* Preview,
		const FSceneView* View,
		FVector& OutC00,
		FVector& OutC10,
		FVector& OutC11,
		FVector& OutC01,
		const float ExtraOutsetCm = 0.0f)
	{
		if (!Preview)
		{
			return false;
		}

		const UDecalComponent* DecalComponent = Preview->GetDecal();
		if (!DecalComponent)
		{
			return false;
		}

		// Local box half-extents; TransformPosition below applies the component scale.
		const double HalfY = FMath::Abs(DecalComponent->DecalSize.Y);
		const double HalfZ = FMath::Abs(DecalComponent->DecalSize.Z);
		if (HalfY < KINDA_SMALL_NUMBER || HalfZ < KINDA_SMALL_NUMBER)
		{
			return false;
		}

		const FTransform CompXform = DecalComponent->GetComponentTransform();
		const FVector Center = CompXform.GetLocation();
		// Unit in-plane axes for a fixed world-space outset (cm), independent of component scale.
		const FVector AxisY = CompXform.GetUnitAxis(EAxis::Y);
		const FVector AxisZ = CompXform.GetUnitAxis(EAxis::Z);

		// True receive-plane corners: local (±Y, ±Z) at X=0, including component scale via TransformPosition.
		const FVector C00 = CompXform.TransformPosition(FVector(0.0, -HalfY, -HalfZ));
		const FVector C10 = CompXform.TransformPosition(FVector(0.0, +HalfY, -HalfZ));
		const FVector C11 = CompXform.TransformPosition(FVector(0.0, +HalfY, +HalfZ));
		const FVector C01 = CompXform.TransformPosition(FVector(0.0, -HalfY, +HalfZ));

		// Component basis: +X projects into the surface. Face the lift toward the view.
		FVector PlaneNormal = -CompXform.GetUnitAxis(EAxis::X);
		if (View && FVector::DotProduct(PlaneNormal, View->ViewLocation - Center) < 0.0)
		{
			PlaneNormal = -PlaneNormal;
		}
		const FVector Lift = PlaneNormal * LiftCm;

		// Expand along in-plane axes from the true corners (not a radial scale from center).
		const double Outset = OutsetCm + ExtraOutsetCm;
		OutC00 = C00 - AxisY * Outset - AxisZ * Outset + Lift;
		OutC10 = C10 + AxisY * Outset - AxisZ * Outset + Lift;
		OutC11 = C11 + AxisY * Outset + AxisZ * Outset + Lift;
		OutC01 = C01 - AxisY * Outset + AxisZ * Outset + Lift;
		return true;
	}

	void DrawDecalCornerTicks(
		FPrimitiveDrawInterface* PDI,
		const FVector& C00, const FVector& C10, const FVector& C11, const FVector& C01,
		const FLinearColor& Color)
	{
		WithXRay(Color, [&](const FLinearColor& PassColor, const uint8 Depth)
		{
			DrawCornerTicks(PDI, C00, C10, C11, C01, PassColor, Depth, TickPx, 1.0f, TickLengthCm);
		});
	}

	/** The depth guide sits well under the corner ticks until the user edits it. */
	constexpr float DepthGuideIdleOpacityScale = 0.45f;
	constexpr float DepthGuideEndMarkerCm = 5.0f;

	/**
	 * Dashed witness through the image bottom-right corner along component X, ± the depth
	 * half-extent: the decal projects that far outward and that far into the surface, and W+Scroll edits
	 * both. Each end carries a small cross; the inward half shows through geometry only via
	 * the x-ray pass. Emphasis 1 is the frame of a depth edit: Highlight colour, full opacity,
	 * heavier line; it settles to the idle look at 0.
	 */
	void DrawPreviewDepthGuide(
		FPrimitiveDrawInterface* PDI,
		const ADecalActor* Preview,
		const FVector& C10,
		const FLinearColor& TickColor,
		const float Emphasis)
	{
		const UDecalComponent* DecalComponent = Preview ? Preview->GetDecal() : nullptr;
		if (!PDI || !DecalComponent)
		{
			return;
		}

		const float DepthCm = FMath::Abs(InteractiveDecalPlacement::GetDecalSignedHalfExtents(*DecalComponent).X);
		if (DepthCm < 1.0f)
		{
			return;
		}

		const FTransform CompXform = DecalComponent->GetComponentTransform();

		// C10 = local (+Y, −Z): image-down / image-right in the placement tangent frame.
		const FVector Center = C10;
		const FVector AlongX = CompXform.GetUnitAxis(EAxis::X) * DepthCm;
		const FVector Ends[] = { Center - AlongX, Center + AlongX };
		const FVector MarkerY = CompXform.GetUnitAxis(EAxis::Y) * DepthGuideEndMarkerCm;
		const FVector MarkerZ = CompXform.GetUnitAxis(EAxis::Z) * DepthGuideEndMarkerCm;
		constexpr float DashCm = 6.0f;
		constexpr float GapCm = 4.0f;

		const FLinearColor Idle = TickColor.CopyWithNewOpacity(TickColor.A * DepthGuideIdleOpacityScale);
		const FLinearColor Color = FMath::Lerp(Idle, Highlight, Emphasis);
		const float LinePx = FMath::Lerp(TickPx, TickPx * 1.8f, Emphasis);

		WithXRay(Color, [&](const FLinearColor& PassColor, const uint8 DepthPriority)
		{
			for (const FVector& End : Ends)
			{
				DrawDashedLine(PDI, Center, End, PassColor, DepthPriority, LinePx, DashCm, GapCm);
				PDI->DrawTranslucentLine(End - MarkerY, End + MarkerY, PassColor, DepthPriority, LinePx, 0.0f, /*bScreenSpace=*/true);
				PDI->DrawTranslucentLine(End - MarkerZ, End + MarkerZ, PassColor, DepthPriority, LinePx, 0.0f, /*bScreenSpace=*/true);
			}
		});
		for (const FVector& End : Ends)
		{
			PDI->DrawPoint(End, Color, FMath::Lerp(3.0f, 5.0f, Emphasis), SDPG_Foreground);
		}
	}

	/** 0 → 1 → 0 progress of a Highlight-and-settle started at StartSeconds (1 = the frame of the edit). */
	float SettleEmphasis(const double StartSeconds)
	{
		if (StartSeconds < 0.0)
		{
			return 0.0f;
		}
		const float Age = static_cast<float>(FPlatformTime::Seconds() - StartSeconds) / SettleSeconds;
		return 1.0f - EaseOutCubic(Age);
	}
}

void FInteractiveDecalPlacementEdMode::DrawSceneDecalTicks(const FSceneView* View, FPrimitiveDrawInterface* PDI) const
{
	if (!PDI || !bShowSceneBoundsTicks)
	{
		return;
	}

	using namespace InteractiveDecalPlacement::BoundsTicks;

	const FVector ViewOrigin = View ? View->ViewLocation : FVector::ZeroVector;
	const FLinearColor BaseColor = Neutral.CopyWithNewOpacity(0.72f);

	for (const TWeakObjectPtr<ADecalActor>& WeakDecal : CachedSceneDecals)
	{
		const ADecalActor* DecalActor = WeakDecal.Get();
		if (!DecalActor || DecalActor == PreviewActor.Get() || DecalActor->IsTemporarilyHiddenInEditor())
		{
			continue;
		}

		const float Distance = View ? static_cast<float>(FVector::Dist(ViewOrigin, DecalActor->GetActorLocation())) : 0.0f;
		const float Fade = 1.0f - FMath::SmoothStep(SceneFadeStartCm, SceneFadeEndCm, Distance);
		if (Fade <= 0.0f)
		{
			continue;
		}

		FVector C00, C10, C11, C01;
		if (!GetOutsetInPlaneCorners(DecalActor, View, C00, C10, C11, C01))
		{
			continue;
		}

		DrawDecalCornerTicks(PDI, C00, C10, C11, C01, BaseColor.CopyWithNewOpacity(BaseColor.A * Fade));
	}
}

void FInteractiveDecalPlacementEdMode::DrawPreviewBounds(const FSceneView* View, FPrimitiveDrawInterface* PDI) const
{
	using namespace InteractiveDecalPlacement::BoundsTicks;

	if (!PreviewActor.IsValid() || PreviewActor->IsTemporarilyHiddenInEditor())
	{
		return;
	}

	FVector C00, C10, C11, C01;
	if (!GetOutsetInPlaneCorners(PreviewActor.Get(), View, C00, C10, C11, C01))
	{
		return;
	}

	const bool bDragging = State == EInteractiveDecalPlacementState::Dragging;
	const FLinearColor TickColor = Accent().CopyWithNewOpacity(bDragging ? DragTickOpacity : PreviewTickOpacity);

	// A ping (flip / opacity / sort / reset / inherit — changes the pose alone doesn't show) lifts the faint
	// outline to Highlight and settles it back.
	const float Ping = SettleEmphasis(PreviewPingStartSeconds);
	const FLinearColor IdleOutline = Accent().CopyWithNewOpacity(bDragging ? DragOutlineOpacity : PreviewOutlineOpacity);
	const FLinearColor OutlineColor = FMath::Lerp(IdleOutline, Highlight, Ping);
	DrawOutline(PDI, C00, C10, C11, C01, OutlineColor, Ping > 0.0f ? SDPG_Foreground : SDPG_World, TickPx * Ping);
	DrawDecalCornerTicks(PDI, C00, C10, C11, C01, TickColor);

	DrawPreviewDepthGuide(PDI, PreviewActor.Get(), C10, TickColor, SettleEmphasis(DepthGuideHighlightStartSeconds));

	const FVector AnchorPoint = (bDragging && bHasAnchor) ? AnchorFrame.Position : HoverAnchorPoint;
	PDI->DrawPoint(AnchorPoint, Accent(), AnchorDotSizePx, SDPG_Foreground);

	// Fit Surface: the surface points the pose was fitted to, so the user sees what is being averaged.
	if (bDragging && IsFitSurfaceEnabled())
	{
		const FLinearColor SampleColor = Accent().CopyWithNewOpacity(0.55f);
		for (const FVector& Sample : FitSurfaceSamples)
		{
			PDI->DrawPoint(Sample, SampleColor, AnchorDotSizePx * 0.6f, SDPG_Foreground);
		}
	}
}

void FInteractiveDecalPlacementEdMode::DrawStampFlash(const FSceneView* View, FPrimitiveDrawInterface* PDI) const
{
	using namespace InteractiveDecalPlacement::BoundsTicks;

	const ADecalActor* Stamped = StampFlashActor.Get();
	if (!Stamped || StampFlashStartSeconds < 0.0)
	{
		return;
	}

	const float T = static_cast<float>(FPlatformTime::Seconds() - StampFlashStartSeconds) / PulseSeconds;
	if (T >= 1.0f)
	{
		return;
	}

	FVector C00, C10, C11, C01;
	if (!GetOutsetInPlaneCorners(Stamped, View, C00, C10, C11, C01, StampFlashGrowCm * EaseOutCubic(T)))
	{
		return;
	}

	const FLinearColor FlashColor = Accent().CopyWithNewOpacity(0.9f * (1.0f - T));
	DrawOutline(PDI, C00, C10, C11, C01, FlashColor, SDPG_Foreground);
}

void FInteractiveDecalPlacementEdMode::DrawPickFlash(const FSceneView* View, FPrimitiveDrawInterface* PDI) const
{
	using namespace InteractiveDecalPlacement::BoundsTicks;

	const ADecalActor* Picked = PickFlashActor.Get();
	const float Emphasis = SettleEmphasis(PickFlashStartSeconds);
	if (!Picked || Emphasis <= 0.0f)
	{
		return;
	}

	FVector C00, C10, C11, C01;
	if (!GetOutsetInPlaneCorners(Picked, View, C00, C10, C11, C01))
	{
		return;
	}

	// The picked decal's own ticks go Highlight and settle; a faint outline reads the full footprint.
	const FLinearColor Color = Highlight.CopyWithNewOpacity(Emphasis);
	DrawDecalCornerTicks(PDI, C00, C10, C11, C01, Color);
	DrawOutline(PDI, C00, C10, C11, C01, Color.CopyWithNewOpacity(Emphasis * 0.35f), SDPG_Foreground);
}

void FInteractiveDecalPlacementEdMode::DrawPickBurst(FCanvas* Canvas) const
{
	using namespace ProWorkflowTools::OverlayStyle;

	if (!Canvas || PickFlashStartSeconds < 0.0)
	{
		return;
	}

	// Same ring as the Material Clipboard pick: collapses onto the click point over one pulse.
	constexpr float StartRadius = 14.0f;
	constexpr float EndRadius = 3.0f;
	constexpr int32 Segments = 48;
	const float T = static_cast<float>(FPlatformTime::Seconds() - PickFlashStartSeconds) / PulseSeconds;
	if (T >= 1.0f)
	{
		return;
	}

	const float Eased = EaseOutCubic(T);
	const float Radius = FMath::Lerp(StartRadius, EndRadius, Eased);
	const FLinearColor Color = Highlight.CopyWithNewOpacity(0.95f * (1.0f - Eased));
	const float DPI = FMath::Max(Canvas->GetDPIScale(), 0.01f);
	const FVector2D Center(PickFlashPixel.X / DPI, PickFlashPixel.Y / DPI);

	FVector2D Prev(Center.X + Radius, Center.Y);
	for (int32 Segment = 1; Segment <= Segments; ++Segment)
	{
		const float Angle = 2.0f * PI * static_cast<float>(Segment) / static_cast<float>(Segments);
		const FVector2D Next(Center.X + FMath::Cos(Angle) * Radius, Center.Y + FMath::Sin(Angle) * Radius);
		FCanvasLineItem Line(Prev, Next);
		Line.SetColor(Color);
		Line.LineThickness = 2.0f;
		Canvas->DrawItem(Line);
		Prev = Next;
	}
}

void FInteractiveDecalPlacementEdMode::DrawModifierGuides(const FSceneView* View, FPrimitiveDrawInterface* PDI) const
{
	using namespace InteractiveDecalPlacement::BoundsTicks;

	if (State != EInteractiveDecalPlacementState::Dragging || !bDragConfirmed || !bHasAnchor)
	{
		return;
	}

	if (bCtrlRotating)
	{
		const FVector DragVector = LastDragPlanePoint - AnchorFrame.Position;
		const double U = FVector::DotProduct(DragVector, AnchorFrame.Tangent);
		const double V = FVector::DotProduct(DragVector, AnchorFrame.Bitangent);
		const float Radius = static_cast<float>(FMath::Sqrt(U * U + V * V));
		if (Radius > 1.0f)
		{
			auto PointAt = [this, Radius](const float AngleRad)
			{
				return AnchorFrame.Position
					+ (AnchorFrame.Tangent * FMath::Cos(AngleRad) + AnchorFrame.Bitangent * FMath::Sin(AngleRad)) * Radius;
			};

			const float StartRad = CtrlStartMouseAngleRad;
			const float SweepRad = DragRotationRad - RotationAtCtrlStartRad;
			const FLinearColor Faint = Accent().CopyWithNewOpacity(0.4f);
			const FLinearColor Bright = Accent().CopyWithNewOpacity(0.7f);

			PDI->DrawTranslucentLine(AnchorFrame.Position, PointAt(StartRad), Faint, SDPG_Foreground);
			PDI->DrawTranslucentLine(AnchorFrame.Position, PointAt(StartRad + SweepRad), Bright, SDPG_Foreground);

			const int32 Segments = FMath::Max(2, FMath::CeilToInt(FMath::Abs(FMath::RadiansToDegrees(SweepRad)) / 3.0f));
			FVector Prev = PointAt(StartRad);
			for (int32 Segment = 1; Segment <= Segments; ++Segment)
			{
				const FVector Next = PointAt(StartRad + SweepRad * static_cast<float>(Segment) / static_cast<float>(Segments));
				PDI->DrawTranslucentLine(Prev, Next, Bright, SDPG_Foreground);
				Prev = Next;
			}
		}
	}

	if (bAspectLocked && PreviewActor.IsValid())
	{
		FVector Corners[4];
		if (GetOutsetInPlaneCorners(PreviewActor.Get(), View, Corners[0], Corners[1], Corners[2], Corners[3]))
		{
			// The locked ratio line is the diagonal from the drag corner (farthest along the drag from the
			// anchor) to its opposite. The drag quadrant picks it, so it never hops with small cursor moves.
			const FVector DragVector = LastDragPlanePoint - AnchorFrame.Position;
			int32 DragCorner = 0;
			for (int32 Index = 1; Index < 4; ++Index)
			{
				if (FVector::DotProduct(Corners[Index] - AnchorFrame.Position, DragVector)
					> FVector::DotProduct(Corners[DragCorner] - AnchorFrame.Position, DragVector))
				{
					DragCorner = Index;
				}
			}
			PDI->DrawTranslucentLine(Corners[(DragCorner + 2) % 4], Corners[DragCorner], Accent().CopyWithNewOpacity(0.35f), SDPG_Foreground);
		}
	}
}

void FInteractiveDecalPlacementEdMode::DrawMoveGlyph(const FSceneView* View, FCanvas* Canvas) const
{
	const UDecalComponent* DecalComponent = PreviewActor.IsValid() ? PreviewActor->GetDecal() : nullptr;
	FVector2D Pixel;
	if (!View || !Canvas || !DecalComponent || !View->WorldToPixel(DecalComponent->GetComponentLocation(), Pixel))
	{
		return;
	}

	constexpr float Gap = 4.0f;
	constexpr float Arm = 14.0f;
	constexpr float Head = 4.0f;
	const float DPI = FMath::Max(Canvas->GetDPIScale(), 0.01f);
	const FVector2D Center = Pixel / DPI;
	const FLinearColor Color = ProWorkflowTools::OverlayStyle::Accent().CopyWithNewOpacity(0.9f);

	auto DrawLine = [Canvas, &Color](const FVector2D& From, const FVector2D& To)
	{
		FCanvasLineItem Line(From, To);
		Line.SetColor(Color);
		Line.LineThickness = 1.5f;
		Canvas->DrawItem(Line);
	};

	const FVector2D Directions[] = { {1.0, 0.0}, {-1.0, 0.0}, {0.0, 1.0}, {0.0, -1.0} };
	for (const FVector2D& Direction : Directions)
	{
		const FVector2D Side(-Direction.Y, Direction.X);
		const FVector2D Tip = Center + Direction * Arm;
		DrawLine(Center + Direction * Gap, Tip);
		DrawLine(Tip, Tip - Direction * Head + Side * Head);
		DrawLine(Tip, Tip - Direction * Head - Side * Head);
	}
}

void FInteractiveDecalPlacementEdMode::DrawHUD(FEditorViewportClient* ViewportClient, FViewport* Viewport, const FSceneView* View, FCanvas* Canvas)
{
	FEdMode::DrawHUD(ViewportClient, Viewport, View, Canvas);

	using namespace ProWorkflowTools;
	using ProWorkflowTools::OverlayStyle::Accent;

	if (!Viewport || !Canvas || !Owner || ViewportClient != Owner->GetHoveredViewportClient() || IsPointerOverHud())
	{
		return;
	}

	const FIntPoint MousePixel(Viewport->GetMouseX(), Viewport->GetMouseY());
	const bool bDragging = State == EInteractiveDecalPlacementState::Dragging && bDragConfirmed;

	if (bDragging && bSpacePanning)
	{
		DrawMoveGlyph(View, Canvas);
	}

	DrawPickBurst(Canvas);

	// The live rotation readout takes the label slot while Ctrl rotates.
	if (bDragging && bCtrlRotating)
	{
		const float SweepDegrees = FMath::RadiansToDegrees(DragRotationRad - RotationAtCtrlStartRad);
		const CursorLabel::FLine Line{ FText::FromString(FString::Printf(TEXT("%+.1f°"), SweepDegrees)), Accent() };
		CursorLabel::Draw(Canvas, MousePixel, MakeArrayView(&Line, 1), 1.0f);
		return;
	}

	FeedbackLabel.Draw(Canvas, MousePixel);
}

void FInteractiveDecalPlacementEdMode::Render(const FSceneView* View, FViewport* Viewport, FPrimitiveDrawInterface* PDI)
{
	FEdMode::Render(View, Viewport, PDI);

	if (!PDI
		|| (State != EInteractiveDecalPlacementState::Preview && State != EInteractiveDecalPlacementState::Dragging))
	{
		return;
	}

	DrawSceneDecalTicks(View, PDI);
	DrawStampFlash(View, PDI);
	DrawPickFlash(View, PDI);
	DrawPreviewBounds(View, PDI);
	DrawModifierGuides(View, PDI);
}

#undef LOCTEXT_NAMESPACE
