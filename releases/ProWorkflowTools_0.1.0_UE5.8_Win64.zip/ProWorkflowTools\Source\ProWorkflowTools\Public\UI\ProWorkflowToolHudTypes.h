// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "Internationalization/Text.h"
#include "Templates/Function.h"

class SWidget;

/** One keycap chip: key label + action label. */
struct FProWorkflowToolHudKeycap
{
	FText Key;
	FText Action;
	/** Start a new hotkey row at this chip. */
	bool bNewRow = false;
};

/** Compact info-strip item: value, accent name, or checkbox. */
struct FProWorkflowHudField
{
	FName Id;
	FText Label;
	FText Value;
	/** Fixed slot width for the value (px). 0 = auto. */
	float WidthPx = 0.0f;
	bool bSeparatorBefore = false;
	bool bAccent = false;
	bool bMuted = false;
	bool bCheckbox = false;
	bool bChecked = false;
	/** True = left-align in the cell (names). False = center (numeric / mode values). */
	bool bAlignLeft = false;
	/** Collapsed when the info strip is wider than the viewport. */
	bool bLowPriority = false;
	TFunction<void(bool)> OnCheckChanged;
	/** Set = the value is a dropdown; called when the menu opens. */
	TFunction<TSharedRef<SWidget>()> OnGetMenu;
	/** Set = the value is click-to-edit; receives the typed text on Enter or focus loss. */
	TFunction<void(const FString&)> OnCommitText;
};

inline FProWorkflowHudField MakeHudTextField(
	const FName Id,
	FText Label,
	FText Value,
	const float WidthPx = 0.0f,
	const bool bAccent = false,
	const bool bMuted = false,
	const bool bSeparatorBefore = false,
	const bool bAlignLeft = false)
{
	FProWorkflowHudField Field;
	Field.Id = Id;
	Field.Label = MoveTemp(Label);
	Field.Value = MoveTemp(Value);
	Field.WidthPx = WidthPx;
	Field.bAccent = bAccent;
	Field.bMuted = bMuted;
	Field.bSeparatorBefore = bSeparatorBefore;
	Field.bAlignLeft = bAlignLeft;
	return Field;
}

inline FProWorkflowHudField MakeHudCheckField(
	const FName Id,
	FText Label,
	const bool bChecked,
	TFunction<void(bool)> OnCheckChanged,
	const bool bSeparatorBefore = false)
{
	FProWorkflowHudField Field;
	Field.Id = Id;
	Field.Label = MoveTemp(Label);
	Field.bCheckbox = true;
	Field.bChecked = bChecked;
	Field.OnCheckChanged = MoveTemp(OnCheckChanged);
	Field.bSeparatorBefore = bSeparatorBefore;
	return Field;
}

inline void AddHudKeycap(TArray<FProWorkflowToolHudKeycap>& Out, FText Key, FText Action, const bool bNewRow = false)
{
	FProWorkflowToolHudKeycap Cap;
	Cap.Key = MoveTemp(Key);
	Cap.Action = MoveTemp(Action);
	Cap.bNewRow = bNewRow;
	Out.Add(MoveTemp(Cap));
}

/**
 * Data-driven model for SProWorkflowToolHud. The HUD pulls it from the tool once per Slate tick;
 * every slot reads that cached copy.
 */
struct FProWorkflowToolHudModel
{
	FText Title;
	TArray<FProWorkflowHudField> Fields;
	TArray<FProWorkflowToolHudKeycap> Keycaps;
};
