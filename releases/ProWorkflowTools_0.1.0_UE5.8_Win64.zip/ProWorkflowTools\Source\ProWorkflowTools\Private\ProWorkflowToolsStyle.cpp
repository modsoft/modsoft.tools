// Copyright © 2026 Trey McNair. All rights reserved.

#include "ProWorkflowToolsStyle.h"

#include "Brushes/SlateImageBrush.h"
#include "Interfaces/IPluginManager.h"
#include "Styling/SlateStyleRegistry.h"

TSharedPtr<FSlateStyleSet> FProWorkflowToolsStyle::StyleSet;

FName FProWorkflowToolsStyle::GetStyleSetName()
{
	static FName StyleName(TEXT("ProWorkflowToolsStyle"));
	return StyleName;
}

const ISlateStyle& FProWorkflowToolsStyle::Get()
{
	return *StyleSet;
}

void FProWorkflowToolsStyle::Initialize()
{
	if (StyleSet.IsValid())
	{
		return;
	}

	StyleSet = MakeShared<FSlateStyleSet>(GetStyleSetName());

	FString ResourcesDir;
	if (const TSharedPtr<IPlugin> Plugin = IPluginManager::Get().FindPlugin(TEXT("ProWorkflowTools")))
	{
		ResourcesDir = Plugin->GetBaseDir() / TEXT("Resources");
	}
	StyleSet->SetContentRoot(ResourcesDir);

	const FVector2D Icon20(20.0f, 20.0f);
	const FVector2D Icon40(40.0f, 40.0f);

	auto RegisterSizedIcon = [](FSlateStyleSet& Set, const TCHAR* StyleBase, const TCHAR* FileBase, const FVector2D& Size20, const FVector2D& Size40)
	{
		Set.Set(
			*(FString(StyleBase) + TEXT(".Large")),
			new FSlateImageBrush(Set.RootToContentDir(FileBase, TEXT("_40.png")), Size40));
		Set.Set(
			StyleBase,
			new FSlateImageBrush(Set.RootToContentDir(FileBase, TEXT("_20.png")), Size20));
	};

	// Toolbar
	StyleSet->Set(
		"ProWorkflowTools.ToolbarIcon",
		new FSlateImageBrush(StyleSet->RootToContentDir(TEXT("Icon40"), TEXT(".png")), Icon40));
	StyleSet->Set(
		"ProWorkflowTools.ToolbarIcon.Small",
		new FSlateImageBrush(StyleSet->RootToContentDir(TEXT("Icon20"), TEXT(".png")), Icon20));

	// Feature icons (masters are Icon_*_20 / _40 next to 128px sources)
	RegisterSizedIcon(*StyleSet, TEXT("ProWorkflowTools.Icon.DCC"), TEXT("Icon_DCC"), Icon20, Icon40);
	RegisterSizedIcon(*StyleSet, TEXT("ProWorkflowTools.Icon.MaterialClipboard"), TEXT("Icon_MatClipBoard"), Icon20, Icon40);
	RegisterSizedIcon(*StyleSet, TEXT("ProWorkflowTools.Icon.GridPaint"), TEXT("Icon_ActorTile"), Icon20, Icon40);
	RegisterSizedIcon(*StyleSet, TEXT("ProWorkflowTools.Icon.DecalPlacement"), TEXT("Icon_IntDecal"), Icon20, Icon40);
	RegisterSizedIcon(*StyleSet, TEXT("ProWorkflowTools.Icon.BoxScale"), TEXT("Icon_BBoxS"), Icon20, Icon40);
	RegisterSizedIcon(*StyleSet, TEXT("ProWorkflowTools.Icon.LocalOrigin"), TEXT("Icon_LocalOrigin"), Icon20, Icon40);
	RegisterSizedIcon(*StyleSet, TEXT("ProWorkflowTools.Icon.SuperGroups"), TEXT("Icon_SuperGroups"), Icon20, Icon40);
	RegisterSizedIcon(*StyleSet, TEXT("ProWorkflowTools.Icon.DuplicateWithLast"), TEXT("Icon_DupLast"), Icon20, Icon40);
	RegisterSizedIcon(*StyleSet, TEXT("ProWorkflowTools.Icon.ShowLastHidden"), TEXT("Icon_ShowHidden"), Icon20, Icon40);
	RegisterSizedIcon(*StyleSet, TEXT("ProWorkflowTools.Icon.DuplicateInPlace"), TEXT("Icon_DupInPlace"), Icon20, Icon40);
	RegisterSizedIcon(*StyleSet, TEXT("ProWorkflowTools.Icon.ShiftClick"), TEXT("Icon_ShiftClick"), Icon20, Icon40);

	// Viewport toolbar: white 16px SVG, tinted by the toolbar like the engine's transform icons.
	StyleSet->Set(
		"ProWorkflowTools.Viewport.BoxScale",
		new FSlateVectorImageBrush(StyleSet->RootToContentDir(TEXT("Icon_BoxScale_16"), TEXT(".svg")), FVector2D(16.0f, 16.0f)));

	FSlateStyleRegistry::RegisterSlateStyle(*StyleSet);
}

void FProWorkflowToolsStyle::Shutdown()
{
	if (!StyleSet.IsValid())
	{
		return;
	}

	FSlateStyleRegistry::UnRegisterSlateStyle(*StyleSet);
	ensure(StyleSet.IsUnique());
	StyleSet.Reset();
}
