// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "Framework/Commands/UICommandInfo.h"
#include "ProWorkflowToolsSettings.h"
#include "Styling/SlateBrush.h"
#include "Styling/SlateTypes.h"
#include "Widgets/SCompoundWidget.h"

class SWindow;

/** Welcome splash: feature toggles, current shortcut chips, links to settings. */
class SProWorkflowWelcomeSplash : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SProWorkflowWelcomeSplash) {}
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs);

	/** Open or focus the splash. */
	static void OpenWindow();

private:
	/** One feature row: icon column, title, optional hotkey chip, optional On/Off toggle, description. */
	struct FRowSpec
	{
		FText Label;
		FText Description;
		FName IconBrushName;
		TFunction<bool()> Getter;
		TFunction<void(bool)> Setter;
		TFunction<FText()> HotkeyText;
		TFunction<void()> OnHotkeyClicked;
		TSharedPtr<SWidget> Footnote;
	};

	TSharedRef<SWidget> BuildSectionHeader(const FText& Title) const;
	TSharedRef<SWidget> BuildRow(const FRowSpec& Spec) const;
	TSharedRef<SWidget> BuildHotkeyChip(TFunction<FText()> HotkeyText, TFunction<void()> OnClicked) const;
	TSharedRef<SWidget> BuildDecalCollectionHint() const;
	TSharedRef<SWidget> BuildBannerWidget();
	TSharedRef<SWidget> BuildFooter();
	void LoadBannerBrush();

	/**
	 * Row spec from settings members. ToggleMember gives the On/Off switch; Command or
	 * HoldKeyMember gives the hotkey chip (chip click opens the place that key is edited).
	 */
	FRowSpec MakeRow(
		const FText& Label,
		const FText& Description,
		FName Icon = NAME_None,
		bool UProWorkflowToolsSettings::* ToggleMember = nullptr,
		TSharedPtr<FUICommandInfo> Command = nullptr,
		FKey UProWorkflowToolsSettings::* HoldKeyMember = nullptr) const;

	void PersistBoolSetting(bool UProWorkflowToolsSettings::* Member, bool bValue) const;

	/** Writes bDontShowWelcomeSplashAgain to the per-user config. */
	static void PersistDontShowAgainPreference(bool bDontShowAgain);
	void PersistDontShowAgainPreference() const { PersistDontShowAgainPreference(bDontShowAgain); }

	static FText GetCommandChordText(TSharedPtr<FUICommandInfo> Command);

	void OnCloseClicked();
	void OnDocumentationClicked() const;
	void OnOpenPluginSettingsClicked() const;
	/** Opens Keyboard Shortcuts; on 5.8 pre-filtered to the command's binding context. */
	void OnOpenKeyboardShortcutsClicked(FName BindingContext) const;
	void OnSetupExampleDecalsClicked();

	/** Mirrors UProWorkflowToolsUserSettings::bDontShowWelcomeSplashAgain while the dialog is open. */
	bool bDontShowAgain = false;

	/** Banner PNG brush (must outlive the image widget). */
	TSharedPtr<FSlateBrush> BannerBrush;
	FText VersionText;

	/** Hotkey chip look: recessed, outlined, clickable. Owned here so it outlives the buttons. */
	FButtonStyle ChipButtonStyle;

	static TWeakPtr<SWindow> ActiveWindow;
};
