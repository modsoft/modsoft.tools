// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "Framework/Commands/Commands.h"

/** Super Groups hotkeys (Editor Preferences → Keyboard Shortcuts). */
class FSuperGroupsCommands : public TCommands<FSuperGroupsCommands>
{
public:
	FSuperGroupsCommands();

	virtual void RegisterCommands() override;

	TSharedPtr<FUICommandInfo> EnterGroup;
	TSharedPtr<FUICommandInfo> ExitGroup;
};

