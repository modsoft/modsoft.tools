// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "CoreMinimal.h"

namespace ProWorkflowPlaceholderSetup
{
	/** Creates the example decal material, collection PWF_ExampleDecals, and wires settings. */
	bool EnsureExampleDecalCollection(FText* OutStatusMessage = nullptr);
}
