// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "UObject/WeakObjectPtr.h"

class AActor;

/** Frozen grid definition captured from the source actor when Actor Grid Paint is entered. */
struct FGridPaintContext
{
	TWeakObjectPtr<AActor> SourceActor;
	/** Source->GetActorLocation() at mode start; grid cell (0,0,0) pivot. */
	FVector PivotWorld = FVector::ZeroVector;
	/** Source->GetActorQuat(); grid axes. */
	FQuat GridRotation = FQuat::Identity;
	/** Local bounds size x actor/component scale, per axis (min-epsilon guarded). Placement step. */
	FVector CellSize = FVector::OneVector;
	/**
	 * Source mesh/decal AABB in grid-local space (pivot-relative, grid-rotation aligned, scale applied).
	 * Overlay cell quads use Min/Max on the paint-plane axes so footprints hug the asset outline
	 * (corner pivots) instead of a CellSize box centered on the pivot.
	 */
	FBox MeshBoundsGridLocal = FBox(ForceInit);
	/**
	 * True when the paint source is a decal (ADecalActor / UDecalComponent).
	 * Plane is locked to the decal receive plane (normal = local X / projection axis); mesh sources
	 * still freestyle PickPlaneAxis from the camera (with thin-axis preference).
	 */
	bool bIsDecalSource = false;
	/** Thin-axis rule: an axis is thin below max(ThinAxisFloorCm, ThinAxisRelativeRatio × longest CellSize axis). */
	float ThinAxisFloorCm = 12.5f;
	float ThinAxisRelativeRatio = 0.12f;
};

namespace GridPaintMath
{
	/** World position -> fractional grid coordinates (pivot units; CellSize-normalized). */
	FVector WorldToGrid(const FGridPaintContext& C, const FVector& W);
	/** Integer grid cell -> world position of that cell's pivot. */
	FVector GridToWorld(const FGridPaintContext& C, const FIntVector& Cell);
	/**
	 * Maps fractional WorldToGrid coords to an integer cell using the same mesh-footprint tiling as
	 * the overlay (floor of offset-by-bounds-min), not pivot-centered RoundToInt Voronoi cells.
	 * Plane-axis coordinate is forced to 0; thin non-plane axes are clamped to 0 (no stacking).
	 */
	FIntVector GridCoordsToFootprintCell(const FGridPaintContext& C, const FVector& GridCoords, int32 PlaneAxis);
	/**
	 * Returns 0/1/2: paint-plane normal. Prefers a thin CellSize axis when one exists (floors/slabs)
	 * so strokes stay on the thick in-plane axes; otherwise the axis most aligned with ViewDir.
	 * PreferAxis (when valid) applies hysteresis so near-45° views don't chatter; pass INDEX_NONE
	 * for an immediate best pick (mode enter). Decals do not use this — plane locked to local X.
	 */
	int32 PickPlaneAxis(const FGridPaintContext& C, const FVector& ViewDir, int32 PreferAxis = INDEX_NONE);
	/** True when CellSize[Axis] is under the context's thin-axis rule. */
	bool IsThinCellAxis(const FGridPaintContext& C, int32 Axis);
	/** Bresenham over the integer line From->To; visits each cell once, excluding From, including To. */
	void WalkCells2D(FIntPoint From, FIntPoint To, TFunctionRef<void(FIntPoint)> Visit);
	/** Anchor and Target share the plane layer and differ along exactly one in-plane axis. */
	bool IsExactAxisAlignedLine(const FIntVector& Anchor, const FIntVector& Target, int32 PlaneAxis);
}
