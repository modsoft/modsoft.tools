// Copyright © 2026 Trey McNair. All rights reserved.

using UnrealBuildTool;

public class ProWorkflowTools : ModuleRules
{
	public ProWorkflowTools(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

		PublicDependencyModuleNames.AddRange(
			new string[]
			{
				"Core",
				"CoreUObject",
				"Engine",
				"InputCore", // public: FKey UPROPERTIES in ProWorkflowToolsSettings.h
				"Slate",     // public: SProWorkflowToolHud
				"SlateCore",
				"DeveloperSettings"
			}
		);

		PrivateDependencyModuleNames.AddRange(
			new string[]
			{
				// FBuiltinEditorModes / FEditorModeInfo link symbols (not IAssetViewport — that is UnrealEd).
				"EditorFramework",
				"EditorSubsystem",
				"UnrealEd",
				"LevelEditor",
				"TypedElementFramework",
				"TypedElementRuntime",
				"EditorInteractiveToolsFramework",
				"InteractiveToolsFramework",
				"Settings",
				"ToolMenus",
				"RenderCore", // FRenderResource behind the dynamic coloured material proxies (Grid Paint, Box Scale shaded volumes)
				"ContentBrowser",
				"CollectionManager",
				"SourceControl",   // Shared collections only save under revision control; the example setup asks before choosing a scope
				"AssetRegistry",
				"AssetTools",
				"MaterialEditor",
				"Projects",
				"PropertyEditor",
				"ImageWrapper",    // Welcome splash reads the banner PNG's pixel size so the brush matches the asset
				"ApplicationCore", // Welcome splash validates its saved window position against connected monitors
				"EditorWidgets"    // SAssetSearchBox: the 5.8 Keyboard Shortcuts search box the welcome splash pre-fills
			}
		);
	}
}
