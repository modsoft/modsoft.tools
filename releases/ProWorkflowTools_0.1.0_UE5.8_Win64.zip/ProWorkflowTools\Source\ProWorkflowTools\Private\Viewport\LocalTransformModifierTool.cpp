// Copyright © 2026 Trey McNair. All rights reserved.

#include "Viewport/LocalTransformModifierTool.h"

#include "ProWorkflowToolsEngineAdapter.h"
#include "ProWorkflowToolsSettings.h"
#include "Viewport/WorkflowViewportMath.h"

#include "Editor.h"
#include "Editor/GroupActor.h"
#include "EditorModeManager.h"
#include "EditorViewportClient.h"
#include "Engine/Selection.h"
#include "GameFramework/Actor.h"
#include "PrimitiveDrawingUtils.h"
#include "SceneView.h"
#include "SuperGroups/SuperGroupSubsystem.h"
#include "Tools/EdModeInteractiveToolsContext.h"
#include "UnrealWidget.h"

namespace LocalTransformModifierTool::Private
{
	bool IsModifierDown(const FEditorViewportClient* ViewportClient, const FViewport* Viewport, const FKey& Key)
	{
		if (Key == EKeys::LeftShift || Key == EKeys::RightShift)
		{
			return ViewportClient && ViewportClient->IsShiftPressed();
		}
		if (Key == EKeys::LeftAlt || Key == EKeys::RightAlt)
		{
			return ViewportClient && ViewportClient->IsAltPressed();
		}
		if (Key == EKeys::LeftControl || Key == EKeys::RightControl)
		{
			return ViewportClient && ViewportClient->IsCtrlPressed();
		}
		return Viewport && Viewport->KeyState(Key);
	}

	bool IsModifierKey(const FKey& Key, const FKey& Configured)
	{
		if (Configured == EKeys::LeftShift || Configured == EKeys::RightShift)
		{
			return Key == EKeys::LeftShift || Key == EKeys::RightShift;
		}
		if (Configured == EKeys::LeftAlt || Configured == EKeys::RightAlt)
		{
			return Key == EKeys::LeftAlt || Key == EKeys::RightAlt;
		}
		if (Configured == EKeys::LeftControl || Configured == EKeys::RightControl)
		{
			return Key == EKeys::LeftControl || Key == EKeys::RightControl;
		}
		return Key == Configured;
	}

	bool IsScaleOrRotate(const FEditorModeTools* ModeTools)
	{
		const UE::Widget::EWidgetMode WidgetMode = ModeTools ? ModeTools->GetWidgetMode() : UE::Widget::WM_None;
		return WidgetMode == UE::Widget::WM_Scale || WidgetMode == UE::Widget::WM_Rotate;
	}

	const UProWorkflowToolsSettings* GetEnabledSettings()
	{
		const UProWorkflowToolsSettings* Settings = GetDefault<UProWorkflowToolsSettings>();
		return Settings && Settings->bEnableLocalScaleModifier ? Settings : nullptr;
	}

	FQuat GetOriginHintRotation(const FEditorViewportClient* ViewportClient, const AActor* Actor)
	{
		if (!ViewportClient || !Actor)
		{
			return FQuat::Identity;
		}

		switch (ViewportClient->GetWidgetCoordSystemSpace())
		{
		case COORD_Local:
			return Actor->GetActorQuat();
		case COORD_Parent:
			if (const AActor* Parent = Actor->GetAttachParentActor())
			{
				return Parent->GetActorQuat();
			}
			return FQuat::Identity;
		default:
			return ViewportClient->GetWidgetCoordSystem().ToQuat();
		}
	}

	/**
	 * Locked groups move as one about the group pivot. While Super Groups is editing, members
	 * are independent and keep per-actor hints.
	 */
	bool CollectLockedGroupPivotActors(TArray<AActor*, TInlineAllocator<8>>& OutPivots)
	{
		OutPivots.Reset();
		if (!GEditor)
		{
			return false;
		}

		if (const UWorld* World = GEditor->GetEditorWorldContext().World())
		{
			if (const USuperGroupSubsystem* SuperGroups = World->GetSubsystem<USuperGroupSubsystem>())
			{
				if (SuperGroups->IsEditing())
				{
					return false;
				}
			}
		}

		TSet<AGroupActor*> Groups;
		for (FSelectionIterator It(GEditor->GetSelectedActorIterator()); It; ++It)
		{
			AActor* Actor = Cast<AActor>(*It);
			if (!Actor)
			{
				continue;
			}

			if (AGroupActor* AsGroup = Cast<AGroupActor>(Actor))
			{
				if (!AsGroup->IsLocked())
				{
					return false;
				}
				Groups.Add(AsGroup);
				continue;
			}

			AGroupActor* Root = AGroupActor::GetRootForActor(Actor, /*bMustBeLocked=*/true);
			if (!Root)
			{
				return false;
			}
			Groups.Add(Root);
		}

		if (Groups.IsEmpty())
		{
			return false;
		}

		for (AGroupActor* Group : Groups)
		{
			OutPivots.Add(Group);
		}
		return true;
	}

	void GatherGroupTransformActors(AGroupActor& Group, TArray<AActor*>& OutActors)
	{
		OutActors.Reset();
		Group.GetAllChildren(OutActors, /*bRecurse=*/true);
		OutActors.AddUnique(&Group);
	}

	FQuat GetGroupWorldRotationDelta(const FEditorViewportClient* ViewportClient, const AGroupActor& Group, const FRotator& Rot)
	{
		if (ViewportClient && ViewportClient->GetWidgetCoordSystemSpace() == COORD_Local)
		{
			FVector WorldAxis = FVector::XAxisVector;
			float AngleRadians = 0.0f;
			Rot.Quaternion().ToAxisAndAngle(WorldAxis, AngleRadians);
			if (FMath::IsNearlyZero(AngleRadians))
			{
				return FQuat::Identity;
			}

			const FQuat WidgetQ = ViewportClient->GetWidgetCoordSystem().ToQuat();
			const FVector LocalAxis = WidgetQ.UnrotateVector(WorldAxis).GetSafeNormal();
			const FVector GroupAxis = Group.GetActorQuat().RotateVector(LocalAxis);
			return FQuat(GroupAxis, AngleRadians);
		}

		return Rot.Quaternion();
	}

	void ApplyScaleAboutGroupPivot(AActor& Actor, const FVector& Pivot, const FQuat& GroupQ, const FVector& AdjustedScale)
	{
		const FVector RelLocal = GroupQ.UnrotateVector(Actor.GetActorLocation() - Pivot);
		const FVector ScaledRel = RelLocal * (FVector::OneVector + AdjustedScale);
		Actor.SetActorLocation(Pivot + GroupQ.RotateVector(ScaledRel), false);

		FTransform World = Actor.GetActorTransform();
		World.SetScale3D(World.GetScale3D() + AdjustedScale);
		Actor.SetActorTransform(World);
	}

	void ApplyRotationAboutGroupPivot(AActor& Actor, const FVector& Pivot, const FQuat& WorldRot)
	{
		if (WorldRot.Equals(FQuat::Identity, UE_KINDA_SMALL_NUMBER))
		{
			return;
		}

		Actor.SetActorLocation(Pivot + WorldRot.RotateVector(Actor.GetActorLocation() - Pivot), false);
		Actor.SetActorRotation(WorldRot * Actor.GetActorQuat());
	}

	void DrawOriginHints(
		const FSceneView* View,
		FEditorViewportClient* ViewportClient,
		FPrimitiveDrawInterface* PDI,
		const EAxisList::Type Axis)
	{
		if (!View || !PDI || !GEditor)
		{
			return;
		}

		const bool bDrawX = (Axis & EAxisList::X) != 0 || Axis == EAxisList::Screen;
		const bool bDrawY = (Axis & EAxisList::Y) != 0 || Axis == EAxisList::Screen;
		const bool bDrawZ = (Axis & EAxisList::Z) != 0 || Axis == EAxisList::Screen;
		if (!bDrawX && !bDrawY && !bDrawZ)
		{
			return;
		}

		const FVector WidgetLocation = ViewportClient->GetWidgetLocation();

		// Hints sit on top of selection outlines, so they get a dark halo and grow heavier while the
		// drag is live (the axis shown is the one being scaled / rotated).
		constexpr float HintSizePx = 44.0f;
		constexpr float HandlePixelsPerWidgetUnit = 4.0f;
		constexpr float HaloPx = 1.5f;
		const bool bDragging = ViewportClient->IsTracking();
		const float LineThickness = bDragging ? 2.5f : 1.5f;
		const FLinearColor Halo(0.0f, 0.0f, 0.0f, 0.55f);
		const FLinearColor ColorX(0.80f, 0.08f, 0.04f, 1.0f);
		const FLinearColor ColorY(0.26f, 0.62f, 0.05f, 1.0f);
		const FLinearColor ColorZ(0.12f, 0.36f, 1.0f, 1.0f);
		const FEditorModeTools* ModeTools = ViewportClient->GetModeTools();
		const bool bRotate = ModeTools && ModeTools->GetWidgetMode() == UE::Widget::WM_Rotate;

		TArray<AActor*, TInlineAllocator<8>> HintActors;
		if (!CollectLockedGroupPivotActors(HintActors))
		{
			for (FSelectionIterator It(GEditor->GetSelectedActorIterator()); It; ++It)
			{
				AActor* Actor = Cast<AActor>(*It);
				if (Actor && !Actor->IsLockLocation())
				{
					HintActors.Add(Actor);
				}
			}
		}

		for (AActor* Actor : HintActors)
		{
			if (!Actor)
			{
				continue;
			}

			const FVector Origin = Actor->GetActorLocation();
			if (Origin.Equals(WidgetLocation, 1.0))
			{
				continue;
			}
			const FQuat Rotation = GetOriginHintRotation(ViewportClient, Actor);
			const float HalfWorld = ProWorkflowTools::GetScreenSpaceUniformScale(View, Origin) * (HintSizePx / HandlePixelsPerWidgetUnit);
			const FVector AxisX = Rotation.GetAxisX();
			const FVector AxisY = Rotation.GetAxisY();
			const FVector AxisZ = Rotation.GetAxisZ();

			if (bRotate)
			{
				auto DrawRing = [&](const FVector& BasisA, const FVector& BasisB, const FLinearColor& Color)
				{
					DrawCircle(PDI, Origin, BasisA, BasisB, Halo, HalfWorld, 32, SDPG_Foreground, LineThickness + HaloPx, 0.0f, true);
					DrawCircle(PDI, Origin, BasisA, BasisB, Color, HalfWorld, 32, SDPG_Foreground, LineThickness, 0.0f, true);
				};

				if (bDrawX)
				{
					DrawRing(AxisY, AxisZ, ColorX);
				}
				if (bDrawY)
				{
					DrawRing(AxisX, AxisZ, ColorY);
				}
				if (bDrawZ)
				{
					DrawRing(AxisX, AxisY, ColorZ);
				}
			}
			else
			{
				auto DrawAxis = [&](const FVector& Direction, const FLinearColor& Color)
				{
					const FVector Extent = Direction.GetSafeNormal() * HalfWorld;
					PDI->DrawLine(Origin - Extent, Origin + Extent, Halo, SDPG_Foreground, LineThickness + HaloPx, 0.0f, true);
					PDI->DrawLine(Origin - Extent, Origin + Extent, Color, SDPG_Foreground, LineThickness, 0.0f, true);
				};

				if (bDrawX)
				{
					DrawAxis(AxisX, ColorX);
				}
				if (bDrawY)
				{
					DrawAxis(AxisY, ColorY);
				}
				if (bDrawZ)
				{
					DrawAxis(AxisZ, ColorZ);
				}
			}

			PDI->DrawPoint(Origin, Halo, 8.0f, SDPG_Foreground);
			PDI->DrawPoint(Origin, FLinearColor(1.0f, 1.0f, 1.0f, 0.95f), 5.0f, SDPG_Foreground);
		}
	}
}

bool FLocalTransformModifierTool::ShouldShowOriginHints(const FEditorViewportClient* ViewportClient) const
{
	using namespace LocalTransformModifierTool::Private;

	const UProWorkflowToolsSettings* Settings = GetEnabledSettings();
	if (!Settings || !Settings->bShowLocalScaleOriginHints || !ViewportClient || !GEditor || IsTransformGizmoReplaced()
		|| !IsScaleOrRotate(GetModeTools()) || GEditor->GetSelectedComponentCount() > 0)
	{
		return false;
	}

	return IsModifierDown(ViewportClient, ViewportClient->Viewport, Settings->LocalScaleModifierKey);
}

bool FLocalTransformModifierTool::InputKey(FEditorViewportClient* ViewportClient, FViewport* Viewport, FKey Key, EInputEvent Event)
{
	using namespace LocalTransformModifierTool::Private;

	const UProWorkflowToolsSettings* Settings = GetEnabledSettings();
	if (ViewportClient
		&& Settings
		&& (Event == IE_Pressed || Event == IE_Released)
		&& IsModifierKey(Key, Settings->LocalScaleModifierKey)
		&& IsScaleOrRotate(GetModeTools())
		&& !IsTransformGizmoReplaced())
	{
		ViewportClient->Invalidate(false, false);
	}
	return false;
}

bool FLocalTransformModifierTool::CapturedMouseMove(FEditorViewportClient* ViewportClient, FViewport* Viewport, int32 MouseX, int32 MouseY)
{
	if (ShouldShowOriginHints(ViewportClient))
	{
		ViewportClient->Invalidate(false, false);
	}
	return false;
}

bool FLocalTransformModifierTool::MouseMove(FEditorViewportClient* ViewportClient, FViewport* Viewport, int32 MouseX, int32 MouseY)
{
	if (ShouldShowOriginHints(ViewportClient))
	{
		ViewportClient->Invalidate(false, false);
	}
	return false;
}

void FLocalTransformModifierTool::Render(const FSceneView* View, FViewport* Viewport, FPrimitiveDrawInterface* PDI)
{
	using namespace LocalTransformModifierTool::Private;

	FEditorViewportClient* ViewportClient = Viewport ? static_cast<FEditorViewportClient*>(Viewport->GetClient()) : nullptr;
	if (!ViewportClient || !IsScaleOrRotate(GetModeTools()) || IsTransformGizmoReplaced())
	{
		return;
	}

	// Tracked every frame, not only while the modifier is held: the handle a drag holds is the
	// one hovered when it began, and the modifier may come down after that.
	const EAxisList::Type Axis = ProWorkflowTools::GetLiveTransformGizmoAxis(GizmoHandle, ViewportClient, Viewport, GetModeTools());

	if (!ShouldShowOriginHints(ViewportClient))
	{
		return;
	}

	if (Axis != EAxisList::None)
	{
		DrawOriginHints(View, ViewportClient, PDI, Axis);
	}
}

bool FLocalTransformModifierTool::InputDelta(FEditorViewportClient* ViewportClient, FViewport* Viewport, FVector& Drag, FRotator& Rot, FVector& Scale)
{
	using namespace LocalTransformModifierTool::Private;

	const UProWorkflowToolsSettings* Settings = GetEnabledSettings();
	const FEditorModeTools* ModeTools = GetModeTools();
	if (!Settings || !GEditor || !ModeTools || IsTransformGizmoReplaced())
	{
		return false;
	}

	const UE::Widget::EWidgetMode WidgetMode = ModeTools->GetWidgetMode();
	const bool bScale = WidgetMode == UE::Widget::WM_Scale && !Scale.IsNearlyZero(0.000001f);
	const bool bRotate = WidgetMode == UE::Widget::WM_Rotate && !Rot.IsNearlyZero(0.000001f);
	const bool bSelectionMovementLocked = ProWorkflowTools::HasSelectionMovementLocked();
	if ((!bScale && !bRotate)
		|| GEditor->GetSelectedComponentCount() > 0
		|| bSelectionMovementLocked
		|| !IsModifierDown(ViewportClient, Viewport, Settings->LocalScaleModifierKey))
	{
		return false;
	}

	FVector AdjustedScale = Scale;
	if (bScale)
	{
		ProWorkflowTools::AdjustPercentageBasedScale(AdjustedScale);
	}

	TArray<AActor*, TInlineAllocator<8>> GroupPivots;
	const bool bLockedGroups = CollectLockedGroupPivotActors(GroupPivots);
	TSet<AActor*> Transformed;

	bool bApplied = false;
	if (bLockedGroups)
	{
		for (AActor* PivotActor : GroupPivots)
		{
			AGroupActor* Group = Cast<AGroupActor>(PivotActor);
			if (!Group)
			{
				continue;
			}

			TArray<AActor*> GroupActors;
			GatherGroupTransformActors(*Group, GroupActors);
			const FVector Pivot = Group->GetActorLocation();
			const FQuat GroupQ = Group->GetActorQuat();
			const FQuat WorldRot = bRotate ? GetGroupWorldRotationDelta(ViewportClient, *Group, Rot) : FQuat::Identity;

			for (AActor* Actor : GroupActors)
			{
				if (!Actor || Actor->IsLockLocation() || Transformed.Contains(Actor))
				{
					continue;
				}

				Actor->Modify();
				if (bScale)
				{
					ApplyScaleAboutGroupPivot(*Actor, Pivot, GroupQ, AdjustedScale);
				}
				else
				{
					ApplyRotationAboutGroupPivot(*Actor, Pivot, WorldRot);
				}
				Actor->PostEditMove(false);
				Transformed.Add(Actor);
				bApplied = true;
			}
		}
	}

	for (FSelectionIterator It(GEditor->GetSelectedActorIterator()); It; ++It)
	{
		AActor* Actor = Cast<AActor>(*It);
		if (!Actor || Actor->IsLockLocation() || Transformed.Contains(Actor))
		{
			continue;
		}

		Actor->Modify();
		if (bScale)
		{
			FTransform World = Actor->GetActorTransform();
			World.SetScale3D(World.GetScale3D() + AdjustedScale);
			Actor->SetActorTransform(World);
		}
		else if (ViewportClient && ViewportClient->GetWidgetCoordSystemSpace() == COORD_Local)
		{
			// Rot is a world delta around the gizmo (first/pivot actor). Remap that axis
			// into each actor's local frame so Local-mode X/Y/Z is that actor's own X/Y/Z.
			FVector WorldAxis = FVector::XAxisVector;
			float AngleRadians = 0.0f;
			Rot.Quaternion().ToAxisAndAngle(WorldAxis, AngleRadians);
			if (!FMath::IsNearlyZero(AngleRadians))
			{
				const FQuat WidgetQ = ViewportClient->GetWidgetCoordSystem().ToQuat();
				const FVector LocalAxis = WidgetQ.UnrotateVector(WorldAxis).GetSafeNormal();
				const FQuat ActorQ = Actor->GetActorQuat();
				const FVector ActorAxis = ActorQ.RotateVector(LocalAxis);
				Actor->SetActorRotation(FQuat(ActorAxis, AngleRadians) * ActorQ);
			}
		}
		else
		{
			// World/parent: same world axes for every actor, each about its own origin.
			Actor->EditorApplyRotation(Rot, false, false, false);
		}
		Actor->PostEditMove(false);
		bApplied = true;
	}

	if (!bApplied)
	{
		return false;
	}

	Drag = FVector::ZeroVector;
	Rot = FRotator::ZeroRotator;
	return true;
}
