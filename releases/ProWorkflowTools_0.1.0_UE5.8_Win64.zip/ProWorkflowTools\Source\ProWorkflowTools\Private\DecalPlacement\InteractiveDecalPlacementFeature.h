// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "CoreMinimal.h"

class FInteractiveDecalPlacementEdMode;

/** Interactive Decal Placement feature (owned by FProWorkflowToolsModule). */
class FInteractiveDecalPlacementFeature
{
public:
	void Startup();
	void Shutdown();

	void StartPlacement();
	FInteractiveDecalPlacementEdMode* GetActivePlacementMode() const;

private:
	void RegisterSettings();
	void UnregisterSettings();
	void BindCommands();
	bool CanStartPlacement() const;

	/** Exit placement if Interactive Decal Placement is disabled while active. */
	void OnSettingsChanged(UObject* Settings, struct FPropertyChangedEvent& PropertyChangedEvent);

	FDelegateHandle SettingsChangedHandle;
};

