// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "Engine/EngineTypes.h"

class FPrimitiveDrawInterface;

/** The shared look of in-viewport tool overlays: one accent, pixel-width lines, a faint on-top pass. */
namespace ProWorkflowTools::OverlayStyle
{
	/** Primary overlay colour, opaque (Editor Preferences → Viewport Overlays → Accent Color). */
	FLinearColor Accent();
	const FLinearColor Neutral(0.65f, 0.65f, 0.68f, 1.0f);
	const FLinearColor Erase(1.0f, 0.2f, 0.16f, 1.0f);
	/** A value the user just changed (depth guide after W+Scroll); settles back to its idle colour. */
	const FLinearColor Highlight(1.0f, 0.78f, 0.25f, 1.0f);

	/** Corner ticks and emphasis lines, in screen pixels. Outlines are 1 px hairlines. */
	constexpr float TickPx = 1.5f;

	/** The on-top pass shows lines through geometry at this fraction of the depth-tested opacity. */
	constexpr float XRayOpacityScale = 0.42f;

	/** Feedback pulses (decal stamp, painted / erased cell). */
	constexpr float PulseSeconds = 0.35f;
	/** A highlighted value settling back to idle after an edit. */
	constexpr float SettleSeconds = 0.7f;

	inline float EaseOutCubic(const float T)
	{
		return 1.0f - FMath::Cube(1.0f - FMath::Clamp(T, 0.0f, 1.0f));
	}

	/** World-space dashes; thickness is screen pixels when ThicknessPx > 0. */
	void DrawDashedLine(
		FPrimitiveDrawInterface* PDI,
		const FVector& Start, const FVector& End,
		const FLinearColor& Color, uint8 DepthPriority, float ThicknessPx,
		float DashLengthCm, float GapLengthCm);

	/** Closed quad through the four corners. ThicknessPx 0 = hairline. */
	void DrawOutline(
		FPrimitiveDrawInterface* PDI,
		const FVector& C00, const FVector& C10, const FVector& C11, const FVector& C01,
		const FLinearColor& Color, uint8 DepthPriority, float ThicknessPx = 0.0f);

	/** L-shaped corners. Each arm is TickFraction of its edge, capped at MaxTickLengthCm. */
	void DrawCornerTicks(
		FPrimitiveDrawInterface* PDI,
		const FVector& C00, const FVector& C10, const FVector& C11, const FVector& C01,
		const FLinearColor& Color, uint8 DepthPriority, float ThicknessPx,
		float TickFraction, float MaxTickLengthCm = UE_BIG_NUMBER);

	/**
	 * Three-arm brackets at the eight corners of an oriented box (Axis* unit, Extent half-sizes):
	 * shows a volume without covering what is inside it. Arms as in DrawCornerTicks.
	 */
	void DrawBoxCornerBrackets(
		FPrimitiveDrawInterface* PDI,
		const FVector& Center, const FVector& AxisX, const FVector& AxisY, const FVector& AxisZ, const FVector& Extent,
		const FLinearColor& Color, uint8 DepthPriority, float ThicknessPx,
		float TickFraction, float MaxTickLengthCm = UE_BIG_NUMBER);

	/** Runs Draw depth-tested at Color, then on top at the x-ray opacity. */
	template <typename DrawFn>
	void WithXRay(const FLinearColor& Color, DrawFn&& Draw, const float XRayScale = XRayOpacityScale)
	{
		Draw(Color, static_cast<uint8>(SDPG_World));
		Draw(Color.CopyWithNewOpacity(Color.A * XRayScale), static_cast<uint8>(SDPG_Foreground));
	}
}
