// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "ProWorkflowToolsEngineAdapter.h"
#include "Viewport/WorkflowViewportTool.h"

/**
 * Local scale/rotate modifier: while the configured key is held in Scale or Rotate, each selected
 * actor scales or rotates about its own origin, and origin hints mark those pivots. Stands down
 * whenever another tool replaces the transform gizmo.
 */
class FLocalTransformModifierTool : public FWorkflowViewportTool
{
public:
	virtual bool InputKey(FEditorViewportClient* ViewportClient, FViewport* Viewport, FKey Key, EInputEvent Event) override;
	virtual bool CapturedMouseMove(FEditorViewportClient* ViewportClient, FViewport* Viewport, int32 MouseX, int32 MouseY) override;
	virtual bool MouseMove(FEditorViewportClient* ViewportClient, FViewport* Viewport, int32 MouseX, int32 MouseY) override;
	virtual bool InputDelta(FEditorViewportClient* ViewportClient, FViewport* Viewport, FVector& Drag, FRotator& Rot, FVector& Scale) override;
	virtual void Render(const FSceneView* View, FViewport* Viewport, FPrimitiveDrawInterface* PDI) override;

private:
	/** Modifier held in Scale/Rotate: redraw so hover enter/leave can show or clear the hints. */
	bool ShouldShowOriginHints(const FEditorViewportClient* ViewportClient) const;

	/** Handle the gizmo is hovering or dragging, sampled in Render. */
	ProWorkflowTools::FTransformGizmoHandleTracker GizmoHandle;
};
