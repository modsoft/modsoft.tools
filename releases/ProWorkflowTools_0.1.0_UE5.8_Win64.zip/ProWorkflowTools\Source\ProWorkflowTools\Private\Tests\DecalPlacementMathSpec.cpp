// Copyright © 2026 Trey McNair. All rights reserved.

#include "DecalPlacement/InteractiveDecalPlacementMath.h"

#include "Misc/AutomationTest.h"

#if WITH_DEV_AUTOMATION_TESTS

namespace DecalPlacementMathSpec
{
	constexpr float Tolerance = 1.0e-3f;
	constexpr double ScalarTolerance = 1.0e-3;

	/** Floor frame at the origin: normal +Z, tangent +X, bitangent +Y. */
	FInteractiveDecalTangentFrame MakeFloorFrame()
	{
		FInteractiveDecalTangentFrame Frame;
		Frame.Position = FVector::ZeroVector;
		Frame.Normal = FVector::UpVector;
		Frame.Tangent = FVector::ForwardVector;
		Frame.Bitangent = FVector::RightVector;
		return Frame;
	}
}

DEFINE_SPEC(FDecalPlacementMathSpec, "ProWorkflowTools.Math.DecalPlacement",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::ProductFilter)

void FDecalPlacementMathSpec::Define()
{
	using namespace DecalPlacementMathSpec;

	auto TestOrthonormal = [this](const FInteractiveDecalTangentFrame& Frame)
	{
		TestEqual(TEXT("|T|"), Frame.Tangent.Size(), 1.0, ScalarTolerance);
		TestEqual(TEXT("|B|"), Frame.Bitangent.Size(), 1.0, ScalarTolerance);
		TestEqual(TEXT("T.N"), FVector::DotProduct(Frame.Tangent, Frame.Normal), 0.0, ScalarTolerance);
		TestEqual(TEXT("B.N"), FVector::DotProduct(Frame.Bitangent, Frame.Normal), 0.0, ScalarTolerance);
		TestEqual(TEXT("T.B"), FVector::DotProduct(Frame.Tangent, Frame.Bitangent), 0.0, ScalarTolerance);
	};

	Describe("MakeTangentFrameFromHit", [this, TestOrthonormal]()
	{
		It("hangs upright on a wall regardless of view", [this, TestOrthonormal]()
		{
			const FInteractiveDecalTangentFrame Frame = InteractiveDecalPlacement::MakeTangentFrameFromHit(FVector(10.0), FVector(-1.0, 0.0, 0.0), FVector(0.3, 0.9, -0.3));
			TestOrthonormal(Frame);
			TestEqual(TEXT("tangent = image down"), Frame.Tangent, FVector(0.0, 0.0, -1.0), Tolerance);
			TestEqual(TEXT("position"), Frame.Position, FVector(10.0), Tolerance);
		});

		It("faces the viewer on a floor", [this, TestOrthonormal]()
		{
			const FInteractiveDecalTangentFrame Frame = InteractiveDecalPlacement::MakeTangentFrameFromHit(FVector::ZeroVector, FVector::UpVector, FVector(1.0, 0.0, -1.0).GetSafeNormal());
			TestOrthonormal(Frame);
			TestEqual(TEXT("tangent = -view on plane"), Frame.Tangent, FVector(-1.0, 0.0, 0.0), Tolerance);
		});

		It("stays valid when the view looks straight down", [this, TestOrthonormal]()
		{
			TestOrthonormal(InteractiveDecalPlacement::MakeTangentFrameFromHit(FVector::ZeroVector, FVector::UpVector, FVector::DownVector));
		});
	});

	Describe("RotateFrameInPlane", [this]()
	{
		It("turns the tangent onto the bitangent at 90 degrees", [this]()
		{
			const FInteractiveDecalTangentFrame Rotated = InteractiveDecalPlacement::RotateFrameInPlane(MakeFloorFrame(), HALF_PI);
			TestEqual(TEXT("tangent"), Rotated.Tangent, FVector::RightVector, Tolerance);
			TestEqual(TEXT("bitangent"), Rotated.Bitangent, FVector::BackwardVector, Tolerance);
			TestEqual(TEXT("normal"), Rotated.Normal, FVector::UpVector, Tolerance);
		});
	});

	Describe("RayPlaneIntersection", [this]()
	{
		It("hits a plane in front, misses parallel and behind", [this]()
		{
			FVector Hit;
			TestTrue(TEXT("front"), InteractiveDecalPlacement::RayPlaneIntersection(FVector(5.0, 5.0, 100.0), FVector::DownVector, FVector::ZeroVector, FVector::UpVector, Hit));
			TestEqual(TEXT("hit"), Hit, FVector(5.0, 5.0, 0.0), Tolerance);
			TestFalse(TEXT("parallel"), InteractiveDecalPlacement::RayPlaneIntersection(FVector(0.0, 0.0, 100.0), FVector::ForwardVector, FVector::ZeroVector, FVector::UpVector, Hit));
			TestFalse(TEXT("behind"), InteractiveDecalPlacement::RayPlaneIntersection(FVector(0.0, 0.0, 100.0), FVector::UpVector, FVector::ZeroVector, FVector::UpVector, Hit));
		});
	});

	Describe("MakeDecalActorRotation", [this]()
	{
		It("projects along -normal with width along the tangent", [this]()
		{
			const FQuat Rotation = InteractiveDecalPlacement::MakeDecalActorRotation(FVector(-1.0, 0.0, 0.0), FVector(0.0, 0.0, -1.0));
			TestEqual(TEXT("+X into the surface"), Rotation.GetAxisX(), FVector(1.0, 0.0, 0.0), Tolerance);
			TestEqual(TEXT("+Y = tangent"), Rotation.GetAxisY(), FVector(0.0, 0.0, -1.0), Tolerance);
		});
	});

	Describe("ComputePlacementFromDrag", [this]()
	{
		const FInteractiveDecalTangentFrame Floor = MakeFloorFrame();

		It("keeps the anchor corner and centres between it and the mouse", [this, Floor]()
		{
			const FInteractiveDecalPlacementResult Result = InteractiveDecalPlacement::ComputePlacementFromDrag(Floor, FVector(100.0, 50.0, 0.0), false, false, 1.0f, 10.0f, 1.0f);
			TestEqual(TEXT("size"), Result.DecalSize, FVector(10.0, 50.0, 25.0), Tolerance);
			TestEqual(TEXT("centre"), Result.ActorTransform.GetLocation(), FVector(50.0, 25.0, 0.0), Tolerance);
		});

		It("mirrors the centre for a negative drag", [this, Floor]()
		{
			const FInteractiveDecalPlacementResult Result = InteractiveDecalPlacement::ComputePlacementFromDrag(Floor, FVector(-100.0, -50.0, 0.0), false, false, 1.0f, 10.0f, 1.0f);
			TestEqual(TEXT("size"), Result.DecalSize, FVector(10.0, 50.0, 25.0), Tolerance);
			TestEqual(TEXT("centre"), Result.ActorTransform.GetLocation(), FVector(-50.0, -25.0, 0.0), Tolerance);
		});

		It("grows from the anchor in centre mode", [this, Floor]()
		{
			const FInteractiveDecalPlacementResult Result = InteractiveDecalPlacement::ComputePlacementFromDrag(Floor, FVector(100.0, 50.0, 0.0), true, false, 1.0f, 10.0f, 1.0f);
			TestEqual(TEXT("size"), Result.DecalSize, FVector(10.0, 100.0, 50.0), Tolerance);
			TestEqual(TEXT("centre"), Result.ActorTransform.GetLocation(), FVector::ZeroVector, Tolerance);
		});

		It("locks the aspect to the dominant drag axis", [this, Floor]()
		{
			const FInteractiveDecalPlacementResult Square = InteractiveDecalPlacement::ComputePlacementFromDrag(Floor, FVector(100.0, 50.0, 0.0), true, true, 1.0f, 10.0f, 1.0f);
			TestEqual(TEXT("1:1"), Square.DecalSize, FVector(10.0, 100.0, 100.0), Tolerance);

			const FInteractiveDecalPlacementResult Wide = InteractiveDecalPlacement::ComputePlacementFromDrag(Floor, FVector(20.0, 50.0, 0.0), true, true, 2.0f, 10.0f, 1.0f);
			TestEqual(TEXT("2:1 from V"), Wide.DecalSize, FVector(10.0, 100.0, 50.0), Tolerance);
		});

		It("clamps tiny drags to MinExtent", [this, Floor]()
		{
			const FInteractiveDecalPlacementResult Result = InteractiveDecalPlacement::ComputePlacementFromDrag(Floor, FVector(0.5, 0.5, 0.0), true, false, 1.0f, 10.0f, 4.0f);
			TestEqual(TEXT("size"), Result.DecalSize, FVector(10.0, 4.0, 4.0), Tolerance);
		});
	});
}

#endif
