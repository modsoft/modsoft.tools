// Copyright © 2026 Trey McNair. All rights reserved.

#include "BoxScale/BoxScaleTool.h"

#include "ProWorkflowToolsEngineAdapter.h"
#include "ProWorkflowToolsModule.h"
#include "ProWorkflowToolsSettings.h"
#include "UI/ProWorkflowToolHudOverlay.h"
#include "UI/SProWorkflowToolHud.h"
#include "Viewport/WorkflowViewportMath.h"

#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Widgets/SWidget.h"

#include "Components/BrushComponent.h"
#include "Components/DecalComponent.h"
#include "Components/PrimitiveComponent.h"
#include "Components/SceneComponent.h"
#include "Components/SkinnedMeshComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Editor.h"
#include "EditorModeManager.h"
#include "EditorViewportClient.h"
#include "Engine/BlueprintGeneratedClass.h"
#include "Engine/Engine.h"
#include "Engine/Selection.h"
#include "Engine/SkeletalMesh.h"
#include "Engine/StaticMesh.h"
#include "GameFramework/Actor.h"
#include "LevelEditorViewport.h"
#include "LevelInstance/LevelInstanceActor.h"
#include "Materials/Material.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Model.h"
#include "PrimitiveDrawingUtils.h"
#include "SceneView.h"
#include "SnappingUtils.h"
#include "UObject/Package.h"
#include "UnrealWidget.h"

#define LOCTEXT_NAMESPACE "ProWorkflowTools"

IMPLEMENT_HIT_PROXY(HBoxScaleHandle, HHitProxy);

namespace BoxScaleTool::Private
{
	/** Blender-style precision: mouse deltas while Shift is held. */
	constexpr double PrecisionScale = 0.1;

	/**
	 * Screen diameter (px) is 4× the widget-unit half-extent passed through GetScreenSpaceUniformScale.
	 * 12 px matches the previous fixed half-extent of 3.
	 */
	constexpr float DefaultHandleSizePx = 12.0f;
	constexpr float HandlePixelsPerWidgetUnit = 4.0f;
	/** Anchor ghost diameter relative to the handle. */
	constexpr float AnchorGhostScale = 0.75f;

	const FLinearColor AxisColors[3] =
	{
		FLinearColor(0.594f, 0.0197f, 0.0f),  // X
		FLinearColor(0.1349f, 0.3959f, 0.0f), // Y
		FLinearColor(0.0251f, 0.207f, 0.85f)  // Z
	};

	const FLinearColor WhiteHandleColor(0.92f, 0.92f, 0.92f);
	const FLinearColor HandleOutlineColor(0.02f, 0.02f, 0.02f, 1.0f);
	const FLinearColor CageWireColor(1.0f, 1.0f, 1.0f, 0.28f);
	const FLinearColor AnchorGhostColor(1.0f, 1.0f, 0.35f, 0.45f);

	FTransform GetTargetWorldTransform(const AActor* Actor, const USceneComponent* Component, const bool bComponentSpace)
	{
		if (bComponentSpace && Component)
		{
			return Component->GetComponentTransform();
		}
		return Actor ? Actor->GetActorTransform() : FTransform::Identity;
	}

	/** Draw order: corners → edges → faces so faces win overlapping picks. */
	enum class ESiteDrawPass : uint8
	{
		Corners = 1,
		Edges = 2,
		Faces = 3,
	};

	static bool ShouldDrawSiteInPass(const FBoxScaleSite& Site, const ESiteDrawPass Pass)
	{
		const int32 Free = Site.NumFreeAxes();
		switch (Pass)
		{
		case ESiteDrawPass::Corners: return Free == 3;
		case ESiteDrawPass::Edges: return Free == 2;
		case ESiteDrawPass::Faces: return Free == 1;
		default: return false;
		}
	}

	static void ForEachCageSite(TFunctionRef<void(const FBoxScaleSite&)> Visitor)
	{
		for (int32 X = -1; X <= 1; ++X)
		{
			for (int32 Y = -1; Y <= 1; ++Y)
			{
				for (int32 Z = -1; Z <= 1; ++Z)
				{
					if (X == 0 && Y == 0 && Z == 0)
					{
						continue;
					}
					FBoxScaleSite Site;
					Site.SX = static_cast<int8>(X);
					Site.SY = static_cast<int8>(Y);
					Site.SZ = static_cast<int8>(Z);
					Visitor(Site);
				}
			}
		}
	}

	/** Hold V: editor vertex snap for this drag. Same key Grid Paint uses on a bounds face. */
	static bool IsVertexSnapKeyDown(const FViewport* Viewport)
	{
		return Viewport && Viewport->KeyState(EKeys::V);
	}

	struct FBoxScaleViewSettings
	{
		FLinearColor CageColor = CageWireColor;
		FLinearColor EdgeCornerColor = WhiteHandleColor;
		float HandleSizePx = DefaultHandleSizePx;
		float FlatAxisRatio = 0.05f;
		bool bShowFaceHandles = true;
		bool bShowEdgeHandles = true;
		bool bShowCornerHandles = true;
	};

	static FBoxScaleViewSettings GetViewSettings()
	{
		FBoxScaleViewSettings Result;
		if (const UProWorkflowToolsUserSettings* UserSettings = GetDefault<UProWorkflowToolsUserSettings>())
		{
			Result.bShowFaceHandles = UserSettings->bBoxScaleShowFaceHandles;
			Result.bShowEdgeHandles = UserSettings->bBoxScaleShowEdgeHandles;
			Result.bShowCornerHandles = UserSettings->bBoxScaleShowCornerHandles;
		}

		const UProWorkflowToolsSettings* Settings = GetDefault<UProWorkflowToolsSettings>();
		if (!Settings)
		{
			return Result;
		}

		Result.CageColor = Settings->BoxScaleCageColor;
		Result.EdgeCornerColor = Settings->BoxScaleEdgeCornerHandleColor;
		Result.HandleSizePx = Settings->BoxScaleHandleSize;
		Result.FlatAxisRatio = Settings->BoxScaleFlatAxisRatio;
		return Result;
	}

	static void PersistHandleFlag(bool UProWorkflowToolsUserSettings::* const Member, const bool bValue)
	{
		if (UProWorkflowToolsUserSettings* UserSettings = GetMutableDefault<UProWorkflowToolsUserSettings>())
		{
			UserSettings->*Member = bValue;
			UserSettings->SaveConfig();
		}
		if (GEditor)
		{
			GEditor->RedrawLevelEditingViewports();
		}
	}

	/** Half-extent in world units for a constant screen-pixel handle diameter. */
	static float GetHandleHalfWorld(const FSceneView* View, const FVector& WorldLocation, const float HandleSizePx)
	{
		const float Pixels = FMath::Clamp(HandleSizePx, 4.0f, 64.0f);
		const float WidgetUnits = Pixels / HandlePixelsPerWidgetUnit;
		return WidgetUnits * ProWorkflowTools::GetScreenSpaceUniformScale(View, WorldLocation);
	}

	/** Keep the OS cursor on the dragged site so precision mode cannot run off-screen. */
	static bool WarpMouseToWorld(FEditorViewportClient* ViewportClient, FViewport* Viewport, const FVector& WorldPos)
	{
		if (!ViewportClient || !Viewport)
		{
			return false;
		}

		FSceneViewFamilyContext ViewFamily(FSceneViewFamily::ConstructionValues(
			ViewportClient->Viewport,
			ViewportClient->GetScene(),
			ViewportClient->EngineShowFlags)
			.SetRealtimeUpdate(ViewportClient->IsRealtime()));
		FSceneView* View = ViewportClient->CalcSceneView(&ViewFamily);
		if (!View)
		{
			return false;
		}

		FVector2D Pixel;
		if (!View->WorldToPixel(WorldPos, Pixel))
		{
			return false;
		}

		Viewport->SetMouse(FMath::RoundToInt(Pixel.X), FMath::RoundToInt(Pixel.Y));
		return true;
	}
}

void FBoxScaleTool::Exit()
{
	CancelTracking();
	ReleaseWidgetSuppression();
	HideHudOverlay();
}

void FBoxScaleTool::CancelTracking()
{
	if (bDraggingHandle)
	{
		bDraggingHandle = false;
		ProWorkflowTools::EndVertexSnap(VertexSnapQuery);
		if (bAltPressOwnsDrag && GEditor)
		{
			if (FViewport* CaptureViewport = GEditor->GetActiveViewport())
			{
				CaptureViewport->CaptureMouse(false);
			}
		}
		bAltPressOwnsDrag = false;
		if (GEditor)
		{
			if (bDragApplied)
			{
				GEditor->EndTransaction();
			}
			else
			{
				GEditor->CancelTransaction(DragTransactionIndex);
			}
		}
		DragTransactionIndex = INDEX_NONE;
		bDragApplied = false;
	}
}

void FBoxScaleTool::ReleaseWidgetSuppression()
{
	if (!bHoldingWidgetSuppression)
	{
		return;
	}

	bHoldingWidgetSuppression = false;
	ProWorkflowTools::ReleaseTransformWidget();
}

bool FBoxScaleTool::IsActive() const
{
	const FEditorModeTools* ModeTools = GetModeTools();
	const FProWorkflowToolsModule* Module = FProWorkflowToolsModule::GetPtr();
	if (!Module || !Module->IsBoxScaleEnabled() || !ModeTools || !GEditor)
	{
		return false;
	}

	if (ModeTools->GetWidgetMode() != UE::Widget::WM_Scale)
	{
		return false;
	}

	AActor* Actor = nullptr;
	USceneComponent* Component = nullptr;
	FBox LocalBounds(ForceInit);
	bool bComponentSpace = false;
	return GetBoxScaleTarget(Actor, Component, LocalBounds, bComponentSpace);
}

bool FBoxScaleTool::GetBoxScaleTarget(AActor*& OutActor, USceneComponent*& OutComponent, FBox& OutLocalBounds, bool& bOutComponentSpace)
{
	OutActor = nullptr;
	OutComponent = nullptr;
	OutLocalBounds.Init();
	bOutComponentSpace = false;
	if (!GEditor)
	{
		return false;
	}

	auto AcceptTarget = [&](AActor* Owner, USceneComponent* Component, const FBox& LocalBounds, const bool bComponentSpace) -> bool
	{
		if (!Owner || !Component
			|| !LocalBounds.IsValid
			|| LocalBounds.GetSize().GetMax() <= UE_KINDA_SMALL_NUMBER)
		{
			return false;
		}

		OutActor = Owner;
		OutComponent = Component;
		OutLocalBounds = LocalBounds;
		bOutComponentSpace = bComponentSpace;
		return true;
	};

	const int32 NumComponents = GEditor->GetSelectedComponentCount();
	if (NumComponents > 0)
	{
		if (NumComponents != 1)
		{
			return false;
		}

		USelection* ComponentSelection = GEditor->GetSelectedComponents();
		if (!ComponentSelection)
		{
			return false;
		}

		FBox LocalBounds(ForceInit);
		if (UDecalComponent* Decal = ComponentSelection->GetTop<UDecalComponent>())
		{
			return GetDecalComponentLocalBounds(Decal, LocalBounds)
				&& AcceptTarget(Decal->GetOwner(), Decal, LocalBounds, true);
		}

		UPrimitiveComponent* Primitive = ComponentSelection->GetTop<UPrimitiveComponent>();
		AActor* Owner = Primitive ? Primitive->GetOwner() : nullptr;
		return Primitive
			&& GetPrimitiveComponentLocalBounds(Primitive, LocalBounds)
			&& AcceptTarget(Owner, Primitive, LocalBounds, true);
	}

	if (GEditor->GetSelectedActorCount() != 1)
	{
		return false;
	}

	AActor* Actor = GEditor->GetSelectedActors()->GetTop<AActor>();
	if (!Actor)
	{
		return false;
	}

	// Whole-actor scaling is for plain placed primitives. A Level Instance or Blueprint actor is an
	// assembly whose bounds say nothing about what a scale would do to it; select one of its
	// components to cage that component instead.
	if (Actor->IsA<ALevelInstance>() || Cast<UBlueprintGeneratedClass>(Actor->GetClass()))
	{
		return false;
	}

	UDecalComponent* FirstDecal = nullptr;
	for (UActorComponent* ActorComponent : Actor->GetComponents())
	{
		if (UPrimitiveComponent* Primitive = Cast<UPrimitiveComponent>(ActorComponent))
		{
			FBox LocalBounds(ForceInit);
			if (GetPrimitiveComponentLocalBounds(Primitive, LocalBounds)
				&& LocalBounds.IsValid
				&& LocalBounds.GetSize().GetMax() > UE_KINDA_SMALL_NUMBER)
			{
				return AcceptTarget(Actor, Primitive, LocalBounds, false);
			}
		}

		if (!FirstDecal)
		{
			FirstDecal = Cast<UDecalComponent>(ActorComponent);
		}
	}

	FBox DecalBounds(ForceInit);
	if (FirstDecal && GetDecalComponentLocalBounds(FirstDecal, DecalBounds))
	{
		const bool bComponentSpace = FirstDecal != Actor->GetRootComponent();
		return AcceptTarget(Actor, FirstDecal, DecalBounds, bComponentSpace);
	}

	return false;
}

bool FBoxScaleTool::GetPrimitiveComponentLocalBounds(const UPrimitiveComponent* Component, FBox& OutBounds)
{
	if (const UStaticMeshComponent* StaticMeshComponent = Cast<const UStaticMeshComponent>(Component))
	{
		if (StaticMeshComponent->GetStaticMesh())
		{
			OutBounds = StaticMeshComponent->GetStaticMesh()->GetBoundingBox();
			return true;
		}
		return false;
	}

	if (const UBrushComponent* BrushComponent = Cast<const UBrushComponent>(Component))
	{
		if (BrushComponent->Brush)
		{
			OutBounds = BrushComponent->Brush->Bounds.GetBox();
			return true;
		}
		return false;
	}

	if (const USkinnedMeshComponent* SkinnedMeshComponent = Cast<const USkinnedMeshComponent>(Component))
	{
		if (const USkeletalMesh* SkeletalMesh = Cast<USkeletalMesh>(SkinnedMeshComponent->GetSkinnedAsset()))
		{
			OutBounds = SkeletalMesh->GetImportedBounds().GetBox();
			return true;
		}
		return false;
	}

	return false;
}

bool FBoxScaleTool::GetDecalComponentLocalBounds(const UDecalComponent* Component, FBox& OutBounds)
{
	if (!Component)
	{
		return false;
	}

	const FVector HalfExtents = Component->DecalSize.GetAbs();
	if (HalfExtents.GetMax() <= UE_KINDA_SMALL_NUMBER)
	{
		return false;
	}

	OutBounds = FBox(-HalfExtents, HalfExtents);
	return true;
}

void FBoxScaleTool::CreateHandleMaterials()
{
	if (AxisMaterials[0] || !GEngine || !GEngine->ArrowMaterial)
	{
		return;
	}

	for (int32 Axis = 0; Axis < 3; ++Axis)
	{
		AxisMaterials[Axis] = UMaterialInstanceDynamic::Create(GEngine->ArrowMaterial, GetTransientPackage());
		AxisMaterials[Axis]->SetVectorParameterValue(TEXT("GizmoColor"), BoxScaleTool::Private::AxisColors[Axis]);
	}

	CurrentAxisMaterial = UMaterialInstanceDynamic::Create(GEngine->ArrowMaterial, GetTransientPackage());
	CurrentAxisMaterial->SetVectorParameterValue(TEXT("GizmoColor"), FLinearColor::Yellow);

	WhiteHandleMaterial = UMaterialInstanceDynamic::Create(GEngine->ArrowMaterial, GetTransientPackage());
	WhiteHandleMaterial->SetVectorParameterValue(TEXT("GizmoColor"), BoxScaleTool::Private::WhiteHandleColor);

	AnchorGhostMaterial = UMaterialInstanceDynamic::Create(GEngine->ArrowMaterial, GetTransientPackage());
	AnchorGhostMaterial->SetVectorParameterValue(TEXT("GizmoColor"), BoxScaleTool::Private::AnchorGhostColor);
}

void FBoxScaleTool::Render(const FSceneView* View, FViewport* Viewport, FPrimitiveDrawInterface* PDI)
{
	if (!IsActive())
	{
		return;
	}

	AActor* Actor = nullptr;
	USceneComponent* Component = nullptr;
	FBox LocalBounds(ForceInit);
	bool bComponentSpace = false;
	if (!GetBoxScaleTarget(Actor, Component, LocalBounds, bComponentSpace))
	{
		return;
	}

	CreateHandleMaterials();
	if (!AxisMaterials[0] || !WhiteHandleMaterial)
	{
		return;
	}

	const BoxScaleTool::Private::FBoxScaleViewSettings ViewSettings = BoxScaleTool::Private::GetViewSettings();

	const FTransform TargetTransform = BoxScaleTool::Private::GetTargetWorldTransform(Actor, Component, bComponentSpace);
	const FQuat Rotation = TargetTransform.GetRotation();

	FVector LocalCenter, LocalExtent;
	LocalBounds.GetCenterAndExtents(LocalCenter, LocalExtent);

	const FVector WorldCenter = TargetTransform.TransformPosition(LocalCenter);
	const FVector ScaledExtent = LocalExtent * TargetTransform.GetScale3D().GetAbs();
	// While dragging, keep the handles that were valid at press time so a shrinking face does not vanish.
	const FVector SiteExtent = bDraggingHandle ? (LocalExtent * DragFrame.StartScale.GetAbs()) : ScaledExtent;
	const FMatrix FrameMatrix = FQuatRotationTranslationMatrix(Rotation, WorldCenter);

	WhiteHandleMaterial->SetVectorParameterValue(TEXT("GizmoColor"), ViewSettings.EdgeCornerColor);
	DrawWireBox(PDI, FrameMatrix, FBox(-ScaledExtent, ScaledExtent), ViewSettings.CageColor, SDPG_Foreground, 0.0f);

	auto IsHighlighted = [this](const FBoxScaleSite& Site) -> bool
	{
		if (bDraggingHandle)
		{
			return DragFrame.Site.Equals(Site);
		}
		return bHasHoveredSite && HoveredSite.Equals(Site);
	};

	// Corners → edges → faces: later draws win hit tests → face preferred.
	using BoxScaleTool::Private::ESiteDrawPass;
	for (ESiteDrawPass Pass : { ESiteDrawPass::Corners, ESiteDrawPass::Edges, ESiteDrawPass::Faces })
	{
		BoxScaleTool::Private::ForEachCageSite([&](const FBoxScaleSite& Site)
		{
			if (!BoxScaleTool::Private::ShouldDrawSiteInPass(Site, Pass)
				|| !BoxScaleMath::ShouldDrawSite(
					Site,
					SiteExtent,
					ViewSettings.bShowFaceHandles,
					ViewSettings.bShowEdgeHandles,
					ViewSettings.bShowCornerHandles,
					ViewSettings.FlatAxisRatio))
			{
				return;
			}

			const int32 FreeAxes = Site.NumFreeAxes();
			const int32 ColorAxis = Site.PrimaryAxis();
			const bool bHighlighted = IsHighlighted(Site);

			FVector Offset = FVector::ZeroVector;
			for (int32 Axis = 0; Axis < 3; ++Axis)
			{
				const int8 S = Site.Get(Axis);
				if (S != 0)
				{
					Offset[Axis] = ScaledExtent[Axis] * static_cast<double>(S);
				}
			}

			const FVector HandleWorld = FrameMatrix.TransformPosition(Offset);
			const float Half = BoxScaleTool::Private::GetHandleHalfWorld(View, HandleWorld, ViewSettings.HandleSizePx);
			const FVector HandleHalfExtent(Half);

			// Faces keep axis colors; edges/corners stay white — same cube size/shape for all.
			FMaterialRenderProxy* FillMaterial = nullptr;
			if (bHighlighted)
			{
				FillMaterial = CurrentAxisMaterial->GetRenderProxy();
			}
			else if (FreeAxes == 1)
			{
				FillMaterial = AxisMaterials[ColorAxis]->GetRenderProxy();
			}
			else
			{
				FillMaterial = WhiteHandleMaterial->GetRenderProxy();
			}

			const FMatrix HandleMatrix = FTranslationMatrix(Offset) * FrameMatrix;
			PDI->SetHitProxy(new HBoxScaleHandle(Site));
			DrawBox(PDI, HandleMatrix, HandleHalfExtent, FillMaterial, SDPG_Foreground);
			PDI->SetHitProxy(nullptr);

			DrawWireBox(
				PDI,
				HandleMatrix,
				FBox(-HandleHalfExtent, HandleHalfExtent),
				bHighlighted ? FLinearColor::Yellow : BoxScaleTool::Private::HandleOutlineColor,
				SDPG_Foreground,
				0.0f);
		});
	}

	auto DrawScreenSpaceGhost = [&](const FVector& AnchorWorld)
	{
		if (!AnchorGhostMaterial)
		{
			return;
		}
		const float Half = BoxScaleTool::Private::AnchorGhostScale
			* BoxScaleTool::Private::GetHandleHalfWorld(View, AnchorWorld, ViewSettings.HandleSizePx);
		const FVector GhostHalf(Half);
		DrawBox(PDI, FTranslationMatrix(AnchorWorld), GhostHalf, AnchorGhostMaterial->GetRenderProxy(), SDPG_Foreground);
		DrawWireBox(
			PDI,
			FTranslationMatrix(AnchorWorld),
			FBox(-GhostHalf, GhostHalf),
			BoxScaleTool::Private::HandleOutlineColor,
			SDPG_Foreground,
			0.0f);
	};

	const FEditorViewportClient* const ViewportClient = Viewport
		? static_cast<FEditorViewportClient*>(Viewport->GetClient())
		: nullptr;
	const bool bScaleFromCenter = ViewportClient && ViewportClient->IsAltPressed();
	if (bDraggingHandle)
	{
		DrawScreenSpaceGhost(bScaleFromCenter ? DragFrame.CenterWorld : DragFrame.AnchorWorld);
	}
	else if (bHasHoveredSite)
	{
		if (bScaleFromCenter)
		{
			DrawScreenSpaceGhost(WorldCenter);
		}
		else
		{
			const FBoxScaleSite AnchorSite = HoveredSite.Opposite();
			DrawScreenSpaceGhost(BoxScaleMath::GetSiteWorldPosition(AnchorSite, LocalCenter, LocalExtent, TargetTransform));
		}
	}
}

void FBoxScaleTool::Tick(FEditorViewportClient* ViewportClient, float DeltaTime)
{
	if (IsActive())
	{
		ShowHudOverlay();
	}
	else
	{
		HideHudOverlay();
	}

	UpdateWidgetSuppression();

	const bool bAlt = ViewportClient && ViewportClient->IsAltPressed();
	const bool bCtrl = ViewportClient && ViewportClient->IsCtrlPressed();
	const bool bVertexSnapKey = ViewportClient && BoxScaleTool::Private::IsVertexSnapKeyDown(ViewportClient->Viewport);
	if (bAlt == bAltHeldForAnchor && bCtrl == bCtrlHeldForUniform && bVertexSnapKey == bVertexSnapKeyHeld)
	{
		return;
	}

	// Record the edge before any redraw so a re-entrant tick does not apply twice.
	bAltHeldForAnchor = bAlt;
	bCtrlHeldForUniform = bCtrl;
	bVertexSnapKeyHeld = bVertexSnapKey;

	// Alt changes the fixed point, Ctrl uniform, and V the snap. Reapply a drag that has already moved; otherwise just redraw the ghost.
	if (bDraggingHandle && bDragApplied && ViewportClient && ViewportClient->Viewport)
	{
		CapturedMouseMove(
			ViewportClient,
			ViewportClient->Viewport,
			ViewportClient->Viewport->GetMouseX(),
			ViewportClient->Viewport->GetMouseY());
	}
	else if (!bDraggingHandle && bHasHoveredSite && ViewportClient)
	{
		ViewportClient->Invalidate(false, false);
	}
}

void FBoxScaleTool::UpdateWidgetSuppression()
{
	if (!GetModeTools())
	{
		return;
	}

	if (IsActive())
	{
		if (!bHoldingWidgetSuppression)
		{
			bHoldingWidgetSuppression = true;
			ProWorkflowTools::SuppressTransformWidget();
		}
	}
	else
	{
		ReleaseWidgetSuppression();
	}
}

bool FBoxScaleTool::MouseMove(FEditorViewportClient* ViewportClient, FViewport* Viewport, int32 X, int32 Y)
{
	// Alt+LMB on a handle never enters viewport tracking, so this move is the drag.
	if (bDraggingHandle && bAltPressOwnsDrag)
	{
		return CapturedMouseMove(ViewportClient, Viewport, X, Y);
	}

	if (IsActive() && !bDraggingHandle && Viewport)
	{
		FBoxScaleSite NewSite;
		bool bNewHover = false;

		if (HHitProxy* HitProxy = Viewport->GetHitProxy(X, Y))
		{
			if (HitProxy->IsA(HBoxScaleHandle::StaticGetType()))
			{
				const HBoxScaleHandle* Handle = static_cast<HBoxScaleHandle*>(HitProxy);
				NewSite = Handle->Site;
				bNewHover = NewSite.IsValid();
			}
		}

		if (bNewHover != bHasHoveredSite || (bNewHover && !NewSite.Equals(HoveredSite)))
		{
			bHasHoveredSite = bNewHover;
			HoveredSite = NewSite;
			if (ViewportClient)
			{
				ViewportClient->Invalidate(false, false);
			}
		}
		return false;
	}

	if (bHasHoveredSite && !IsActive())
	{
		bHasHoveredSite = false;
		HoveredSite = FBoxScaleSite();
	}

	return false;
}

bool FBoxScaleTool::ComputeAxisDragParam(
	FEditorViewportClient* ViewportClient,
	int32 MouseX,
	int32 MouseY,
	const FVector& AxisOrigin,
	const FVector& AxisDir,
	double& OutParam)
{
	FSceneViewFamilyContext ViewFamily(FSceneViewFamily::ConstructionValues(
		ViewportClient->Viewport,
		ViewportClient->GetScene(),
		ViewportClient->EngineShowFlags)
		.SetRealtimeUpdate(ViewportClient->IsRealtime()));
	FSceneView* View = ViewportClient->CalcSceneView(&ViewFamily);
	if (!View)
	{
		return false;
	}

	const FViewportCursorLocation Cursor(View, ViewportClient, MouseX, MouseY);
	const FVector RayOrigin = Cursor.GetOrigin();
	const FVector RayDir = Cursor.GetDirection();

	const FVector W0 = AxisOrigin - RayOrigin;
	const double B = FVector::DotProduct(AxisDir, RayDir);
	const double D = FVector::DotProduct(AxisDir, W0);
	const double E = FVector::DotProduct(RayDir, W0);
	const double Denom = 1.0 - B * B;

	if (FMath::Abs(Denom) < UE_DOUBLE_SMALL_NUMBER)
	{
		return false;
	}

	OutParam = (E * B - D) / Denom;
	return true;
}

bool FBoxScaleTool::ComputePlaneDragPoint(
	FEditorViewportClient* ViewportClient,
	int32 MouseX,
	int32 MouseY,
	const FVector& PointOnPlane,
	const FVector& PlaneNormal,
	FVector& OutPoint)
{
	FSceneViewFamilyContext ViewFamily(FSceneViewFamily::ConstructionValues(
		ViewportClient->Viewport,
		ViewportClient->GetScene(),
		ViewportClient->EngineShowFlags)
		.SetRealtimeUpdate(ViewportClient->IsRealtime()));
	FSceneView* View = ViewportClient->CalcSceneView(&ViewFamily);
	if (!View)
	{
		return false;
	}

	const FViewportCursorLocation Cursor(View, ViewportClient, MouseX, MouseY);
	const FVector RayOrigin = Cursor.GetOrigin();
	const FVector RayDir = Cursor.GetDirection();

	const double Denom = FVector::DotProduct(RayDir, PlaneNormal);
	if (FMath::Abs(Denom) < UE_DOUBLE_SMALL_NUMBER)
	{
		return false;
	}

	const double T = FVector::DotProduct(PointOnPlane - RayOrigin, PlaneNormal) / Denom;
	OutPoint = RayOrigin + RayDir * T;
	return true;
}

bool FBoxScaleTool::StartTracking(FEditorViewportClient* InViewportClient, FViewport* InViewport)
{
	// ITF can re-capture mid-drag and restart mode tracking; the drag in progress keeps LMB.
	if (bDraggingHandle)
	{
		return true;
	}

	if (!IsActive() || !InViewport || !InViewport->KeyState(EKeys::LeftMouseButton))
	{
		return false;
	}

	HHitProxy* HitProxy = InViewport->GetHitProxy(InViewport->GetMouseX(), InViewport->GetMouseY());
	if (!HitProxy || !HitProxy->IsA(HBoxScaleHandle::StaticGetType()))
	{
		return false;
	}

	AActor* Actor = nullptr;
	USceneComponent* Component = nullptr;
	FBox LocalBounds(ForceInit);
	bool bComponentSpace = false;
	if (!GetBoxScaleTarget(Actor, Component, LocalBounds, bComponentSpace))
	{
		return false;
	}

	const HBoxScaleHandle* Handle = static_cast<HBoxScaleHandle*>(HitProxy);
	const FTransform TargetTransform = BoxScaleTool::Private::GetTargetWorldTransform(Actor, Component, bComponentSpace);
	if (!BoxScaleMath::MakeDragFrame(Handle->Site, LocalBounds, TargetTransform, BoxScaleTool::Private::GetViewSettings().FlatAxisRatio, DragFrame))
	{
		return false;
	}

	DragActor = Actor;
	DragComponent = Component;
	bDragComponentSpace = bComponentSpace;

	const int32 FreeAxes = DragFrame.Site.NumFreeAxes();
	DragAppliedDistance = 0.0;
	DragAppliedPlaneDelta = FVector::ZeroVector;

	if (FreeAxes == 1)
	{
		const int32 Axis = DragFrame.Site.PrimaryAxis();
		if (!ComputeAxisDragParam(
			InViewportClient,
			InViewport->GetMouseX(),
			InViewport->GetMouseY(),
			DragFrame.HandleStartWorld,
			DragFrame.AxisWorld[Axis],
			DragStartParam))
		{
			return false;
		}
		DragLastRawParam = DragStartParam;
	}
	else
	{
		if (FreeAxes == 2)
		{
			// Plane spanned by the two free axes (normal = their cross product).
			int32 A0 = INDEX_NONE;
			int32 A1 = INDEX_NONE;
			for (int32 Axis = 0; Axis < 3; ++Axis)
			{
				if (DragFrame.Site.Get(Axis) != 0)
				{
					if (A0 == INDEX_NONE) { A0 = Axis; }
					else { A1 = Axis; }
				}
			}
			DragPlaneNormal = FVector::CrossProduct(DragFrame.AxisWorld[A0], DragFrame.AxisWorld[A1]).GetSafeNormal();
			if (DragPlaneNormal.IsNearlyZero())
			{
				DragPlaneNormal = DragFrame.AxisWorld[A0];
			}
		}
		else
		{
			// Corner: camera-facing plane through the handle.
			DragPlaneNormal = InViewportClient
				? -InViewportClient->GetViewRotation().Vector()
				: FVector::UpVector;
		}

		if (!ComputePlaneDragPoint(
			InViewportClient,
			InViewport->GetMouseX(),
			InViewport->GetMouseY(),
			DragFrame.HandleStartWorld,
			DragPlaneNormal,
			DragStartPlanePoint))
		{
			return false;
		}
		DragLastRawPlanePoint = DragStartPlanePoint;
	}

	VertexSnapQuery.FrameNumber = MAX_uint64;
	DragTransactionIndex = GEditor->BeginTransaction(LOCTEXT("BoxScaleTransaction", "Box Scale"));
	Actor->Modify();
	if (bComponentSpace && Component)
	{
		Component->Modify();
	}
	bDraggingHandle = true;
	bDragApplied = false;
	bAltHeldForAnchor = InViewportClient && InViewportClient->IsAltPressed();
	bCtrlHeldForUniform = InViewportClient && InViewportClient->IsCtrlPressed();
	// This drag owns LMB. ITF may already be in a camera or marquee capture on the same press.
	ProWorkflowTools::TerminateInteractiveToolsMouseCapture(InViewportClient);
	return true;
}

bool FBoxScaleTool::CapturedMouseMove(FEditorViewportClient* InViewportClient, FViewport* InViewport, int32 InMouseX, int32 InMouseY)
{
	if (!bDraggingHandle)
	{
		return false;
	}

	// The ITF capture can begin after StartTracking, on the same move that writes the camera delta.
	ProWorkflowTools::TerminateInteractiveToolsMouseCapture(InViewportClient);

	AActor* Actor = DragActor.Get();
	USceneComponent* Component = DragComponent.Get();
	if (!Actor || (bDragComponentSpace && !Component))
	{
		return true;
	}

	FVector NewHandleWorld = DragFrame.HandleStartWorld;
	const int32 FreeAxes = DragFrame.Site.NumFreeAxes();
	const bool bPrecision = InViewportClient && InViewportClient->IsShiftPressed();
	const double PrecisionMul = bPrecision ? BoxScaleTool::Private::PrecisionScale : 1.0;
	const bool bUniform = InViewportClient && InViewportClient->IsCtrlPressed();
	const bool bVertexSnap = BoxScaleTool::Private::IsVertexSnapKeyDown(InViewport);
	const bool bScaleFromCenter = InViewportClient && InViewportClient->IsAltPressed();

	if (FreeAxes == 1)
	{
		const int32 Axis = DragFrame.Site.PrimaryAxis();
		double Param = 0.0;
		if (!ComputeAxisDragParam(InViewportClient, InMouseX, InMouseY, DragFrame.HandleStartWorld, DragFrame.AxisWorld[Axis], Param))
		{
			return true;
		}

		DragAppliedDistance += (Param - DragLastRawParam) * PrecisionMul;
		DragLastRawParam = Param;

		double DragDistance = DragAppliedDistance;
		// Face handles: position/grid snap. Vertex snap replaces it while V is held.
		if (!bVertexSnap && FSnappingUtils::IsSnapToGridEnabled())
		{
			DragDistance = FMath::GridSnap(DragDistance, static_cast<double>(GEditor->GetGridSize()));
		}
		NewHandleWorld = DragFrame.HandleStartWorld + DragFrame.AxisWorld[Axis] * DragDistance;
	}
	else
	{
		FVector PlanePoint = DragStartPlanePoint;
		if (!ComputePlaneDragPoint(InViewportClient, InMouseX, InMouseY, DragFrame.HandleStartWorld, DragPlaneNormal, PlanePoint))
		{
			return true;
		}

		DragAppliedPlaneDelta += (PlanePoint - DragLastRawPlanePoint) * PrecisionMul;
		DragLastRawPlanePoint = PlanePoint;
		NewHandleWorld = DragFrame.HandleStartWorld + DragAppliedPlaneDelta;
	}

	if (!bVertexSnap)
	{
		ProWorkflowTools::EndVertexSnap(VertexSnapQuery);
	}
	else
	{
		FVector SnapLocation = NewHandleWorld;
		TSet<TWeakObjectPtr<AActor>> Ignore;
		if (AActor* IgnoreActor = DragActor.Get())
		{
			Ignore.Add(IgnoreActor);
		}
		const bool bSnapped = ProWorkflowTools::QueryVertexSnapOncePerFrame(
			VertexSnapQuery,
			SnapLocation,
			FVector2D(InMouseX, InMouseY),
			InViewportClient,
			Ignore);
		if (bSnapped)
		{
			if (FreeAxes <= 1)
			{
				const int32 Axis = DragFrame.Site.PrimaryAxis();
				const double Along = FVector::DotProduct(SnapLocation - DragFrame.HandleStartWorld, DragFrame.AxisWorld[Axis]);
				NewHandleWorld = DragFrame.HandleStartWorld + DragFrame.AxisWorld[Axis] * Along;
			}
			else if (FreeAxes == 2)
			{
				const double PlaneDist = FVector::DotProduct(SnapLocation - DragFrame.HandleStartWorld, DragPlaneNormal);
				NewHandleWorld = SnapLocation - DragPlaneNormal * PlaneDist;
			}
			else
			{
				NewHandleWorld = SnapLocation;
			}
		}
	}

	// Edge/corner handles: step the scale (or the uniform factor) with the editor scale snap size.
	double ScaleSnapStep = 0.0;
	if (!bVertexSnap
		&& FreeAxes >= 2
		&& FSnappingUtils::IsScaleSnapEnabled())
	{
		ScaleSnapStep = GEditor->UsePercentageBasedScaling()
			? static_cast<double>(GEditor->GetGridSize())
			: static_cast<double>(GEditor->GetScaleGridSize());
	}

	const FBoxScaleSolve Solve = BoxScaleMath::SolveDrag(DragFrame, NewHandleWorld, bScaleFromCenter, bUniform, ScaleSnapStep);
	if (bDragComponentSpace && Component)
	{
		Component->SetWorldTransform(FTransform(DragFrame.Rotation, Solve.Location, Solve.Scale));
		Component->PostEditComponentMove(false);
	}
	else
	{
		Actor->SetActorScale3D(Solve.Scale);
		Actor->SetActorLocation(Solve.Location);
		Actor->PostEditMove(false);
	}
	bDragApplied = true;

	// Precision slows the handle vs the cursor; warp back onto the site so the mouse
	// cannot run to the monitor edge and release far from the gizmo.
	// Vertex snap aims at another mesh, so the cursor stays where the user put it.
	if (bPrecision
		&& !bVertexSnap
		&& BoxScaleTool::Private::WarpMouseToWorld(InViewportClient, InViewport, NewHandleWorld))
	{
		if (FreeAxes == 1)
		{
			const int32 Axis = DragFrame.Site.PrimaryAxis();
			ComputeAxisDragParam(
				InViewportClient,
				InViewport->GetMouseX(),
				InViewport->GetMouseY(),
				DragFrame.HandleStartWorld,
				DragFrame.AxisWorld[Axis],
				DragLastRawParam);
		}
		else
		{
			ComputePlaneDragPoint(
				InViewportClient,
				InViewport->GetMouseX(),
				InViewport->GetMouseY(),
				DragFrame.HandleStartWorld,
				DragPlaneNormal,
				DragLastRawPlanePoint);
		}
	}

	// Hit proxies are not read mid-drag; EndTracking's redraw refreshes them.
	GEditor->RedrawLevelEditingViewports(/*bInvalidateHitProxies=*/false);
	return true;
}

bool FBoxScaleTool::BlocksViewportDragTool() const
{
	if (bDraggingHandle)
	{
		return true;
	}

	const FEditorViewportClient* ViewportClient = GCurrentLevelEditingViewportClient;
	FViewport* Viewport = ViewportClient ? ViewportClient->Viewport : nullptr;
	if (!Viewport || !IsActive())
	{
		return false;
	}

	HHitProxy* HitProxy = Viewport->GetHitProxy(Viewport->GetMouseX(), Viewport->GetMouseY());
	return HitProxy && HitProxy->IsA(HBoxScaleHandle::StaticGetType());
}

bool FBoxScaleTool::InputKey(FEditorViewportClient* ViewportClient, FViewport* Viewport, FKey Key, EInputEvent Event)
{
	if (Key != EKeys::LeftMouseButton)
	{
		return false;
	}

	// Alt+LMB on a cage handle is two-sided scale. Empty-space Alt+LMB still orbits.
	if (Event == IE_Pressed || Event == IE_DoubleClick)
	{
		return TryConsumeAltHandlePress(ViewportClient, Viewport);
	}
	if (Event == IE_Released)
	{
		return HandleLmbRelease(ViewportClient, Viewport);
	}
	return false;
}

bool FBoxScaleTool::TryConsumeAltHandlePress(FEditorViewportClient* ViewportClient, FViewport* Viewport)
{
	if (bDraggingHandle || !ViewportClient || !Viewport || !ViewportClient->IsAltPressed())
	{
		return false;
	}

	if (!Viewport->KeyState(EKeys::LeftMouseButton))
	{
		return false;
	}

	HHitProxy* HitProxy = Viewport->GetHitProxy(Viewport->GetMouseX(), Viewport->GetMouseY());
	if (!HitProxy || !HitProxy->IsA(HBoxScaleHandle::StaticGetType()))
	{
		return false;
	}

	if (!StartTracking(ViewportClient, Viewport))
	{
		return false;
	}

	// The viewport orbit path does not see this press. Own the capture the engine tracking path would have taken.
	ViewportClient->SetCurrentWidgetAxis(EAxisList::None);
	ViewportClient->bWidgetAxisControlledByDrag = false;
	Viewport->CaptureMouse(true);
	bAltPressOwnsDrag = true;
	return true;
}

bool FBoxScaleTool::HandleLmbRelease(FEditorViewportClient* ViewportClient, FViewport* Viewport)
{
	if (!bDraggingHandle)
	{
		return false;
	}

	// Alt drags never entered viewport tracking, so their release is ours to consume.
	const bool bConsume = bAltPressOwnsDrag;
	EndTracking(ViewportClient, Viewport);
	return bConsume;
}

bool FBoxScaleTool::EndTracking(FEditorViewportClient* InViewportClient, FViewport* InViewport)
{
	// LMB release ends the drag. Mode tracking can end earlier, on any key, once ITF capture is gone.
	if (bDraggingHandle && InViewport && InViewport->KeyState(EKeys::LeftMouseButton))
	{
		return true;
	}

	if (!bDraggingHandle)
	{
		bAltPressOwnsDrag = false;
		return false;
	}

	const bool bReleaseCapture = bAltPressOwnsDrag;
	bAltPressOwnsDrag = false;
	bDraggingHandle = false;
	ProWorkflowTools::EndVertexSnap(VertexSnapQuery);

	if (bReleaseCapture)
	{
		FViewport* CaptureViewport = InViewport;
		if (!CaptureViewport && GEditor)
		{
			CaptureViewport = GEditor->GetActiveViewport();
		}
		if (CaptureViewport)
		{
			CaptureViewport->CaptureMouse(false);
		}
	}

	if (bDragApplied)
	{
		if (USceneComponent* Component = DragComponent.Get(); Component && bDragComponentSpace)
		{
			Component->PostEditComponentMove(true);
			GLevelEditorModeTools().SetPivotLocation(Component->GetComponentLocation(), false);
		}
		else if (AActor* Actor = DragActor.Get())
		{
			Actor->PostEditMove(true);
			GLevelEditorModeTools().SetPivotLocation(Actor->GetActorLocation(), false);
		}
	}
	DragActor.Reset();
	DragComponent.Reset();
	bDragComponentSpace = false;

	if (bDragApplied)
	{
		GEditor->EndTransaction();
	}
	else
	{
		GEditor->CancelTransaction(DragTransactionIndex);
	}
	DragTransactionIndex = INDEX_NONE;
	bDragApplied = false;
	DragAppliedDistance = 0.0;
	DragAppliedPlaneDelta = FVector::ZeroVector;

	GEditor->RedrawLevelEditingViewports();
	return true;
}

void FBoxScaleTool::AddReferencedObjects(FReferenceCollector& Collector)
{
	for (int32 Axis = 0; Axis < 3; ++Axis)
	{
		Collector.AddReferencedObject(AxisMaterials[Axis]);
	}
	Collector.AddReferencedObject(CurrentAxisMaterial);
	Collector.AddReferencedObject(WhiteHandleMaterial);
	Collector.AddReferencedObject(AnchorGhostMaterial);
}

void FBoxScaleTool::ShowHudOverlay()
{
	HudOverlay.Show([this]()
	{
		return SNew(SProWorkflowToolHud)
			.bPanelHitTestable(true)
			.Model_Lambda([this]()
			{
				return BuildHudModel();
			});
	});
}

void FBoxScaleTool::HideHudOverlay()
{
	HudOverlay.Hide();
}

FProWorkflowToolHudModel FBoxScaleTool::BuildHudModel() const
{
	FProWorkflowToolHudModel Model;
	Model.Title = LOCTEXT("BoxScaleHudTitle", "Bounding Box Scale");

	const BoxScaleTool::Private::FBoxScaleViewSettings ViewSettings = BoxScaleTool::Private::GetViewSettings();
	const bool bEdges = ViewSettings.bShowEdgeHandles;
	const bool bCorners = ViewSettings.bShowCornerHandles;
	const bool bFaces = ViewSettings.bShowFaceHandles;

	Model.Fields.Add(MakeHudCheckField(
		TEXT("Faces"),
		LOCTEXT("BoxScaleHudFaces", "Faces"),
		bFaces,
		[](const bool bChecked)
		{
			BoxScaleTool::Private::PersistHandleFlag(&UProWorkflowToolsUserSettings::bBoxScaleShowFaceHandles, bChecked);
		}));
	Model.Fields.Add(MakeHudCheckField(
		TEXT("Edges"),
		LOCTEXT("BoxScaleHudEdges", "Edges"),
		bEdges,
		[](const bool bChecked)
		{
			BoxScaleTool::Private::PersistHandleFlag(&UProWorkflowToolsUserSettings::bBoxScaleShowEdgeHandles, bChecked);
		}));
	Model.Fields.Add(MakeHudCheckField(
		TEXT("Corners"),
		LOCTEXT("BoxScaleHudCorners", "Corners"),
		bCorners,
		[](const bool bChecked)
		{
			BoxScaleTool::Private::PersistHandleFlag(&UProWorkflowToolsUserSettings::bBoxScaleShowCornerHandles, bChecked);
		}));

	AddHudKeycap(Model.Keycaps, LOCTEXT("BoxScaleKeyCtrl", "Ctrl"), LOCTEXT("BoxScaleActUniform", "Uniform"));
	AddHudKeycap(Model.Keycaps, LOCTEXT("BoxScaleKeyAlt", "Alt"), LOCTEXT("BoxScaleActCenter", "From Center"));
	AddHudKeycap(Model.Keycaps, LOCTEXT("BoxScaleKeyShift", "Shift"), LOCTEXT("BoxScaleActPrecision", "Precision"));
	AddHudKeycap(Model.Keycaps, LOCTEXT("BoxScaleKeyV", "V"), LOCTEXT("BoxScaleActVertexSnap", "Vertex Snap"));

	return Model;
}

#undef LOCTEXT_NAMESPACE
