// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "DecalPlacement/InteractiveDecalPlacementTypes.h"
#include "EdMode.h"
#include "ProWorkflowToolsEngineAdapter.h"
#include "UI/ProWorkflowToolHudOverlay.h"
#include "UI/ViewportCursorLabel.h"
#include "UObject/WeakObjectPtr.h"

class ADecalActor;
class FEditorViewportClient;
class FViewport;
class SInteractiveDecalPlacementHud;
class UDecalComponent;
class UMaterialInterface;

namespace InteractiveDecalPlacement
{
	struct FDecalBrowseCategory;
}

class FInteractiveDecalPlacementEdMode : public FEdMode
{
public:
	static const FEditorModeID EM_InteractiveDecalPlacement;

	FInteractiveDecalPlacementEdMode() = default;

	virtual bool IsCompatibleWith(FEditorModeID OtherModeID) const override { return true; }
	virtual bool UsesToolkits() const override { return false; }
	virtual bool ShouldDrawWidget() const override { return false; }

	virtual bool IsSelectionAllowed(AActor* InActor, bool bInSelection) const override;

	virtual void Enter() override;
	virtual void Exit() override;
	virtual void Tick(FEditorViewportClient* ViewportClient, float DeltaTime) override;
	virtual void Render(const FSceneView* View, FViewport* Viewport, FPrimitiveDrawInterface* PDI) override;
	virtual void DrawHUD(FEditorViewportClient* ViewportClient, FViewport* Viewport, const FSceneView* View, FCanvas* Canvas) override;

	virtual bool InputKey(FEditorViewportClient* ViewportClient, FViewport* Viewport, FKey Key, EInputEvent Event) override;
	virtual bool InputAxis(FEditorViewportClient* ViewportClient, FViewport* Viewport, int32 ControllerId, FKey Key, float Delta, float DeltaTime) override;
	virtual bool StartTracking(FEditorViewportClient* InViewportClient, FViewport* InViewport) override;
	virtual bool EndTracking(FEditorViewportClient* InViewportClient, FViewport* InViewport) override;
	virtual bool CapturedMouseMove(FEditorViewportClient* InViewportClient, FViewport* InViewport, int32 InMouseX, int32 InMouseY) override;
	virtual bool MouseMove(FEditorViewportClient* ViewportClient, FViewport* Viewport, int32 x, int32 y) override;
	virtual bool DisallowMouseDeltaTracking() const override;

	virtual void AddReferencedObjects(FReferenceCollector& Collector) override;
	virtual FString GetReferencerName() const override { return TEXT("FInteractiveDecalPlacementEdMode"); }

	void BeginPlacement();

	FString GetHudCategoryName() const;
	FString GetHudDecalName() const;
	bool TryGetHudDecalIndex(int32& OutIndexOneBased, int32& OutCount) const;
	float GetHudAngleDegrees() const;
	float GetHudProjectionDepth() const;
	float GetHudAlpha() const { return PreviewDecalColorAlpha; }
	int32 GetHudSortOrder() const { return PreviewSortOrder; }
	FVector GetHudInPlaneSize() const;

	bool IsRandomRotationEnabled() const { return bRandomRotationEnabled; }
	void SetRandomRotationEnabled(const bool bEnabled) { bRandomRotationEnabled = bEnabled; }

	/** Persisted per user (Alt tap toggles it). Alt pressed during a drag inverts it for that drag. */
	bool IsCenteredPlacementEnabled() const;
	void SetCenteredPlacementEnabled(bool bEnabled);

	/** Persisted per user (C toggles). Hover and drag poses are fitted to the surface under the footprint. */
	bool IsFitSurfaceEnabled() const;
	void SetFitSurfaceEnabled(bool bEnabled);

	//~ HUD value edits. Each goes through the same state its scroll binding writes; the next drag or scroll overrides it.
	/** Width and height in cm; HeightCm <= 0 derives the height from the material aspect. */
	void SetHudInPlaneSize(float WidthCm, float HeightCm);
	void SetHudAngleDegrees(float Degrees);
	void SetHudProjectionDepth(float DepthCm);
	void SetHudAlpha(float Alpha);
	void SetHudSortOrder(int32 SortOrder);

	/** Index into GetBrowseCategories(), or INDEX_NONE outside collection browsing. */
	int32 GetHudCategoryIndex() const;
	/** Switches to collection browsing at that browse category. */
	void SelectBrowseCategory(int32 CategoryIndex);
	/** Decals of the active category; empty outside collection browsing. */
	const TArray<FSoftObjectPath>& GetHudCollectionDecals() const;
	void SelectDecal(int32 DecalIndex);

	/** Session-only browse-category toggles for the HUD Collections popover (invalidates browse cache). */
	bool IsSessionCollectionEnabled(FName CollectionName) const;
	void SetSessionCollectionEnabled(FName CollectionName, bool bEnabled);
	/** Check/uncheck every session UI browse category (invalidates cache + restores selection). */
	void SetAllSessionCollectionsEnabled(bool bEnabled);
	/** Expanded browse categories for HUD checkboxes (includes subcategories; ignores session filter). */
	void GetSessionUiBrowseCategories(TArray<InteractiveDecalPlacement::FDecalBrowseCategory>& OutCategories) const;

	/** Session-only: draw grey corner ticks on all scene ADecalActors while the mode is active. */
	bool IsShowSceneBoundsTicks() const;
	void SetShowSceneBoundsTicks(bool bEnabled);

	/** True when the cursor is over the visible Slate HUD panel (not empty overlay chrome). */
	bool IsPointerOverHud() const;

private:
	enum class EDecalSourceMode : uint8
	{
		ContentBrowser,
		Collection
	};

	bool ProjectCursorOntoAnchorPlane(FEditorViewportClient* ViewportClient, FVector& OutPlanePoint) const;

	void UpdateHoverPreview(FEditorViewportClient* ViewportClient);
	void UpdateDragPreview(FEditorViewportClient* ViewportClient);
	void ApplyPreviewTransform(const FInteractiveDecalPlacementResult& Placement);
	void ApplyPreviewDecalProperties();
	FVector ApplyFlipToDecalSize(const FVector& DecalSize) const;

	bool TrySetMaterialFromContentBrowser();
	bool ActivateBrowseCategoryAtIndex(int32 CategoryIndex);
	bool TryActivateFirstCollectionWithDecals();
	bool TryRestoreSessionBrowseSelection();
	/**
	 * At placement start only: if exactly one scene decal is selected, seed material + size/alpha/sort/flip
	 * from it. Browse index stays at the normal session position so Scroll/Tab leave inheritance cleanly.
	 */
	bool TryInheritFromSelectedDecal();
	/** Seeds material + size/alpha/sort/flip from a scene decal; false if it has no decal material. */
	bool InheritFromDecal(const UDecalComponent* SourceDecal);
	/**
	 * The scene decal visible at the cursor: the surface point under the cursor (nearest geometry, so
	 * nothing behind a wall) must lie inside the decal's projection box. Of several, the one drawn on
	 * top wins (highest SortOrder, then the smallest box). This is what MMB inherits from.
	 */
	ADecalActor* FindSceneDecalUnderCursor(FEditorViewportClient* ViewportClient) const;
	/** Clears selection-inherit; optionally restores ActiveMaterial from the browse baseline. */
	void ClearSelectionInherit(bool bRestoreBrowseMaterial);
	void RememberActiveDecalIndex();
	void PersistSessionBrowseSelection();
	void CycleCollection(int32 Delta);
	void CycleDecalInCollection(int32 Delta);

	void CommitPlacement();
	void CancelPlacement();
	void EnsurePreviewActor();
	void DestroyPreviewActor();
	void SetPreviewVisible(bool bVisible);
	void ShowHudOverlay();
	void HideHudOverlay();
	bool HandleMouseWheelInput(FEditorViewportClient* ViewportClient, int32 WheelDelta);
	bool AdjustActiveDecalSize(int32 WheelDelta);
	bool AdjustProjectionDepth(int32 WheelDelta);
	void ResetPlacementTweaks();
	void ApplyPostPlacementRotation();
	float GetRotationIntervalRadians() const;
	float GetActiveProjectionDepth() const;
	bool IsSpaceHeld(const FEditorViewportClient* ViewportClient) const;
	bool IsWHeld(const FEditorViewportClient* ViewportClient) const;
	bool IsTabHeld(const FEditorViewportClient* ViewportClient) const;
	bool IsCenteredFor(const FEditorViewportClient* ViewportClient) const;
	void RefreshSceneDecalCache(bool bForce = false);
	void DrawSceneDecalTicks(const FSceneView* View, FPrimitiveDrawInterface* PDI) const;
	void DrawPreviewBounds(const FSceneView* View, FPrimitiveDrawInterface* PDI) const;
	void DrawStampFlash(const FSceneView* View, FPrimitiveDrawInterface* PDI) const;
	/** The decal MMB just inherited from: Highlight corner ticks + outline settling back to nothing. */
	void DrawPickFlash(const FSceneView* View, FPrimitiveDrawInterface* PDI) const;
	/** Screen-space pick burst at the MMB click (the Material Clipboard's pick ring). */
	void DrawPickBurst(FCanvas* Canvas) const;
	/** Drag-modifier guides in the decal plane: Ctrl rotation arc, Shift aspect diagonal. */
	void DrawModifierGuides(const FSceneView* View, FPrimitiveDrawInterface* PDI) const;
	/** Screen-space Space-move glyph at the preview center. */
	void DrawMoveGlyph(const FSceneView* View, FCanvas* Canvas) const;

	/** Fading cursor label with the active decal name and its category / position. */
	void ShowBrowseLabel();
	/** Fading cursor label for a hotkey / scroll command result ("Flip H on", "Depth 128 cm"). */
	void ShowActionLabel(const FText& Text);
	/** The preview outline flashes Highlight and settles: a value changed that the pose alone doesn't show. */
	void PingPreviewOutline();
	/** A quick Alt press and release with nothing in between toggles Centered. Never consumes input. */
	void TrackAltTap(const FKey& Key, EInputEvent Event);

	float GetActiveMaterialAspectRatio() const;
	FString GetActiveCategoryLabel() const;
	FString GetActiveDecalLabel() const;
	FVector GetCurrentInPlaneSize() const;

	/** Outliner folder for the next stamp (Decals/<category> or Decals), or None when nesting is off. */
	FName GetPlacedDecalFolderPath() const;

	UMaterialInterface* LoadDecalMaterial(const FSoftObjectPath& AssetPath) const;
	bool TrySwitchToCollectionBrowsing();
	/**
	 * Hover / pre-threshold preview pose. Corner-anchored (cursor at visual top-left) unless
	 * bCentered, which centers it on the hit so a center-scale drag starts without a jump.
	 */
	FInteractiveDecalPlacementResult MakeHoverPlacement(const FInteractiveDecalTangentFrame& Frame, bool bCentered) const;

	/**
	 * Fit Surface post-pass on a flat hover / drag pose: samples the surface at the footprint's nine
	 * points and re-orients the pose to their mean (see FitPlacementToSurface). PinPoint is the rect
	 * point that must stay under the cursor. Returns Flat when the toggle is off.
	 */
	FInteractiveDecalPlacementResult FitToSurfaceIfEnabled(FEditorViewportClient* ViewportClient, const FInteractiveDecalPlacementResult& Flat, const FVector& PinPoint);

	/** Session size (the value click-stamps, Shift+Scroll and W+Scroll build on) and the preview with it. */
	void SetSessionSize(const FVector& Size);
	/** Re-poses the preview after a value edit, for whichever state is active. */
	void RefreshPreviewPose();

	/**
	 * The only writer of State. A drag owns every mouse button and the camera: entering Dragging
	 * suspends the ITF camera interactions (dolly, fly keys, orbit...) and leaving it resumes them.
	 */
	void SetState(EInteractiveDecalPlacementState NewState, FEditorViewportClient* ViewportClient = nullptr);

	EInteractiveDecalPlacementState State = EInteractiveDecalPlacementState::Inactive;
	ProWorkflowTools::FCameraInteractionsSuspension DragCameraSuspension;
	EDecalSourceMode SourceMode = EDecalSourceMode::ContentBrowser;

	int32 ActiveCollectionIndex = INDEX_NONE;
	int32 ActiveDecalIndex = 0;
	TArray<FSoftObjectPath> ActiveCollectionDecals;

	FInteractiveDecalTangentFrame AnchorFrame;
	bool bHasAnchor = false;

	/** Surface point under the cursor while hovering; the preview's corner or center sits here. */
	FVector HoverAnchorPoint = FVector::ZeroVector;

	ProWorkflowTools::CursorLabel::FFadingLabel FeedbackLabel;
	/** Alt press time while it can still count as a tap; reset by any other press. */
	double AltTapStartSeconds = -1.0;
	/** Shift aspect lock as applied by the last drag update. */
	bool bAspectLocked = false;
	TWeakObjectPtr<ADecalActor> StampFlashActor;
	double StampFlashStartSeconds = -1.0;
	/** Last W+Scroll depth edit; the depth guide highlights then settles from this time. */
	double DepthGuideHighlightStartSeconds = -1.0;
	/** Last flip / opacity / sort / reset / inherit; the preview outline highlights then settles from this time. */
	double PreviewPingStartSeconds = -1.0;
	/** MMB pick feedback: the inherited decal and the click pixel, from PickFlashStartSeconds. */
	TWeakObjectPtr<ADecalActor> PickFlashActor;
	double PickFlashStartSeconds = -1.0;
	FIntPoint PickFlashPixel = FIntPoint::ZeroValue;

	/** Screen position where LMB went down; used to distinguish click from drag. */
	FIntPoint DragStartScreenPos = FIntPoint::ZeroValue;
	/** True once the mouse moved past the click threshold and drag-sizing began. */
	bool bDragConfirmed = false;

	/** Space-held panning: the decal keeps its size and follows the mouse. */
	bool bSpacePanning = false;

	/** Preview yielded tracking to the viewport (Alt orbit / dolly / track, RMB fly); the preview hides until it ends. */
	bool bCameraTracking = false;
	FVector SpacePanFrozenDragVector = FVector::ZeroVector;
	FVector LastDragPlanePoint = FVector::ZeroVector;

	/** In-plane rotation applied to the hover preview / click stamps (Ctrl+Scroll). */
	float PreviewRotationRad = 0.0f;
	/** In-plane rotation of the current drag (seeded from PreviewRotationRad, changed by Ctrl-rotate). */
	float DragRotationRad = 0.0f;

	/** Ctrl-held rotate/uniform-scale around the anchor corner. */
	bool bCtrlRotating = false;
	float CtrlStartMouseAngleRad = 0.0f;
	float RotationAtCtrlStartRad = 0.0f;

	/** When enabled, each placement picks a new random in-plane rotation for the next stamp. */
	bool bRandomRotationEnabled = false;

	/** Horizontal flip (X; mirrors the actor's Z scale). */
	bool bFlipHorizontal = false;
	/** Vertical flip (Z; mirrors the actor's Y scale). */
	bool bFlipVertical = false;

	/** Tab held (consumed in InputKey). */
	bool bTabModifierHeld = false;

	/** W held (consumed in InputKey). */
	bool bWModifierHeld = false;

	/** Scene ADecalActors for grey corner ticks (refreshed periodically). */
	TArray<TWeakObjectPtr<ADecalActor>> CachedSceneDecals;
	double SceneDecalCacheTimeSeconds = 0.0;
	static constexpr float SceneDecalCacheRefreshInterval = 1.0f;
	static constexpr float ProjectionDepthScrollStepCm = 1.0f;

	/** Session-only: grey corner ticks on existing world decals (default ON). */
	bool bShowSceneBoundsTicks = true;

	/** Decal Color alpha for the next placement (0-1). */
	float PreviewDecalColorAlpha = 1.0f;

	/** Sort order for the next placement. */
	int32 PreviewSortOrder = 0;

	/**
	 * True while ActiveMaterial / size / alpha / sort came from the scene decal selected at placement start.
	 * Cleared on Backspace or when browsing (Scroll / Tab+Scroll).
	 */
	bool bInheritedFromSelection = false;

	/** Remembered half-extents (cm, unsigned) from the most recent placement for click-stamp reuse. */
	bool bHasLastPlacedSize = false;
	FVector LastPlacedDecalSize = FVector::ZeroVector;

	/** Surface points the last Fit Surface pass used; drawn while dragging. */
	TArray<FVector> FitSurfaceSamples;

	/** Skip redundant preview applies when hover/drag pose & props are unchanged. */
	bool bHasLastAppliedPreview = false;
	FTransform LastAppliedActorTransform = FTransform::Identity;
	FVector LastAppliedDecalSize = FVector::ZeroVector;
	float LastAppliedDecalColorAlpha = 1.0f;
	int32 LastAppliedSortOrder = 0;
	TWeakObjectPtr<UMaterialInterface> LastAppliedMaterial;
	bool LastAppliedFlipHorizontal = false;
	bool LastAppliedFlipVertical = false;

	/** True while this mode holds a shared transform-widget suppression. */
	bool bHoldingWidgetSuppression = false;

	static constexpr float DecalColorAlphaScrollStep = 0.0125f;

	TWeakObjectPtr<UMaterialInterface> ActiveMaterial;
	TWeakObjectPtr<ADecalActor> PreviewActor;
	TProWorkflowToolHudOverlay<SInteractiveDecalPlacementHud> HudOverlay;
	float CachedAspectRatio = 1.0f;
};

