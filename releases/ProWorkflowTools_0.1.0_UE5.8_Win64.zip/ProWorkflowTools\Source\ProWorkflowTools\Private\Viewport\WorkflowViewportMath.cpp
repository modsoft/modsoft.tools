// Copyright © 2026 Trey McNair. All rights reserved.

#include "Viewport/WorkflowViewportMath.h"

#include "ProWorkflowToolsEngineVersion.h"
#include "SceneView.h"

float ProWorkflowTools::GetScreenSpaceUniformScale(const FSceneView* View, const FVector& WorldLocation)
{
	if (!View)
	{
		return 1.0f;
	}

	const float W = View->WorldToScreen(WorldLocation).W;
	const float Width = static_cast<float>(View->UnscaledViewRect.Width());
#if PWT_UE_5_8_OR_LATER
	const float ProjScale = View->ViewMatrices.GetViewToClip().M[0][0];
#else
	const float ProjScale = View->ViewMatrices.GetProjectionMatrix().M[0][0];
#endif
	if (FMath::Abs(W) < UE_KINDA_SMALL_NUMBER || Width < UE_KINDA_SMALL_NUMBER || FMath::Abs(ProjScale) < UE_KINDA_SMALL_NUMBER)
	{
		return 1.0f;
	}

	return FMath::Abs(W) * (4.0f / Width / ProjScale);
}
