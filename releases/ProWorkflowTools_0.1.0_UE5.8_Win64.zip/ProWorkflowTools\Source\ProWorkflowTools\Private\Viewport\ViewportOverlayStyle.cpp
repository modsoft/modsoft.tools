// Copyright © 2026 Trey McNair. All rights reserved.

#include "Viewport/ViewportOverlayStyle.h"

#include "ProWorkflowToolsSettings.h"
#include "SceneManagement.h"

namespace ProWorkflowTools::OverlayStyle
{
	FLinearColor Accent()
	{
		return GetDefault<UProWorkflowToolsSettings>()->OverlayAccentColor.CopyWithNewOpacity(1.0f);
	}

	void DrawDashedLine(
		FPrimitiveDrawInterface* PDI,
		const FVector& Start, const FVector& End,
		const FLinearColor& Color, const uint8 DepthPriority, const float ThicknessPx,
		const float DashLengthCm, const float GapLengthCm)
	{
		if (!PDI)
		{
			return;
		}

		const FVector Delta = End - Start;
		const double Length = Delta.Size();
		if (Length < KINDA_SMALL_NUMBER)
		{
			return;
		}

		const FVector Direction = Delta / Length;
		const double Dash = FMath::Max(static_cast<double>(DashLengthCm), KINDA_SMALL_NUMBER);
		const double Period = Dash + FMath::Max(static_cast<double>(GapLengthCm), 0.0);
		for (double Travel = 0.0; Travel < Length; Travel += Period)
		{
			const FVector From = Start + Direction * Travel;
			const FVector To = Start + Direction * FMath::Min(Travel + Dash, Length);
			PDI->DrawTranslucentLine(From, To, Color, DepthPriority, ThicknessPx, 0.0f, /*bScreenSpace=*/true);
		}
	}

	void DrawOutline(
		FPrimitiveDrawInterface* PDI,
		const FVector& C00, const FVector& C10, const FVector& C11, const FVector& C01,
		const FLinearColor& Color, const uint8 DepthPriority, const float ThicknessPx)
	{
		if (!PDI)
		{
			return;
		}
		PDI->DrawTranslucentLine(C00, C10, Color, DepthPriority, ThicknessPx, 0.0f, /*bScreenSpace=*/true);
		PDI->DrawTranslucentLine(C10, C11, Color, DepthPriority, ThicknessPx, 0.0f, /*bScreenSpace=*/true);
		PDI->DrawTranslucentLine(C11, C01, Color, DepthPriority, ThicknessPx, 0.0f, /*bScreenSpace=*/true);
		PDI->DrawTranslucentLine(C01, C00, Color, DepthPriority, ThicknessPx, 0.0f, /*bScreenSpace=*/true);
	}

	void DrawCornerTicks(
		FPrimitiveDrawInterface* PDI,
		const FVector& C00, const FVector& C10, const FVector& C11, const FVector& C01,
		const FLinearColor& Color, const uint8 DepthPriority, const float ThicknessPx,
		const float TickFraction, const float MaxTickLengthCm)
	{
		if (!PDI)
		{
			return;
		}

		auto DrawArm = [&](const FVector& Corner, const FVector& Along)
		{
			const FVector Edge = Along - Corner;
			const double Length = FMath::Min(Edge.Size() * TickFraction, static_cast<double>(MaxTickLengthCm));
			PDI->DrawTranslucentLine(Corner, Corner + Edge.GetSafeNormal() * Length, Color, DepthPriority, ThicknessPx, 0.0f, /*bScreenSpace=*/true);
		};

		DrawArm(C00, C10);
		DrawArm(C00, C01);
		DrawArm(C10, C00);
		DrawArm(C10, C11);
		DrawArm(C11, C10);
		DrawArm(C11, C01);
		DrawArm(C01, C00);
		DrawArm(C01, C11);
	}

	void DrawBoxCornerBrackets(
		FPrimitiveDrawInterface* PDI,
		const FVector& Center, const FVector& AxisX, const FVector& AxisY, const FVector& AxisZ, const FVector& Extent,
		const FLinearColor& Color, const uint8 DepthPriority, const float ThicknessPx,
		const float TickFraction, const float MaxTickLengthCm)
	{
		if (!PDI)
		{
			return;
		}

		const FVector Axes[3] = { AxisX * Extent.X, AxisY * Extent.Y, AxisZ * Extent.Z };
		for (int32 Corner = 0; Corner < 8; ++Corner)
		{
			const double Signs[3] = { (Corner & 1) ? 1.0 : -1.0, (Corner & 2) ? 1.0 : -1.0, (Corner & 4) ? 1.0 : -1.0 };
			const FVector Point = Center + Axes[0] * Signs[0] + Axes[1] * Signs[1] + Axes[2] * Signs[2];
			for (int32 Axis = 0; Axis < 3; ++Axis)
			{
				// Arms point inward along each edge leaving the corner.
				const FVector Edge = Axes[Axis] * (-2.0 * Signs[Axis]);
				const double Length = FMath::Min(Edge.Size() * TickFraction, static_cast<double>(MaxTickLengthCm));
				PDI->DrawTranslucentLine(Point, Point + Edge.GetSafeNormal() * Length, Color, DepthPriority, ThicknessPx, 0.0f, /*bScreenSpace=*/true);
			}
		}
	}
}
