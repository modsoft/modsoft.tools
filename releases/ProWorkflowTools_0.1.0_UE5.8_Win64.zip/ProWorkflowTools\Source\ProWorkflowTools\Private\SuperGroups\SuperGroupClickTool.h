// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "Viewport/WorkflowViewportTool.h"

/**
 * Double-click a group member to enter its group (Double-Click to Enter Groups). Outside group edit
 * that is the member's root group; inside, the nested group directly under the one being edited.
 */
class FSuperGroupClickTool : public FWorkflowViewportTool
{
public:
	virtual bool HandleClick(FEditorViewportClient* ViewportClient, HHitProxy* HitProxy, const FViewportClick& Click) override;
};
