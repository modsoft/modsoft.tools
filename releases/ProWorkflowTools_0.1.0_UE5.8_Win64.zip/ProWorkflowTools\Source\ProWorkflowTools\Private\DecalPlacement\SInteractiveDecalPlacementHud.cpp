// Copyright © 2026 Trey McNair. All rights reserved.

#include "SInteractiveDecalPlacementHud.h"

#include "EditorModeManager.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"
#include "Input/Reply.h"
#include "InteractiveDecalPlacementCollectionUtils.h"
#include "InteractiveDecalPlacementEdMode.h"
#include "Styling/AppStyle.h"
#include "UI/ProWorkflowToolHudTypes.h"
#include "UI/SProWorkflowToolHud.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SCheckBox.h"
#include "Widgets/Input/SComboButton.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Layout/SWrapBox.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/Text/STextBlock.h"

#define LOCTEXT_NAMESPACE "InteractiveDecalPlacementHud"

namespace InteractiveDecalPlacementHud
{
	const FLinearColor MutedText(0.65f, 0.65f, 0.65f, 1.0f);
	const FLinearColor QuietText(0.78f, 0.82f, 0.86f, 1.0f);

	FSlateFontInfo MakeScaledFont(const FName StyleName, const float SizeScale)
	{
		FSlateFontInfo Font = FAppStyle::GetFontStyle(StyleName);
		Font.Size = FMath::Max(1, FMath::RoundToInt(static_cast<float>(Font.Size) * SizeScale) + 1);
		return Font;
	}
}

/** Typed HUD values. Units and symbols the HUD itself shows (cm, °, %) are accepted and ignored. */
namespace HudValueParse
{
	bool ParseNumber(const FString& Text, float& OutValue)
	{
		FString Cleaned = Text;
		Cleaned.ReplaceInline(TEXT("cm"), TEXT(""), ESearchCase::IgnoreCase);
		Cleaned.ReplaceInline(TEXT("°"), TEXT(""));
		Cleaned.ReplaceInline(TEXT("%"), TEXT(""));
		Cleaned.TrimStartAndEndInline();
		return !Cleaned.IsEmpty() && LexTryParseString(OutValue, *Cleaned) && FMath::IsFinite(OutValue);
	}

	/** "0.75", "75%" and "75" all mean 0.75. */
	bool ParseAlpha(const FString& Text, float& OutAlpha)
	{
		if (!ParseNumber(Text, OutAlpha))
		{
			return false;
		}
		if (Text.Contains(TEXT("%")) || OutAlpha > 1.0f)
		{
			OutAlpha /= 100.0f;
		}
		return true;
	}

	/** "256 × 128", "256x128", "256, 128" or "256 128". One number is the width; OutHeight is then 0. */
	bool ParseSize(const FString& Text, float& OutWidth, float& OutHeight)
	{
		FString Cleaned = Text;
		Cleaned.ReplaceInline(TEXT("cm"), TEXT(""), ESearchCase::IgnoreCase);
		Cleaned.ReplaceInline(TEXT("×"), TEXT(" "));
		Cleaned.ReplaceInline(TEXT("x"), TEXT(" "), ESearchCase::IgnoreCase);
		Cleaned.ReplaceInline(TEXT(","), TEXT(" "));

		TArray<FString> Parts;
		Cleaned.ParseIntoArrayWS(Parts);
		if (Parts.IsEmpty() || Parts.Num() > 2)
		{
			return false;
		}

		OutHeight = 0.0f;
		return ParseNumber(Parts[0], OutWidth)
			&& (Parts.Num() == 1 || ParseNumber(Parts[1], OutHeight))
			&& OutWidth > 0.0f && OutHeight >= 0.0f;
	}
}

void SInteractiveDecalPlacementHud::Construct(const FArguments& InArgs)
{
	SetVisibility(EVisibility::SelfHitTestInvisible);

	const TSharedRef<SProWorkflowToolHud> Hud = SNew(SProWorkflowToolHud)
		.bPanelHitTestable(true)
		.Footer(MakeCollectionsButton())
		.Model_Lambda([this]()
		{
			return BuildHudModel();
		});

	ToolHud = Hud;

	ChildSlot
	[
		Hud
	];
}

bool SInteractiveDecalPlacementHud::IsPointerOverPanel() const
{
	return GetVisibility().IsVisible() && ToolHud.IsValid() && ToolHud->IsPointerOverPanel();
}

FProWorkflowToolHudModel SInteractiveDecalPlacementHud::BuildHudModel() const
{
	FProWorkflowToolHudModel Model;
	Model.Title = LOCTEXT("DecalHudTitle", "Interactive Decal Placement");

	const FInteractiveDecalPlacementEdMode* Mode = GetPlacementMode();
	if (!Mode)
	{
		return Model;
	}

	FProWorkflowHudField& CategoryField = Model.Fields.Add_GetRef(MakeHudTextField(
		TEXT("Category"),
		FText::GetEmpty(),
		FText::FromString(Mode->GetHudCategoryName()),
		90.0f,
		false,
		true,
		false,
		true));
	if (!InteractiveDecalPlacement::GetBrowseCategories().IsEmpty())
	{
		CategoryField.OnGetMenu = [this]() { return MakeCategoryMenu(); };
	}

	FProWorkflowHudField& DecalField = Model.Fields.Add_GetRef(MakeHudTextField(
		TEXT("Decal"),
		FText::GetEmpty(),
		FText::FromString(Mode->GetHudDecalName()),
		160.0f,
		true,
		false,
		true,
		true));
	if (!Mode->GetHudCollectionDecals().IsEmpty())
	{
		DecalField.OnGetMenu = [this]() { return MakeDecalMenu(); };
	}

	int32 IndexOneBased = 0;
	int32 Count = 0;
	FString IndexText = TEXT("—");
	if (Mode->TryGetHudDecalIndex(IndexOneBased, Count))
	{
		IndexText = FString::Printf(TEXT("%d / %d"), IndexOneBased, Count);
	}
	Model.Fields.Add_GetRef(MakeHudTextField(
		TEXT("Index"),
		FText::GetEmpty(),
		FText::FromString(IndexText),
		48.0f,
		false,
		true)).bLowPriority = true;

	// Numeric values are click-to-edit; each commit goes through the same setter as its scroll binding.
	const FVector Size = Mode->GetHudInPlaneSize();
	Model.Fields.Add_GetRef(MakeHudTextField(
		TEXT("Size"),
		FText::GetEmpty(),
		FText::FromString(FString::Printf(TEXT("%.0f × %.0f"), FMath::Abs(Size.Z), FMath::Abs(Size.Y))),
		72.0f,
		false,
		false,
		true)).OnCommitText = [this](const FString& Text)
	{
		float Width = 0.0f;
		float Height = 0.0f;
		if (FInteractiveDecalPlacementEdMode* Mode = GetPlacementMode(); Mode && HudValueParse::ParseSize(Text, Width, Height))
		{
			Mode->SetHudInPlaneSize(Width, Height);
		}
	};

	FProWorkflowHudField& DepthField = Model.Fields.Add_GetRef(MakeHudTextField(
		TEXT("Depth"),
		LOCTEXT("DecalHudDepth", "Depth"),
		FText::FromString(FString::Printf(TEXT("%.0f"), Mode->GetHudProjectionDepth())),
		36.0f));
	DepthField.bLowPriority = true;
	DepthField.OnCommitText = [this](const FString& Text)
	{
		float Depth = 0.0f;
		if (FInteractiveDecalPlacementEdMode* Mode = GetPlacementMode(); Mode && HudValueParse::ParseNumber(Text, Depth))
		{
			Mode->SetHudProjectionDepth(Depth);
		}
	};

	Model.Fields.Add_GetRef(MakeHudTextField(
		TEXT("Angle"),
		FText::GetEmpty(),
		FText::FromString(FString::Printf(TEXT("%.0f°"), Mode->GetHudAngleDegrees())),
		36.0f)).OnCommitText = [this](const FString& Text)
	{
		float Degrees = 0.0f;
		if (FInteractiveDecalPlacementEdMode* Mode = GetPlacementMode(); Mode && HudValueParse::ParseNumber(Text, Degrees))
		{
			Mode->SetHudAngleDegrees(Degrees);
		}
	};

	FProWorkflowHudField& AlphaField = Model.Fields.Add_GetRef(MakeHudTextField(
		TEXT("Alpha"),
		LOCTEXT("DecalHudAlpha", "Alpha"),
		FText::FromString(FString::Printf(TEXT("%.2f"), Mode->GetHudAlpha())),
		36.0f));
	AlphaField.bLowPriority = true;
	AlphaField.OnCommitText = [this](const FString& Text)
	{
		float Alpha = 0.0f;
		if (FInteractiveDecalPlacementEdMode* Mode = GetPlacementMode(); Mode && HudValueParse::ParseAlpha(Text, Alpha))
		{
			Mode->SetHudAlpha(Alpha);
		}
	};

	FProWorkflowHudField& SortField = Model.Fields.Add_GetRef(MakeHudTextField(
		TEXT("Sort"),
		LOCTEXT("DecalHudSort", "Sort"),
		FText::FromString(FString::Printf(TEXT("%d"), Mode->GetHudSortOrder())),
		28.0f));
	SortField.bLowPriority = true;
	SortField.OnCommitText = [this](const FString& Text)
	{
		float Sort = 0.0f;
		if (FInteractiveDecalPlacementEdMode* Mode = GetPlacementMode(); Mode && HudValueParse::ParseNumber(Text, Sort))
		{
			Mode->SetHudSortOrder(FMath::RoundToInt(Sort));
		}
	};

	Model.Fields.Add(MakeHudCheckField(
		TEXT("Random"),
		LOCTEXT("DecalHudRandom", "Random Rotation"),
		Mode->IsRandomRotationEnabled(),
		[this](const bool bChecked)
		{
			if (FInteractiveDecalPlacementEdMode* Mode = GetPlacementMode())
			{
				Mode->SetRandomRotationEnabled(bChecked);
			}
		},
		true));

	Model.Fields.Add(MakeHudCheckField(
		TEXT("Centered"),
		LOCTEXT("DecalHudCentered", "Centered"),
		Mode->IsCenteredPlacementEnabled(),
		[this](const bool bChecked)
		{
			if (FInteractiveDecalPlacementEdMode* Mode = GetPlacementMode())
			{
				Mode->SetCenteredPlacementEnabled(bChecked);
			}
		}));

	Model.Fields.Add(MakeHudCheckField(
		TEXT("FitSurface"),
		LOCTEXT("DecalHudFitSurface", "Fit Surface"),
		Mode->IsFitSurfaceEnabled(),
		[this](const bool bChecked)
		{
			if (FInteractiveDecalPlacementEdMode* Mode = GetPlacementMode())
			{
				Mode->SetFitSurfaceEnabled(bChecked);
			}
		}));

	Model.Fields.Add_GetRef(MakeHudCheckField(
		TEXT("Bounds"),
		LOCTEXT("DecalHudBounds", "Bounds"),
		Mode->IsShowSceneBoundsTicks(),
		[this](const bool bChecked)
		{
			if (FInteractiveDecalPlacementEdMode* Mode = GetPlacementMode())
			{
				Mode->SetShowSceneBoundsTicks(bChecked);
			}
		})).bLowPriority = true;

	// Row 1: mouse, modifiers and keys. Row 2: scroll bindings.
	AddHudKeycap(Model.Keycaps, LOCTEXT("DecalKeyLmb", "LMB"), LOCTEXT("DecalActPlace", "Place"));
	AddHudKeycap(Model.Keycaps, LOCTEXT("DecalKeyMmb", "MMB"), LOCTEXT("DecalActPick", "Pick Decal"));
	AddHudKeycap(Model.Keycaps, LOCTEXT("DecalKeyDrag", "Drag"), LOCTEXT("DecalActSize", "Size"));
	AddHudKeycap(Model.Keycaps, LOCTEXT("DecalKeySpace", "Space"), LOCTEXT("DecalActMove", "Move"));
	AddHudKeycap(Model.Keycaps, LOCTEXT("DecalKeyCtrl", "Ctrl"), LOCTEXT("DecalActRotate", "Rotate"));
	AddHudKeycap(Model.Keycaps, LOCTEXT("DecalKeyShift", "Shift"), LOCTEXT("DecalActUniform", "Uniform"));
	AddHudKeycap(Model.Keycaps, LOCTEXT("DecalKeyAlt", "Alt"), LOCTEXT("DecalActCenter", "Toggle Pivot"));
	AddHudKeycap(Model.Keycaps, LOCTEXT("DecalKeyR", "R"), LOCTEXT("DecalActRandom", "Random Rotation"));
	AddHudKeycap(Model.Keycaps, LOCTEXT("DecalKeyX", "X"), LOCTEXT("DecalActFlipH", "Flip H"));
	AddHudKeycap(Model.Keycaps, LOCTEXT("DecalKeyZ", "Z"), LOCTEXT("DecalActFlipV", "Flip V"));
	AddHudKeycap(Model.Keycaps, LOCTEXT("DecalKeyC", "C"), LOCTEXT("DecalActFitSurface", "Fit Surface"));
	AddHudKeycap(Model.Keycaps, LOCTEXT("DecalKeyBackspace", "Backspace"), LOCTEXT("DecalActReset", "Reset"));
	AddHudKeycap(Model.Keycaps, LOCTEXT("DecalKeyScroll", "Scroll"), LOCTEXT("DecalActDecal", "Decal"), /*bNewRow=*/true);
	AddHudKeycap(Model.Keycaps, LOCTEXT("DecalKeyTabScroll", "Tab+Scroll"), LOCTEXT("DecalActCategory", "Category"));
	AddHudKeycap(Model.Keycaps, LOCTEXT("DecalKeyShiftScroll", "Shift+Scroll"), LOCTEXT("DecalActScrollSize", "Size"));
	AddHudKeycap(Model.Keycaps, LOCTEXT("DecalKeyCtrlScroll", "Ctrl+Scroll"), LOCTEXT("DecalActScrollRotate", "Rotate"));
	AddHudKeycap(Model.Keycaps, LOCTEXT("DecalKeyWScroll", "W+Scroll"), LOCTEXT("DecalActDepth", "Depth"));
	AddHudKeycap(Model.Keycaps, LOCTEXT("DecalKeyTScroll", "T+Scroll"), LOCTEXT("DecalActAlpha", "Alpha"));
	AddHudKeycap(Model.Keycaps, LOCTEXT("DecalKeySScroll", "S+Scroll"), LOCTEXT("DecalActSort", "Sort"));
	AddHudKeycap(Model.Keycaps, LOCTEXT("DecalKeyEsc", "Esc"), LOCTEXT("DecalActExit", "Exit"));

	return Model;
}

TSharedRef<SWidget> SInteractiveDecalPlacementHud::MakeCollectionsButton() const
{
	using namespace InteractiveDecalPlacementHud;

	const FSlateFontInfo LabelFont = MakeScaledFont("SmallText", 1.0f);

	return SNew(SComboButton)
		.ButtonStyle(FAppStyle::Get(), "SimpleButton")
		.ContentPadding(FMargin(4.0f, 1.0f))
		.HasDownArrow(true)
		.ForegroundColor(FSlateColor(MutedText))
		.ButtonContent()
		[
			SNew(STextBlock)
			.Font(LabelFont)
			.ColorAndOpacity(FSlateColor(MutedText))
			.Text(LOCTEXT("DecalHudCollections", "Collections"))
		]
		.MenuContent()
		[
			MakeCollectionsMenu()
		];
}

TSharedRef<SWidget> SInteractiveDecalPlacementHud::MakeCollectionsMenu() const
{
	using namespace InteractiveDecalPlacementHud;

	const FSlateFontInfo RowFont = MakeScaledFont("SmallText", 1.05f);
	const FSlateFontInfo LinkFont = MakeScaledFont("SmallText", 0.95f);

	TSharedRef<SVerticalBox> CheckboxList = SNew(SVerticalBox);

	TArray<InteractiveDecalPlacement::FDecalBrowseCategory> BrowseCategories;
	if (const FInteractiveDecalPlacementEdMode* Mode = GetPlacementMode())
	{
		Mode->GetSessionUiBrowseCategories(BrowseCategories);
	}

	if (BrowseCategories.IsEmpty())
	{
		CheckboxList->AddSlot()
			.AutoHeight()
			[
				SNew(STextBlock)
				.Font(RowFont)
				.ColorAndOpacity(FSlateColor(MutedText))
				.Text(LOCTEXT("DecalHudNoCollections", "No collections configured in settings."))
			];
	}
	else
	{
		TSharedRef<SWrapBox> CategoryWrap = SNew(SWrapBox)
			.UseAllottedSize(true)
			.InnerSlotPadding(FVector2D(10.0f, 4.0f));

		for (const InteractiveDecalPlacement::FDecalBrowseCategory& Category : BrowseCategories)
		{
			const FName CollectionName = Category.CollectionName;
			const FName DisplayName = Category.DisplayName.IsNone() ? CollectionName : Category.DisplayName;

			CategoryWrap->AddSlot()
				.Padding(FMargin(0.0f, 1.0f, 0.0f, 1.0f))
				[
					SNew(SCheckBox)
					.IsChecked_Lambda([this, CollectionName]()
					{
						if (const FInteractiveDecalPlacementEdMode* Mode = GetPlacementMode())
						{
							return Mode->IsSessionCollectionEnabled(CollectionName)
								? ECheckBoxState::Checked
								: ECheckBoxState::Unchecked;
						}
						return ECheckBoxState::Checked;
					})
					.OnCheckStateChanged_Lambda([this, CollectionName](const ECheckBoxState NewState)
					{
						if (FInteractiveDecalPlacementEdMode* Mode = GetPlacementMode())
						{
							Mode->SetSessionCollectionEnabled(
								CollectionName,
								NewState == ECheckBoxState::Checked);
						}
					})
					[
						SNew(STextBlock)
						.Font(RowFont)
						.ColorAndOpacity(FSlateColor(QuietText))
						.Text(FText::FromName(DisplayName))
					]
				];
		}

		CheckboxList->AddSlot()
			.AutoHeight()
			[
				CategoryWrap
			];

		CheckboxList->AddSlot()
			.AutoHeight()
			.Padding(FMargin(0.0f, 6.0f, 0.0f, 0.0f))
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
				.AutoWidth()
				.VAlign(VAlign_Center)
				[
					SNew(SButton)
					.ButtonStyle(FAppStyle::Get(), "SimpleButton")
					.ContentPadding(FMargin(2.0f, 0.0f))
					.OnClicked_Lambda([this]()
					{
						if (FInteractiveDecalPlacementEdMode* Mode = GetPlacementMode())
						{
							Mode->SetAllSessionCollectionsEnabled(true);
						}
						return FReply::Handled();
					})
					[
						SNew(STextBlock)
						.Font(LinkFont)
						.ColorAndOpacity(FSlateColor(QuietText))
						.Text(LOCTEXT("DecalHudSelectAll", "Select All"))
					]
				]
				+ SHorizontalBox::Slot()
				.AutoWidth()
				.VAlign(VAlign_Center)
				.Padding(FMargin(10.0f, 0.0f, 0.0f, 0.0f))
				[
					SNew(SButton)
					.ButtonStyle(FAppStyle::Get(), "SimpleButton")
					.ContentPadding(FMargin(2.0f, 0.0f))
					.OnClicked_Lambda([this]()
					{
						if (FInteractiveDecalPlacementEdMode* Mode = GetPlacementMode())
						{
							Mode->SetAllSessionCollectionsEnabled(false);
						}
						return FReply::Handled();
					})
					[
						SNew(STextBlock)
						.Font(LinkFont)
						.ColorAndOpacity(FSlateColor(QuietText))
						.Text(LOCTEXT("DecalHudSelectNone", "Select None"))
					]
				]
			];
	}

	return SNew(SBox)
		.MinDesiredWidth(220.0f)
		.MaxDesiredWidth(360.0f)
		.Padding(FMargin(8.0f, 6.0f))
		[
			CheckboxList
		];
}

TSharedRef<SWidget> SInteractiveDecalPlacementHud::MakeCategoryMenu() const
{
	FMenuBuilder MenuBuilder(/*bInShouldCloseWindowAfterMenuSelection=*/true, nullptr);

	const TArray<InteractiveDecalPlacement::FDecalBrowseCategory>& Categories = InteractiveDecalPlacement::GetBrowseCategories();
	for (int32 CategoryIndex = 0; CategoryIndex < Categories.Num(); ++CategoryIndex)
	{
		const InteractiveDecalPlacement::FDecalBrowseCategory& Category = Categories[CategoryIndex];
		const FName DisplayName = Category.DisplayName.IsNone() ? Category.CollectionName : Category.DisplayName;
		MenuBuilder.AddMenuEntry(
			FText::FromName(DisplayName),
			FText::GetEmpty(),
			FSlateIcon(),
			FUIAction(
				FExecuteAction::CreateLambda([this, CategoryIndex]()
				{
					if (FInteractiveDecalPlacementEdMode* Mode = GetPlacementMode())
					{
						Mode->SelectBrowseCategory(CategoryIndex);
					}
				}),
				FCanExecuteAction(),
				FIsActionChecked::CreateLambda([this, CategoryIndex]()
				{
					const FInteractiveDecalPlacementEdMode* Mode = GetPlacementMode();
					return Mode && Mode->GetHudCategoryIndex() == CategoryIndex;
				})),
			NAME_None,
			EUserInterfaceActionType::RadioButton);
	}

	return MenuBuilder.MakeWidget();
}

TSharedRef<SWidget> SInteractiveDecalPlacementHud::MakeDecalMenu() const
{
	FMenuBuilder MenuBuilder(/*bInShouldCloseWindowAfterMenuSelection=*/true, nullptr);

	const FInteractiveDecalPlacementEdMode* Mode = GetPlacementMode();
	const TArray<FSoftObjectPath> Decals = Mode ? Mode->GetHudCollectionDecals() : TArray<FSoftObjectPath>();
	int32 CurrentIndex = INDEX_NONE;
	int32 Count = 0;
	if (Mode && Mode->TryGetHudDecalIndex(CurrentIndex, Count))
	{
		--CurrentIndex;
	}

	for (int32 DecalIndex = 0; DecalIndex < Decals.Num(); ++DecalIndex)
	{
		MenuBuilder.AddMenuEntry(
			FText::FromString(Decals[DecalIndex].GetAssetName()),
			FText::FromString(Decals[DecalIndex].GetLongPackageName()),
			FSlateIcon(),
			FUIAction(
				FExecuteAction::CreateLambda([this, DecalIndex]()
				{
					if (FInteractiveDecalPlacementEdMode* PlacementMode = GetPlacementMode())
					{
						PlacementMode->SelectDecal(DecalIndex);
					}
				}),
				FCanExecuteAction(),
				FIsActionChecked::CreateLambda([CurrentIndex, DecalIndex]()
				{
					return CurrentIndex == DecalIndex;
				})),
			NAME_None,
			EUserInterfaceActionType::RadioButton);
	}

	return MenuBuilder.MakeWidget();
}

FInteractiveDecalPlacementEdMode* SInteractiveDecalPlacementHud::GetPlacementMode() const
{
	return static_cast<FInteractiveDecalPlacementEdMode*>(
		GLevelEditorModeTools().GetActiveMode(FInteractiveDecalPlacementEdMode::EM_InteractiveDecalPlacement));
}

#undef LOCTEXT_NAMESPACE
