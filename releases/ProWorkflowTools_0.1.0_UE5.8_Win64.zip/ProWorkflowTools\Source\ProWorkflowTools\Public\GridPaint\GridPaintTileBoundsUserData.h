// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "Engine/AssetUserData.h"
#include "GridPaintTileBoundsUserData.generated.h"

/**
 * Per-mesh tile cell AABB for Actor Grid Paint (mesh-local space, same as UStaticMesh bounds).
 * Written when committing bounds edit (B); read on paint-mode enter.
 */
UCLASS()
class PROWORKFLOWTOOLS_API UGridPaintTileBoundsUserData : public UAssetUserData
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, Category = "Grid Paint")
	FVector BoundsMin = FVector::ZeroVector;

	UPROPERTY(EditAnywhere, Category = "Grid Paint")
	FVector BoundsMax = FVector::ZeroVector;

	FBox GetBox() const
	{
		return FBox(BoundsMin, BoundsMax);
	}

	void SetBox(const FBox& Box)
	{
		BoundsMin = Box.Min;
		BoundsMax = Box.Max;
	}
};
