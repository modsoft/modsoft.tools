// Copyright © 2026 Trey McNair. All rights reserved.

#include "DecalPlacement/InteractiveDecalPlacementCommands.h"

#define LOCTEXT_NAMESPACE "InteractiveDecalPlacementCommands"

void FInteractiveDecalPlacementCommands::RegisterCommands()
{
	UI_COMMAND(
		StartPlacement,
		"Interactive Decal Placement",
		"Enter Interactive Decal Placement; Esc exits.",
		EUserInterfaceActionType::Button,
		FInputChord(EKeys::J));
}

#undef LOCTEXT_NAMESPACE

