// Copyright © 2026 Trey McNair. All rights reserved.

#include "ViewportSurfaceTrace.h"

#include "Components/InstancedStaticMeshComponent.h"
#include "Components/ModelComponent.h"
#include "Editor/EditorPerProjectUserSettings.h"
#include "EditorViewportClient.h"
#include "Engine/StaticMesh.h"
#include "EngineUtils.h"
#include "HModel.h"
#include "MaterialShared.h"
#include "Materials/MaterialInterface.h"
#include "StaticMeshResources.h"
#include "UnrealClient.h"

namespace ProWorkflowTools
{
	namespace
	{
		struct FWorldRay
		{
			FVector Origin;
			/** Unit length. */
			FVector Direction;
		};

		/** Two-sided Moller-Trumbore. OutT is the distance along the unit Direction. */
		bool IntersectTriangle(const FVector& Origin, const FVector& Direction, const FVector& A, const FVector& B, const FVector& C, double& OutT)
		{
			const FVector EdgeAB = B - A;
			const FVector EdgeAC = C - A;
			const FVector P = FVector::CrossProduct(Direction, EdgeAC);
			const double Det = FVector::DotProduct(EdgeAB, P);
			if (FMath::Abs(Det) <= UE_DOUBLE_SMALL_NUMBER)
			{
				return false;
			}

			const double InvDet = 1.0 / Det;
			const FVector S = Origin - A;
			const double U = FVector::DotProduct(S, P) * InvDet;
			if (U < 0.0 || U > 1.0)
			{
				return false;
			}

			const FVector Q = FVector::CrossProduct(S, EdgeAB);
			const double V = FVector::DotProduct(Direction, Q) * InvDet;
			if (V < 0.0 || U + V > 1.0)
			{
				return false;
			}

			OutT = FVector::DotProduct(EdgeAC, Q) * InvDet;
			return OutT > 0.0;
		}

		/** Keeps OutHit when this hit is nearer than InOutDistance (world units along the ray). */
		bool AcceptNearer(const FWorldRay& Ray, const FVector& Location, const FVector& Normal, double& InOutDistance, FViewportSurfaceHit& OutHit)
		{
			const double Distance = FVector::DotProduct(Location - Ray.Origin, Ray.Direction);
			if (Distance <= 0.0 || Distance >= InOutDistance)
			{
				return false;
			}
			InOutDistance = Distance;
			OutHit.Location = Location;
			OutHit.Normal = Normal;
			return true;
		}

		/** Nearest LOD0 render triangle of the component's mesh placed at Transform (component or instance, world space). */
		bool TraceMeshTriangles(const UStaticMeshComponent& Component, const FTransform& Transform, const FWorldRay& Ray, const bool bAllowTranslucent, double& InOutDistance, FViewportSurfaceHit& OutHit)
		{
			const UStaticMesh* Mesh = Component.GetStaticMesh();
			const FStaticMeshRenderData* RenderData = Mesh ? Mesh->GetRenderData() : nullptr;
			if (!RenderData || RenderData->LODResources.IsEmpty() || FMath::IsNearlyZero(Transform.GetDeterminant()))
			{
				return false;
			}

			const FStaticMeshLODResources& LOD = RenderData->LODResources[0];
			const FPositionVertexBuffer& Positions = LOD.VertexBuffers.PositionVertexBuffer;
			const FIndexArrayView Indices = LOD.IndexBuffer.GetArrayView();
			if (!Positions.GetVertexData() || Indices.Num() == 0)
			{
				return false;
			}

			const FVector LocalOrigin = Transform.InverseTransformPosition(Ray.Origin);
			const FVector LocalDirection = Transform.InverseTransformVector(Ray.Direction).GetSafeNormal();
			const FVector LocalEnd = LocalOrigin + LocalDirection * HALF_WORLD_MAX;
			if (LocalDirection.IsZero() || !FMath::LineBoxIntersection(Mesh->GetBounds().GetBox(), LocalOrigin, LocalEnd, LocalEnd - LocalOrigin))
			{
				return false;
			}

			double BestT = TNumericLimits<double>::Max();
			FVector BestA, BestB, BestC;
			for (const FStaticMeshSection& Section : LOD.Sections)
			{
				if (!bAllowTranslucent)
				{
					const UMaterialInterface* Material = Component.GetMaterial(Section.MaterialIndex);
					if (Material && IsTranslucentBlendMode(*Material))
					{
						continue;
					}
				}

				const uint32 SectionEnd = FMath::Min<uint32>(Section.FirstIndex + Section.NumTriangles * 3, Indices.Num());
				for (uint32 Index = Section.FirstIndex; Index + 2 < SectionEnd; Index += 3)
				{
					const FVector A(Positions.VertexPosition(Indices[Index]));
					const FVector B(Positions.VertexPosition(Indices[Index + 1]));
					const FVector C(Positions.VertexPosition(Indices[Index + 2]));
					double T;
					if (IntersectTriangle(LocalOrigin, LocalDirection, A, B, C, T) && T < BestT)
					{
						BestT = T;
						BestA = A;
						BestB = B;
						BestC = C;
					}
				}
			}

			if (BestT == TNumericLimits<double>::Max())
			{
				return false;
			}

			// World-space face normal, so non-uniform and mirrored scale stay correct.
			const FVector WorldA = Transform.TransformPosition(BestA);
			FVector Normal = FVector::CrossProduct(Transform.TransformPosition(BestB) - WorldA, Transform.TransformPosition(BestC) - WorldA).GetSafeNormal();
			if (FVector::DotProduct(Normal, Ray.Direction) > 0.0)
			{
				Normal = -Normal;
			}
			return AcceptNearer(Ray, Transform.TransformPosition(LocalOrigin + LocalDirection * BestT), Normal, InOutDistance, OutHit);
		}

		bool TraceComponentCollision(UPrimitiveComponent& Component, const FWorldRay& Ray, double& InOutDistance, FViewportSurfaceHit& OutHit)
		{
			const FVector End = Ray.Origin + Ray.Direction * WORLD_MAX;
			if (!FMath::LineBoxIntersection(Component.Bounds.GetBox(), Ray.Origin, End, End - Ray.Origin))
			{
				return false;
			}

			FHitResult Hit;
			const FCollisionQueryParams Params(SCENE_QUERY_STAT(ProWorkflowToolsSurfaceTrace), /*bTraceComplex=*/true);
			return Component.LineTraceComponent(Hit, Ray.Origin, End, Params)
				&& AcceptNearer(Ray, Hit.ImpactPoint, Hit.ImpactNormal, InOutDistance, OutHit);
		}

		bool TraceSurfaceAtPixelAlongRay(FViewport* Viewport, const FIntPoint& Pixel, const FWorldRay& Ray, FViewportSurfaceHit& OutHit)
		{
			HHitProxy* HitProxy = Viewport->GetHitProxy(Pixel.X, Pixel.Y);
			if (!HitProxy)
			{
				return false;
			}
	
			const bool bAllowTranslucent = GetDefault<UEditorPerProjectUserSettings>()->bAllowSelectTranslucent;
			double Distance = TNumericLimits<double>::Max();
	
			if (const HInstancedStaticMeshInstance* InstanceProxy = HitProxyCast<HInstancedStaticMeshInstance>(HitProxy))
			{
				FTransform InstanceTransform;
				return InstanceProxy->Component
					&& InstanceProxy->Component->GetInstanceTransform(InstanceProxy->InstanceIndex, InstanceTransform, /*bWorldSpace=*/true)
					&& TraceMeshTriangles(*InstanceProxy->Component, InstanceTransform, Ray, bAllowTranslucent, Distance, OutHit);
			}
	
			if (const HModel* ModelProxy = HitProxyCast<HModel>(HitProxy))
			{
				UModelComponent* ModelComponent = ModelProxy->GetModelComponent();
				return ModelComponent && TraceComponentCollision(*ModelComponent, Ray, Distance, OutHit);
			}
	
			const HActor* ActorProxy = HitProxyCast<HActor>(HitProxy);
			const UPrimitiveComponent* Component = ActorProxy ? ActorProxy->PrimComponent.Get() : nullptr;
			if (!Component)
			{
				return false;
			}
	
			// Without per-instance hit proxies, every instance shares the component's proxy.
			if (const UInstancedStaticMeshComponent* Instanced = Cast<UInstancedStaticMeshComponent>(Component))
			{
				bool bHit = false;
				for (int32 InstanceIndex = 0; InstanceIndex < Instanced->GetInstanceCount(); ++InstanceIndex)
				{
					FTransform InstanceTransform;
					if (Instanced->GetInstanceTransform(InstanceIndex, InstanceTransform, /*bWorldSpace=*/true))
					{
						bHit |= TraceMeshTriangles(*Instanced, InstanceTransform, Ray, bAllowTranslucent, Distance, OutHit);
					}
				}
				return bHit;
			}
	
			if (const UStaticMeshComponent* StaticMesh = Cast<UStaticMeshComponent>(Component))
			{
				return TraceMeshTriangles(*StaticMesh, StaticMesh->GetComponentTransform(), Ray, bAllowTranslucent, Distance, OutHit);
			}
	
			AActor* Owner = Component->GetOwner();
			if (!Owner)
			{
				return false;
			}
	
			bool bHit = false;
			Owner->ForEachComponent<UPrimitiveComponent>(/*bIncludeFromChildActors=*/false, [&](UPrimitiveComponent* Primitive)
			{
				bHit |= TraceComponentCollision(*Primitive, Ray, Distance, OutHit);
			});
			return bHit;
		}
	}

	bool TraceSurfaceUnderCursor(FEditorViewportClient* ViewportClient, FViewportSurfaceHit& OutHit)
	{
		FViewport* Viewport = ViewportClient ? ViewportClient->Viewport : nullptr;
		if (!Viewport)
		{
			return false;
		}

		const FViewportCursorLocation Cursor = ViewportClient->GetCursorWorldLocationFromMousePos();
		return TraceSurfaceAtPixelAlongRay(
			Viewport,
			FIntPoint(Viewport->GetMouseX(), Viewport->GetMouseY()),
			FWorldRay{ Cursor.GetOrigin(), Cursor.GetDirection() },
			OutHit);
	}

	bool TraceSurfaceAtPixel(FEditorViewportClient* ViewportClient, const FSceneView& View, const FIntPoint& Pixel, FViewportSurfaceHit& OutHit)
	{
		FViewport* Viewport = ViewportClient ? ViewportClient->Viewport : nullptr;
		if (!Viewport)
		{
			return false;
		}

		const FIntPoint Size = Viewport->GetSizeXY();
		if (Pixel.X < 0 || Pixel.Y < 0 || Pixel.X >= Size.X || Pixel.Y >= Size.Y)
		{
			return false;
		}

		const FViewportCursorLocation Cursor(&View, ViewportClient, Pixel.X, Pixel.Y);
		return TraceSurfaceAtPixelAlongRay(Viewport, Pixel, FWorldRay{ Cursor.GetOrigin(), Cursor.GetDirection() }, OutHit);
	}
}
