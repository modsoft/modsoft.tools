// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "CoreMinimal.h"

class FSceneView;

namespace ProWorkflowTools
{
	/** World units per widget unit at WorldLocation; the factor FWidget uses for constant pixel size. 1 without a view. */
	float GetScreenSpaceUniformScale(const FSceneView* View, const FVector& WorldLocation);
}
