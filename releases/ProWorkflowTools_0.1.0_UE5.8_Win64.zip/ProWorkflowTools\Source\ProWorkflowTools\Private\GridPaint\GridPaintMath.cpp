// Copyright © 2026 Trey McNair. All rights reserved.

#include "GridPaint/GridPaintMath.h"

FVector GridPaintMath::WorldToGrid(const FGridPaintContext& C, const FVector& W)
{
	const FVector L = C.GridRotation.UnrotateVector(W - C.PivotWorld);
	return FVector(L.X / C.CellSize.X, L.Y / C.CellSize.Y, L.Z / C.CellSize.Z);
}

FVector GridPaintMath::GridToWorld(const FGridPaintContext& C, const FIntVector& Cell)
{
	const FVector L(Cell.X * C.CellSize.X, Cell.Y * C.CellSize.Y, Cell.Z * C.CellSize.Z);
	return C.PivotWorld + C.GridRotation.RotateVector(L);
}

bool GridPaintMath::IsThinCellAxis(const FGridPaintContext& C, int32 Axis)
{
	if (Axis < 0 || Axis > 2)
	{
		return false;
	}
	const double MaxExtent = FMath::Max3(C.CellSize.X, C.CellSize.Y, C.CellSize.Z);
	const double RelThresh = MaxExtent * double(C.ThinAxisRelativeRatio);
	// max(absolute, relative×longest): absolute alone cannot catch a thick-but-flat wall when
	// the floor is set near zero; relative catches elongated kit pieces.
	return C.CellSize[Axis] < FMath::Max(double(C.ThinAxisFloorCm), RelThresh);
}

FIntVector GridPaintMath::GridCoordsToFootprintCell(
	const FGridPaintContext& C,
	const FVector& GridCoords,
	int32 PlaneAxis)
{
	const int32 AxisU = (PlaneAxis + 1) % 3;
	const int32 AxisV = (PlaneAxis + 2) % 3;

	FIntVector Cell = FIntVector::ZeroValue;

	// Overlay quads = GridToWorld(Cell) + MeshBoundsGridLocal Min/Max on the plane axes.
	// Map hits with the same footprint tiling: floor(G - BoundsMin/CellSize) per in-plane axis
	// (CellSize step preserved for flush modular placement). Pivot-centered RoundToInt would
	// misalign whenever the pivot is not the bounds center.
	const FBox& Bounds = C.MeshBoundsGridLocal;
	if (Bounds.IsValid)
	{
		const double MinU = Bounds.Min[AxisU] / C.CellSize[AxisU];
		const double MinV = Bounds.Min[AxisV] / C.CellSize[AxisV];
		Cell[AxisU] = FMath::FloorToInt32(GridCoords[AxisU] - MinU);
		Cell[AxisV] = FMath::FloorToInt32(GridCoords[AxisV] - MinV);
	}
	else
	{
		Cell[AxisU] = FMath::RoundToInt32(GridCoords[AxisU]);
		Cell[AxisV] = FMath::RoundToInt32(GridCoords[AxisV]);
	}

	// Plane layer stays on the source cell (0). Refuse stacking along any thin in-plane axis
	// (e.g. a rod's thin cross-section) even if the camera looks edge-on.
	for (int32 Axis = 0; Axis < 3; ++Axis)
	{
		if (Axis == PlaneAxis || IsThinCellAxis(C, Axis))
		{
			Cell[Axis] = 0;
		}
	}
	return Cell;
}

int32 GridPaintMath::PickPlaneAxis(const FGridPaintContext& C, const FVector& ViewDir, int32 PreferAxis)
{
	const FVector D = C.GridRotation.UnrotateVector(ViewDir);

	// Hysteresis so near-45° camera doesn't chatter. Margin 0.12 in |dot| space ≈ switch when the
	// new axis is ~40° from view and the old is ~50° (Schmitt gap around the 45° bisector).
	constexpr double PlaneAxisHysteresisMargin = 0.12;

	auto BestAxisByView = [&D](const int32* Candidates, int32 NumCandidates, int32 InPreferAxis) -> int32
	{
		int32 BestAxis = Candidates[0];
		double BestAbs = FMath::Abs(D[BestAxis]);
		for (int32 Index = 1; Index < NumCandidates; ++Index)
		{
			const int32 Axis = Candidates[Index];
			const double Abs = FMath::Abs(D[Axis]);
			if (Abs > BestAbs)
			{
				BestAxis = Axis;
				BestAbs = Abs;
			}
		}

		if (InPreferAxis == INDEX_NONE)
		{
			return BestAxis;
		}

		// Keep PreferAxis until another candidate clearly wins by the hysteresis margin.
		for (int32 Index = 0; Index < NumCandidates; ++Index)
		{
			if (Candidates[Index] == InPreferAxis)
			{
				const double PreferAbs = FMath::Abs(D[InPreferAxis]);
				if (BestAbs < PreferAbs + PlaneAxisHysteresisMargin)
				{
					return InPreferAxis;
				}
				break;
			}
		}
		return BestAxis;
	};

	// Prefer/force a thin CellSize axis as the plane normal so in-plane strokes cannot climb a
	// floor slab's thickness into a vertical stack. One thin → that axis. Two thin → pick the
	// thin axis most aligned with the view (in-plane keeps the thick axis + the other thin,
	// which GridCoordsToFootprintCell then clamps to 0). Three thin / none → view among all.
	int32 ThinAxes[3];
	int32 NumThin = 0;
	for (int32 Axis = 0; Axis < 3; ++Axis)
	{
		if (IsThinCellAxis(C, Axis))
		{
			ThinAxes[NumThin++] = Axis;
		}
	}

	if (NumThin == 1 || NumThin == 2)
	{
		return BestAxisByView(ThinAxes, NumThin, PreferAxis);
	}

	const int32 AllAxes[3] = { 0, 1, 2 };
	return BestAxisByView(AllAxes, 3, PreferAxis);
}

void GridPaintMath::WalkCells2D(FIntPoint From, FIntPoint To, TFunctionRef<void(FIntPoint)> Visit)
{
	int32 X = From.X;
	int32 Y = From.Y;
	const int32 DeltaX = FMath::Abs(To.X - X);
	const int32 DeltaY = -FMath::Abs(To.Y - Y);
	const int32 StepX = (X < To.X) ? 1 : -1;
	const int32 StepY = (Y < To.Y) ? 1 : -1;
	int32 Error = DeltaX + DeltaY;

	while (X != To.X || Y != To.Y)
	{
		const int32 DoubledError = 2 * Error;
		if (DoubledError >= DeltaY)
		{
			Error += DeltaY;
			X += StepX;
		}
		if (DoubledError <= DeltaX)
		{
			Error += DeltaX;
			Y += StepY;
		}
		Visit(FIntPoint(X, Y));
	}
}

bool GridPaintMath::IsExactAxisAlignedLine(
	const FIntVector& Anchor,
	const FIntVector& Target,
	int32 PlaneAxis)
{
	if (PlaneAxis < 0 || PlaneAxis > 2 || Anchor == Target)
	{
		return false;
	}
	if (Anchor[PlaneAxis] != Target[PlaneAxis])
	{
		return false;
	}

	const int32 AxisU = (PlaneAxis + 1) % 3;
	const int32 AxisV = (PlaneAxis + 2) % 3;
	const int32 DeltaU = Target[AxisU] - Anchor[AxisU];
	const int32 DeltaV = Target[AxisV] - Anchor[AxisV];
	// Exact row or column only — no diagonals, no projection.
	return (DeltaU == 0) != (DeltaV == 0);
}
