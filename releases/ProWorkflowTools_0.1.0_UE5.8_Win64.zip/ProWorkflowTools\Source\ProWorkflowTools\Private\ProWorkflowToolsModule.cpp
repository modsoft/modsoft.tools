﻿// Copyright Â© 2026 Trey McNair. All rights reserved.

#include "ProWorkflowToolsModule.h"

#include "ProWorkflowToolsEngineAdapter.h"
#include "ProWorkflowToolsEngineVersion.h"
#include "ProWorkflowToolsSettings.h"
#include "ProWorkflowToolsCommands.h"
#include "ProWorkflowToolsStyle.h"
#include "DecalPlacement/InteractiveDecalPlacementCommands.h"
#include "DecalPlacement/InteractiveDecalPlacementEdMode.h"
#include "DecalPlacement/InteractiveDecalPlacementFeature.h"
#include "SuperGroups/SuperGroupsFeature.h"
#include "UI/ViewportCursorLabel.h"
#include "Viewport/ProWorkflowToolsEdMode.h"
#include "Viewport/ViewportOverlayStyle.h"
#include "Welcome/SProWorkflowWelcomeSplash.h"

#include "Editor.h"
#include "Editor/GroupActor.h"
#include "Editor/UnrealEdEngine.h"
#include "EditorModeManager.h"
#include "EditorModeRegistry.h"
#include "Engine/Selection.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "Framework/Commands/InputBindingManager.h"
#include "Framework/Commands/InputChord.h"
#include "Framework/Commands/UICommandInfo.h"
#include "Framework/Commands/UICommandList.h"
#include "Framework/Notifications/NotificationManager.h"
#include "GameFramework/Actor.h"
#include "ILevelEditor.h"
#include "ISettingsModule.h"
#include "LevelEditor.h"
#include "LevelEditorActions.h"
#include "LevelEditorViewport.h"
#include "Materials/MaterialInterface.h"
#include "Misc/ConfigCacheIni.h"
#include "ScopedTransaction.h"
#include "Textures/SlateIcon.h"
#include "ToolMenus.h"
#include "UnrealEdGlobals.h"
#include "Widgets/Notifications/SNotificationList.h"

DEFINE_LOG_CATEGORY_STATIC(LogProWorkflowTools, Log, All);

namespace
{
	/** Cap unhide history; drop oldest when over limit. */
	constexpr int32 MaxHiddenBatchHistory = 16;

	/**
	 * Every actor a hide command can reach: the selection and its attached descendants.
	 * A superset is fine; the wrapper diffs actual visibility to find what was hidden.
	 */
	TArray<TWeakObjectPtr<AActor>> GatherVisibleHideCandidates()
	{
		TSet<AActor*> Candidates;
		TArray<AActor*> Descendants;
		for (FSelectionIterator It(GEditor->GetSelectedActorIterator()); It; ++It)
		{
			AActor* Actor = Cast<AActor>(*It);
			if (!Actor)
			{
				continue;
			}

			Candidates.Add(Actor);
			Actor->GetAttachedActors(Descendants, /*bResetArray=*/true, /*bRecursivelyIncludeAttachedActors=*/true);
			Candidates.Append(Descendants);
		}

		TArray<TWeakObjectPtr<AActor>> Visible;
		for (AActor* Actor : Candidates)
		{
			if (ProWorkflowTools::IsActorVisibleInEditor(Actor))
			{
				Visible.Add(Actor);
			}
		}
		return Visible;
	}

	/**
	 * One-shot: former splash/settings FKeys for Grid Paint T and Decal J.
	 * Apply onto the command then drop the ini key so Keyboard Shortcuts stays the store.
	 */
	void AdoptLegacySettingsHotkey(const TCHAR* PropertyName, const TSharedPtr<FUICommandInfo>& Command)
	{
		if (!GConfig || !Command.IsValid())
		{
			return;
		}

		const TCHAR* Section = TEXT("/Script/ProWorkflowTools.ProWorkflowToolsSettings");
		auto ConsumeFrom = [&](const FString& IniFile)
		{
			if (IniFile.IsEmpty())
			{
				return;
			}

			FString Raw;
			if (!GConfig->GetString(Section, PropertyName, Raw, IniFile))
			{
				return;
			}

			GConfig->RemoveKey(Section, PropertyName, IniFile);
			Raw.TrimStartAndEndInline();
			const FKey Legacy(*Raw);
			if (!Legacy.IsValid())
			{
				return;
			}

			const FInputChord NewChord(Legacy);
			if (*Command->GetActiveChord(EMultipleKeyBindingIndex::Primary) != NewChord)
			{
				Command->SetActiveChord(NewChord, EMultipleKeyBindingIndex::Primary);
				FInputBindingManager::Get().SaveInputBindings();
			}
		};

		ConsumeFrom(GEditorPerProjectIni);
		ConsumeFrom(GEditorIni);
	}
}

#define LOCTEXT_NAMESPACE "ProWorkflowTools"

FTransform FProWorkflowToolsModule::FTransformActionDelta::StripScale(const FTransform& InTransform)
{
	FTransform Out = InTransform;
	Out.SetScale3D(FVector::OneVector);
	return Out;
}

FVector FProWorkflowToolsModule::FTransformActionDelta::ComputeScaleRatio(const FTransform& Start, const FTransform& End)
{
	const FVector StartScale = Start.GetScale3D();
	const FVector EndScale = End.GetScale3D();
	auto SafeScaleRatio = [](float EndComponent, float StartComponent)
	{
		return FMath::IsNearlyZero(StartComponent) ? 1.0f : EndComponent / StartComponent;
	};

	return FVector(
		SafeScaleRatio(EndScale.X, StartScale.X),
		SafeScaleRatio(EndScale.Y, StartScale.Y),
		SafeScaleRatio(EndScale.Z, StartScale.Z));
}

void FProWorkflowToolsModule::FTransformActionDelta::SetFromMovement(const FTransform& Start, const FTransform& End)
{
	const FTransform StartTRS = StripScale(Start);
	const FTransform EndTRS = StripScale(End);
	TransformDelta = StartTRS.Inverse() * EndTRS;
	TransformDelta.NormalizeRotation();
	ScaleMultiplier = ComputeScaleRatio(Start, End);
}

void FProWorkflowToolsModule::FTransformActionDelta::ApplyTo(FTransform& InOutTransform) const
{
	const FVector OriginalScale = InOutTransform.GetScale3D();
	FTransform Basis = StripScale(InOutTransform);
	FTransform Result = Basis * TransformDelta;
	Result.SetScale3D(OriginalScale * ScaleMultiplier);
	InOutTransform = Result;
}

bool FProWorkflowToolsModule::IsDccControlsEnabled() const
{
	const UProWorkflowToolsSettings* Settings = GetDefault<UProWorkflowToolsSettings>();
	return Settings && Settings->bEnableDccViewportControls;
}

bool FProWorkflowToolsModule::IsDuplicateInPlaceEnabled() const
{
	const UProWorkflowToolsSettings* Settings = GetDefault<UProWorkflowToolsSettings>();
	return Settings && Settings->bDuplicateInPlace;
}

bool FProWorkflowToolsModule::IsMaterialClipboardToolEnabled() const
{
	const UProWorkflowToolsSettings* Settings = GetDefault<UProWorkflowToolsSettings>();
	return Settings && Settings->bEnableMaterialClipboardTool;
}

bool FProWorkflowToolsModule::IsGridPaintEnabled() const
{
	const UProWorkflowToolsSettings* Settings = GetDefault<UProWorkflowToolsSettings>();
	return Settings && Settings->bEnableGridPaint;
}

bool FProWorkflowToolsModule::IsWorkflowModeNeeded() const
{
	// Duplicate with Last Transform has no off switch and draws its readout through the mode, so the
	// mode is always wanted; the per-tool settings only decide which hosted tools respond.
	return true;
}

namespace ProWorkflowToolsModulePrivate
{
	/** Mode tools are not safe until a level editor exists (startup map load can fire OnMapOpened earlier). */
	bool IsLevelEditorReady()
	{
		if (const FLevelEditorModule* LevelEditorModule = FModuleManager::GetModulePtr<FLevelEditorModule>("LevelEditor"))
		{
			return LevelEditorModule->GetFirstLevelEditor().IsValid();
		}
		return false;
	}
}

void FProWorkflowToolsModule::UpdateWorkflowModeActivation()
{
	if (!ProWorkflowToolsModulePrivate::IsLevelEditorReady())
	{
		return;
	}

	FEditorModeTools& ModeTools = GLevelEditorModeTools();
	const FEditorModeID ModeID = FProWorkflowToolsEdMode::EM_ProWorkflowTools;
	const bool bNeeded = IsWorkflowModeNeeded();
	const bool bActive = ModeTools.IsModeActive(ModeID);

	if (bNeeded && !bActive)
	{
		ModeTools.ActivateMode(ModeID);
	}
	else if (!bNeeded && bActive)
	{
		ModeTools.DeactivateMode(ModeID);
	}

	// Our invisible mode counts toward ActiveScriptableModes, which prevents the mode manager's
	// tick-time ActivateDefaultMode() path (that only runs when Num() == 0). Keep Selection
	// active alongside our utility mode whenever it is needed.
	ProWorkflowTools::EnsureSelectionModeActive();
}

UMaterialInterface* FProWorkflowToolsModule::GetPickedMaterial() const
{
	return PickedMaterial.Get();
}

void FProWorkflowToolsModule::SetPickedMaterial(UMaterialInterface* InMaterial)
{
	PickedMaterial.Reset(InMaterial);
}

void FProWorkflowToolsModule::StartupModule()
{
	FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>("LevelEditor");

	FProWorkflowToolsStyle::Initialize();
	FProWorkflowToolsCommands::Register();
	RegisterSettings();

	FEditorModeRegistry::Get().RegisterMode<FProWorkflowToolsEdMode>(
		FProWorkflowToolsEdMode::EM_ProWorkflowTools,
		LOCTEXT("WorkflowToolsModeName", "Pro Workflow Tools"),
		FSlateIcon(),
		/*bVisible=*/false);

	const TSharedRef<FUICommandList> CommandList = LevelEditorModule.GetGlobalLevelEditorActions();
	const FProWorkflowToolsCommands& Commands = FProWorkflowToolsCommands::Get();

	CommandList->MapAction(
		Commands.DuplicateWithLastAction,
		FExecuteAction::CreateRaw(this, &FProWorkflowToolsModule::DuplicateWithLastAction),
		FCanExecuteAction::CreateRaw(this, &FProWorkflowToolsModule::CanDuplicateWithLastAction));

	CommandList->MapAction(
		Commands.ToggleBoxScale,
		FExecuteAction::CreateRaw(this, &FProWorkflowToolsModule::ToggleBoxScale),
		FCanExecuteAction::CreateLambda([]()
		{
			const UProWorkflowToolsSettings* Settings = GetDefault<UProWorkflowToolsSettings>();
			return Settings && Settings->bEnableBoxScale;
		}),
		FIsActionChecked::CreateLambda([this]() { return bBoxScaleEnabled; }));

	CommandList->MapAction(
		Commands.ToggleGridPaint,
		FExecuteAction::CreateRaw(this, &FProWorkflowToolsModule::ToggleGridPaint),
		FCanExecuteAction::CreateRaw(this, &FProWorkflowToolsModule::IsGridPaintEnabled),
		FIsActionChecked::CreateRaw(this, &FProWorkflowToolsModule::IsGridPaintActive));

	CommandList->MapAction(
		Commands.ShowLastHidden,
		FExecuteAction::CreateRaw(this, &FProWorkflowToolsModule::ShowLastHidden),
		FCanExecuteAction::CreateRaw(this, &FProWorkflowToolsModule::CanShowLastHidden));

	CommandList->MapAction(
		Commands.OpenWelcomeSplash,
		FExecuteAction::CreateRaw(this, &FProWorkflowToolsModule::OpenWelcomeSplash));

	WrapHideCommands();
	RegisterToolbar();

	LevelEditorModule.OnLevelEditorCreated().AddRaw(this, &FProWorkflowToolsModule::OnLevelEditorCreated);
	BindEditorDelegates();

	SuperGroupsFeature = MakeUnique<FSuperGroupsFeature>();
	SuperGroupsFeature->Startup();

	DecalPlacementFeature = MakeUnique<FInteractiveDecalPlacementFeature>();
	DecalPlacementFeature->Startup();

	if (FProWorkflowToolsCommands::IsRegistered())
	{
		AdoptLegacySettingsHotkey(TEXT("GridPaintToggleKey"), FProWorkflowToolsCommands::Get().ToggleGridPaint);
	}
	if (FInteractiveDecalPlacementCommands::IsRegistered())
	{
		AdoptLegacySettingsHotkey(TEXT("DecalPlacementToggleKey"), FInteractiveDecalPlacementCommands::Get().StartPlacement);
	}

	if (LevelEditorModule.GetFirstLevelEditor().IsValid())
	{
		UpdateWorkflowModeActivation();
		MaybeShowWelcomeSplash();
	}
}

void FProWorkflowToolsModule::ShutdownModule()
{

	if (DecalPlacementFeature)
	{
		DecalPlacementFeature->Shutdown();
		DecalPlacementFeature.Reset();
	}

	if (SuperGroupsFeature)
	{
		SuperGroupsFeature->Shutdown();
		SuperGroupsFeature.Reset();
	}

	// On editor exit the UObject subsystem can shut down before modules unload. Avoid CDO /
	// selection / mode-tools access once objects are gone (crash was GetMutableDefault here).
	if (UObjectInitialized())
	{
		UnregisterToolbar();
		UnregisterSettings();

		if (GEditor)
		{
			if (ProWorkflowToolsModulePrivate::IsLevelEditorReady())
			{
				FEditorModeTools& ModeTools = GLevelEditorModeTools();
				if (ModeTools.IsModeActive(FProWorkflowToolsEdMode::EM_ProWorkflowTools))
				{
					ModeTools.DeactivateMode(FProWorkflowToolsEdMode::EM_ProWorkflowTools);
				}
			}

			// After all tool modes are down, clear any leftover suppress refcount.
			ProWorkflowTools::ReleaseAllTransformWidgetSuppressions();
		}

		USelection::SelectionChangedEvent.Remove(SelectionChangedHandle);
	}
	else if (ISettingsModule* SettingsModule = FModuleManager::GetModulePtr<ISettingsModule>("Settings"))
	{
		SettingsModule->UnregisterSettings("Editor", "Plugins", "ProWorkflowTools");
	}

	FEditorDelegates::OnEditorPreExit.Remove(EditorPreExitHandle);
	FEditorDelegates::OnMapOpened.Remove(MapOpenedHandle);
	FEditorDelegates::PostUndoRedo.Remove(PostUndoRedoHandle);

	if (FLevelEditorModule* LevelEditorModule = FModuleManager::GetModulePtr<FLevelEditorModule>("LevelEditor"))
	{
		LevelEditorModule->OnLevelEditorCreated().RemoveAll(this);
		UnwrapHideCommands();

		if (FProWorkflowToolsCommands::IsRegistered())
		{
			const FProWorkflowToolsCommands& Commands = FProWorkflowToolsCommands::Get();
			const TSharedRef<FUICommandList> CommandList = LevelEditorModule->GetGlobalLevelEditorActions();
			CommandList->UnmapAction(Commands.DuplicateWithLastAction);
			CommandList->UnmapAction(Commands.ToggleBoxScale);
			CommandList->UnmapAction(Commands.ToggleGridPaint);
			CommandList->UnmapAction(Commands.ShowLastHidden);
		}
	}

	FEditorModeRegistry::Get().UnregisterMode(FProWorkflowToolsEdMode::EM_ProWorkflowTools);
	FProWorkflowToolsCommands::Unregister();
	FProWorkflowToolsStyle::Shutdown();
}

void FProWorkflowToolsModule::RegisterSettings()
{
	if (ISettingsModule* SettingsModule = FModuleManager::GetModulePtr<ISettingsModule>("Settings"))
	{
		SettingsModule->RegisterSettings(
			"Editor",
			"Plugins",
			"ProWorkflowTools",
			LOCTEXT("SettingsName", "Pro Workflow Tools"),
			LOCTEXT("SettingsDescription", "Level editor preferences for Pro Workflow Tools."),
			GetMutableDefault<UProWorkflowToolsSettings>());

		SettingsChangedHandle = GetMutableDefault<UProWorkflowToolsSettings>()->OnSettingChanged().AddRaw(
			this, &FProWorkflowToolsModule::OnSettingsChanged);
	}
}

void FProWorkflowToolsModule::UnregisterSettings()
{
	if (UObjectInitialized())
	{
		if (UProWorkflowToolsSettings* Settings = GetMutableDefault<UProWorkflowToolsSettings>())
		{
			Settings->OnSettingChanged().Remove(SettingsChangedHandle);
		}
	}

	if (ISettingsModule* SettingsModule = FModuleManager::GetModulePtr<ISettingsModule>("Settings"))
	{
		SettingsModule->UnregisterSettings("Editor", "Plugins", "ProWorkflowTools");
	}
}

void FProWorkflowToolsModule::OnSettingsChanged(UObject* Settings, FPropertyChangedEvent& PropertyChangedEvent)
{
	const UProWorkflowToolsSettings* WorkflowSettings = Cast<UProWorkflowToolsSettings>(Settings);
	if (WorkflowSettings && !WorkflowSettings->bEnableBoxScale && bBoxScaleEnabled)
	{
		bBoxScaleEnabled = false;
		if (ProWorkflowToolsModulePrivate::IsLevelEditorReady())
		{
			FEditorModeTools& ModeTools = GLevelEditorModeTools();
			if (FProWorkflowToolsEdMode* WorkflowMode = static_cast<FProWorkflowToolsEdMode*>(
				ModeTools.GetActiveMode(FProWorkflowToolsEdMode::EM_ProWorkflowTools)))
			{
				WorkflowMode->NotifyBoxScaleDisabled();
			}
		}
	}

	UpdateWorkflowModeActivation();

	// The splash and Super Groups toggles notify without a property, so the mode decides from state,
	// not from the changed-property name.
	if (ProWorkflowToolsModulePrivate::IsLevelEditorReady())
	{
		if (FProWorkflowToolsEdMode* WorkflowMode = static_cast<FProWorkflowToolsEdMode*>(
			GLevelEditorModeTools().GetActiveMode(FProWorkflowToolsEdMode::EM_ProWorkflowTools)))
		{
			WorkflowMode->SyncViewportInteractions();
		}
	}

	if (GEditor)
	{
		GEditor->RedrawLevelEditingViewports();
	}
}

void FProWorkflowToolsModule::BindEditorDelegates()
{
	EditorPreExitHandle = FEditorDelegates::OnEditorPreExit.AddStatic(&ProWorkflowTools::RestoreTransformWidgetForEditorExit);

	SelectionChangedHandle = USelection::SelectionChangedEvent.AddRaw(this, &FProWorkflowToolsModule::OnEditorSelectionChanged);

	// Map changes can drop active modes; re-evaluate whether our invisible mode is still needed.
	MapOpenedHandle = FEditorDelegates::OnMapOpened.AddRaw(this, &FProWorkflowToolsModule::OnMapOpened);
	PostUndoRedoHandle = FEditorDelegates::PostUndoRedo.AddRaw(this, &FProWorkflowToolsModule::OnPostUndoRedo);
}

void FProWorkflowToolsModule::OnMapOpened(const FString& Filename, bool bAsTemplate)
{
	ResetHiddenActorHistory();
	VerifyHideCommandOwnership(TEXT("OnMapOpened"));

	// Startup loads the template map before the Level Editor exists; mode activation waits for
	// OnLevelEditorCreated (and later map opens once the editor is ready).
	if (!ProWorkflowToolsModulePrivate::IsLevelEditorReady())
	{
		return;
	}

	UpdateWorkflowModeActivation();

	// Map loads call DeactivateAllModes() before OnMapOpened, clearing Selection mode too.
	// Re-assert it here so the toolbar never sits on "No Active Mode" after startup.
	ProWorkflowTools::EnsureSelectionModeActive();
}

void FProWorkflowToolsModule::OnPostUndoRedo()
{
	if (!ProWorkflowToolsModulePrivate::IsLevelEditorReady())
	{
		return;
	}

	FEditorModeTools& ModeTools = GLevelEditorModeTools();
	if (FProWorkflowToolsEdMode* WorkflowMode = static_cast<FProWorkflowToolsEdMode*>(
		ModeTools.GetActiveMode(FProWorkflowToolsEdMode::EM_ProWorkflowTools)))
	{
		WorkflowMode->NotifyPostUndoRedo();
	}
}

void FProWorkflowToolsModule::OnLevelEditorCreated(TSharedPtr<ILevelEditor> InLevelEditor)
{
	VerifyHideCommandOwnership(TEXT("OnLevelEditorCreated"));
	UpdateWorkflowModeActivation();
	MaybeShowWelcomeSplash();
}

void FProWorkflowToolsModule::UpdateMarqueeFilterFromSelection()
{
	if (IsDccControlsEnabled())
	{
		MarqueeFilter.BuildFromSelection();
	}
	else
	{
		MarqueeFilter.Reset();
	}
}

void FProWorkflowToolsModule::SnapshotMarqueeFilterForDrag()
{
	if (IsDccControlsEnabled())
	{
		MarqueeFilter.BuildFromSelection();
	}
}

void FProWorkflowToolsModule::WrapHideCommands()
{
	FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>("LevelEditor");
	const TSharedRef<FUICommandList> CommandList = LevelEditorModule.GetGlobalLevelEditorActions();
	const FLevelEditorCommands& LevelCommands = FLevelEditorCommands::Get();

	// H is Hide Selected on 5.6 and Toggle Selected Hierarchy Visibility on 5.7+; the
	// others are the same family and can be rebound to the key.
	TArray<TSharedPtr<FUICommandInfo>> HideCommands = { LevelCommands.HideSelected };
#if PWT_UE_5_7_OR_LATER
	HideCommands.Append({
		LevelCommands.HideSelectedHierarchy,
		LevelCommands.ToggleSelectedVisibility,
		LevelCommands.ToggleSelectedHierarchyVisibility });
#endif

	for (const TSharedPtr<FUICommandInfo>& Command : HideCommands)
	{
		// Copy before MapAction: the pointer is into the list's map, which MapAction grows.
		const FUIAction* EngineActionPtr = CommandList->GetActionForCommand(Command);
		if (!EngineActionPtr)
		{
			UE_LOG(LogProWorkflowTools, Warning, TEXT("Hide command '%s' has no engine action; Show Last Hidden will not record it."),
				*Command->GetCommandName().ToString());
			continue;
		}
		const FUIAction EngineAction = *EngineActionPtr;

		const int32 Index = WrappedHideCommands.Add({ Command, EngineAction });
		FUIAction Wrapped = EngineAction;
		Wrapped.ExecuteAction = FExecuteAction::CreateRaw(this, &FProWorkflowToolsModule::ExecuteWrappedHide, Index);
		CommandList->MapAction(Command, Wrapped);
	}
}

void FProWorkflowToolsModule::UnwrapHideCommands()
{
	FLevelEditorModule* LevelEditorModule = FModuleManager::GetModulePtr<FLevelEditorModule>("LevelEditor");
	if (LevelEditorModule)
	{
		const TSharedRef<FUICommandList> CommandList = LevelEditorModule->GetGlobalLevelEditorActions();
		for (const FWrappedHideCommand& Wrapped : WrappedHideCommands)
		{
			CommandList->MapAction(Wrapped.Command, Wrapped.EngineAction);
		}
	}
	WrappedHideCommands.Reset();
}

void FProWorkflowToolsModule::ExecuteWrappedHide(int32 WrappedIndex)
{
	if (!GEditor || !WrappedHideCommands.IsValidIndex(WrappedIndex))
	{
		return;
	}

	// Diffing visibility across the engine action is exact for hide and toggle alike, and
	// survives Hide Selected deselecting what it hid.
	const TArray<TWeakObjectPtr<AActor>> VisibleBefore = GatherVisibleHideCandidates();

	WrappedHideCommands[WrappedIndex].EngineAction.Execute();

	TArray<TWeakObjectPtr<AActor>> Batch;
	for (const TWeakObjectPtr<AActor>& WeakActor : VisibleBefore)
	{
		if (const AActor* Actor = WeakActor.Get(); Actor && !ProWorkflowTools::IsActorVisibleInEditor(Actor))
		{
			Batch.Add(WeakActor);
		}
	}
	PushHiddenBatch(MoveTemp(Batch));
}

void FProWorkflowToolsModule::VerifyHideCommandOwnership(const TCHAR* When) const
{
	FLevelEditorModule* LevelEditorModule = FModuleManager::GetModulePtr<FLevelEditorModule>("LevelEditor");
	if (!LevelEditorModule)
	{
		return;
	}

	const TSharedRef<FUICommandList> CommandList = LevelEditorModule->GetGlobalLevelEditorActions();
	for (const FWrappedHideCommand& Wrapped : WrappedHideCommands)
	{
		const FUIAction* Action = CommandList->GetActionForCommand(Wrapped.Command);
		if (!Action || !Action->ExecuteAction.IsBoundToObject(this))
		{
			UE_LOG(LogProWorkflowTools, Warning, TEXT("%s: hide command '%s' is no longer owned by Pro Workflow Tools; Show Last Hidden will not record it."),
				When, *Wrapped.Command->GetCommandName().ToString());
		}
	}
}

void FProWorkflowToolsModule::UpdateSessionAnchors()
{
	TSet<TWeakObjectPtr<AActor>> SelectedActors;
	for (FSelectionIterator It(GEditor->GetSelectedActorIterator()); It; ++It)
	{
		if (AActor* Actor = Cast<AActor>(*It))
		{
			SelectedActors.Add(Actor);
		}
	}

	const bool bSameActors = SelectedActors.Num() == LastSelectionSet.Num() && LastSelectionSet.Includes(SelectedActors);
	if (bSameActors)
	{
		return;
	}

	// A new selection starts a new session: everything the user does to it from here is
	// what Duplicate with Last Transform replays.
	LastSelectionSet = MoveTemp(SelectedActors);
	AnchorSelectionHere();
}

void FProWorkflowToolsModule::AnchorSelectionHere()
{
	SessionStartTransforms.Reset();
	for (const TWeakObjectPtr<AActor>& WeakActor : LastSelectionSet)
	{
		if (const AActor* Actor = WeakActor.Get())
		{
			SessionStartTransforms.Add(WeakActor, Actor->GetActorTransform());
		}
	}
}

TOptional<FProWorkflowToolsModule::FTransformActionDelta> FProWorkflowToolsModule::ComputeSessionDelta() const
{
	if (!GEditor)
	{
		return TOptional<FTransformActionDelta>();
	}

	// One gizmo delta drives the whole selection, so the first anchored actor speaks for it.
	for (FSelectionIterator It(GEditor->GetSelectedActorIterator()); It; ++It)
	{
		AActor* Actor = Cast<AActor>(*It);
		const FTransform* StartTransform = Actor ? SessionStartTransforms.Find(Actor) : nullptr;
		if (!StartTransform)
		{
			continue;
		}

		FTransformActionDelta Delta;
		Delta.SetFromMovement(*StartTransform, Actor->GetActorTransform());
		if (!Delta.IsNearlyIdentity())
		{
			return Delta;
		}
	}

	return TOptional<FTransformActionDelta>();
}

void FProWorkflowToolsModule::OnEditorSelectionChanged(UObject* NewSelection)
{
	UpdateMarqueeFilterFromSelection();

	if (GEditor && NewSelection == GEditor->GetSelectedActors())
	{
		UpdateSessionAnchors();
	}
}

bool FProWorkflowToolsModule::CanDuplicateWithLastAction() const
{
	return GEditor && GEditor->GetSelectedActorCount() > 0;
}

void FProWorkflowToolsModule::DuplicateWithLastAction()
{
	UWorld* World = GEditor ? GEditor->GetEditorWorldContext().World() : nullptr;
	if (!World || !GUnrealEd)
	{
		return;
	}

	const FScopedTransaction Transaction(LOCTEXT("DuplicateWithLastActionTransaction", "Duplicate with Last Transform"));

	// Keep the previous delta when the selection has not moved: repeat chains the offset.
	if (TOptional<FTransformActionDelta> SessionDelta = ComputeSessionDelta())
	{
		ReplayDelta = SessionDelta;
	}

	FEditorDelegates::OnDuplicateActorsBegin.Broadcast();
	GUnrealEd->edactDuplicateSelected(World->GetCurrentLevel(), /*bOffsetLocations=*/false);
	FEditorDelegates::OnDuplicateActorsEnd.Broadcast();

	// Readout: how far the selection's centre moved during the replay (world cm).
	auto SelectionCentroid = []() -> FVector
	{
		FVector Sum = FVector::ZeroVector;
		int32 Count = 0;
		for (FSelectionIterator It(GEditor->GetSelectedActorIterator()); It; ++It)
		{
			if (const AActor* Actor = Cast<AActor>(*It); Actor && !Actor->IsA<AGroupActor>())
			{
				Sum += Actor->GetActorLocation();
				++Count;
			}
		}
		return Count > 0 ? Sum / static_cast<double>(Count) : FVector::ZeroVector;
	};
	const FVector CentroidBeforeReplay = SelectionCentroid();

	if (ReplayDelta.IsSet())
	{
		const FTransformActionDelta& Delta = ReplayDelta.GetValue();

		struct FGroupPivotRel
		{
			AGroupActor* Group = nullptr;
			FVector OffsetFromCentroid = FVector::ZeroVector;
			FQuat Rotation = FQuat::Identity;
		};

		auto LeafCentroid = [](AGroupActor& Group) -> FVector
		{
			TArray<AActor*> Children;
			Group.GetAllChildren(Children, /*bRecurse=*/true);
			FVector Sum = FVector::ZeroVector;
			int32 Count = 0;
			for (AActor* Child : Children)
			{
				if (Child && !Child->IsA<AGroupActor>())
				{
					Sum += Child->GetActorLocation();
					++Count;
				}
			}
			return Count > 0 ? Sum / static_cast<double>(Count) : Group.GetActorLocation();
		};

		TArray<FGroupPivotRel> PivotRels;
		for (FSelectionIterator It(GEditor->GetSelectedActorIterator()); It; ++It)
		{
			if (AGroupActor* Group = Cast<AGroupActor>(*It))
			{
				FGroupPivotRel Rel;
				Rel.Group = Group;
				Rel.OffsetFromCentroid = Group->GetActorLocation() - LeafCentroid(*Group);
				Rel.Rotation = Group->GetActorQuat();
				PivotRels.Add(Rel);
			}
		}

		if (PivotRels.IsEmpty())
		{
			TSet<AGroupActor*> Groups;
			for (FSelectionIterator It(GEditor->GetSelectedActorIterator()); It; ++It)
			{
				if (AActor* Actor = Cast<AActor>(*It))
				{
					if (AGroupActor* Root = AGroupActor::GetRootForActor(Actor, /*bMustBeLocked=*/true))
					{
						Groups.Add(Root);
					}
				}
			}
			for (AGroupActor* Group : Groups)
			{
				FGroupPivotRel Rel;
				Rel.Group = Group;
				Rel.OffsetFromCentroid = Group->GetActorLocation() - LeafCentroid(*Group);
				Rel.Rotation = Group->GetActorQuat();
				PivotRels.Add(Rel);
			}
		}

		for (FSelectionIterator It(GEditor->GetSelectedActorIterator()); It; ++It)
		{
			AActor* Actor = Cast<AActor>(*It);
			if (!Actor || Actor->IsA<AGroupActor>())
			{
				continue;
			}

			Actor->Modify();
			FTransform NewTransform = Actor->GetActorTransform();
			Delta.ApplyTo(NewTransform);
			Actor->SetActorTransform(NewTransform);
			Actor->PostEditMove(true);
		}

		for (const FGroupPivotRel& Rel : PivotRels)
		{
			if (!Rel.Group)
			{
				continue;
			}

			Rel.Group->Modify();
			Rel.Group->SetActorLocation(LeafCentroid(*Rel.Group) + Rel.OffsetFromCentroid, false);
			Rel.Group->SetActorRotation(Rel.Rotation);
			Rel.Group->PostEditMove(true);
		}
	}

	GEditor->NoteSelectionChange();
	GEditor->RedrawLevelEditingViewports();

	// The duplicates were anchored where they spawned, before the replay moved them. Anchor
	// them where they landed so the next Shift+D repeats the delta instead of compounding it.
	AnchorSelectionHere();

	ShowDuplicateWithLastReadout(SelectionCentroid() - CentroidBeforeReplay);
}

void FProWorkflowToolsModule::ShowDuplicateWithLastReadout(const FVector& CentroidMove) const
{
	using namespace ProWorkflowTools::CursorLabel;
	using namespace ProWorkflowTools::OverlayStyle;

	if (!ProWorkflowToolsModulePrivate::IsLevelEditorReady())
	{
		return;
	}
	FProWorkflowToolsEdMode* WorkflowMode = static_cast<FProWorkflowToolsEdMode*>(
		GLevelEditorModeTools().GetActiveMode(FProWorkflowToolsEdMode::EM_ProWorkflowTools));
	if (!WorkflowMode)
	{
		return;
	}

	TArray<FLine, TInlineAllocator<3>> Lines;
	if (!ReplayDelta.IsSet())
	{
		Lines.Add({LOCTEXT("DupLastReadoutNone", "No last transform"), Neutral});
	}
	else
	{
		const FLinearColor Color = Accent();
		const FTransformActionDelta& Delta = ReplayDelta.GetValue();

		if (!CentroidMove.IsNearlyZero(0.05))
		{
			Lines.Add({FText::Format(LOCTEXT("DupLastReadoutMove", "Move {0}, {1}, {2}"),
				FText::FromString(FormatAmount(CentroidMove.X)),
				FText::FromString(FormatAmount(CentroidMove.Y)),
				FText::FromString(FormatAmount(CentroidMove.Z))), Color});
		}

		// FQuat::GetAngle is [0, 2π]; report the short way round.
		double AngleDeg = FMath::RadiansToDegrees(Delta.TransformDelta.GetRotation().GetAngle());
		if (AngleDeg > 180.0)
		{
			AngleDeg = 360.0 - AngleDeg;
		}
		if (AngleDeg > 0.05)
		{
			Lines.Add({FText::Format(LOCTEXT("DupLastReadoutRotate", "Rotate {0}\u00B0"),
				FText::FromString(FormatAmount(AngleDeg))), Color});
		}

		const FVector& Scale = Delta.ScaleMultiplier;
		if (!Scale.Equals(FVector::OneVector, 0.001))
		{
			const bool bUniform = FMath::IsNearlyEqual(Scale.X, Scale.Y, 0.001) && FMath::IsNearlyEqual(Scale.X, Scale.Z, 0.001);
			Lines.Add({bUniform
				? FText::Format(LOCTEXT("DupLastReadoutScaleUniform", "Scale \u00D7{0}"), FText::FromString(FormatAmount(Scale.X)))
				: FText::Format(LOCTEXT("DupLastReadoutScale", "Scale \u00D7{0}, {1}, {2}"),
					FText::FromString(FormatAmount(Scale.X)),
					FText::FromString(FormatAmount(Scale.Y)),
					FText::FromString(FormatAmount(Scale.Z))), Color});
		}

		if (Lines.IsEmpty())
		{
			Lines.Add({LOCTEXT("DupLastReadoutInPlace", "No offset"), Neutral});
		}
	}

	WorkflowMode->ShowCommandLabel(Lines);
}

void FProWorkflowToolsModule::ResetHiddenActorHistory()
{
	LastHiddenBatches.Reset();
}

void FProWorkflowToolsModule::PushHiddenBatch(TArray<TWeakObjectPtr<AActor>>&& Batch)
{
	if (Batch.Num() == 0)
	{
		return;
	}

	LastHiddenBatches.Add(MoveTemp(Batch));
	while (LastHiddenBatches.Num() > MaxHiddenBatchHistory)
	{
		LastHiddenBatches.RemoveAt(0, EAllowShrinking::No);
	}
}


bool FProWorkflowToolsModule::CanShowLastHidden() const
{
	for (int32 BatchIndex = LastHiddenBatches.Num() - 1; BatchIndex >= 0; --BatchIndex)
	{
		for (const TWeakObjectPtr<AActor>& WeakActor : LastHiddenBatches[BatchIndex])
		{
			const AActor* Actor = WeakActor.Get();
			if (Actor && !ProWorkflowTools::IsActorVisibleInEditor(Actor))
			{
				return true;
			}
		}
	}
	return false;
}

void FProWorkflowToolsModule::ShowLastHidden()
{
	if (!GEditor)
	{
		return;
	}

	while (LastHiddenBatches.Num() > 0)
	{
		TArray<TWeakObjectPtr<AActor>> Batch = LastHiddenBatches.Pop();

		TArray<AActor*> ActorsToShow;
		ActorsToShow.Reserve(Batch.Num());
		for (const TWeakObjectPtr<AActor>& WeakActor : Batch)
		{
			// Skip what the user has already shown again, and fall through to the older batch
			// when nothing in this one is still hidden.
			if (AActor* Actor = WeakActor.Get(); Actor && !ProWorkflowTools::IsActorVisibleInEditor(Actor))
			{
				ActorsToShow.Add(Actor);
			}
		}

		if (ActorsToShow.Num() == 0)
		{
			continue;
		}

		const FScopedTransaction Transaction(LOCTEXT("ShowLastHiddenTransaction", "Show Last Hidden"));

		// Write visibility the way the engine's own hide does, rather than running ACTOR
		// UNHIDE SELECTED: that command only acts on actors whose IsHiddenEd() is set.
		// Visibility only: the current selection is left exactly as it was.
		for (AActor* Actor : ActorsToShow)
		{
			ProWorkflowTools::SetActorVisibleInEditor(Actor, true);
		}
		GEditor->RedrawLevelEditingViewports();

		const int32 RestoredCount = ActorsToShow.Num();
		FNotificationInfo Info(FText::Format(
			RestoredCount == 1
				? LOCTEXT("ShowLastHiddenToastSingular", "Show Last Hidden: {0} actor")
				: LOCTEXT("ShowLastHiddenToastPlural", "Show Last Hidden: {0} actors"),
			FText::AsNumber(RestoredCount)));
		Info.ExpireDuration = 2.0f;
		Info.bFireAndForget = true;
		FSlateNotificationManager::Get().AddNotification(Info);
		return;
	}
}

void FProWorkflowToolsModule::ReleaseViewportToolsExcept(const EProWorkflowViewportTool Incoming)
{
	if (!ProWorkflowToolsModulePrivate::IsLevelEditorReady())
	{
		return;
	}

	FEditorModeTools& ModeTools = GLevelEditorModeTools();

	if (Incoming != EProWorkflowViewportTool::DecalPlacement
		&& ModeTools.IsModeActive(FInteractiveDecalPlacementEdMode::EM_InteractiveDecalPlacement))
	{
		ModeTools.DeactivateMode(FInteractiveDecalPlacementEdMode::EM_InteractiveDecalPlacement);
	}

	if (Incoming != EProWorkflowViewportTool::GridPaint)
	{
		if (FProWorkflowToolsEdMode* WorkflowMode = static_cast<FProWorkflowToolsEdMode*>(
			ModeTools.GetActiveMode(FProWorkflowToolsEdMode::EM_ProWorkflowTools)))
		{
			if (WorkflowMode->IsGridPaintActive())
			{
				WorkflowMode->ToggleGridPaint(GCurrentLevelEditingViewportClient);
			}
		}
	}

	if (Incoming != EProWorkflowViewportTool::BoxScale && bBoxScaleEnabled)
	{
		bBoxScaleEnabled = false;
		if (FProWorkflowToolsEdMode* WorkflowMode = static_cast<FProWorkflowToolsEdMode*>(
			ModeTools.GetActiveMode(FProWorkflowToolsEdMode::EM_ProWorkflowTools)))
		{
			WorkflowMode->NotifyBoxScaleDisabled();
		}
		UpdateWorkflowModeActivation();
	}
}

void FProWorkflowToolsModule::ToggleBoxScale()
{
	const UProWorkflowToolsSettings* Settings = GetDefault<UProWorkflowToolsSettings>();
	if (!Settings || !Settings->bEnableBoxScale)
	{
		return;
	}

	if (!bBoxScaleEnabled)
	{
		ReleaseViewportToolsExcept(EProWorkflowViewportTool::BoxScale);
	}

	bBoxScaleEnabled = !bBoxScaleEnabled;

	// Release Show-Widget suppression immediately when turning Box Scale off. The ed mode may
	// stay alive for other tools, so we must not wait for Exit().
	if (!bBoxScaleEnabled && ProWorkflowToolsModulePrivate::IsLevelEditorReady())
	{
		FEditorModeTools& ModeTools = GLevelEditorModeTools();
		if (FProWorkflowToolsEdMode* WorkflowMode = static_cast<FProWorkflowToolsEdMode*>(
			ModeTools.GetActiveMode(FProWorkflowToolsEdMode::EM_ProWorkflowTools)))
		{
			WorkflowMode->NotifyBoxScaleDisabled();
		}
	}

	UpdateWorkflowModeActivation();

	if (GEditor)
	{
		GEditor->RedrawLevelEditingViewports();
	}
}

bool FProWorkflowToolsModule::IsGridPaintActive() const
{
	if (!ProWorkflowToolsModulePrivate::IsLevelEditorReady())
	{
		return false;
	}

	FEditorModeTools& ModeTools = GLevelEditorModeTools();
	const FProWorkflowToolsEdMode* WorkflowMode = static_cast<const FProWorkflowToolsEdMode*>(
		ModeTools.GetActiveMode(FProWorkflowToolsEdMode::EM_ProWorkflowTools));
	return WorkflowMode && WorkflowMode->IsGridPaintActive();
}

void FProWorkflowToolsModule::ToggleGridPaint()
{
	if (!IsGridPaintEnabled() || !ProWorkflowToolsModulePrivate::IsLevelEditorReady())
	{
		return;
	}

	UpdateWorkflowModeActivation();

	FEditorModeTools& ModeTools = GLevelEditorModeTools();
	FProWorkflowToolsEdMode* WorkflowMode = static_cast<FProWorkflowToolsEdMode*>(
		ModeTools.GetActiveMode(FProWorkflowToolsEdMode::EM_ProWorkflowTools));
	if (!WorkflowMode)
	{
		return;
	}

	if (WorkflowMode->IsGridPaintActive())
	{
		WorkflowMode->ToggleGridPaint(GCurrentLevelEditingViewportClient);
		return;
	}

	ReleaseViewportToolsExcept(EProWorkflowViewportTool::GridPaint);
	UpdateWorkflowModeActivation();

	WorkflowMode = static_cast<FProWorkflowToolsEdMode*>(
		ModeTools.GetActiveMode(FProWorkflowToolsEdMode::EM_ProWorkflowTools));
	if (!WorkflowMode)
	{
		return;
	}

	WorkflowMode->ToggleGridPaint(GCurrentLevelEditingViewportClient);
}

void FProWorkflowToolsModule::MaybeShowWelcomeSplash()
{
	if (GetDefault<UProWorkflowToolsUserSettings>()->bDontShowWelcomeSplashAgain)
	{
		return;
	}

	SProWorkflowWelcomeSplash::OpenWindow();
}

void FProWorkflowToolsModule::OpenWelcomeSplash()
{
	SProWorkflowWelcomeSplash::OpenWindow();
}

void FProWorkflowToolsModule::RegisterToolbar()
{
	UToolMenus::RegisterStartupCallback(
		FSimpleMulticastDelegate::FDelegate::CreateRaw(this, &FProWorkflowToolsModule::RegisterToolbarMenus));
}

void FProWorkflowToolsModule::RegisterToolbarMenus()
{
	FToolMenuOwnerScoped OwnerScoped(this);
	UToolMenu* Toolbar = UToolMenus::Get()->ExtendMenu("LevelEditor.LevelEditorToolBar.User");
	FToolMenuSection& Section = Toolbar->FindOrAddSection("ProWorkflowTools");

	FToolMenuEntry Entry = FToolMenuEntry::InitToolBarButton(
		FProWorkflowToolsCommands::Get().OpenWelcomeSplash,
		TAttribute<FText>(),
		TAttribute<FText>(),
		FSlateIcon(FProWorkflowToolsStyle::GetStyleSetName(), "ProWorkflowTools.ToolbarIcon"));
	Entry.Name = "ProWorkflowToolsWelcome";
	Section.AddEntry(Entry);

	// Box Scale sits with the viewport's transform tools, right after Scale.
	const FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>("LevelEditor");
	UToolMenu* TransformMenu = UToolMenus::Get()->ExtendMenu("LevelEditor.ViewportToolbar.Transform");
	FToolMenuSection& TransformTools = TransformMenu->FindOrAddSection("TransformTools");
	FToolMenuEntry BoxScaleEntry = FToolMenuEntry::InitMenuEntryWithCommandList(
		FProWorkflowToolsCommands::Get().ToggleBoxScale,
		LevelEditorModule.GetGlobalLevelEditorActions(),
		LOCTEXT("ViewportBoxScaleLabel", "Bounding Box Scale"),
		TAttribute<FText>(),
		FSlateIcon(FProWorkflowToolsStyle::GetStyleSetName(), "ProWorkflowTools.Viewport.BoxScale"));
	BoxScaleEntry.SetShowInToolbarTopLevel(true);
	BoxScaleEntry.ToolBarData.StyleNameOverride = "ViewportToolbar.TransformTools";
	BoxScaleEntry.InsertPosition = FToolMenuInsert("ScaleMode", EToolMenuInsertType::After);
	TransformTools.AddEntry(BoxScaleEntry);
}

void FProWorkflowToolsModule::UnregisterToolbar()
{
	UToolMenus::UnRegisterStartupCallback(this);
	if (UToolMenus* ToolMenus = UToolMenus::TryGet())
	{
		ToolMenus->UnregisterOwner(this);
		ToolMenus->RemoveSection("LevelEditor.LevelEditorToolBar.User", "ProWorkflowTools");
	}
}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FProWorkflowToolsModule, ProWorkflowTools)

