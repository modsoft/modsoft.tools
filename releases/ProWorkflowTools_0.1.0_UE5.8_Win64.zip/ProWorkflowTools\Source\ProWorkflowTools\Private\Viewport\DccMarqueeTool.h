// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "UI/ViewportCursorLabel.h"
#include "Viewport/DccMarqueeSelection.h"
#include "Viewport/WorkflowViewportTool.h"

/**
 * DCC viewport controls: LMB marquee in perspective (replacing camera dolly), Ctrl/Shift/Alt marquee
 * modes, Ctrl+click deselect and select-similar. Also hosts the independently-toggled Shift+click
 * "make last selected" click.
 */
class FDccMarqueeTool : public FWorkflowViewportTool
{
public:
	static bool IsDccControlsEnabled();

	/** Armed but not yet dragging, a plain press may still be a click (selection, Material Clipboard apply). */
	virtual bool IsExclusive() const override { return bMarqueeActive && (bMarqueeDragging || bMarqueeFromInputKey); }
	virtual bool CapturesMouse() const override { return bMarqueeActive; }
	virtual bool BlocksViewportDragTool() const override;

	virtual void Exit() override;
	virtual void CancelTracking() override;

	/** The select-similar result label fades at the cursor, so it follows the hovered viewport. */
	virtual EWorkflowToolTickViewport GetTickViewport() const override { return EWorkflowToolTickViewport::Hovered; }
	virtual void Tick(FEditorViewportClient* ViewportClient, float DeltaTime) override;

	virtual bool InputKey(FEditorViewportClient* ViewportClient, FViewport* Viewport, FKey Key, EInputEvent Event) override;
	virtual bool StartTracking(FEditorViewportClient* ViewportClient, FViewport* Viewport) override;
	virtual bool CapturedMouseMove(FEditorViewportClient* ViewportClient, FViewport* Viewport, int32 MouseX, int32 MouseY) override;
	virtual bool MouseMove(FEditorViewportClient* ViewportClient, FViewport* Viewport, int32 MouseX, int32 MouseY) override;
	virtual bool EndTracking(FEditorViewportClient* ViewportClient, FViewport* Viewport) override;
	virtual bool HandleClick(FEditorViewportClient* ViewportClient, HHitProxy* HitProxy, const FViewportClick& Click) override;
	virtual bool BoxSelect(FBox& Box, bool bSelect) override;
	virtual bool FrustumSelect(const FConvexVolume& Frustum, FEditorViewportClient* ViewportClient, bool bSelect) override;

	virtual bool GetOverrideCursorVisibility(bool& bWantsOverride, bool& bHardwareCursorVisible, bool bSoftwareCursorVisible) const override;
	virtual void DrawHUD(FEditorViewportClient* ViewportClient, FViewport* Viewport, const FSceneView* View, FCanvas* Canvas) override;

private:
	bool CanBeginDrag(FEditorViewportClient* ViewportClient, FViewport* Viewport) const;
	void SnapshotFilterIfNeeded(FEditorViewportClient* ViewportClient);

	/**
	 * bFromInputKey is true only for the Ctrl chords intercepted in InputKey (before the normal
	 * tracking flow), which also require cancelling the TRS gizmo's ITF mouse capture. Plain/Shift
	 * marquees start from StartTracking and keep the engine's press/release flow, so single clicks
	 * still fall through to selection.
	 */
	void BeginDrag(FEditorViewportClient* ViewportClient, FViewport* Viewport, bool bFromInputKey);
	void UpdateDrag(FEditorViewportClient* ViewportClient, int32 MouseX, int32 MouseY);
	/** Commits the marquee (or applies a Ctrl+click deselect) and clears marquee state. */
	void Finish(FEditorViewportClient* ViewportClient, FViewport* Viewport);
	void Commit(FEditorViewportClient* ViewportClient);

	/** Select-similar only (Settings → Select Similar Feedback): accent marquee and a match-count label. */
	static bool IsSelectSimilarFeedbackEnabled();
	void ShowSelectSimilarResult(int32 MatchCount);

	bool bMarqueeActive = false;
	bool bMarqueeDragging = false;
	/** Started via the InputKey Ctrl interception, so the LMB release in InputKey ends it. */
	bool bMarqueeFromInputKey = false;

	EDccMarqueeMode MarqueeMode = EDccMarqueeMode::Replace;
	FVector MarqueeStart = FVector::ZeroVector;
	FVector MarqueeEnd = FVector::ZeroVector;

	ProWorkflowTools::CursorLabel::FFadingLabel ResultLabel;
};
