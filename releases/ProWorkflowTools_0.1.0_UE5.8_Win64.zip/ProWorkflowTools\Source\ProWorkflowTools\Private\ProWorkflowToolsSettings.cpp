// Copyright © 2026 Trey McNair. All rights reserved.

#include "ProWorkflowToolsSettings.h"

#include "DecalPlacement/InteractiveDecalPlacementCollectionUtils.h"

void UProWorkflowToolsSettings::NotifyAndPersist(FProperty* Property)
{
	FPropertyChangedEvent ChangeEvent(Property);
	PostEditChangeProperty(ChangeEvent);
	if (!Property)
	{
		TryUpdateDefaultConfigFile();
	}
}

#if WITH_EDITOR
void UProWorkflowToolsUserSettings::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);
	SaveConfig();
	if (PropertyChangedEvent.GetMemberPropertyName() == GET_MEMBER_NAME_CHECKED(UProWorkflowToolsUserSettings, CollectionEntries))
	{
		InteractiveDecalPlacement::InvalidateBrowseCategoryCache();
	}
}

void UProWorkflowToolsUserSettings::NotifyAndPersist(FProperty* Property)
{
	FPropertyChangedEvent ChangeEvent(Property);
	PostEditChangeProperty(ChangeEvent);
}
#endif

void UProWorkflowToolsUserSettings::ImportProjectCollectionEntriesIfNeeded()
{
	if (bDecalCollectionEntriesInitialized)
	{
		return;
	}

	bDecalCollectionEntriesInitialized = true;
	if (CollectionEntries.IsEmpty())
	{
		if (const UProWorkflowToolsSettings* ProjectSettings = GetDefault<UProWorkflowToolsSettings>())
		{
			CollectionEntries = ProjectSettings->CollectionEntries;
		}
	}
	SaveConfig();
}

