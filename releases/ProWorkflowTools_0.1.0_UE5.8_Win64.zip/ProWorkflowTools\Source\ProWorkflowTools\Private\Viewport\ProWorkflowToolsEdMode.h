// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "BoxScale/BoxScaleTool.h"
#include "GridPaint/GridPaintTool.h"
#include "MaterialClipboard/MaterialClipboardTool.h"
#include "SuperGroups/SuperGroupClickTool.h"
#include "UI/ViewportCursorLabel.h"
#include "Viewport/DccMarqueeTool.h"
#include "Viewport/LocalTransformModifierTool.h"
#include "Viewport/WorkflowViewportTool.h"
#include "EdMode.h"
#include "ProWorkflowToolsEngineVersion.h"
#include "UObject/WeakObjectPtr.h"

class UModeManagerInteractiveToolsContext;

/**
 * Invisible utility EdMode hosting the viewport tools: Grid Paint, Material Clipboard, Box Scale,
 * DCC marquee, and the local transform modifier. Every viewport hook routes through the tools in that
 * priority order (see RouteInput).
 */
class FProWorkflowToolsEdMode : public FEdMode, public IWorkflowToolHost
{
public:
	static const FEditorModeID EM_ProWorkflowTools;

	FProWorkflowToolsEdMode();
	virtual ~FProWorkflowToolsEdMode() override;

	// Coexist with every other editor mode, never show up in the modes UI.
	virtual bool IsCompatibleWith(FEditorModeID OtherModeID) const override { return true; }
	virtual bool UsesToolkits() const override { return false; }

#if PWT_UE_5_8_OR_LATER
	/** Always-on utility mode. The FEdMode default would disable ITF gizmos for the whole editor. */
	virtual bool RequiresLegacyViewportInteractions() const override { return false; }
#endif

	virtual void Enter() override;
	virtual void Exit() override;

	/** Box Scale off — release TRS suppression now. */
	void NotifyBoxScaleDisabled();

	/**
	 * Settings changed without a mode change — rebuild viewport interactions if the bare-LMB owner the
	 * engine was last told about no longer matches OwnsBareLmb().
	 */
	void SyncViewportInteractions();

	/** Undo/redo → Grid Paint occupancy refresh. */
	void NotifyPostUndoRedo();

	bool IsGridPaintActive() const { return GridPaintTool.IsActive(); }
	void ToggleGridPaint(FEditorViewportClient* ViewportClient);

	/**
	 * Readout next to the cursor for a module command (Shift+D). Shown only if a level viewport is
	 * hovered when the command fires, and drawn in that viewport.
	 */
	void ShowCommandLabel(TConstArrayView<ProWorkflowTools::CursorLabel::FLine> Lines);

	// Strip Ctrl+D grid nudge when Duplicate In Place is on.
	virtual void ActorsDuplicatedNotify(TArray<AActor*>& PreDuplicateSelection, TArray<AActor*>& PostDuplicateSelection, bool bOffsetLocations) override;

	// IWorkflowToolHost
	virtual FEditorModeTools* GetModeTools() const override { return Owner; }
	virtual bool IsTransformGizmoReplaced() const override;

	// --- Routed tool hooks ---
	virtual void Tick(FEditorViewportClient* ViewportClient, float DeltaTime) override;
	virtual void Render(const FSceneView* View, FViewport* Viewport, FPrimitiveDrawInterface* PDI) override;
	virtual void DrawHUD(FEditorViewportClient* ViewportClient, FViewport* Viewport, const FSceneView* View, FCanvas* Canvas) override;
	virtual bool InputKey(FEditorViewportClient* ViewportClient, FViewport* Viewport, FKey Key, EInputEvent Event) override;
	virtual bool StartTracking(FEditorViewportClient* InViewportClient, FViewport* InViewport) override;
	virtual bool EndTracking(FEditorViewportClient* InViewportClient, FViewport* InViewport) override;
	virtual bool CapturedMouseMove(FEditorViewportClient* InViewportClient, FViewport* InViewport, int32 InMouseX, int32 InMouseY) override;
	virtual bool MouseMove(FEditorViewportClient* ViewportClient, FViewport* Viewport, int32 x, int32 y) override;
	virtual bool HandleClick(FEditorViewportClient* InViewportClient, HHitProxy* HitProxy, const FViewportClick& Click) override;
	virtual bool InputDelta(FEditorViewportClient* InViewportClient, FViewport* InViewport, FVector& InDrag, FRotator& InRot, FVector& InScale) override;
	virtual bool BoxSelect(FBox& InBox, bool InSelect = true) override;
	virtual bool FrustumSelect(const FConvexVolume& InFrustum, FEditorViewportClient* InViewportClient, bool InSelect = true) override;
	virtual bool GetOverrideCursorVisibility(bool& bWantsOverride, bool& bHardwareCursorVisible, bool bSoftwareCursorVisible) const override;
	virtual bool AllowsViewportDragTool() const override;
	virtual bool DisallowMouseDeltaTracking() const override;

	// FGCObject
	virtual void AddReferencedObjects(FReferenceCollector& Collector) override;
	virtual FString GetReferencerName() const override { return TEXT("FProWorkflowToolsEdMode"); }

private:
	/**
	 * Input routing: while a tool is exclusive only that tool is asked, otherwise every tool in
	 * priority order until one handles the event. Returns the tool that handled it, or null.
	 */
	template <typename FunctorType>
	FWorkflowViewportTool* RouteInput(FunctorType&& Handler) const;

	/**
	 * Viewport interactions include PerspectiveMoveYaw (bare LMB camera drag). While the plugin owns
	 * bare LMB it is reported unsupported. Interactions rebuild on every mode enter/exit, so a handler
	 * registered in Enter and removed in Exit covers Decal mode and this mode's own lifetime.
	 * 5.6 has no OnGetUnsupportedInteractions; DCC LMB ownership uses AllowsViewportDragTool there.
	 */
#if PWT_UE_5_8_OR_LATER
	void AddUnsupportedViewportInteractions(TArray<FName>& Interactions);
#endif
	void RemoveUnsupportedInteractionsHandler();

	/** DCC marquee or Interactive Decal Placement owns bare LMB. */
	bool OwnsBareLmb() const;

#if PWT_UE_5_8_OR_LATER
	TWeakObjectPtr<UModeManagerInteractiveToolsContext> UnsupportedInteractionsContext;
	FDelegateHandle UnsupportedInteractionsHandle;
	/** OwnsBareLmb() as reported during the last interactions rebuild. */
	bool bBareLmbOwnedAtLastBuild = false;
#endif

	FGridPaintTool GridPaintTool;
	FMaterialClipboardTool MaterialClipboardTool;
	FBoxScaleTool BoxScaleTool;
	FDccMarqueeTool DccMarqueeTool;
	FLocalTransformModifierTool LocalTransformModifierTool;
	FSuperGroupClickTool SuperGroupClickTool;

	/** Priority order for every routed hook. */
	TArray<FWorkflowViewportTool*, TInlineAllocator<6>> Tools;

	ProWorkflowTools::CursorLabel::FFadingLabel CommandLabel;
};
