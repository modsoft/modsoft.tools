// Copyright © 2026 Trey McNair. All rights reserved.

#include "MaterialClipboard/MaterialClipboardTool.h"

#include "DecalPlacement/InteractiveDecalPlacementEdMode.h"
#include "ProWorkflowToolsModule.h"
#include "ProWorkflowToolsSettings.h"
#include "UI/ProWorkflowToolHudOverlay.h"
#include "UI/ProWorkflowToolHudTypes.h"
#include "UI/SProWorkflowToolHud.h"
#include "UI/ViewportCursorLabel.h"
#include "Viewport/ViewportOverlayStyle.h"

#include "CanvasItem.h"
#include "CanvasTypes.h"
#include "Components/MeshComponent.h"
#include "Editor.h"
#include "EditorModeManager.h"
#include "EditorViewportClient.h"
#include "Engine/Selection.h"
#include "EngineUtils.h"
#include "Framework/Application/SlateApplication.h"
#include "Framework/Notifications/NotificationManager.h"
#include "GameFramework/Actor.h"
#include "HitProxies.h"
#include "Materials/Material.h"
#include "Materials/MaterialInstanceConstant.h"
#include "Materials/MaterialInterface.h"
#include "ProWorkflowToolsEngineAdapter.h"
#include "ScopedTransaction.h"
#include "UnrealClient.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Widgets/Notifications/SNotificationList.h"

#define LOCTEXT_NAMESPACE "ProWorkflowTools"

namespace MaterialClipboardTool::Private
{
	/** Canvas units are DPI-scaled by FCanvas; only mouse pixels need dividing. */
	constexpr float BurstSeconds = 0.35f;
	constexpr float BurstStartRadius = 14.0f;
	constexpr float BurstEndRadius = 40.0f;
	constexpr float BurstInnerRadius = 3.0f;
	constexpr float DualRingGap = 8.0f;
	constexpr float RingThickness = 2.0f;
	constexpr int32 RingSegments = 48;

	constexpr float FeedbackOpacity = 0.95f;

	void ShowMaterialClipboardNotification(const FText& Message)
	{
		FNotificationInfo Info(Message);
		Info.ExpireDuration = 1.5f;
		Info.bFireAndForget = true;
		FSlateNotificationManager::Get().AddNotification(Info);
	}

	bool IsMaterialClipboardHoldActive(FEditorViewportClient* ViewportClient, FViewport* Viewport)
	{
		if (!ViewportClient || !Viewport)
		{
			return false;
		}

		const UProWorkflowToolsSettings* Settings = GetDefault<UProWorkflowToolsSettings>();
		if (!Settings || !Settings->bEnableMaterialClipboardTool)
		{
			return false;
		}

		const FKey HoldKey = Settings->MaterialClipboardHoldKey.IsValid() ? Settings->MaterialClipboardHoldKey : EKeys::Tab;
		return Viewport->KeyState(HoldKey);
	}

	/**
	 * Maps the hovered slot onto a target component for single-slot apply/clear. The hovered component
	 * itself uses the exact hovered index; other selected components are matched by slot name so the
	 * same logical slot is affected even when meshes have different slot orderings.
	 */
	int32 ResolveTargetSlotIndex(const UPrimitiveComponent* Target, const UPrimitiveComponent* HoveredComponent,
		int32 HoveredMaterialIndex, FName SlotName)
	{
		if (Target == HoveredComponent)
		{
			return HoveredMaterialIndex;
		}
		if (SlotName != NAME_None)
		{
			return Target->GetMaterialIndex(SlotName);
		}
		return INDEX_NONE;
	}

	float EaseOutCubic(const float T)
	{
		const float Inv = 1.0f - FMath::Clamp(T, 0.0f, 1.0f);
		return 1.0f - Inv * Inv * Inv;
	}

	bool IsErase(const EMaterialClipboardCursorBurst Burst)
	{
		return Burst == EMaterialClipboardCursorBurst::Erase || Burst == EMaterialClipboardCursorBurst::EraseAll;
	}

	/** Pick collapses inward. Apply and erase expand outward; the all-slots variants get a second ring. */
	bool IsAllSlots(const EMaterialClipboardCursorBurst Burst)
	{
		return Burst == EMaterialClipboardCursorBurst::ApplyAll || Burst == EMaterialClipboardCursorBurst::EraseAll;
	}

	FText SlotCountText(const int32 NumSlots)
	{
		return FText::Format(LOCTEXT("MatClipboardSlotCount", "{0} {0}|plural(one=slot,other=slots)"), NumSlots);
	}

	/** The slot as the Details panel names it: its slot name, else "Element N". */
	FText SlotText(const FName SlotName, const int32 MaterialIndex)
	{
		return SlotName != NAME_None
			? FText::FromName(SlotName)
			: FText::Format(LOCTEXT("MatClipboardElement", "Element {0}"), MaterialIndex);
	}

	/** Single-slot result: the slot, plus the slot count when the selection matched it on several meshes. */
	FText SingleSlotResultText(const FText& Prefix, const FName SlotName, const int32 MaterialIndex, const int32 NumSlots)
	{
		const FText Slot = FText::Format(LOCTEXT("MatClipboardSlotResult", "{0} {1}"), Prefix, SlotText(SlotName, MaterialIndex));
		return NumSlots > 1
			? FText::Format(LOCTEXT("MatClipboardSlotResultCount", "{0} ({1})"), Slot, SlotCountText(NumSlots))
			: Slot;
	}
}

bool FMaterialClipboardTool::InputKey(FEditorViewportClient* ViewportClient, FViewport* Viewport, FKey Key, EInputEvent Event)
{
	if (!ViewportClient || !Viewport || !GEditor)
	{
		return false;
	}

	const bool bActionButton = (Key == EKeys::LeftMouseButton || Key == EKeys::RightMouseButton || Key == EKeys::MiddleMouseButton);
	if (!bActionButton)
	{
		return false;
	}

	// Consume the release paired with a gesture we started so the viewport skips selection / the RMB
	// context menu, even if the hold key was released before the mouse button.
	if (Event == IE_Released)
	{
		if (bMaterialGestureActive)
		{
			bMaterialGestureActive = false;
			return true;
		}
		return false;
	}

	if (Event != IE_Pressed && Event != IE_DoubleClick)
	{
		return false;
	}

	if (!bHoldKeyWasDown)
	{
		return false;
	}

	ProWorkflowTools::TerminateInteractiveToolsMouseCapture(ViewportClient);

	UPrimitiveComponent* SlotComponent = nullptr;
	int32 SlotIndex = INDEX_NONE;
	GetHoveredMeshSlot(Viewport, SlotComponent, SlotIndex);

	ClickViewportClient = ViewportClient;
	ClickPixel = FIntPoint(Viewport->GetMouseX(), Viewport->GetMouseY());

	const bool bAllSlots = (Event == IE_DoubleClick);

	if (Key == EKeys::MiddleMouseButton)
	{
		PickMaterialUnderCursor(SlotComponent, SlotIndex);
	}
	else if (Key == EKeys::LeftMouseButton)
	{
		ApplyMaterialUnderCursor(SlotComponent, SlotIndex, bAllSlots);
	}
	else if (Key == EKeys::RightMouseButton)
	{
		RemoveMaterialUnderCursor(SlotComponent, SlotIndex, bAllSlots);
	}

	bMaterialGestureActive = true;
	return true;
}

void FMaterialClipboardTool::Tick(FEditorViewportClient* ViewportClient, float DeltaTime)
{
	using namespace MaterialClipboardTool::Private;

	if (!ViewportClient || !ViewportClient->Viewport)
	{
		return;
	}

	// The focused viewport's key state is the hold authority (it empties on focus loss). Decal
	// Placement uses Tab+Scroll for categories, so the clipboard is off while that mode is active.
	const bool bHoldDown = IsMaterialClipboardHoldActive(ViewportClient, ViewportClient->Viewport)
		&& !GLevelEditorModeTools().IsModeActive(FInteractiveDecalPlacementEdMode::EM_InteractiveDecalPlacement);
	if (bHoldDown != bHoldKeyWasDown)
	{
		UpdateHoldKeyState(bHoldDown);
	}
	else if (bHoldDown)
	{
		// The viewport resets its cursor override on focus change and when tracking ends.
		ProWorkflowTools::SetLevelViewportsCursorOverride(true, EMouseCursor::EyeDropper);
	}

	if (Burst == EMaterialClipboardCursorBurst::None)
	{
		return;
	}

	const double Now = FPlatformTime::Seconds();
	if (BurstStart < 0.0)
	{
		BurstStart = Now;
	}
	else if (Now - BurstStart >= ProWorkflowTools::CursorLabel::VisibleSeconds)
	{
		Burst = EMaterialClipboardCursorBurst::None;
	}

	// Clicking focuses the viewport, so the ticking (focused) client is the one showing the feedback.
	ViewportClient->Invalidate(false, false);
}

void FMaterialClipboardTool::DrawHUD(FEditorViewportClient* ViewportClient, FViewport* Viewport, const FSceneView* View, FCanvas* Canvas)
{
	using namespace MaterialClipboardTool::Private;

	(void)Viewport;
	(void)View;
	if (Burst == EMaterialClipboardCursorBurst::None || BurstStart < 0.0 || !Canvas
		|| ViewportClient != ClickViewportClient)
	{
		return;
	}

	const float Elapsed = static_cast<float>(FPlatformTime::Seconds() - BurstStart);
	const float DPI = FMath::Max(Canvas->GetDPIScale(), 0.01f);
	const FVector2D Center(ClickPixel.X / DPI, ClickPixel.Y / DPI);
	const FLinearColor BaseColor = (IsErase(Burst) ? ProWorkflowTools::OverlayStyle::Erase : ProWorkflowTools::OverlayStyle::Accent())
		.CopyWithNewOpacity(FeedbackOpacity);

	auto DrawRing = [&](const float Radius, const FLinearColor& Color)
	{
		FVector2D Prev(Center.X + Radius, Center.Y);
		for (int32 Segment = 1; Segment <= RingSegments; ++Segment)
		{
			const float Angle = 2.0f * PI * static_cast<float>(Segment) / static_cast<float>(RingSegments);
			const FVector2D Next(Center.X + FMath::Cos(Angle) * Radius, Center.Y + FMath::Sin(Angle) * Radius);
			FCanvasLineItem Line(Prev, Next);
			Line.SetColor(Color);
			Line.LineThickness = RingThickness;
			Canvas->DrawItem(Line);
			Prev = Next;
		}
	};

	if (Elapsed < BurstSeconds)
	{
		const float T = EaseOutCubic(Elapsed / BurstSeconds);
		const float Radius = Burst == EMaterialClipboardCursorBurst::Pick
			? FMath::Lerp(BurstStartRadius, BurstInnerRadius, T)
			: FMath::Lerp(BurstStartRadius, BurstEndRadius, T);
		FLinearColor RingColor = BaseColor;
		RingColor.A *= 1.0f - T;
		DrawRing(Radius, RingColor);
		if (IsAllSlots(Burst))
		{
			DrawRing(Radius + DualRingGap, RingColor);
		}
	}

	const ProWorkflowTools::CursorLabel::FLine Label{BurstLabel, BaseColor};
	ProWorkflowTools::CursorLabel::Draw(Canvas, ClickPixel, MakeArrayView(&Label, 1), ProWorkflowTools::CursorLabel::GetAlpha(Elapsed));
}

void FMaterialClipboardTool::Exit()
{
	HideHudOverlay();
	if (bHoldKeyWasDown)
	{
		ProWorkflowTools::SetLevelViewportsCursorOverride(false, EMouseCursor::EyeDropper);
	}
	bHoldKeyWasDown = false;
	bMaterialGestureActive = false;
	Burst = EMaterialClipboardCursorBurst::None;
	ClickViewportClient = nullptr;
}

void FMaterialClipboardTool::UpdateHoldKeyState(const bool bHoldDown)
{
	bHoldKeyWasDown = bHoldDown;
	if (bHoldDown)
	{
		ShowHudOverlay();
	}
	else
	{
		HideHudOverlay();
	}

	ProWorkflowTools::SetLevelViewportsCursorOverride(bHoldDown, EMouseCursor::EyeDropper);

	// Slate only re-queries the cursor on mouse movement; the hold edge changes it too.
	if (FSlateApplication::IsInitialized())
	{
		FSlateApplication::Get().QueryCursor();
	}
}

void FMaterialClipboardTool::BeginFeedback(const EMaterialClipboardCursorBurst InBurst, const FText& Label)
{
	Burst = InBurst;
	BurstLabel = Label;
	BurstStart = -1.0;
	if (HudOverlay.IsValid())
	{
		HudOverlay->Invalidate(EInvalidateWidgetReason::Paint);
	}
}

FProWorkflowToolHudModel FMaterialClipboardTool::BuildHudModel() const
{
	FProWorkflowToolHudModel Model;
	Model.Title = LOCTEXT("MatClipboardHudTitle", "Material Clipboard");

	const FProWorkflowToolsModule* Module = FProWorkflowToolsModule::GetPtr();
	UMaterialInterface* Material = Module ? Module->GetPickedMaterial() : nullptr;
	if (Material)
	{
		Model.Fields.Add(MakeHudTextField(
			TEXT("Payload"),
			FText::GetEmpty(),
			FText::FromString(Material->GetName()),
			180.0f,
			true));
	}
	else
	{
		Model.Fields.Add(MakeHudTextField(
			TEXT("Payload"),
			FText::GetEmpty(),
			LOCTEXT("MatClipboardHudEmpty", "[empty]"),
			180.0f,
			false,
			true));
	}

	AddHudKeycap(Model.Keycaps, LOCTEXT("MatClipboardKeyMmb", "MMB"), LOCTEXT("MatClipboardActPick", "Pick"));
	AddHudKeycap(Model.Keycaps, LOCTEXT("MatClipboardKeyLmb", "LMB"), LOCTEXT("MatClipboardActApply", "Apply"));
	AddHudKeycap(Model.Keycaps, LOCTEXT("MatClipboardKeyRmb", "RMB"), LOCTEXT("MatClipboardActClear", "Clear"));
	AddHudKeycap(Model.Keycaps, LOCTEXT("MatClipboardKeyDblLmb", "Double LMB"), LOCTEXT("MatClipboardActApplyAll", "Apply All"));
	AddHudKeycap(Model.Keycaps, LOCTEXT("MatClipboardKeyDblRmb", "Double RMB"), LOCTEXT("MatClipboardActClearAll", "Clear All"));

	return Model;
}

void FMaterialClipboardTool::ShowHudOverlay()
{
	HudOverlay.Show([this]()
	{
		return SNew(SProWorkflowToolHud)
			.bPanelHitTestable(false)
			.Model_Lambda([this]()
			{
				return BuildHudModel();
			});
	});
}

void FMaterialClipboardTool::HideHudOverlay()
{
	HudOverlay.Hide();
}

void FMaterialClipboardTool::GetHoveredMeshSlot(FViewport* Viewport, UPrimitiveComponent*& OutComponent, int32& OutMaterialIndex)
{
	OutComponent = nullptr;
	OutMaterialIndex = INDEX_NONE;

	// The editor's hit proxy is the slot authority: what the user sees under the cursor.
	const HActor* ActorProxy = HitProxyCast<HActor>(Viewport->GetHitProxy(Viewport->GetMouseX(), Viewport->GetMouseY()));
	UPrimitiveComponent* Component = ActorProxy ? const_cast<UPrimitiveComponent*>(ActorProxy->PrimComponent.Get()) : nullptr;
	const int32 MaterialIndex = Component ? ProWorkflowTools::GetHitProxyMaterialIndex(*ActorProxy) : INDEX_NONE;
	if (MaterialIndex == INDEX_NONE)
	{
		return;
	}

	OutComponent = Component;
	OutMaterialIndex = MaterialIndex;
}

void FMaterialClipboardTool::GatherMaterialTargets(UPrimitiveComponent* HoveredComponent, TArray<UPrimitiveComponent*>& OutTargets)
{
	OutTargets.Reset();

	AActor* HoveredActor = HoveredComponent ? HoveredComponent->GetOwner() : nullptr;
	USelection* Selection = GEditor ? GEditor->GetSelectedActors() : nullptr;
	const int32 NumSelected = Selection ? Selection->Num() : 0;
	const bool bHoveredIsSelected = HoveredActor && Selection && Selection->IsSelected(HoveredActor);

	if (NumSelected > 0 && bHoveredIsSelected)
	{
		for (FSelectionIterator It(GEditor->GetSelectedActorIterator()); It; ++It)
		{
			if (AActor* Actor = Cast<AActor>(*It))
			{
				TArray<UMeshComponent*> MeshComponents;
				Actor->GetComponents<UMeshComponent>(MeshComponents);
				for (UMeshComponent* MeshComponent : MeshComponents)
				{
					if (MeshComponent && MeshComponent->GetNumMaterials() > 0)
					{
						OutTargets.AddUnique(MeshComponent);
					}
				}
			}
		}
	}
	else if (HoveredComponent)
	{
		OutTargets.Add(HoveredComponent);
	}
}

void FMaterialClipboardTool::PickMaterialUnderCursor(UPrimitiveComponent* InHoveredComponent, int32 InHoveredMaterialIndex)
{
	FProWorkflowToolsModule* Module = FProWorkflowToolsModule::GetPtr();
	if (!Module)
	{
		return;
	}

	if (!InHoveredComponent || InHoveredMaterialIndex == INDEX_NONE)
	{
		return;
	}

	// Only Material / Material Instance assets. Dynamic and level-owned instances belong to one world.
	UMaterialInterface* Material = InHoveredComponent->GetMaterial(InHoveredMaterialIndex);
	if (!Material || !Material->IsAsset() || !(Material->IsA<UMaterial>() || Material->IsA<UMaterialInstanceConstant>()))
	{
		MaterialClipboardTool::Private::ShowMaterialClipboardNotification(
			LOCTEXT("MatClipboardPickNotAsset", "Material Clipboard: slot has no Material or Material Instance asset"));
		return;
	}

	Module->SetPickedMaterial(Material);
	BeginFeedback(EMaterialClipboardCursorBurst::Pick, FText::FromString(Material->GetName()));
}

void FMaterialClipboardTool::ApplyMaterialUnderCursor(UPrimitiveComponent* InHoveredComponent, int32 InHoveredMaterialIndex, bool bAllSlots)
{
	FProWorkflowToolsModule* Module = FProWorkflowToolsModule::GetPtr();
	if (!Module || !GEditor)
	{
		return;
	}

	if (!InHoveredComponent || InHoveredMaterialIndex == INDEX_NONE)
	{
		return;
	}

	UMaterialInterface* Material = Module->GetPickedMaterial();
	if (!Material)
	{
		MaterialClipboardTool::Private::ShowMaterialClipboardNotification(
			LOCTEXT("MatClipboardApplyEmpty", "Material Clipboard: nothing picked (hold key + MMB)"));
		return;
	}

	TArray<UPrimitiveComponent*> Targets;
	GatherMaterialTargets(InHoveredComponent, Targets);
	if (Targets.Num() == 0)
	{
		return;
	}

	FName SlotName = NAME_None;
	const TArray<FName> HoveredSlotNames = InHoveredComponent->GetMaterialSlotNames();
	if (HoveredSlotNames.IsValidIndex(InHoveredMaterialIndex))
	{
		SlotName = HoveredSlotNames[InHoveredMaterialIndex];
	}

	int32 NumSlots = 0;
	const FScopedTransaction Transaction(LOCTEXT("MatClipboardApplyTransaction", "Apply Material"));
	for (UPrimitiveComponent* Target : Targets)
	{
		if (!Target)
		{
			continue;
		}

		Target->Modify();

		if (bAllSlots)
		{
			const int32 NumMaterials = Target->GetNumMaterials();
			for (int32 Index = 0; Index < NumMaterials; ++Index)
			{
				Target->SetMaterial(Index, Material);
			}
			NumSlots += NumMaterials;
		}
		else
		{
			const int32 Index = MaterialClipboardTool::Private::ResolveTargetSlotIndex(Target, InHoveredComponent, InHoveredMaterialIndex, SlotName);
			if (Index != INDEX_NONE && Index < Target->GetNumMaterials())
			{
				Target->SetMaterial(Index, Material);
				++NumSlots;
			}
		}
	}

	// SetMaterial rebuilds scene proxies, so the viewports' cached hit proxies are stale until invalidated.
	GEditor->RedrawLevelEditingViewports();

	using namespace MaterialClipboardTool::Private;
	BeginFeedback(bAllSlots ? EMaterialClipboardCursorBurst::ApplyAll : EMaterialClipboardCursorBurst::Apply,
		bAllSlots
			? FText::Format(LOCTEXT("MatClipboardApplied", "{0} ({1})"), FText::FromString(Material->GetName()), SlotCountText(NumSlots))
			: SingleSlotResultText(
				FText::Format(LOCTEXT("MatClipboardAppliedTo", "{0} →"), FText::FromString(Material->GetName())),
				SlotName, InHoveredMaterialIndex, NumSlots));
}

void FMaterialClipboardTool::RemoveMaterialUnderCursor(UPrimitiveComponent* InHoveredComponent, int32 InHoveredMaterialIndex, bool bAllSlots)
{
	if (!GEditor)
	{
		return;
	}

	if (!InHoveredComponent || InHoveredMaterialIndex == INDEX_NONE)
	{
		return;
	}

	TArray<UPrimitiveComponent*> Targets;
	GatherMaterialTargets(InHoveredComponent, Targets);
	if (Targets.Num() == 0)
	{
		return;
	}

	FName SlotName = NAME_None;
	const TArray<FName> HoveredSlotNames = InHoveredComponent->GetMaterialSlotNames();
	if (HoveredSlotNames.IsValidIndex(InHoveredMaterialIndex))
	{
		SlotName = HoveredSlotNames[InHoveredMaterialIndex];
	}

	int32 NumSlots = 0;
	const FScopedTransaction Transaction(LOCTEXT("MatClipboardClearTransaction", "Clear Material Override"));
	for (UPrimitiveComponent* Target : Targets)
	{
		if (!Target)
		{
			continue;
		}

		Target->Modify();

		if (bAllSlots)
		{
			const int32 NumMaterials = Target->GetNumMaterials();
			for (int32 Index = 0; Index < NumMaterials; ++Index)
			{
				Target->SetMaterial(Index, nullptr);
			}
			NumSlots += NumMaterials;
		}
		else
		{
			const int32 Index = MaterialClipboardTool::Private::ResolveTargetSlotIndex(Target, InHoveredComponent, InHoveredMaterialIndex, SlotName);
			if (Index != INDEX_NONE && Index < Target->GetNumMaterials())
			{
				Target->SetMaterial(Index, nullptr);
				++NumSlots;
			}
		}
	}

	// SetMaterial rebuilds scene proxies, so the viewports' cached hit proxies are stale until invalidated.
	GEditor->RedrawLevelEditingViewports();

	using namespace MaterialClipboardTool::Private;
	BeginFeedback(bAllSlots ? EMaterialClipboardCursorBurst::EraseAll : EMaterialClipboardCursorBurst::Erase,
		bAllSlots
			? FText::Format(LOCTEXT("MatClipboardCleared", "Cleared ({0})"), SlotCountText(NumSlots))
			: SingleSlotResultText(LOCTEXT("MatClipboardClearedSlot", "Cleared"), SlotName, InHoveredMaterialIndex, NumSlots));
}

#undef LOCTEXT_NAMESPACE
