// Copyright © 2026 Trey McNair. All rights reserved.

#include "InteractiveDecalPlacementMath.h"

#include "Components/DecalComponent.h"

namespace InteractiveDecalPlacement
{
	FVector MakeDecalScaleForHalfExtents(const FVector& SignedHalfExtentsCm)
	{
		return SignedHalfExtentsCm / DefaultDecalSize;
	}

	FVector GetDecalSignedHalfExtents(const UDecalComponent& Decal)
	{
		return Decal.DecalSize * Decal.GetComponentTransform().GetScale3D();
	}

	FInteractiveDecalTangentFrame MakeTangentFrameFromHit(const FVector& Position, const FVector& Normal, const FVector& ViewDirection)
	{
		FInteractiveDecalTangentFrame Frame;
		Frame.Position = Position;
		Frame.Normal = Normal.GetSafeNormal();

		// Align the decal's vertical axis with the surface: on walls, project world-up onto the
		// surface plane so the decal hangs straight (poster-style). On near-horizontal surfaces
		// (floor/ceiling), world-up is degenerate, so use the view direction projected onto the
		// plane instead, which makes the decal face the viewer naturally.
		const bool bNearHorizontal = FMath::Abs(Frame.Normal.Z) > 0.9f;
		FVector UpReference = bNearHorizontal ? ViewDirection : FVector::UpVector;

		FVector ImageUp = FVector::VectorPlaneProject(UpReference, Frame.Normal).GetSafeNormal();
		if (ImageUp.IsNearlyZero())
		{
			ImageUp = FVector::VectorPlaneProject(FVector::ForwardVector, Frame.Normal).GetSafeNormal();
		}

		// The deferred decal shader maps texture V along the actor's local +Y (Tangent) and
		// texture U along local +Z, so the image's "up" direction is -Y. Point the tangent
		// at -ImageUp so the decal texture reads upright on the surface.
		Frame.Tangent = -ImageUp;
		Frame.Bitangent = FVector::CrossProduct(Frame.Normal, Frame.Tangent).GetSafeNormal();
		return Frame;
	}

	FInteractiveDecalTangentFrame RotateFrameInPlane(const FInteractiveDecalTangentFrame& Frame, const float AngleRad)
	{
		FInteractiveDecalTangentFrame Rotated = Frame;
		const float CosA = FMath::Cos(AngleRad);
		const float SinA = FMath::Sin(AngleRad);
		Rotated.Tangent = (Frame.Tangent * CosA + Frame.Bitangent * SinA).GetSafeNormal();
		Rotated.Bitangent = (Frame.Bitangent * CosA - Frame.Tangent * SinA).GetSafeNormal();
		return Rotated;
	}

	bool RayPlaneIntersection(
		const FVector& RayOrigin,
		const FVector& RayDirection,
		const FVector& PlaneOrigin,
		const FVector& PlaneNormal,
		FVector& OutIntersection)
	{
		const float Denominator = FVector::DotProduct(RayDirection, PlaneNormal);
		if (FMath::IsNearlyZero(Denominator))
		{
			return false;
		}

		const float DistanceAlongRay = FVector::DotProduct(PlaneOrigin - RayOrigin, PlaneNormal) / Denominator;
		if (DistanceAlongRay < 0.0f)
		{
			return false;
		}

		OutIntersection = RayOrigin + RayDirection * DistanceAlongRay;
		return true;
	}

	FQuat MakeDecalActorRotation(const FVector& Normal, const FVector& Tangent)
	{
		const FVector SurfaceNormal = Normal.GetSafeNormal();
		const FVector WidthAxis = Tangent.GetSafeNormal();
		const FVector ProjectionAxis = -SurfaceNormal;
		const FVector HeightAxis = FVector::CrossProduct(ProjectionAxis, WidthAxis).GetSafeNormal();
		const FMatrix BasisMatrix(ProjectionAxis, WidthAxis, HeightAxis, FVector::ZeroVector);
		return BasisMatrix.ToQuat();
	}

	FInteractiveDecalPlacementResult ComputePlacementFromDrag(
		const FInteractiveDecalTangentFrame& AnchorFrame,
		const FVector& DragPlanePoint,
		const bool bCenterScale,
		const bool bLockAspectRatio,
		const float TangentOverBitangentRatio,
		const float ProjectionDepth,
		const float MinExtent)
	{
		FInteractiveDecalPlacementResult Result;

		const FVector DragVector = DragPlanePoint - AnchorFrame.Position;
		float DragU = FVector::DotProduct(DragVector, AnchorFrame.Tangent);
		float DragV = FVector::DotProduct(DragVector, AnchorFrame.Bitangent);

		if (bLockAspectRatio)
		{
			const float AbsU = FMath::Abs(DragU);
			const float AbsV = FMath::Abs(DragV);
			const float SafeAspect = FMath::Max(TangentOverBitangentRatio, KINDA_SMALL_NUMBER);

			if (AbsU >= AbsV * SafeAspect)
			{
				DragV = FMath::Sign(DragV) * AbsU / SafeAspect;
			}
			else
			{
				DragU = FMath::Sign(DragU) * AbsV * SafeAspect;
			}
		}

		const FVector2D DragComponents(DragU, DragV);
		const FVector2D AbsDrag = DragComponents.GetAbs();

		// UDecalComponent::DecalSize stores half-extents in local Y/Z.
		const FVector2D HalfExtents = bCenterScale ? AbsDrag : AbsDrag * 0.5f;
		const FVector2D ClampedHalfExtents(
			FMath::Max(HalfExtents.X, MinExtent),
			FMath::Max(HalfExtents.Y, MinExtent));

		// Corner mode: mouse stays at the dragged corner. Natural screen down-right is +U/-V
		// (image down = +Tangent, image right = -Bitangent), matching hover's +T/-B offset.
		const FVector WidthDir = (DragU >= 0.0f) ? AnchorFrame.Tangent : -AnchorFrame.Tangent;
		const FVector HeightDir = (DragV >= 0.0f) ? AnchorFrame.Bitangent : -AnchorFrame.Bitangent;
		const FVector Center = bCenterScale
			? AnchorFrame.Position
			: AnchorFrame.Position + WidthDir * ClampedHalfExtents.X + HeightDir * ClampedHalfExtents.Y;

		Result.ActorTransform = FTransform(
			MakeDecalActorRotation(AnchorFrame.Normal, AnchorFrame.Tangent),
			Center);
		Result.DecalSize = FVector(
			ProjectionDepth,
			ClampedHalfExtents.X,
			ClampedHalfExtents.Y);
		return Result;
	}

	void GetPlacementSamplePoints(const FInteractiveDecalPlacementResult& Flat, TArray<FVector, TInlineAllocator<9>>& OutPoints)
	{
		const FQuat Rotation = Flat.ActorTransform.GetRotation();
		const FVector Center = Flat.ActorTransform.GetLocation();
		// Actor Y is the decal's height axis (DecalSize.Y), actor Z its width axis (DecalSize.Z).
		const FVector HalfY = Rotation.GetAxisY() * FMath::Abs(Flat.DecalSize.Y);
		const FVector HalfZ = Rotation.GetAxisZ() * FMath::Abs(Flat.DecalSize.Z);

		OutPoints.Reset();
		for (int32 StepY = -1; StepY <= 1; ++StepY)
		{
			for (int32 StepZ = -1; StepZ <= 1; ++StepZ)
			{
				OutPoints.Add(Center + HalfY * StepY + HalfZ * StepZ);
			}
		}
	}

	FInteractiveDecalPlacementResult FitPlacementToSurface(
		const FInteractiveDecalPlacementResult& Flat,
		const TConstArrayView<FSurfaceFitSample> Samples,
		const FVector& PinPoint,
		const FVector& ViewOrigin,
		const FVector& ViewDirection,
		const bool bPerspective,
		TArray<FVector>* OutUsedSamples)
	{
		if (OutUsedSamples)
		{
			OutUsedSamples->Reset();
		}

		const FQuat FlatRotation = Flat.ActorTransform.GetRotation();
		const FVector FlatCenter = Flat.ActorTransform.GetLocation();
		const FVector FlatNormal = -FlatRotation.GetAxisX();
		const double MaxPlaneDistance = FMath::Max(FMath::Abs(Flat.DecalSize.Y), FMath::Abs(Flat.DecalSize.Z));
		constexpr double MinNormalDot = 0.5; // cos 60°

		FVector NormalSum = FVector::ZeroVector;
		FVector Centroid = FVector::ZeroVector;
		int32 Count = 0;
		for (const FSurfaceFitSample& Sample : Samples)
		{
			if (FVector::DotProduct(Sample.Normal, FlatNormal) < MinNormalDot
				|| FMath::Abs(FVector::DotProduct(Sample.Location - FlatCenter, FlatNormal)) > MaxPlaneDistance)
			{
				continue;
			}
			NormalSum += Sample.Normal;
			Centroid += Sample.Location;
			++Count;
			if (OutUsedSamples)
			{
				OutUsedSamples->Add(Sample.Location);
			}
		}

		const FVector Normal = NormalSum.GetSafeNormal();
		if (Count < 3 || Normal.IsNearlyZero())
		{
			if (OutUsedSamples)
			{
				OutUsedSamples->Reset();
			}
			return Flat;
		}
		Centroid /= Count;

		const FVector Tangent = FVector::VectorPlaneProject(FlatRotation.GetAxisY(), Normal).GetSafeNormal();
		if (Tangent.IsNearlyZero())
		{
			return Flat;
		}
		const FQuat Rotation = MakeDecalActorRotation(Normal, Tangent);

		// The flat center dropped onto the fitted plane.
		FVector Center = FlatCenter - Normal * FVector::DotProduct(FlatCenter - Centroid, Normal);

		// The pin keeps its screen position: find where its view ray meets the fitted plane and move
		// the whole decal so the fitted pin lands there.
		const FVector2D PinOffset(
			FVector::DotProduct(PinPoint - FlatCenter, FlatRotation.GetAxisY()),
			FVector::DotProduct(PinPoint - FlatCenter, FlatRotation.GetAxisZ()));
		const FVector FittedPin = Center + Rotation.GetAxisY() * PinOffset.X + Rotation.GetAxisZ() * PinOffset.Y;

		const FVector RayDirection = bPerspective ? (PinPoint - ViewOrigin).GetSafeNormal() : ViewDirection.GetSafeNormal();
		const double Denominator = FVector::DotProduct(RayDirection, Normal);
		if (!FMath::IsNearlyZero(Denominator))
		{
			const double T = FVector::DotProduct(Center - PinPoint, Normal) / Denominator;
			const FVector PinOnPlane = PinPoint + RayDirection * T;
			Center += PinOnPlane - FittedPin;
		}

		FInteractiveDecalPlacementResult Result;
		Result.ActorTransform = FTransform(Rotation, Center);
		Result.DecalSize = Flat.DecalSize;
		return Result;
	}
}

