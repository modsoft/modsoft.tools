// Copyright © 2026 Trey McNair. All rights reserved.

#include "SuperGroups/SuperGroupClickTool.h"

#include "SuperGroups/SuperGroupSubsystem.h"
#include "ProWorkflowToolsSettings.h"

#include "Components/InstancedStaticMeshComponent.h"
#include "Editor/GroupActor.h"
#include "EditorViewportClient.h"
#include "Engine/World.h"
#include "EngineUtils.h"

namespace SuperGroupClickTool
{
	/** The actor a viewport click selects (child actors resolve to their parent, as the level viewport does). */
	AActor* GetClickedActor(HHitProxy* HitProxy)
	{
		AActor* Actor = nullptr;
		if (const HActor* ActorProxy = HitProxyCast<HActor>(HitProxy))
		{
			Actor = ActorProxy->Actor;
		}
		else if (const HInstancedStaticMeshInstance* InstanceProxy = HitProxyCast<HInstancedStaticMeshInstance>(HitProxy))
		{
			Actor = InstanceProxy->Component ? InstanceProxy->Component->GetOwner() : nullptr;
		}

		while (Actor && Actor->IsChildActor())
		{
			Actor = Actor->GetParentActor();
		}
		return Actor;
	}

	/** AGroupActor::GetParentForActor reads this field; it is not exported from UnrealEd. */
	AGroupActor* GetParentGroup(const AActor* Actor)
	{
		return Actor ? Cast<AGroupActor>(Actor->GroupActor) : nullptr;
	}

	AGroupActor* GetGroupToEnter(AActor* Actor, const USuperGroupSubsystem& Subsystem)
	{
		const AGroupActor* EditingGroup = Subsystem.GetEditingGroup();
		if (!EditingGroup || !Subsystem.IsActorInEditingHierarchy(Actor))
		{
			return AGroupActor::GetRootForActor(Actor);
		}

		AGroupActor* Group = GetParentGroup(Actor);
		while (Group && GetParentGroup(Group) != EditingGroup)
		{
			Group = GetParentGroup(Group);
		}
		return Group;
	}
}

bool FSuperGroupClickTool::HandleClick(FEditorViewportClient* ViewportClient, HHitProxy* HitProxy, const FViewportClick& Click)
{
	const UProWorkflowToolsSettings* Settings = GetDefault<UProWorkflowToolsSettings>();
	if (!Settings->bEnableSuperGroups
		|| !Settings->bDoubleClickToEnterGroups
		|| Click.GetEvent() != IE_DoubleClick
		|| Click.GetKey() != EKeys::LeftMouseButton
		|| Click.IsControlDown()
		|| Click.IsShiftDown()
		|| Click.IsAltDown()
		|| !ViewportClient)
	{
		return false;
	}

	UWorld* World = ViewportClient->GetWorld();
	USuperGroupSubsystem* Subsystem = World ? World->GetSubsystem<USuperGroupSubsystem>() : nullptr;
	AActor* Actor = SuperGroupClickTool::GetClickedActor(HitProxy);
	if (!Subsystem || !Actor)
	{
		return false;
	}

	AGroupActor* Group = SuperGroupClickTool::GetGroupToEnter(Actor, *Subsystem);
	return Group && Subsystem->EnterEdit(Group);
}
