// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "Containers/Set.h"
#include "GenericPlatform/ICursor.h"
#include "Math/Axis.h"
#include "ProWorkflowToolsEngineVersion.h"
#include "UObject/WeakObjectPtr.h"

class AActor;
class FEditorModeTools;
class FEditorViewportClient;
class FViewport;
class UMaterialInterface;
class UTexture;
class UViewportInteraction;
struct HActor;

/**
 * The one place that works around engine behaviour (UE 5.6+). Each entry names the engine
 * function it depends on, so an engine upgrade is checked here rather than across the tools.
 *
 * Input order the tools are written against, not wrapped here:
 * FEditorModeTools::InputKey sends the event to the ITF first. A new ITF mouse capture starts
 * mode tracking before modes see the press; any key event while tracking without an ITF capture
 * ends that tracking. Tools end their drags on the LMB release, and the ed mode cancels other
 * tools' tracking when one takes a press.
 */
namespace ProWorkflowTools
{
	/**
	 * Transform widget suppression (refcounted). Tools never call SetShowWidget directly.
	 * Hiding destroys the ITF TRS gizmo (UEditorInteractiveGizmoManager); showing again does not
	 * recreate it, so the last release does. `ProWorkflowTools.LogGizmoState 1` logs each hide/restore.
	 */
	void SuppressTransformWidget();
	void ReleaseTransformWidget();

	/** Clear the suppress count and restore the widget if it was hidden (module shutdown). */
	void ReleaseAllTransformWidgetSuppressions();

	/**
	 * Show Widget is the persisted flag the suppression clears. Editor close writes it
	 * (FMainFrameHandler / FUnrealEdMisc; QUIT_EDITOR skips OnEditorClose) and AppExit flushes
	 * the config. Bound to OnEditorPreExit, which runs between those, so a suppression held at
	 * exit is never saved.
	 */
	void RestoreTransformWidgetForEditorExit();

	/**
	 * Activate the default modes if they are down and the editor world is stable.
	 * EM_Default is a fan-out ID (FEditorModeTools), never itself active.
	 */
	void EnsureSelectionModeActive();

	/** ITF gizmo vs legacy widget. 5.8: AreEditorGizmosAllowed. 5.6: UsesNewTRSGizmos. */
	bool AreEditorGizmosAllowed(const FEditorModeTools* ModeTools);

	/**
	 * The handle a transform gizmo drag started on. The ITF gizmo keeps the handle the user last
	 * used, and the mode's default handle, in Interacting state between drags (indirect
	 * manipulation), so element state cannot say which handle is held. The hovered handle is
	 * sampled by hit test every frame outside a drag and frozen for the drag's duration.
	 */
	struct FTransformGizmoHandleTracker
	{
		EAxisList::Type Axis = EAxisList::None;
	};

	/**
	 * Hovered or dragged axis of the live transform gizmo. Legacy widget: hit proxies via
	 * FEditorViewportClient::GetCurrentWidgetAxis. ITF gizmo: UTransformGizmo::HitTarget ray test
	 * against the cursor, tracked across the drag by Tracker.
	 */
	EAxisList::Type GetLiveTransformGizmoAxis(
		FTransformGizmoHandleTracker& Tracker, FEditorViewportClient* ViewportClient, FViewport* Viewport, const FEditorModeTools* ModeTools);

	/**
	 * Cursor is on the live transform gizmo. The legacy widget draws HWidgetAxis hit proxies; the
	 * ITF gizmo draws none, so this uses UTransformGizmo::HitTarget. Element hover cannot answer:
	 * the input router ends hover on capture (UTransformGizmo::OnEndHover), and arcball / screen-
	 * space rotate still reach mode tracking until the drag passes the gizmo's start threshold.
	 */
	bool IsCursorOnTransformGizmo(FEditorViewportClient* ViewportClient, FViewport* Viewport);

	/**
	 * UInputRouter::ForceTerminateAll if the ITF holds a mouse capture, then drop queued
	 * camera deltas on the viewport navigation helper.
	 */
	void TerminateInteractiveToolsMouseCapture(FEditorViewportClient* ViewportClient);

	/**
	 * The ITF camera interactions a mode drag turned off. FEditorModeTools::InputKey hands every
	 * press to the ITF before the modes, so a legacy-mode drag cannot refuse a second mouse button
	 * or WASD: the dolly / fly interactions would start underneath it. UViewportInteraction::
	 * SetEnabled(false) is what their behaviors check (CanBeActivated, OnKeyPressed), and in ITF
	 * mode FEditorViewportClient::UpdateCameraMovement consumes only interaction impulses.
	 * 5.6 has no ITF viewport interactions; both calls are no-ops there.
	 */
	struct FCameraInteractionsSuspension
	{
		TArray<TWeakObjectPtr<UViewportInteraction>> Disabled;
	};

	/** Disable the camera interactions that are currently enabled; Resume turns exactly those back on. */
	void SuspendCameraInteractions(FEditorViewportClient* ViewportClient, FCameraInteractionsSuspension& Out);
	void ResumeCameraInteractions(FCameraInteractionsSuspension& InOut);

	/**
	 * Space held, including under Alt. Windows keeps Alt+Space for the window system menu and
	 * never forwards it to the viewport (FWindowsApplication), so the OS key state is the
	 * authority there.
	 */
	bool IsSpaceKeyDown(const FViewport* Viewport);

	/**
	 * Hardware cursor override on every level viewport. It precedes editor modes and the ITF
	 * cursor API (FEditorViewportClient::SetRequiredCursorOverride). The viewport clears it on
	 * focus and when tracking ends, so a held cursor is re-asserted each tick.
	 */
	void SetLevelViewportsCursorOverride(bool bOverride, EMouseCursor::Type Cursor);

	/**
	 * Material slot the hit proxy's pixel was drawn with, or INDEX_NONE. Nanite section proxies
	 * store the LOD0 section index (FNaniteMaterialSection / BuildSceneProxy), and that section
	 * holds the slot. ISM / foliage instance proxies carry no slot.
	 */
	int32 GetHitProxyMaterialIndex(const HActor& Proxy);

	/** One engine vertex search per frame. Later calls in that frame reuse Location. */
	struct FVertexSnapFrameQuery
	{
		uint64 FrameNumber = MAX_uint64;
		bool bHasResult = false;
		/** The engine keeps drawing vertex helpers until they are cleared. */
		bool bHelpersDrawn = false;
		FVector Location = FVector::ZeroVector;
	};

	/** V released or drag ended: forget the cached result and clear the engine's vertex helpers. */
	void EndVertexSnap(FVertexSnapFrameQuery& Query);

	/**
	 * Selection contains a movement-locked item. 5.8: HasSelectedMovementLockedItems.
	 * 5.6: HasLockedActors.
	 */
	bool HasSelectionMovementLocked();

	/**
	 * Convert a widget scale delta when percentage-based scaling is on.
	 * 5.8: FSnappingUtils::AdjustPercentageBasedScale. 5.6 has no helper, so divide by 100.
	 */
	void AdjustPercentageBasedScale(FVector& InOutScale);

	/**
	/**
	 * High-quality textures sampled by Material.
	 * 5.7+: GetUsedTextures(QualityLevel). 5.6: the five-argument form.
	 */
	void GetMaterialUsedTextures(const UMaterialInterface* Material, TArray<UTexture*>& OutTextures);

	/**
	 * Temporary editor visibility used by Hide Selected (H).
	 * 5.7+: UUnrealEdEngine::SetActorVisibility → SetIsTemporarilyHiddenInEditor.
	 * 5.6: the same function writes TEDS FVisibleInEditorColumn + SyncBackToWorldTag
	 * and does not touch the actor flag. Unhide must write that column; ACTOR UNHIDE
	 * SELECTED no-ops when IsHiddenEd() is still false.
	 */
	void SetActorVisibleInEditor(AActor* Actor, bool bVisible);

	/**
	 * Reads the same state SetActorVisibleInEditor writes.
	 * 5.6 needs the TEDS column: Hide Selected leaves IsHiddenEd() false there.
	 */
	bool IsActorVisibleInEditor(const AActor* Actor);

	/**
	 * SnapLocationToNearestVertex at most once per frame.
	 * InOutLocation is the search seed, then the snapped point (cached on repeat calls).
	 */
	bool QueryVertexSnapOncePerFrame(
		FVertexSnapFrameQuery& Query,
		FVector& InOutLocation,
		const FVector2D& MouseLocation,
		FEditorViewportClient* ViewportClient,
		const TSet<TWeakObjectPtr<AActor>>& ActorsToIgnore);
}
