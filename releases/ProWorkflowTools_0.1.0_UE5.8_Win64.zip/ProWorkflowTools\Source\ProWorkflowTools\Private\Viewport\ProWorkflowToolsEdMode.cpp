// Copyright © 2026 Trey McNair. All rights reserved.

#include "Viewport/ProWorkflowToolsEdMode.h"

#include "DecalPlacement/InteractiveDecalPlacementEdMode.h"
#include "ProWorkflowToolsSettings.h"

#include "Editor.h"
#include "Editor/UnrealEdEngine.h"
#include "EditorModeManager.h"
#include "EditorViewportClient.h"
#include "GameFramework/Actor.h"
#include "ProWorkflowToolsEngineVersion.h"
#include "Tools/EdModeInteractiveToolsContext.h"
#include "UnrealEdGlobals.h"
#if PWT_UE_5_8_OR_LATER
#include "ViewportInteractions/ViewportInteraction.h"
#endif

const FEditorModeID FProWorkflowToolsEdMode::EM_ProWorkflowTools(TEXT("EM_ProWorkflowTools"));

FProWorkflowToolsEdMode::FProWorkflowToolsEdMode()
{
	Tools = { &GridPaintTool, &MaterialClipboardTool, &BoxScaleTool, &DccMarqueeTool, &LocalTransformModifierTool, &SuperGroupClickTool };
	for (FWorkflowViewportTool* Tool : Tools)
	{
		Tool->SetHost(*this);
	}
}

FProWorkflowToolsEdMode::~FProWorkflowToolsEdMode()
{
	RemoveUnsupportedInteractionsHandler();
}

template <typename FunctorType>
FWorkflowViewportTool* FProWorkflowToolsEdMode::RouteInput(FunctorType&& Handler) const
{
	for (FWorkflowViewportTool* Tool : Tools)
	{
		if (Tool->IsExclusive())
		{
			return Handler(*Tool) ? Tool : nullptr;
		}
	}

	for (FWorkflowViewportTool* Tool : Tools)
	{
		if (Handler(*Tool))
		{
			return Tool;
		}
	}
	return nullptr;
}

void FProWorkflowToolsEdMode::Enter()
{
	FEdMode::Enter();

#if PWT_UE_5_8_OR_LATER
	// Mode activation broadcasts after Enter, which rebuilds viewport interactions with this handler.
	if (UModeManagerInteractiveToolsContext* Context = Owner ? Owner->GetInteractiveToolsContext() : nullptr)
	{
		UnsupportedInteractionsContext = Context;
		UnsupportedInteractionsHandle = Context->OnGetUnsupportedInteractions().AddRaw(
			this, &FProWorkflowToolsEdMode::AddUnsupportedViewportInteractions);
	}
#endif
}

void FProWorkflowToolsEdMode::Exit()
{
	// Mode deactivation dirties viewport interactions; they rebuild after this, without the handler.
	RemoveUnsupportedInteractionsHandler();

	for (FWorkflowViewportTool* Tool : Tools)
	{
		Tool->Exit();
	}
	CommandLabel.Clear();

	FEdMode::Exit();
}

void FProWorkflowToolsEdMode::NotifyBoxScaleDisabled()
{
	BoxScaleTool.ReleaseWidgetSuppression();
}

void FProWorkflowToolsEdMode::NotifyPostUndoRedo()
{
	GridPaintTool.NotifyPostUndoRedo();
}

void FProWorkflowToolsEdMode::ToggleGridPaint(FEditorViewportClient* ViewportClient)
{
	if (GridPaintTool.IsActive())
	{
		if (GridPaintTool.DidToggleOnThisFrame())
		{
			return;
		}
		GridPaintTool.Deactivate();
		return;
	}

	GridPaintTool.HandleToggleKeyPressed(ViewportClient);
}

void FProWorkflowToolsEdMode::ActorsDuplicatedNotify(TArray<AActor*>& PreDuplicateSelection, TArray<AActor*>& PostDuplicateSelection, bool bOffsetLocations)
{
	// Only the offsetting duplicate paths (Ctrl+D / Edit>Duplicate) pass bOffsetLocations. Alt+drag
	// duplication passes false, so it keeps its drag-driven placement.
	const UProWorkflowToolsSettings* Settings = GetDefault<UProWorkflowToolsSettings>();
	if (!bOffsetLocations || !Settings || !Settings->bDuplicateInPlace || !GEditor)
	{
		return;
	}

	// Reproduces the offset applied by DuplicateActors / DuplicateSelectedElements and reverses it,
	// leaving the copies exactly on top of the originals. This happens inside the duplicate's
	// transaction, so it is captured by a single undo and never visibly flickers.
	const FVector Offset = GEditor->GetGridLocationOffset(/*bUniformOffset*/false);
	if (Offset.IsNearlyZero())
	{
		return;
	}

	for (AActor* Actor : PostDuplicateSelection)
	{
		if (Actor)
		{
			Actor->Modify();
			Actor->SetActorLocation(Actor->GetActorLocation() - Offset);
			Actor->PostEditMove(true);
		}
	}

	// edactDuplicateSelected / typed-element duplicate notify after NoteSelectionChange (or
	// equivalent), so the pivot/gizmo still sits at the pre-correction offset location.
	if (GUnrealEd)
	{
		GUnrealEd->UpdatePivotLocationForSelection();
	}
	GEditor->RedrawLevelEditingViewports();
}

bool FProWorkflowToolsEdMode::IsTransformGizmoReplaced() const
{
	return Tools.ContainsByPredicate([](const FWorkflowViewportTool* Tool) { return Tool->ReplacesTransformGizmo(); });
}

///////////////////////////////////////////////////////////////////////////////
// Routed tool hooks

void FProWorkflowToolsEdMode::Tick(FEditorViewportClient* ViewportClient, float DeltaTime)
{
	FEdMode::Tick(ViewportClient, DeltaTime);

	// Modes tick once per visible viewport, and key state / cursor are per viewport. Keyboard-driven
	// tool state follows the focused viewport; cursor-driven previews follow the hovered one.
	if (!Owner)
	{
		return;
	}

	const bool bHovered = ViewportClient == Owner->GetHoveredViewportClient();
	const bool bFocused = ViewportClient == Owner->GetFocusedViewportClient();
	for (FWorkflowViewportTool* Tool : Tools)
	{
		const EWorkflowToolTickViewport TickViewport = Tool->GetTickViewport();
		if ((TickViewport == EWorkflowToolTickViewport::Hovered && bHovered)
			|| (TickViewport == EWorkflowToolTickViewport::Focused && bFocused))
		{
			Tool->Tick(ViewportClient, DeltaTime);
		}
	}

	if (bHovered && CommandLabel.TickNeedsRedraw())
	{
		ViewportClient->Invalidate(false, false);
	}
}

void FProWorkflowToolsEdMode::ShowCommandLabel(TConstArrayView<ProWorkflowTools::CursorLabel::FLine> Lines)
{
	if (Owner && Owner->GetHoveredViewportClient())
	{
		CommandLabel.Show(Lines);
	}
}

void FProWorkflowToolsEdMode::Render(const FSceneView* View, FViewport* Viewport, FPrimitiveDrawInterface* PDI)
{
	FEdMode::Render(View, Viewport, PDI);
	for (FWorkflowViewportTool* Tool : Tools)
	{
		Tool->Render(View, Viewport, PDI);
	}
}

void FProWorkflowToolsEdMode::DrawHUD(FEditorViewportClient* ViewportClient, FViewport* Viewport, const FSceneView* View, FCanvas* Canvas)
{
	FEdMode::DrawHUD(ViewportClient, Viewport, View, Canvas);
	for (FWorkflowViewportTool* Tool : Tools)
	{
		Tool->DrawHUD(ViewportClient, Viewport, View, Canvas);
	}

	if (Owner && Viewport && ViewportClient == Owner->GetHoveredViewportClient())
	{
		CommandLabel.Draw(Canvas, FIntPoint(Viewport->GetMouseX(), Viewport->GetMouseY()));
	}
}

bool FProWorkflowToolsEdMode::InputKey(FEditorViewportClient* ViewportClient, FViewport* Viewport, FKey Key, EInputEvent Event)
{
	FWorkflowViewportTool* Handler = RouteInput([&](FWorkflowViewportTool& Tool) { return Tool.InputKey(ViewportClient, Viewport, Key, Event); });
	if (!Handler)
	{
		return FEdMode::InputKey(ViewportClient, Viewport, Key, Event);
	}

	// A consumed press belongs to the tool that took it. With ITF viewport interactions, mode tracking
	// (and any tool tracking it started) begins before InputKey sees the press.
	if (Key.IsMouseButton() && (Event == IE_Pressed || Event == IE_DoubleClick))
	{
		for (FWorkflowViewportTool* Tool : Tools)
		{
			if (Tool != Handler)
			{
				Tool->CancelTracking();
			}
		}
	}
	return true;
}

bool FProWorkflowToolsEdMode::StartTracking(FEditorViewportClient* InViewportClient, FViewport* InViewport)
{
	return RouteInput([&](FWorkflowViewportTool& Tool) { return Tool.StartTracking(InViewportClient, InViewport); }) != nullptr
		|| FEdMode::StartTracking(InViewportClient, InViewport);
}

bool FProWorkflowToolsEdMode::EndTracking(FEditorViewportClient* InViewportClient, FViewport* InViewport)
{
	// Tracking ending is a notification, not input: every tool settles its own tracking state.
	bool bHandled = false;
	for (FWorkflowViewportTool* Tool : Tools)
	{
		bHandled |= Tool->EndTracking(InViewportClient, InViewport);
	}
	return bHandled;
}

bool FProWorkflowToolsEdMode::CapturedMouseMove(FEditorViewportClient* InViewportClient, FViewport* InViewport, int32 InMouseX, int32 InMouseY)
{
	return RouteInput([&](FWorkflowViewportTool& Tool) { return Tool.CapturedMouseMove(InViewportClient, InViewport, InMouseX, InMouseY); }) != nullptr
		|| FEdMode::CapturedMouseMove(InViewportClient, InViewport, InMouseX, InMouseY);
}

bool FProWorkflowToolsEdMode::MouseMove(FEditorViewportClient* ViewportClient, FViewport* Viewport, int32 x, int32 y)
{
	return RouteInput([&](FWorkflowViewportTool& Tool) { return Tool.MouseMove(ViewportClient, Viewport, x, y); }) != nullptr
		|| FEdMode::MouseMove(ViewportClient, Viewport, x, y);
}

bool FProWorkflowToolsEdMode::HandleClick(FEditorViewportClient* InViewportClient, HHitProxy* HitProxy, const FViewportClick& Click)
{
	return RouteInput([&](FWorkflowViewportTool& Tool) { return Tool.HandleClick(InViewportClient, HitProxy, Click); }) != nullptr
		|| FEdMode::HandleClick(InViewportClient, HitProxy, Click);
}

bool FProWorkflowToolsEdMode::InputDelta(FEditorViewportClient* InViewportClient, FViewport* InViewport, FVector& InDrag, FRotator& InRot, FVector& InScale)
{
	return RouteInput([&](FWorkflowViewportTool& Tool) { return Tool.InputDelta(InViewportClient, InViewport, InDrag, InRot, InScale); }) != nullptr
		|| FEdMode::InputDelta(InViewportClient, InViewport, InDrag, InRot, InScale);
}

bool FProWorkflowToolsEdMode::BoxSelect(FBox& InBox, bool InSelect)
{
	// Unhandled selection stays with the engine's stock marquee.
	return RouteInput([&](FWorkflowViewportTool& Tool) { return Tool.BoxSelect(InBox, InSelect); }) != nullptr;
}

bool FProWorkflowToolsEdMode::FrustumSelect(const FConvexVolume& InFrustum, FEditorViewportClient* InViewportClient, bool InSelect)
{
	return RouteInput([&](FWorkflowViewportTool& Tool) { return Tool.FrustumSelect(InFrustum, InViewportClient, InSelect); }) != nullptr;
}

bool FProWorkflowToolsEdMode::GetOverrideCursorVisibility(bool& bWantsOverride, bool& bHardwareCursorVisible, bool bSoftwareCursorVisible) const
{
	return RouteInput([&](FWorkflowViewportTool& Tool) { return Tool.GetOverrideCursorVisibility(bWantsOverride, bHardwareCursorVisible, bSoftwareCursorVisible); }) != nullptr
		|| FEdMode::GetOverrideCursorVisibility(bWantsOverride, bHardwareCursorVisible, bSoftwareCursorVisible);
}

bool FProWorkflowToolsEdMode::AllowsViewportDragTool() const
{
	// The engine's ortho box select is this drag tool.
	return !Tools.ContainsByPredicate([](const FWorkflowViewportTool* Tool) { return Tool->BlocksViewportDragTool(); });
}

bool FProWorkflowToolsEdMode::DisallowMouseDeltaTracking() const
{
	// Blocks the viewport's mouse-delta camera path (dolly/orbit/pan) while a tool owns the mouse.
	return Tools.ContainsByPredicate([](const FWorkflowViewportTool* Tool) { return Tool->CapturesMouse(); });
}

void FProWorkflowToolsEdMode::AddReferencedObjects(FReferenceCollector& Collector)
{
	FEdMode::AddReferencedObjects(Collector);
	for (FWorkflowViewportTool* Tool : Tools)
	{
		Tool->AddReferencedObjects(Collector);
	}
}

///////////////////////////////////////////////////////////////////////////////
// Viewport interactions

#if PWT_UE_5_8_OR_LATER
void FProWorkflowToolsEdMode::AddUnsupportedViewportInteractions(TArray<FName>& Interactions)
{
	// Called from inside the interactions rebuild: read state only, never touch the context.
	bBareLmbOwnedAtLastBuild = OwnsBareLmb();
	if (bBareLmbOwnedAtLastBuild)
	{
		Interactions.AddUnique(UE::Editor::ViewportInteractions::PerspectiveMoveYaw);
	}
}
#endif

void FProWorkflowToolsEdMode::RemoveUnsupportedInteractionsHandler()
{
#if PWT_UE_5_8_OR_LATER
	if (UModeManagerInteractiveToolsContext* Context = UnsupportedInteractionsContext.Get())
	{
		Context->OnGetUnsupportedInteractions().Remove(UnsupportedInteractionsHandle);
	}
	UnsupportedInteractionsContext.Reset();
	UnsupportedInteractionsHandle.Reset();
#endif
}

bool FProWorkflowToolsEdMode::OwnsBareLmb() const
{
	return FDccMarqueeTool::IsDccControlsEnabled()
		|| (Owner && Owner->IsModeActive(FInteractiveDecalPlacementEdMode::EM_InteractiveDecalPlacement));
}

void FProWorkflowToolsEdMode::SyncViewportInteractions()
{
#if PWT_UE_5_8_OR_LATER
	// No mode change fires for a settings toggle, so compare against what the last rebuild reported
	// and rebuild once when the owner flipped. The level editor is up here, so its click-selection
	// interactions are rebuilt with the rest.
	UModeManagerInteractiveToolsContext* Context = UnsupportedInteractionsContext.Get();
	if (Context && Context->UsesViewportInteractions() && bBareLmbOwnedAtLastBuild != OwnsBareLmb())
	{
		Context->SetViewportInteractionsEnabled(false);
		Context->SetViewportInteractionsEnabled(true);
	}
#endif
}
