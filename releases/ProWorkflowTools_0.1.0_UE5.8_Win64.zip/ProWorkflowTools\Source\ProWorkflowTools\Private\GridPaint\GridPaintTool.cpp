// Copyright © 2026 Trey McNair. All rights reserved.

#include "GridPaint/GridPaintTool.h"
#include "GridPaint/GridPaintToolPrivate.h"

#include "DecalPlacement/InteractiveDecalPlacementEdMode.h"
#include "GridPaint/GridPaintTileBoundsUserData.h"
#include "ProWorkflowToolsCommands.h"
#include "ProWorkflowToolsEngineAdapter.h"
#include "ProWorkflowToolsSettings.h"
#include "UI/ProWorkflowToolHudOverlay.h"
#include "UI/ProWorkflowToolHudTypes.h"
#include "UI/SProWorkflowToolHud.h"
#include "UI/ViewportCursorLabel.h"
#include "Viewport/ViewportOverlayStyle.h"

#include "CanvasItem.h"
#include "CanvasTypes.h"
#include "CollisionQueryParams.h"
#include "CollisionShape.h"
#include "Components/DecalComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Editor.h"
#include "EditorModeManager.h"
#include "EditorViewportClient.h"
#include "EditorViewportCommands.h"
#include "Engine/OverlapResult.h"
#include "Engine/DecalActor.h"
#include "Engine/Selection.h"
#include "Engine/StaticMesh.h"
#include "Engine/StaticMeshActor.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "Framework/Application/SlateApplication.h"
#include "Framework/Commands/GenericCommands.h"
#include "Framework/Commands/InputChord.h"
#include "Framework/Commands/UICommandInfo.h"
#include "Framework/Notifications/NotificationManager.h"
#include "GameFramework/Actor.h"
#include "PrimitiveDrawingUtils.h"
#include "SceneView.h"
#include "SnappingUtils.h"
#include "Subsystems/EditorActorSubsystem.h"
#include "Widgets/Notifications/SNotificationList.h"

#define LOCTEXT_NAMESPACE "ProWorkflowTools"

///////////////////////////////////////////////////////////////////////////////
// Input routing

bool FGridPaintTool::InputKey(FEditorViewportClient* ViewportClient, FViewport* Viewport, FKey Key, EInputEvent Event)
{
	if (!ViewportClient || !Viewport || !GEditor)
	{
		return false;
	}

	const UProWorkflowToolsSettings* Settings = GetDefault<UProWorkflowToolsSettings>();
	if (!Settings || !Settings->bEnableGridPaint)
	{
		if (bActive)
		{
			Deactivate();
		}
		return false;
	}

	const bool bToggleChord = Event == IE_Pressed
		&& GridPaint::Private::IsGridPaintToggleChord(ViewportClient, Key);

	if (!bActive)
	{
		if (bToggleChord)
		{
			// The level-editor command exits Decal / Box Scale and enters. Don't enter here too.
			if (GLevelEditorModeTools().IsModeActive(FInteractiveDecalPlacementEdMode::EM_InteractiveDecalPlacement))
			{
				return false;
			}
			return HandleToggleKeyPressed(ViewportClient);
		}
		return false;
	}

	// Any key while active (Shift erase, Ctrl line fill, B, Backspace, Esc...) can change the overlay.
	ViewportClient->Invalidate(false, false);

	// W/E/R leaves the session the way Escape does, but only as a tap (no mouse down)
	// so WASD camera while LMB/RMB/MMB is held does not exit. The key is not consumed
	// so the editor still switches the transform widget.
	if (Event == IE_Pressed
		&& GridPaint::Private::IsTransformGizmoChord(ViewportClient, Key)
		&& !GridPaint::Private::IsViewportMouseButtonDown(Viewport))
	{
		Deactivate();
		return false;
	}

	if (Key == EKeys::Escape && Event == IE_Pressed)
	{
		if (bBoundsEditActive)
		{
			ExitBoundsEdit(/*bCommit=*/false);
			return true;
		}
		Deactivate();
		return true;
	}

	if (bToggleChord)
	{
		// The level-editor command and this InputKey both see one press. Enter wins for that frame.
		if (ActivatedFrame == GFrameCounter)
		{
			return true;
		}
		Deactivate();
		return true;
	}

	// Inside bounds edit, Undo / Redo step the draft; the editor's transaction history never sees it.
	if (bBoundsEditActive && (Event == IE_Pressed || Event == IE_Repeat))
	{
		const bool bUndo = GridPaint::Private::IsUndoChord(ViewportClient, Key);
		if (bUndo || GridPaint::Private::IsRedoChord(ViewportClient, Key))
		{
			if (!bBoundsFaceDrag)
			{
				StepBoundsEditHistory(/*bRedo=*/!bUndo);
			}
			return true;
		}
	}

	// B: enter / apply tile-bounds edit (not mid paint stroke or face drag).
	if (Key == EKeys::B && Event == IE_Pressed)
	{
		if (bStrokeActive || bBoundsFaceDrag)
		{
			return true;
		}
		if (bBoundsEditActive)
		{
			ExitBoundsEdit(/*bCommit=*/true);
		}
		else
		{
			EnterBoundsEdit();
		}
		return true;
	}

	// Backspace: reset bounds-edit draft to source mesh/decal geometry (ignores AssetUserData).
	if (Key == EKeys::BackSpace && Event == IE_Pressed && bBoundsEditActive)
	{
		if (!bBoundsFaceDrag)
		{
			ResetBoundsEditToSourceGeometry();
		}
		return true;
	}

	// Alt+LMB is camera orbit (DCC / editor) — do not start a paint stroke or consume the drag.
	if (Key == EKeys::LeftMouseButton && ViewportClient->IsAltPressed())
	{
		return false;
	}

	// Consume LMB entirely while active so strokes / bounds drags never fight selection / camera.
	if (Key == EKeys::LeftMouseButton)
	{
		if (Event == IE_Pressed || Event == IE_DoubleClick)
		{
			if (IsPointerOverHud())
			{
				return true;
			}

			// Cancel ITF capture so LMB paint never turns into a gizmo drag or click-select.
			ProWorkflowTools::TerminateInteractiveToolsMouseCapture(ViewportClient);
			if (ViewportClient)
			{
				ViewportClient->SetCurrentWidgetAxis(EAxisList::None);
				ViewportClient->bWidgetAxisControlledByDrag = false;
			}

			if (bBoundsEditActive)
			{
				BeginBoundsFaceDrag(ViewportClient, Viewport);
			}
			else if (IsLineFillIntent(ViewportClient))
			{
				CommitLineFill(ViewportClient);
				bLineFillCapture = true;
			}
			else
			{
				BeginStroke(ViewportClient);
			}
			EnsureSourceSelected();
			return true;
		}
		if (Event == IE_Released)
		{
			if (bLineFillCapture)
			{
				bLineFillCapture = false;
				EnsureSourceSelected();
				return true;
			}
			if (bBoundsFaceDrag)
			{
				EndBoundsFaceDrag();
				EnsureSourceSelected();
				return true;
			}
			if (!bStrokeActive)
			{
				return false;
			}
			EndStroke(ViewportClient);
			EnsureSourceSelected();
			return true;
		}
		return bStrokeActive || bBoundsFaceDrag || bLineFillCapture;
	}

	if (bBoundsEditActive)
	{
		// V is the vertex-snap hold key (read via KeyState while dragging) — do not consume.
		return false;
	}

	// Shift toggles erase intent: hide the ghost and show the erase-hover PDI highlight.
	if (Key == EKeys::LeftShift || Key == EKeys::RightShift)
	{
		UpdateGhostEraseVisibility(ViewportClient);
		UpdateLineFillPreview(ViewportClient);
		return false;
	}

	// Ctrl toggles line-fill preview (exact axis-aligned runs only).
	if (Key == EKeys::LeftControl || Key == EKeys::RightControl)
	{
		UpdateLineFillPreview(ViewportClient);
		return false;
	}

	// Everything else (camera keys, RMB, etc.) passes through so navigation stays free.
	return false;
}

bool FGridPaintTool::HandleToggleKeyPressed(FEditorViewportClient* ViewportClient)
{
	const int32 NumSelected = GEditor->GetSelectedActorCount();
	if (NumSelected == 0)
	{
		GridPaint::Private::ShowGridPaintNotification(
			LOCTEXT("GridPaintNoSelection", "Actor Grid Paint: select one static mesh or decal"));
		return true;
	}
	if (NumSelected > 1)
	{
		GridPaint::Private::ShowGridPaintNotification(
			LOCTEXT("GridPaintMultiSelection", "Actor Grid Paint: select only one actor"));
		return true;
	}

	AActor* Source = GEditor->GetSelectedActors()->GetTop<AActor>();
	UStaticMeshComponent* SourceMeshComponent = GetSourceStaticMeshComponent(Source);
	UDecalComponent* SourceDecalComponent = GetSourceDecalComponent(Source);
	const bool bIsMeshSource = SourceMeshComponent && SourceMeshComponent->GetStaticMesh();
	const bool bIsDecalSource = SourceDecalComponent != nullptr;
	if (!Source || (!bIsMeshSource && !bIsDecalSource))
	{
		GridPaint::Private::ShowGridPaintNotification(
			LOCTEXT("GridPaintNoTileableAsset", "Actor Grid Paint: the selected actor is not a static mesh or decal"));
		return true;
	}

	Context.SourceActor = Source;
	Context.PivotWorld = Source->GetActorLocation();
	Context.GridRotation = Source->GetActorQuat();
	Context.bIsDecalSource = bIsDecalSource && !bIsMeshSource;
	const UProWorkflowToolsSettings* ToolSettings = GetDefault<UProWorkflowToolsSettings>();
	Context.ThinAxisFloorCm = GridPaint::Private::GetThinAxisThresholdCm(ToolSettings);
	Context.ThinAxisRelativeRatio = GridPaint::Private::GetThinAxisRelativeRatio(ToolSettings);

	// Prefer static mesh when both exist (rare); otherwise build the grid from the decal.
	if (bIsMeshSource && !Context.bIsDecalSource)
	{
		// Cell size = local bounds size x scale, per axis. Component world scale covers both the
		// actor scale and any component-relative scale on the SMC. Placement stays pivot-stepped.
		// Prefer committed tile bounds (AssetUserData) when present.
		const FBox MeshLocalBounds = ResolveMeshLocalTileBounds(SourceMeshComponent);
		const FVector LocalBoundsSize = MeshLocalBounds.GetSize();
		const FVector ComponentScale = SourceMeshComponent->GetComponentTransform().GetScale3D();
		const FVector AbsScale = ComponentScale.GetAbs();
		Context.CellSize = FVector(
			FMath::Max(LocalBoundsSize.X * AbsScale.X, GridPaint::Private::MinCellSize),
			FMath::Max(LocalBoundsSize.Y * AbsScale.Y, GridPaint::Private::MinCellSize),
			FMath::Max(LocalBoundsSize.Z * AbsScale.Z, GridPaint::Private::MinCellSize));

		// Mesh footprint in grid-local space (pivot-relative): overlay quads use Min/Max on the paint
		// plane axes so corner pivots frame the asset instead of a ±CellSize/2 box on the pivot.
		FBox GridLocalBounds(ForceInit);
		const FTransform CompWorld = SourceMeshComponent->GetComponentTransform();
		const FVector Corners[8] = {
			FVector(MeshLocalBounds.Min.X, MeshLocalBounds.Min.Y, MeshLocalBounds.Min.Z),
			FVector(MeshLocalBounds.Min.X, MeshLocalBounds.Min.Y, MeshLocalBounds.Max.Z),
			FVector(MeshLocalBounds.Min.X, MeshLocalBounds.Max.Y, MeshLocalBounds.Min.Z),
			FVector(MeshLocalBounds.Min.X, MeshLocalBounds.Max.Y, MeshLocalBounds.Max.Z),
			FVector(MeshLocalBounds.Max.X, MeshLocalBounds.Min.Y, MeshLocalBounds.Min.Z),
			FVector(MeshLocalBounds.Max.X, MeshLocalBounds.Min.Y, MeshLocalBounds.Max.Z),
			FVector(MeshLocalBounds.Max.X, MeshLocalBounds.Max.Y, MeshLocalBounds.Min.Z),
			FVector(MeshLocalBounds.Max.X, MeshLocalBounds.Max.Y, MeshLocalBounds.Max.Z),
		};
		for (const FVector& LocalCorner : Corners)
		{
			const FVector World = CompWorld.TransformPosition(LocalCorner);
			GridLocalBounds += Context.GridRotation.UnrotateVector(World - Context.PivotWorld);
		}
		Context.MeshBoundsGridLocal = GridLocalBounds;
		GhostScale = ComponentScale;
	}
	else
	{
		// Decal receive plane = YZ (perp. to projection). UE projects along local +X into the
		// surface; the image lies on YZ (see InteractiveDecalPlacementMath / MakeDecalActorRotation).
		// UDecalComponent::DecalSize stores half-extents: X = projection depth/fade, Y/Z = in-plane
		// half-width/height. Full cell step = 2*|DecalSize| * component scale (edge-flush tiling).
		const FVector AbsHalfExtents = SourceDecalComponent->DecalSize.GetAbs();
		const FVector ComponentScale = SourceDecalComponent->GetComponentTransform().GetScale3D();
		const FVector AbsScale = ComponentScale.GetAbs();
		Context.CellSize = FVector(
			FMath::Max(2.0 * AbsHalfExtents.X * AbsScale.X, GridPaint::Private::MinCellSize),
			FMath::Max(2.0 * AbsHalfExtents.Y * AbsScale.Y, GridPaint::Private::MinCellSize),
			FMath::Max(2.0 * AbsHalfExtents.Z * AbsScale.Z, GridPaint::Private::MinCellSize));

		// Footprint from the decal box [-DecalSize, +DecalSize] in component local → grid local.
		const FBox DecalLocalBounds(-AbsHalfExtents, AbsHalfExtents);
		FBox GridLocalBounds(ForceInit);
		const FTransform CompWorld = SourceDecalComponent->GetComponentTransform();
		const FVector Corners[8] = {
			FVector(DecalLocalBounds.Min.X, DecalLocalBounds.Min.Y, DecalLocalBounds.Min.Z),
			FVector(DecalLocalBounds.Min.X, DecalLocalBounds.Min.Y, DecalLocalBounds.Max.Z),
			FVector(DecalLocalBounds.Min.X, DecalLocalBounds.Max.Y, DecalLocalBounds.Min.Z),
			FVector(DecalLocalBounds.Min.X, DecalLocalBounds.Max.Y, DecalLocalBounds.Max.Z),
			FVector(DecalLocalBounds.Max.X, DecalLocalBounds.Min.Y, DecalLocalBounds.Min.Z),
			FVector(DecalLocalBounds.Max.X, DecalLocalBounds.Min.Y, DecalLocalBounds.Max.Z),
			FVector(DecalLocalBounds.Max.X, DecalLocalBounds.Max.Y, DecalLocalBounds.Min.Z),
			FVector(DecalLocalBounds.Max.X, DecalLocalBounds.Max.Y, DecalLocalBounds.Max.Z),
		};
		for (const FVector& LocalCorner : Corners)
		{
			const FVector World = CompWorld.TransformPosition(LocalCorner);
			GridLocalBounds += Context.GridRotation.UnrotateVector(World - Context.PivotWorld);
		}
		Context.MeshBoundsGridLocal = GridLocalBounds;
		GhostScale = ComponentScale;
	}

	SourceScale = Source->GetActorScale3D();
	NextLabelIndex = 1;
	bActive = true;
	ActivatedFrame = GFrameCounter;
	bHasHoverCell = false;
	bHideGhostForErase = false;
	bEraseIntent = false;
	bBoundsEditActive = false;
	bBoundsFaceDrag = false;
	BoundsHoverAxis = INDEX_NONE;
	BoundsHoverSign = 0;
	EditBoundsGridLocal = FBox(ForceInit);
	LastPaintedCell.Reset();
	LineFillPreviewCells.Reset();
	bLineFillCapture = false;
	bLineFillIntentActive = false;
	CellPulses.Reset();
	FeedbackLabel.Clear();

	SessionSpawnedActors.Reset();
	CellBlockedCache.Reset();

	// Decals: always paint on the receive plane (normal = local X). Meshes: camera / thin-axis pick.
	CurrentPlaneAxis = Context.bIsDecalSource
		? 0
		: GridPaintMath::PickPlaneAxis(Context, ViewportClient->GetViewRotation().Vector());

	UpdateHover(ViewportClient);
	ShowHudOverlay();

	// Hide the transform gizmo (both systems) while painting.
	ProWorkflowTools::SuppressTransformWidget();

	ViewportClient->Invalidate(false, false);
	return true;
}

bool FGridPaintTool::MouseMove(FEditorViewportClient* ViewportClient, FViewport* Viewport, int32 X, int32 Y)
{
	if (!bActive)
	{
		return false;
	}

	// The overlay follows the cursor: every move redraws.
	if (ViewportClient)
	{
		ViewportClient->Invalidate(false, false);
	}

	if (bBoundsFaceDrag)
	{
		UpdateBoundsFaceDrag(ViewportClient, X, Y);
		return true;
	}

	if (bBoundsEditActive)
	{
		UpdateBoundsFaceHover(ViewportClient, X, Y);
		return false;
	}

	if (bStrokeActive)
	{
		UpdateStroke(ViewportClient);
		return true;
	}

	UpdateHover(ViewportClient);
	// Keep Shift erase intent in sync on hover (IsShiftPressed works without LMB down).
	UpdateGhostEraseVisibility(ViewportClient);
	UpdateLineFillPreview(ViewportClient);
	return false;
}

bool FGridPaintTool::CapturedMouseMove(FEditorViewportClient* ViewportClient, FViewport* Viewport, int32 X, int32 Y)
{
	if (!bActive || (!bBoundsFaceDrag && !bStrokeActive))
	{
		return false;
	}

	// LMB drags arrive here instead of MouseMove.
	if (ViewportClient)
	{
		ViewportClient->Invalidate(false, false);
	}
	if (bBoundsFaceDrag)
	{
		UpdateBoundsFaceDrag(ViewportClient, X, Y);
	}
	else
	{
		UpdateStroke(ViewportClient);
	}
	return true;
}

bool FGridPaintTool::StartTracking(FEditorViewportClient* ViewportClient, FViewport* Viewport)
{
	if (!bActive || !Viewport || !Viewport->KeyState(EKeys::LeftMouseButton))
	{
		return false;
	}

	// Alt+LMB is orbit — do not claim tracking or begin a paint/erase stroke.
	if (ViewportClient && ViewportClient->IsAltPressed())
	{
		return false;
	}

	// Don't capture the viewport when the cursor is over the HUD — that would steal focus
	// from the Prevent Intersect checkbox and can still lead to a paint stroke on release.
	if (IsPointerOverHud())
	{
		return false;
	}

	if (bBoundsEditActive)
	{
		BeginBoundsFaceDrag(ViewportClient, Viewport);
		return bBoundsFaceDrag;
	}

	if (IsLineFillIntent(ViewportClient))
	{
		if (!bLineFillCapture)
		{
			CommitLineFill(ViewportClient);
			bLineFillCapture = true;
		}
		return true;
	}

	// InputKey usually BeginStroke's first; if tracking starts without that (or before release
	// pairing), ensure the stroke flag is set so the camera mouse-delta path stays blocked.
	BeginStroke(ViewportClient);
	return true;
}

bool FGridPaintTool::EndTracking(FEditorViewportClient* ViewportClient, FViewport* Viewport)
{
	// The LMB release (InputKey) ends strokes and drags. With ITF viewport interactions, any key event
	// (including Shift/Ctrl auto-repeat) ends mode tracking while LMB is still held.
	if (bActive && Viewport && Viewport->KeyState(EKeys::LeftMouseButton)
		&& (bLineFillCapture || bBoundsFaceDrag || bStrokeActive))
	{
		return true;
	}

	if (bActive && bLineFillCapture)
	{
		bLineFillCapture = false;
		return true;
	}
	if (bActive && bBoundsFaceDrag)
	{
		EndBoundsFaceDrag();
		return true;
	}
	if (bActive && bStrokeActive)
	{
		EndStroke(ViewportClient);
		return true;
	}
	return false;
}

void FGridPaintTool::Tick(FEditorViewportClient* ViewportClient, float DeltaTime)
{
	if (!bActive)
	{
		return;
	}

	const UProWorkflowToolsSettings* Settings = GetDefault<UProWorkflowToolsSettings>();
	AActor* Source = Context.SourceActor.Get();

	// Exit only when the feature is turned off or the source is gone — never because a click
	// briefly changed selection (we re-lock onto the source for the whole session).
	if (!Settings || !Settings->bEnableGridPaint || !IsValid(Source) || !GEditor)
	{
		Deactivate();
		return;
	}

	EnsureSourceSelected();

	if (ViewportClient)
	{
		LastTickViewportClient = ViewportClient;

		// Input events redraw; Tick only redraws while cell pulses or the fading label animate.
		if (UpdateFeedbackAnimations())
		{
			ViewportClient->Invalidate(false, false);
		}
		UpdatePointerOverride();

		if (bBoundsEditActive)
		{
			SetGhostVisible(false);
			return;
		}

		if (!bStrokeActive)
		{
			// Meshes: plane follows the camera while hovering (frozen during a stroke).
			// Decals: stay locked to the receive plane (normal = local X / projection axis).
			// Pass CurrentPlaneAxis so near-45° views keep the current plane (hysteresis).
			const int32 NewPlaneAxis = Context.bIsDecalSource
				? 0
				: GridPaintMath::PickPlaneAxis(Context, ViewportClient->GetViewRotation().Vector(), CurrentPlaneAxis);
			if (NewPlaneAxis != CurrentPlaneAxis)
			{
				CurrentPlaneAxis = NewPlaneAxis;
				FeedbackLabel.Show(
					FText::Format(
						LOCTEXT("GridPaintPlaneSwitchLabel", "Plane {0}"),
						FText::FromString(GridPaint::Private::GetPlaneName(NewPlaneAxis))),
					ProWorkflowTools::OverlayStyle::Accent());
				CellBlockedCache.Reset();
				UpdateHover(ViewportClient);
			}
		}

		UpdateGhostEraseVisibility(ViewportClient);
		UpdateLineFillPreview(ViewportClient);
	}
}

void FGridPaintTool::EnsureSourceSelected()
{
	AActor* Source = Context.SourceActor.Get();
	if (!bActive || !Source || !GEditor)
	{
		return;
	}

	USelection* Selection = GEditor->GetSelectedActors();
	const bool bOnlySourceSelected =
		Selection
		&& GEditor->GetSelectedActorCount() == 1
		&& Selection->IsSelected(Source);

	if (bOnlySourceSelected)
	{
		return;
	}

	// Quietly restore — do not NoteSelectionChange (avoids UI churn / feedback loops while painting).
	GEditor->SelectNone(/*bNoteSelectionChange=*/false, /*bDeselectBSPSurfs=*/true, /*WarnAboutManyActors=*/false);
	GEditor->SelectActor(Source, /*bSelect=*/true, /*bNotify=*/false);
}

///////////////////////////////////////////////////////////////////////////////
// Cursor -> cell

bool FGridPaintTool::ComputeCellUnderCursor(FEditorViewportClient* ViewportClient, int32 PlaneAxis, FIntVector& OutCell) const
{
	if (!ViewportClient || !ViewportClient->Viewport)
	{
		return false;
	}

	// Same cursor-ray source as the decal placement mode.
	const FViewportCursorLocation Cursor = ViewportClient->GetCursorWorldLocationFromMousePos();
	const FVector RayOrigin = Cursor.GetOrigin();
	const FVector RayDir = Cursor.GetDirection();

	FVector LocalNormal = FVector::ZeroVector;
	LocalNormal[PlaneAxis] = 1.0;
	const FVector PlaneNormal = Context.GridRotation.RotateVector(LocalNormal);

	const double Denom = FVector::DotProduct(RayDir, PlaneNormal);
	if (FMath::Abs(Denom) < GridPaint::Private::MinRayPlaneDot)
	{
		// Near-parallel: intersection would be unstable / at infinity.
		return false;
	}

	const double Distance = FVector::DotProduct(Context.PivotWorld - RayOrigin, PlaneNormal) / Denom;
	if (Distance <= 0.0)
	{
		// Plane intersection is behind the camera.
		return false;
	}

	const FVector HitPoint = RayOrigin + RayDir * Distance;
	const FVector GridCoords = GridPaintMath::WorldToGrid(Context, HitPoint);

	// Footprint tiling (same convention as GetCellPlaneCorners), not RoundToInt.
	OutCell = GridPaintMath::GridCoordsToFootprintCell(Context, GridCoords, PlaneAxis);
	return true;
}

void FGridPaintTool::UpdateHover(FEditorViewportClient* ViewportClient)
{
	FIntVector Cell;
	if (ComputeCellUnderCursor(ViewportClient, CurrentPlaneAxis, Cell))
	{
		bHasHoverCell = true;
		HoverCell = Cell;
		MoveGhostToCell(Cell);
	}
	else
	{
		bHasHoverCell = false;
		SetGhostVisible(false);
	}
}

///////////////////////////////////////////////////////////////////////////////
// Strokes

void FGridPaintTool::BeginStroke(FEditorViewportClient* ViewportClient)
{
	if (bStrokeActive)
	{
		return;
	}

	// Safety: Alt+LMB must never paint (InputKey / StartTracking already gate this).
	if (ViewportClient && ViewportClient->IsAltPressed())
	{
		return;
	}

	bStrokeActive = true;
	// Freeze paint vs erase from Shift at stroke start; releasing Shift mid-drag does not flip mode.
	bEraseStroke = ViewportClient && ViewportClient->IsShiftPressed();
	LockedPlaneAxis = CurrentPlaneAxis;
	LastCell.Reset();
	UpdateGhostEraseVisibility(ViewportClient);

	// First click paints/erases the clicked cell immediately (it may be far from the source).
	FIntVector Cell;
	if (ComputeCellUnderCursor(ViewportClient, LockedPlaneAxis, Cell))
	{
		ShowRefusedClickLabel(Cell);
		ApplyStrokeToCell(Cell);
		LastCell = Cell;
		bHasHoverCell = true;
		HoverCell = Cell;
		MoveGhostToCell(Cell);
	}
}

void FGridPaintTool::UpdateStroke(FEditorViewportClient* ViewportClient)
{
	FIntVector Cell;
	if (!ComputeCellUnderCursor(ViewportClient, LockedPlaneAxis, Cell))
	{
		bHasHoverCell = false;
		SetGhostVisible(false);
		return;
	}

	bHasHoverCell = true;
	HoverCell = Cell;
	MoveGhostToCell(Cell);

	if (!LastCell.IsSet())
	{
		ApplyStrokeToCell(Cell);
		LastCell = Cell;
		return;
	}

	if (Cell == LastCell.GetValue())
	{
		return;
	}

	// Visit every cell between the previous and current cursor cell so fast drags leave no gaps.
	const int32 AxisU = (LockedPlaneAxis + 1) % 3;
	const int32 AxisV = (LockedPlaneAxis + 2) % 3;
	const FIntVector Previous = LastCell.GetValue();
	GridPaintMath::WalkCells2D(
		FIntPoint(Previous[AxisU], Previous[AxisV]),
		FIntPoint(Cell[AxisU], Cell[AxisV]),
		[this, AxisU, AxisV](FIntPoint Point)
		{
			FIntVector StepCell = FIntVector::ZeroValue;
			StepCell[AxisU] = Point.X;
			StepCell[AxisV] = Point.Y;
			ApplyStrokeToCell(StepCell);
		});
	LastCell = Cell;
}

void FGridPaintTool::EndStroke(FEditorViewportClient* ViewportClient)
{
	if (!bStrokeActive)
	{
		return;
	}

	bStrokeActive = false;
	bEraseStroke = false;
	LastCell.Reset();

	const bool bChangedAnything = StrokeTransaction.IsValid();
	StrokeTransaction.Reset(); // closes the per-stroke undo transaction

	EnsureSourceSelected();
	// Restore paint-hover ghost after an erase stroke (Shift may still be held — visibility helper decides).
	UpdateGhostEraseVisibility(ViewportClient);

	if (bChangedAnything && GEditor)
	{
		GEditor->RedrawLevelEditingViewports();
	}
}

void FGridPaintTool::ShowRefusedClickLabel(const FIntVector& Cell)
{
	// Same order as PaintCell / EraseCell.
	if (bEraseStroke)
	{
		if (!FindErasableActorInCell(Cell))
		{
			FeedbackLabel.Show(LOCTEXT("GridPaintNothingToErase", "Nothing to erase"), ProWorkflowTools::OverlayStyle::Erase);
		}
	}
	else if (IsCellOccupied(Cell))
	{
		FeedbackLabel.Show(LOCTEXT("GridPaintCellOccupied", "Occupied"), GridPaint::Private::OccupiedOutlineColor);
	}
	else if (GetDefault<UProWorkflowToolsUserSettings>()->bPreventOverlappingPaint && IsCellOverlapping(Cell))
	{
		FeedbackLabel.Show(LOCTEXT("GridPaintCellBlocked", "Blocked"), GridPaint::Private::IntersectOutlineColor);
	}
}

void FGridPaintTool::ApplyStrokeToCell(const FIntVector& Cell)
{
	if (bEraseStroke)
	{
		EraseCell(Cell);
	}
	else
	{
		PaintCell(Cell);
	}
}

bool FGridPaintTool::IsLineFillIntent(const FEditorViewportClient* ViewportClient) const
{
	return bActive
		&& !bBoundsEditActive
		&& !bStrokeActive
		&& ViewportClient
		&& ViewportClient->IsCtrlPressed()
		&& !ViewportClient->IsShiftPressed();
}

FIntVector FGridPaintTool::GetLineFillAnchor() const
{
	return LastPaintedCell.IsSet() ? LastPaintedCell.GetValue() : FIntVector::ZeroValue;
}

void FGridPaintTool::CollectLineFillCells(TArray<FIntVector>& OutCells, const int32 OverlapTestBudget)
{
	OutCells.Reset();
	if (!bHasHoverCell)
	{
		return;
	}

	const int32 PlaneAxis = GetActivePlaneAxis();
	const FIntVector Anchor = GetLineFillAnchor();
	if (!GridPaintMath::IsExactAxisAlignedLine(Anchor, HoverCell, PlaneAxis))
	{
		return;
	}

	TArray<FIntVector, TInlineAllocator<64>> Empty;
	const int32 AxisU = (PlaneAxis + 1) % 3;
	const int32 AxisV = (PlaneAxis + 2) % 3;
	GridPaintMath::WalkCells2D(
		FIntPoint(Anchor[AxisU], Anchor[AxisV]),
		FIntPoint(HoverCell[AxisU], HoverCell[AxisV]),
		[this, AxisU, AxisV, PlaneAxis, &Empty](FIntPoint Point)
		{
			FIntVector Cell = FIntVector::ZeroValue;
			Cell[AxisU] = Point.X;
			Cell[AxisV] = Point.Y;
			Cell[PlaneAxis] = HoverCell[PlaneAxis];
			if (!IsCellOccupied(Cell))
			{
				Empty.Add(Cell);
			}
		});

	const bool bCheckOverlap = GetDefault<UProWorkflowToolsUserSettings>()->bPreventOverlappingPaint;
	TArray<FIntVector, TInlineAllocator<64>> Accepted;
	int32 OverlapTests = 0;
	for (int32 Index = Empty.Num() - 1; Index >= 0; --Index)
	{
		if (bCheckOverlap)
		{
			if (OverlapTestBudget >= 0 && OverlapTests >= OverlapTestBudget)
			{
				break;
			}
			++OverlapTests;
			if (IsCellOverlapping(Empty[Index]))
			{
				continue;
			}
		}
		Accepted.Add(Empty[Index]);
	}

	for (int32 Index = Accepted.Num() - 1; Index >= 0; --Index)
	{
		OutCells.Add(Accepted[Index]);
	}
}

void FGridPaintTool::UpdateLineFillPreview(FEditorViewportClient* ViewportClient)
{
	LineFillPreviewCells.Reset();
	bLineFillIntentActive = IsLineFillIntent(ViewportClient) && bHasHoverCell;
	if (!bLineFillIntentActive)
	{
		return;
	}

	CollectLineFillCells(LineFillPreviewCells, GridPaint::Private::MaxLineFillPreviewOverlapTests);
}

void FGridPaintTool::CommitLineFill(FEditorViewportClient* ViewportClient)
{
	TArray<FIntVector> Cells;
	CollectLineFillCells(Cells, INDEX_NONE);
	if (Cells.Num() == 0)
	{
		return;
	}

	for (const FIntVector& Cell : Cells)
	{
		PaintCell(Cell);
	}

	const bool bChangedAnything = StrokeTransaction.IsValid();
	StrokeTransaction.Reset();
	EnsureSourceSelected();
	UpdateLineFillPreview(ViewportClient);

	if (bChangedAnything && GEditor)
	{
		GEditor->RedrawLevelEditingViewports();
	}
}

void FGridPaintTool::DrawLineFillPreview(const FSceneView* View, FPrimitiveDrawInterface* PDI) const
{
	if (!PDI || LineFillPreviewCells.Num() == 0)
	{
		return;
	}

	using namespace ProWorkflowTools::OverlayStyle;

	const int32 PlaneAxis = GetActivePlaneAxis();
	const FVector Lift = GetOverlayLift(View, PlaneAxis);
	const FLinearColor Wire = Accent().CopyWithNewOpacity(GridPaint::Private::LineFillOutlineOpacity);

	for (const FIntVector& Cell : LineFillPreviewCells)
	{
		FVector C00, C10, C11, C01;
		GetCellPlaneCorners(Cell, PlaneAxis, Lift, C00, C10, C11, C01);
		WithXRay(Wire, [&](const FLinearColor& PassColor, const uint8 Depth)
		{
			DrawOutline(PDI, C00, C10, C11, C01, PassColor, Depth, TickPx);
		});
	}
}

void FGridPaintTool::DrawLineFillAnchor(const FSceneView* View, FPrimitiveDrawInterface* PDI) const
{
	if (!PDI || !bLineFillIntentActive)
	{
		return;
	}

	using namespace ProWorkflowTools::OverlayStyle;

	const int32 PlaneAxis = GetActivePlaneAxis();
	const int32 AxisU = (PlaneAxis + 1) % 3;
	const int32 AxisV = (PlaneAxis + 2) % 3;
	const FIntVector Anchor = GetLineFillAnchor();

	FVector C00, C10, C11, C01;
	GetCellPlaneCorners(Anchor, PlaneAxis, GetOverlayLift(View, PlaneAxis), C00, C10, C11, C01);
	const FVector Center = (C00 + C10 + C11 + C01) * 0.25;

	// Guides reach past the hover cell so the valid run is visible wherever the cursor is.
	const int32 SpanCells = GridPaint::Private::LineFillGuideReachCells
		+ FMath::Max(FMath::Abs(HoverCell[AxisU] - Anchor[AxisU]), FMath::Abs(HoverCell[AxisV] - Anchor[AxisV]));
	auto AxisSpan = [this, SpanCells](const int32 Axis)
	{
		FVector Dir = FVector::ZeroVector;
		Dir[Axis] = 1.0;
		return Context.GridRotation.RotateVector(Dir) * (Context.CellSize[Axis] * SpanCells);
	};
	const FVector SpanU = AxisSpan(AxisU);
	const FVector SpanV = AxisSpan(AxisV);

	WithXRay(Accent().CopyWithNewOpacity(GridPaint::Private::LineFillGuideOpacity), [&](const FLinearColor& PassColor, const uint8 Depth)
	{
		PDI->DrawTranslucentLine(Center - SpanU, Center + SpanU, PassColor, Depth, 1.0f, 0.0f, /*bScreenSpace=*/true);
		PDI->DrawTranslucentLine(Center - SpanV, Center + SpanV, PassColor, Depth, 1.0f, 0.0f, /*bScreenSpace=*/true);
	});
	PDI->DrawPoint(Center, Accent(), GridPaint::Private::LineFillAnchorDotPx, SDPG_Foreground);
}

void FGridPaintTool::AddCellPulse(const FIntVector& Cell, const bool bErase)
{
	if (CellPulses.Num() >= GridPaint::Private::MaxCellPulses)
	{
		CellPulses.RemoveAt(0, CellPulses.Num() - GridPaint::Private::MaxCellPulses + 1, EAllowShrinking::No);
	}

	FCellPulse& Pulse = CellPulses.AddDefaulted_GetRef();
	Pulse.Cell = Cell;
	Pulse.PlaneAxis = GetActivePlaneAxis();
	Pulse.StartSeconds = FPlatformTime::Seconds();
	Pulse.bErase = bErase;
}

void FGridPaintTool::DrawCellPulses(const FSceneView* View, FPrimitiveDrawInterface* PDI) const
{
	if (!PDI || CellPulses.IsEmpty())
	{
		return;
	}

	using namespace ProWorkflowTools::OverlayStyle;

	const double Now = FPlatformTime::Seconds();
	for (const FCellPulse& Pulse : CellPulses)
	{
		const float T = static_cast<float>(Now - Pulse.StartSeconds) / PulseSeconds;
		if (T >= 1.0f)
		{
			continue;
		}

		FVector C00, C10, C11, C01;
		GetCellPlaneCorners(Pulse.Cell, Pulse.PlaneAxis, GetOverlayLift(View, Pulse.PlaneAxis), C00, C10, C11, C01);
		const FVector Center = (C00 + C10 + C11 + C01) * 0.25;
		const float Ease = EaseOutCubic(T);
		const double Scale = Pulse.bErase
			? 1.0 - GridPaint::Private::ErasePulseShrink * Ease
			: 1.0 + GridPaint::Private::PaintPulseGrow * Ease;
		auto Scaled = [&Center, Scale](const FVector& Corner) { return Center + (Corner - Center) * Scale; };
		const FVector S00 = Scaled(C00);
		const FVector S10 = Scaled(C10);
		const FVector S11 = Scaled(C11);
		const FVector S01 = Scaled(C01);

		const FLinearColor Color = (Pulse.bErase ? Erase : Accent()).CopyWithNewOpacity(0.9f * (1.0f - T));
		WithXRay(Color, [&](const FLinearColor& PassColor, const uint8 Depth)
		{
			DrawOutline(PDI, S00, S10, S11, S01, PassColor, Depth, TickPx);
		});
	}
}

bool FGridPaintTool::UpdateFeedbackAnimations()
{
	const double Now = FPlatformTime::Seconds();
	const bool bPulsesLive = !CellPulses.IsEmpty();
	CellPulses.RemoveAll([Now](const FCellPulse& Pulse)
	{
		return Now - Pulse.StartSeconds >= ProWorkflowTools::OverlayStyle::PulseSeconds;
	});

	const bool bLabelRedraw = FeedbackLabel.TickNeedsRedraw();
	return bPulsesLive || bLabelRedraw;
}

FVector FGridPaintTool::GetOverlayLift(const FSceneView* View, const int32 PlaneAxis) const
{
	FVector Normal = FVector::ZeroVector;
	Normal[FMath::Clamp(PlaneAxis, 0, 2)] = 1.0;
	Normal = Context.GridRotation.RotateVector(Normal);
	if (View && FVector::DotProduct(Normal, View->ViewLocation - Context.PivotWorld) < 0.0)
	{
		Normal = -Normal;
	}
	return Normal * GridPaint::Private::OverlayLift;
}

bool FGridPaintTool::DoesActorMatchSourceAsset(const AActor* Candidate) const
{
	const AActor* Source = Context.SourceActor.Get();
	if (!Candidate || !Source || Candidate == Source)
	{
		return false;
	}

	if (Candidate->bIsEditorPreviewActor)
	{
		return false;
	}

	if (Context.bIsDecalSource)
	{
		const UDecalComponent* SourceDecal = GetSourceDecalComponent(Source);
		const UDecalComponent* CandidateDecal = GetSourceDecalComponent(Candidate);
		return SourceDecal
			&& CandidateDecal
			&& SourceDecal->GetDecalMaterial()
			&& SourceDecal->GetDecalMaterial() == CandidateDecal->GetDecalMaterial();
	}

	const UStaticMeshComponent* SourceMesh = GetSourceStaticMeshComponent(Source);
	const UStaticMeshComponent* CandidateMesh = GetSourceStaticMeshComponent(Candidate);
	return SourceMesh
		&& CandidateMesh
		&& SourceMesh->GetStaticMesh()
		&& SourceMesh->GetStaticMesh() == CandidateMesh->GetStaticMesh();
}

bool FGridPaintTool::DoesActorMatchCellPose(const AActor* Actor, const FIntVector& Cell) const
{
	if (!Actor)
	{
		return false;
	}

	const FVector ExpectedLocation = GridPaintMath::GridToWorld(Context, Cell);
	if (FVector::DistSquared(Actor->GetActorLocation(), ExpectedLocation)
		> FMath::Square(GridPaint::Private::OccupantLocationToleranceCm))
	{
		return false;
	}

	const float MaxAngleRad = FMath::DegreesToRadians(GridPaint::Private::OccupantRotationToleranceDeg);
	if (Actor->GetActorQuat().AngularDistance(Context.GridRotation) > MaxAngleRad)
	{
		return false;
	}

	return Actor->GetActorScale3D().Equals(SourceScale, GridPaint::Private::OccupantScaleTolerance);
}

AActor* FGridPaintTool::QueryMatchingActorAtCell(const FIntVector& Cell) const
{
	AActor* Source = Context.SourceActor.Get();
	UWorld* World = Source ? Source->GetWorld() : nullptr;
	if (!World || Cell == FIntVector::ZeroValue)
	{
		return nullptr;
	}

	const FVector CellPivot = GridPaintMath::GridToWorld(Context, Cell);
	// Slightly larger than pose tolerance so components whose bounds miss the exact pivot still hit.
	const float QueryRadius = GridPaint::Private::OccupantLocationToleranceCm * 2.0f;

	FCollisionQueryParams Params(SCENE_QUERY_STAT(GridPaintOccupantQuery), /*bInTraceComplex=*/false);
	Params.AddIgnoredActor(Source);
	if (const AActor* Ghost = GhostActor.Get())
	{
		Params.AddIgnoredActor(Ghost);
	}

	TArray<FOverlapResult> Overlaps;
	if (!World->OverlapMultiByChannel(
		Overlaps,
		CellPivot,
		FQuat::Identity,
		ECC_WorldStatic,
		FCollisionShape::MakeSphere(QueryRadius),
		Params))
	{
		return nullptr;
	}

	AActor* Best = nullptr;
	float BestDistSq = TNumericLimits<float>::Max();
	for (const FOverlapResult& Overlap : Overlaps)
	{
		AActor* Candidate = Overlap.GetActor();
		if (!IsValid(Candidate)
			|| !DoesActorMatchSourceAsset(Candidate)
			|| !DoesActorMatchCellPose(Candidate, Cell))
		{
			continue;
		}

		const float DistSq = FVector::DistSquared(Candidate->GetActorLocation(), CellPivot);
		if (DistSq < BestDistSq)
		{
			BestDistSq = DistSq;
			Best = Candidate;
		}
	}
	return Best;
}

AActor* FGridPaintTool::FindErasableActorInCell(const FIntVector& Cell) const
{
	if (Cell == FIntVector::ZeroValue)
	{
		return nullptr;
	}

	if (const TWeakObjectPtr<AActor>* Session = SessionSpawnedActors.Find(Cell))
	{
		if (AActor* Actor = Session->Get())
		{
			if (IsValid(Actor) && DoesActorMatchCellPose(Actor, Cell))
			{
				return Actor;
			}
		}
	}

	return QueryMatchingActorAtCell(Cell);
}

bool FGridPaintTool::IsCellOccupied(const FIntVector& Cell) const
{
	if (Cell == FIntVector::ZeroValue)
	{
		return true;
	}

	// Always on — same-type at this cell pose. Not gated by Prevent Intersect.
	return FindErasableActorInCell(Cell) != nullptr;
}

void FGridPaintTool::NotifyPostUndoRedo()
{
	if (!bActive)
	{
		return;
	}

	// Tile-bounds apply is undoable on the mesh — refresh session cell size from stored data.
	ReloadTileBoundsFromSourceMesh();
	// Undo can add or remove geometry anywhere on the grid; occupancy is re-queried live anyway.
	CellBlockedCache.Reset();
	EnsureSourceSelected();

	if (GEditor)
	{
		GEditor->RedrawLevelEditingViewports();
	}
}

void FGridPaintTool::PaintCell(const FIntVector& Cell)
{
	// Occupied = source / live matching asset in the cell.
	if (IsCellOccupied(Cell))
	{
		return;
	}

	// Intersect blocks are skipped but NOT marked occupied, so the stroke continues past them.
	if (GetDefault<UProWorkflowToolsUserSettings>()->bPreventOverlappingPaint && IsCellOverlapping(Cell))
	{
		return;
	}

	SpawnDuplicateAtCell(Cell);
}

void FGridPaintTool::EraseCell(const FIntVector& Cell)
{
	// Never erase the source actor occupying the origin cell.
	if (Cell == FIntVector::ZeroValue)
	{
		return;
	}

	AActor* Actor = FindErasableActorInCell(Cell);
	if (!IsValid(Actor) || !GEditor)
	{
		return;
	}

	if (!StrokeTransaction.IsValid())
	{
		StrokeTransaction = MakeUnique<FScopedTransaction>(LOCTEXT("GridPaintEraseTransaction", "Actor Grid Erase"));
	}

	UEditorActorSubsystem* ActorSubsystem = GEditor->GetEditorSubsystem<UEditorActorSubsystem>();
	if (ActorSubsystem)
	{
		ActorSubsystem->DestroyActor(Actor);
	}
	else if (UWorld* World = Actor->GetWorld())
	{
		Actor->Modify();
		World->EditorDestroyActor(Actor, /*bShouldModifyLevel=*/true);
	}

	SessionSpawnedActors.Remove(Cell);
	CellBlockedCache.Reset();
	AddCellPulse(Cell, /*bErase=*/true);
	EnsureSourceSelected();
}

void FGridPaintTool::SpawnDuplicateAtCell(const FIntVector& Cell)
{
	AActor* Source = Context.SourceActor.Get();
	if (!Source || !GEditor)
	{
		return;
	}

	UEditorActorSubsystem* ActorSubsystem = GEditor->GetEditorSubsystem<UEditorActorSubsystem>();
	if (!ActorSubsystem)
	{
		return;
	}

	if (!StrokeTransaction.IsValid())
	{
		StrokeTransaction = MakeUnique<FScopedTransaction>(LOCTEXT("GridPaintStrokeTransaction", "Actor Grid Paint"));
	}

	AActor* Duplicate = ActorSubsystem->DuplicateActor(Source, Source->GetWorld(), FVector::ZeroVector);
	if (!Duplicate)
	{
		return;
	}

	Duplicate->Modify();
	Duplicate->SetActorLocation(GridPaintMath::GridToWorld(Context, Cell));
	Duplicate->SetActorRotation(Context.GridRotation);
	Duplicate->SetActorScale3D(SourceScale);
	Duplicate->PostEditMove(true);

	FActorLabelUtilities::SetActorLabelUnique(
		Duplicate,
		FString::Printf(TEXT("%s_Grid_%03d"), *Source->GetActorLabel(), NextLabelIndex++));
	Duplicate->SetFolderPath(Source->GetFolderPath());

	SessionSpawnedActors.Add(Cell, Duplicate);
	LastPaintedCell = Cell;
	AddCellPulse(Cell, /*bErase=*/false);

	// The new actor changes the collision picture around it.
	CellBlockedCache.Reset();

	// DuplicateActor moves the selection onto the copy; keep the session locked to the source.
	EnsureSourceSelected();
}

///////////////////////////////////////////////////////////////////////////////
// Overlap prevention

bool FGridPaintTool::IsCellOverlapping(const FIntVector& Cell)
{
	if (const bool* Cached = CellBlockedCache.Find(Cell))
	{
		return *Cached;
	}

	// The cache accumulates as the cursor travels across the grid.
	if (CellBlockedCache.Num() > GridPaint::Private::MaxCachedOverlapCells)
	{
		CellBlockedCache.Reset();
	}

	const bool bBlocked = ComputeCellOverlap(Cell);
	CellBlockedCache.Add(Cell, bBlocked);
	return bBlocked;
}

bool FGridPaintTool::ComputeCellOverlap(const FIntVector& Cell) const
{
	AActor* Source = Context.SourceActor.Get();
	UWorld* World = Source ? Source->GetWorld() : nullptr;
	if (!World)
	{
		return false;
	}

	// Same OBB the paint/erase volumes use — not a separate mesh-AABB guess.
	FMatrix BoxToWorld;
	FVector Radii;
	if (!GetCellOrientedBox(Cell, BoxToWorld, Radii))
	{
		return false;
	}

	// Scale < 1 insets the test so light grazing of neighbors doesn't block; deep clips still do.
	const UProWorkflowToolsSettings* Settings = GetDefault<UProWorkflowToolsSettings>();
	const float BoundsScale = GridPaint::Private::GetOverlapBoundsScale(Settings);
	Radii *= BoundsScale;

	// Triangle collision so a hollow mesh's interior does not block; only surfaces that clip the cell do.
	FCollisionQueryParams Params(SCENE_QUERY_STAT(GridPaintOverlap), /*bInTraceComplex=*/true);
	Params.AddIgnoredActor(Source);
	const AActor* Ghost = GhostActor.Get();
	if (Ghost)
	{
		Params.AddIgnoredActor(Ghost);
	}

	TArray<FOverlapResult> Overlaps;
	if (!World->OverlapMultiByChannel(
		Overlaps,
		BoxToWorld.GetOrigin(),
		Context.GridRotation,
		ECC_WorldStatic,
		FCollisionShape::MakeBox(Radii),
		Params))
	{
		return false;
	}

	// Foreign geometry only. Same-type at this (or any) pose is occupancy / erase — never here.
	for (const FOverlapResult& Overlap : Overlaps)
	{
		AActor* HitActor = Overlap.GetActor();
		if (!IsValid(HitActor) || HitActor == Source || HitActor == Ghost)
		{
			continue;
		}
		if (DoesActorMatchSourceAsset(HitActor))
		{
			continue;
		}
		return true;
	}

	return false;
}

///////////////////////////////////////////////////////////////////////////////
// Ghost preview

void FGridPaintTool::EnsureGhostActor()
{
	if (GhostActor.IsValid())
	{
		return;
	}

	AActor* Source = Context.SourceActor.Get();
	UWorld* World = Source ? Source->GetWorld() : nullptr;
	if (!World)
	{
		return;
	}

	if (Context.bIsDecalSource)
	{
		if (UDecalComponent* SourceDecal = GetSourceDecalComponent(Source))
		{
			EnsureDecalGhostActor(Source, SourceDecal, World);
		}
		return;
	}

	UStaticMeshComponent* SourceComponent = GetSourceStaticMeshComponent(Source);
	if (SourceComponent && SourceComponent->GetStaticMesh())
	{
		EnsureMeshGhostActor(Source, SourceComponent, World);
	}
}

void FGridPaintTool::EnsureMeshGhostActor(AActor* Source, UStaticMeshComponent* SourceComponent, UWorld* World)
{
	if (!Source || !SourceComponent || !World)
	{
		return;
	}

	FActorSpawnParameters SpawnParams;
	SpawnParams.ObjectFlags = RF_Transient | RF_DuplicateTransient;
	SpawnParams.bTemporaryEditorActor = true;
	SpawnParams.bHideFromSceneOutliner = true;
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

	AStaticMeshActor* Ghost = World->SpawnActor<AStaticMeshActor>(
		AStaticMeshActor::StaticClass(),
		FTransform(Context.GridRotation, Context.PivotWorld),
		SpawnParams);
	if (!Ghost)
	{
		return;
	}

	// Never let the ghost enter the transaction buffer (it lives outside undo entirely).
	Ghost->ClearFlags(RF_Transactional);
	Ghost->bIsEditorPreviewActor = true;
	Ghost->SetActorEnableCollision(false);
	Ghost->SetActorScale3D(GhostScale);

	if (UStaticMeshComponent* GhostComponent = Ghost->GetStaticMeshComponent())
	{
		GhostComponent->ClearFlags(RF_Transactional);
		GhostComponent->SetMobility(EComponentMobility::Movable);
		GhostComponent->SetStaticMesh(SourceComponent->GetStaticMesh());
		GhostComponent->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		GhostComponent->SetCastShadow(false);

		// The source's own look, including its per-slot material overrides.
		for (int32 SlotIndex = 0; SlotIndex < SourceComponent->GetNumMaterials(); ++SlotIndex)
		{
			GhostComponent->SetMaterial(SlotIndex, SourceComponent->GetMaterial(SlotIndex));
		}
	}

	GhostActor = Ghost;
}

void FGridPaintTool::EnsureDecalGhostActor(AActor* Source, UDecalComponent* SourceDecal, UWorld* World)
{
	if (!Source || !SourceDecal || !World)
	{
		return;
	}

	// Same hardening as Interactive Decal Placement's preview actor (transient, outliner-hidden,
	// non-transactional). Shows the source material/size; no translucent material override.
	FActorSpawnParameters SpawnParams;
	SpawnParams.ObjectFlags = RF_Transient | RF_DuplicateTransient;
	SpawnParams.bTemporaryEditorActor = true;
	SpawnParams.bHideFromSceneOutliner = true;
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

	ADecalActor* Ghost = World->SpawnActor<ADecalActor>(
		ADecalActor::StaticClass(),
		FTransform(Context.GridRotation, Context.PivotWorld, SourceScale),
		SpawnParams);
	if (!Ghost)
	{
		return;
	}

	Ghost->ClearFlags(RF_Transactional);
	Ghost->bIsEditorPreviewActor = true;
	Ghost->SetActorEnableCollision(false);

	if (UDecalComponent* GhostDecal = Ghost->GetDecal())
	{
		// UDecalComponent is a USceneComponent (no primitive collision API); actor collision off is enough.
		GhostDecal->ClearFlags(RF_Transactional);
		GhostDecal->SetDecalMaterial(SourceDecal->GetDecalMaterial());
		GhostDecal->DecalSize = SourceDecal->DecalSize;
	}

	GhostActor = Ghost;
}

void FGridPaintTool::MoveGhostToCell(const FIntVector& Cell)
{
	EnsureGhostActor();
	AActor* Ghost = GhostActor.Get();
	if (!Ghost)
	{
		return;
	}

	Ghost->SetActorLocation(GridPaintMath::GridToWorld(Context, Cell));
	if (Context.bIsDecalSource)
	{
		Ghost->SetActorRotation(Context.GridRotation);
		Ghost->SetActorScale3D(SourceScale);
	}
	// Erase intent / erase stroke: keep the ghost hidden so the real asset is visible under the brush.
	SetGhostVisible(!bHideGhostForErase);
}

void FGridPaintTool::SetGhostVisible(bool bVisible)
{
	if (AActor* Ghost = GhostActor.Get())
	{
		if (Ghost->IsTemporarilyHiddenInEditor() == bVisible)
		{
			Ghost->SetIsTemporarilyHiddenInEditor(!bVisible);
		}
	}
}

void FGridPaintTool::UpdateGhostEraseVisibility(FEditorViewportClient* ViewportClient)
{
	const bool bShiftHeld = ViewportClient && ViewportClient->IsShiftPressed();
	const bool bOccupiedHover = bHasHoverCell
		&& HoverCell != FIntVector::ZeroValue
		&& IsCellOccupied(HoverCell);
	bEraseIntent = bEraseStroke || bShiftHeld;
	bHideGhostForErase = bEraseIntent || bOccupiedHover;

	SetGhostVisible(bHasHoverCell && !bHideGhostForErase);
}

bool FGridPaintTool::HasEraseHoverTarget() const
{
	if (!bActive || !bEraseIntent || !bHasHoverCell)
	{
		return false;
	}

	return FindErasableActorInCell(HoverCell) != nullptr;
}

void FGridPaintTool::DestroyGhostActor()
{
	if (AActor* Ghost = GhostActor.Get())
	{
		if (UWorld* World = Ghost->GetWorld())
		{
			World->DestroyActor(Ghost);
		}
	}
	GhostActor.Reset();
}

///////////////////////////////////////////////////////////////////////////////
// Lifecycle

void FGridPaintTool::Deactivate()
{
	if (bBoundsFaceDrag)
	{
		EndBoundsFaceDrag();
	}
	bBoundsEditActive = false;
	EditBoundsGridLocal = FBox(ForceInit);

	if (bStrokeActive)
	{
		EndStroke();
	}

	DestroyGhostActor();
	HideHudOverlay();
	ReleasePointerOverride();

	if (!bActive)
	{
		return;
	}

	bActive = false;
	bHasHoverCell = false;
	bEraseStroke = false;
	bEraseIntent = false;
	bHideGhostForErase = false;
	bBoundsFaceDrag = false;
	BoundsHoverAxis = INDEX_NONE;
	BoundsHoverSign = 0;
	LastPaintedCell.Reset();
	LineFillPreviewCells.Reset();
	bLineFillCapture = false;
	bLineFillIntentActive = false;
	CellPulses.Reset();
	FeedbackLabel.Clear();
	SessionSpawnedActors.Reset();
	CellBlockedCache.Reset();
	Context = FGridPaintContext();

	ProWorkflowTools::ReleaseTransformWidget();
	if (GEditor)
	{
		GEditor->RedrawLevelEditingViewports();
	}
}

UStaticMeshComponent* FGridPaintTool::GetSourceStaticMeshComponent(const AActor* Actor)
{
	if (!Actor)
	{
		return nullptr;
	}

	if (UStaticMeshComponent* RootComponent = Cast<UStaticMeshComponent>(Actor->GetRootComponent()))
	{
		return RootComponent;
	}

	return Actor->FindComponentByClass<UStaticMeshComponent>();
}

UDecalComponent* FGridPaintTool::GetSourceDecalComponent(const AActor* Actor)
{
	if (!Actor)
	{
		return nullptr;
	}

	if (const ADecalActor* DecalActor = Cast<ADecalActor>(Actor))
	{
		return DecalActor->GetDecal();
	}

	return Actor->FindComponentByClass<UDecalComponent>();
}

#undef LOCTEXT_NAMESPACE

