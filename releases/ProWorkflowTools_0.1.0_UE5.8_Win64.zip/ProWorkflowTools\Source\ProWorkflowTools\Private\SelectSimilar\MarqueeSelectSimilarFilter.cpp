// Copyright © 2026 Trey McNair. All rights reserved.

#include "SelectSimilar/MarqueeSelectSimilarFilter.h"

#include "Components/SkinnedMeshComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Editor.h"
#include "Engine/Selection.h"
#include "Engine/SkeletalMesh.h"
#include "Engine/StaticMesh.h"
#include "GameFramework/Actor.h"

void FMarqueeSelectSimilarFilter::Reset()
{
	StaticMeshes.Reset();
	SkeletalMeshes.Reset();
	ActorClasses.Reset();
}

void FMarqueeSelectSimilarFilter::BuildFromSelection()
{
	Reset();

	if (!GEditor)
	{
		return;
	}

	for (FSelectionIterator It(GEditor->GetSelectedActorIterator()); It; ++It)
	{
		AActor* Actor = Cast<AActor>(*It);
		if (!Actor)
		{
			continue;
		}

		bool bHadMeshAsset = false;

		for (UActorComponent* Component : Actor->GetComponents())
		{
			if (UStaticMeshComponent* StaticMeshComponent = Cast<UStaticMeshComponent>(Component))
			{
				if (UStaticMesh* StaticMesh = StaticMeshComponent->GetStaticMesh())
				{
					StaticMeshes.Add(StaticMesh);
					bHadMeshAsset = true;
				}
			}
			else if (USkinnedMeshComponent* SkinnedMeshComponent = Cast<USkinnedMeshComponent>(Component))
			{
				if (USkeletalMesh* SkeletalMesh = Cast<USkeletalMesh>(SkinnedMeshComponent->GetSkinnedAsset()))
				{
					SkeletalMeshes.Add(SkeletalMesh);
					bHadMeshAsset = true;
				}
			}
		}

		// Non-mesh selections (lights, volumes, etc.) fall back to actor class matching.
		if (!bHadMeshAsset)
		{
			ActorClasses.Add(Actor->GetClass());
		}
	}
}

bool FMarqueeSelectSimilarFilter::IsEmpty() const
{
	return StaticMeshes.IsEmpty() && SkeletalMeshes.IsEmpty() && ActorClasses.IsEmpty();
}

bool FMarqueeSelectSimilarFilter::MatchesActor(const AActor* InActor) const
{
	if (!InActor || IsEmpty())
	{
		return false;
	}

	if (!StaticMeshes.IsEmpty())
	{
		for (const UActorComponent* Component : InActor->GetComponents())
		{
			if (const UStaticMeshComponent* StaticMeshComponent = Cast<const UStaticMeshComponent>(Component))
			{
				if (StaticMeshes.Contains(StaticMeshComponent->GetStaticMesh()))
				{
					return true;
				}
			}
		}
	}

	if (!SkeletalMeshes.IsEmpty())
	{
		for (const UActorComponent* Component : InActor->GetComponents())
		{
			if (const USkinnedMeshComponent* SkinnedMeshComponent = Cast<const USkinnedMeshComponent>(Component))
			{
				if (SkeletalMeshes.Contains(Cast<USkeletalMesh>(SkinnedMeshComponent->GetSkinnedAsset())))
				{
					return true;
				}
			}
		}
	}

	if (!ActorClasses.IsEmpty() && ActorClasses.Contains(InActor->GetClass()))
	{
		return true;
	}

	return false;
}

