// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "ProWorkflowToolsCommands.h"
#include "ProWorkflowToolsSettings.h"
#include "Viewport/ViewportOverlayStyle.h"

#include "EditorViewportClient.h"
#include "EditorViewportCommands.h"
#include "Framework/Commands/GenericCommands.h"
#include "Framework/Commands/InputChord.h"
#include "Framework/Commands/UICommandInfo.h"
#include "Framework/Notifications/NotificationManager.h"
#include "Widgets/Notifications/SNotificationList.h"

/** Shared constants and small helpers for the Grid Paint translation units. */
namespace GridPaint::Private
{
	/** Smallest usable cell size per axis (guards flat meshes / near-zero scale). */
	constexpr double MinCellSize = 0.1;

	/** Rays closer than this |dot| to the paint plane give unstable, far-away intersections. */
	constexpr double MinRayPlaneDot = 0.05;

	/** Key plus the held modifiers matches either of the command's active chords (Keyboard Shortcuts). */
	inline bool MatchesCommandChord(
		const FEditorViewportClient* ViewportClient, const TSharedPtr<FUICommandInfo>& Command, const FKey& Key)
	{
		if (!ViewportClient || !Command.IsValid())
		{
			return false;
		}

		for (const EMultipleKeyBindingIndex Index : { EMultipleKeyBindingIndex::Primary, EMultipleKeyBindingIndex::Secondary })
		{
			const FInputChord& Chord = *Command->GetActiveChord(Index);
			if (Chord.IsValidChord()
				&& Chord.Key == Key
				&& Chord.bAlt == ViewportClient->IsAltPressed()
				&& Chord.bCtrl == ViewportClient->IsCtrlPressed()
				&& Chord.bShift == ViewportClient->IsShiftPressed()
				&& Chord.bCmd == ViewportClient->IsCmdPressed())
			{
				return true;
			}
		}
		return false;
	}

	/** Translate / rotate / scale / cycle-gizmo chords. */
	inline bool IsTransformGizmoChord(const FEditorViewportClient* ViewportClient, const FKey& Key)
	{
		if (!FEditorViewportCommands::IsRegistered())
		{
			return false;
		}

		const FEditorViewportCommands& Commands = FEditorViewportCommands::Get();
		const TSharedPtr<FUICommandInfo> GizmoCommands[] = {
			Commands.TranslateMode,
			Commands.RotateMode,
			Commands.ScaleMode,
			Commands.TranslateRotateMode,
			Commands.TranslateRotate2DMode,
			Commands.CycleTransformGizmos,
		};

		for (const TSharedPtr<FUICommandInfo>& Command : GizmoCommands)
		{
			if (MatchesCommandChord(ViewportClient, Command, Key))
			{
				return true;
			}
		}
		return false;
	}

	/** W/E/R exit is a tap. Mouse down means camera / stroke, not a widget switch. */
	inline bool IsViewportMouseButtonDown(const FViewport* Viewport)
	{
		return Viewport
			&& (Viewport->KeyState(EKeys::LeftMouseButton)
				|| Viewport->KeyState(EKeys::RightMouseButton)
				|| Viewport->KeyState(EKeys::MiddleMouseButton));
	}

	/** Paint plane named by the two in-plane axes (normal axis 0..2). */
	inline const TCHAR* GetPlaneName(const int32 PlaneAxis)
	{
		static const TCHAR* PlaneNames[3] = { TEXT("YZ"), TEXT("XZ"), TEXT("XY") };
		return PlaneNames[FMath::Clamp(PlaneAxis, 0, 2)];
	}

	/** Plain neutral grid around the hover cell, fading out over a world-space circle of this many cells. */
	constexpr int32 GridRadiusCells = 5;
	constexpr float GridLineOpacity = 0.35f;
	constexpr float GridLineThickness = 1.0f;

	/** Hover cell outline. The cell's state is its colour; there are no fills. */
	constexpr float HoverOutlineThickness = ProWorkflowTools::OverlayStyle::TickPx;
	/** Soft orange — Prevent Intersect blocked (geo collision). */
	const FLinearColor IntersectOutlineColor(1.0f, 0.58f, 0.28f, 1.0f);
	/** Cool slate — cell already occupied by a matching asset. */
	const FLinearColor OccupiedOutlineColor(0.50f, 0.62f, 0.78f, 1.0f);

	/** Erase intent: red hover outline; faint corner brackets mark an actor that will be erased. */
	constexpr float EraseOutlineOpacity = 0.9f;
	constexpr float EraseBracketOpacity = 0.45f;
	constexpr float EraseBracketFraction = 0.15f;
	constexpr float EraseBracketMaxCm = 25.0f;
	/** Minus-in-a-ring badge by the pointer while erase intent is on (Slate pixels). */
	constexpr double EraseBadgeOffsetPx = 14.0;
	constexpr double EraseBadgeRadiusPx = 5.5;
	constexpr float EraseBadgeThicknessPx = 1.5f;
	constexpr float EraseBadgeOpacity = 0.9f;
	constexpr int32 EraseBadgeSegments = 16;

	/** Amber tile-bounds edit OBB (distinct from paint cyan / erase red). */
	const FLinearColor BoundsEditWireColor(1.0f, 0.72f, 0.18f, 1.0f);
	const FLinearColor BoundsEditHoverFaceColor(1.0f, 0.85f, 0.35f, 1.0f);
	constexpr float BoundsEditWireThickness = ProWorkflowTools::OverlayStyle::TickPx;
	constexpr float BoundsEditHandleSize = 10.0f;
	/** Screen-pixel radius for picking a face handle. */
	constexpr float BoundsEditFacePickPixels = 48.0f;
	/** Draft Ctrl+Z steps kept per bounds edit; the oldest drop off. */
	constexpr int32 MaxBoundsEditHistory = 128;

	/** Pose match tolerances for world occupancy (no persisted paint data). */
	constexpr float OccupantLocationToleranceCm = 2.5f;
	constexpr float OccupantRotationToleranceDeg = 2.0f;
	constexpr float OccupantScaleTolerance = 0.02f;

	/** Hover accent (distinct from selection orange); shared with the other tools' overlays. */
	inline FLinearColor HoverAccentColor() { return ProWorkflowTools::OverlayStyle::Accent(); }
	/** Ctrl line-fill preview: hairline outline per paintable cell on the run. */
	constexpr float LineFillOutlineOpacity = 0.8f;
	/** Line-fill anchor dot and the faint axis guides through it while Ctrl is held. */
	constexpr float LineFillAnchorDotPx = 6.0f;
	constexpr float LineFillGuideOpacity = 0.22f;
	/** Cells the anchor guides extend beyond the anchor-to-hover span. */
	constexpr int32 LineFillGuideReachCells = 7;
	/** Painted cells pop outward, erased cells shrink, as their outline fades. */
	constexpr float PaintPulseGrow = 0.08f;
	constexpr float ErasePulseShrink = 0.25f;
	constexpr int32 MaxCellPulses = 256;

	/** Lift (cm) of overlay lines toward the camera so they don't z-fight surfaces on the plane. */
	constexpr double OverlayLift = 1.0;

	constexpr float OverlayXRayOpacityScale = ProWorkflowTools::OverlayStyle::XRayOpacityScale;

	/** Sane clamp for GridPaintThinAxisThreshold (also mirrored in settings meta). */
	constexpr float MinThinAxisThresholdCm = 0.01f;
	constexpr float MaxThinAxisThresholdCm = 50.0f;
	constexpr float DefaultThinAxisThresholdCm = 12.5f;

	/**
	 * Fraction of the paint-cell OBB used for Prevent Intersect (mirrored in settings meta).
	 * Lower = only deeper clips block; 1.0 = full cell box.
	 */
	constexpr float MinOverlapBoundsScale = 0.25f;
	constexpr float MaxOverlapBoundsScale = 1.0f;
	constexpr float DefaultOverlapBoundsScale = 0.85f;

	/** Overlap cache size cap. Hover and a stroke only need recent cells; the oldest drop as a batch. */
	constexpr int32 MaxCachedOverlapCells = 64;
	/** Line-fill preview overlap tests per update, from the hover end. Commit walks the full run. */
	constexpr int32 MaxLineFillPreviewOverlapTests = 32;

	inline float GetOverlapBoundsScale(const UProWorkflowToolsSettings* Settings)
	{
		const float Scale = Settings ? Settings->GridPaintOverlapBoundsScale : DefaultOverlapBoundsScale;
		return FMath::Clamp(Scale, MinOverlapBoundsScale, MaxOverlapBoundsScale);
	}

	/** Absolute thin-axis floor in cm. */
	inline float GetThinAxisThresholdCm(const UProWorkflowToolsSettings* Settings)
	{
		const float Threshold = Settings ? Settings->GridPaintThinAxisThreshold : DefaultThinAxisThresholdCm;
		return FMath::Clamp(Threshold, MinThinAxisThresholdCm, MaxThinAxisThresholdCm);
	}

	constexpr float DefaultThinAxisRelativeRatio = 0.12f;
	constexpr float MinThinAxisRelativeRatio = 0.01f;
	constexpr float MaxThinAxisRelativeRatio = 0.5f;

	/** Fraction of longest CellSize axis; combined with absolute floor via max(). */
	inline float GetThinAxisRelativeRatio(const UProWorkflowToolsSettings* Settings)
	{
		const float Ratio = Settings ? Settings->GridPaintThinAxisRelativeRatio : DefaultThinAxisRelativeRatio;
		return FMath::Clamp(Ratio, MinThinAxisRelativeRatio, MaxThinAxisRelativeRatio);
	}

	inline void ShowGridPaintNotification(const FText& Message)
	{
		FNotificationInfo Info(Message);
		Info.ExpireDuration = 2.0f;
		Info.bFireAndForget = true;
		FSlateNotificationManager::Get().AddNotification(Info);
	}

	/** Current Actor Grid Paint toggle chord (Keyboard Shortcuts). */
	inline bool IsGridPaintToggleChord(const FEditorViewportClient* ViewportClient, const FKey& Key)
	{
		return FProWorkflowToolsCommands::IsRegistered()
			&& MatchesCommandChord(ViewportClient, FProWorkflowToolsCommands::Get().ToggleGridPaint, Key);
	}

	/** The editor's Undo / Redo chords; bounds edit applies them to its draft. */
	inline bool IsUndoChord(const FEditorViewportClient* ViewportClient, const FKey& Key)
	{
		return FGenericCommands::IsRegistered() && MatchesCommandChord(ViewportClient, FGenericCommands::Get().Undo, Key);
	}

	inline bool IsRedoChord(const FEditorViewportClient* ViewportClient, const FKey& Key)
	{
		return FGenericCommands::IsRegistered() && MatchesCommandChord(ViewportClient, FGenericCommands::Get().Redo, Key);
	}
}
