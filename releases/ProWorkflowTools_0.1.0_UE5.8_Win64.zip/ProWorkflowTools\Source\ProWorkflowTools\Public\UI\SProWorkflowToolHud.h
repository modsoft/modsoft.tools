// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "UI/ProWorkflowToolHudTypes.h"
#include "Widgets/Layout/SWrapBox.h"
#include "Widgets/SCompoundWidget.h"

class SEditableTextBox;
struct FSlateBrush;

/**
 * Shared bottom-center HUD for Grid Paint, Material Clipboard, Decal Placement, and Box Scale.
 * Two compact strips: info (title / values / checks) and a darker hotkey row that wraps
 * at the viewport edges. Root is SelfHitTestInvisible so empty overlay space never blocks
 * the viewport. Panel is Visible only when hits are needed.
 *
 * A field with OnCommitText is click-to-edit: one text box at a time, Enter commits, Esc cancels,
 * and keyboard focus goes back where it was so the tool's hotkeys resume. While the box has focus
 * no key reaches the viewport (the tool's own hotkeys would otherwise fire on the typed letters).
 */
class PROWORKFLOWTOOLS_API SProWorkflowToolHud : public SCompoundWidget
{
public:
	static constexpr int32 MaxFields = 12;
	static constexpr int32 MaxKeycaps = 20;

	SLATE_BEGIN_ARGS(SProWorkflowToolHud)
		: _bPanelHitTestable(false)
	{}
		SLATE_ATTRIBUTE(FProWorkflowToolHudModel, Model)
		/** When true, bordered panel receives hits (Decal hover / interactive footer). */
		SLATE_ARGUMENT(bool, bPanelHitTestable)
		/** Optional leading widget on the info strip (e.g. Exit Group). */
		SLATE_ARGUMENT(TSharedPtr<SWidget>, Header)
		/** Optional trailing widget on the info strip (e.g. Collections). */
		SLATE_ARGUMENT(TSharedPtr<SWidget>, Footer)
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs);
	virtual void Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime) override;

	/** False while another HUD covers this one (see ProWorkflowToolHudOverlay). */
	bool IsPointerOverPanel() const;

private:
	const FProWorkflowToolHudModel& GetModel() const { return CachedModel; }
	void RefreshModel();
	bool IsFieldShown(int32 FieldIndex) const;
	FSlateColor GetFieldValueColor(int32 FieldIndex) const;
	float GetKeyStripMaxWidth() const;

	TSharedRef<SWidget> MakeInfoStrip(const TSharedPtr<SWidget>& Header, const TSharedPtr<SWidget>& Footer);
	TSharedRef<SWidget> MakeKeyStrip();
	TSharedRef<SWidget> MakeField(int32 FieldIndex);
	TSharedRef<SWidget> MakeFieldValueText(int32 FieldIndex);
	bool FieldHasMenu(int32 FieldIndex) const;
	bool FieldIsEditable(int32 FieldIndex) const;
	void BeginFieldEdit(int32 FieldIndex);
	/** Leaves edit mode; bCommit hands the text to the field, bRestoreFocus returns focus to the pre-edit widget. */
	void EndFieldEdit(bool bCommit, const FString& Text, bool bRestoreFocus);
	TSharedRef<SWidget> MakeHintChip(int32 CapIndex) const;
	TSharedRef<SWidget> MakeDivider(float HeightPx) const;
	TSharedRef<SWidget> MakeTitle() const;

	TAttribute<FProWorkflowToolHudModel> ModelAttr;
	/** Pulled from ModelAttr once per tick; every slot attribute reads this. */
	FProWorkflowToolHudModel CachedModel;
	/** Width available to the strips, in Slate units, from this widget's own geometry. */
	float AvailableWidth = 0.0f;
	/** Info strip width with every field shown, re-measured whenever nothing is collapsed. */
	float FullInfoStripWidth = 0.0f;
	bool bCollapseLowPriority = false;

	TSharedPtr<SWidget> PanelWidget;
	TSharedPtr<SWidget> InfoStripWidget;
	TArray<SWrapBox::FSlot*> KeycapSlots;
	TSharedPtr<FSlateBrush> InfoBarBrush;
	TSharedPtr<FSlateBrush> KeyBarBrush;

	TMap<FName, FString> LastFieldValues;
	TMap<FName, double> FieldFlashUntil;

	/** One text box per field slot; only the editing field's is shown. */
	TArray<TSharedPtr<SEditableTextBox>> FieldEditBoxes;
	int32 EditingFieldIndex = INDEX_NONE;
	/** Focus moves on the Tick after the box becomes visible; Slate cannot focus a collapsed widget. */
	bool bFocusEditBoxOnTick = false;
	TWeakPtr<SWidget> FocusBeforeEdit;
};
