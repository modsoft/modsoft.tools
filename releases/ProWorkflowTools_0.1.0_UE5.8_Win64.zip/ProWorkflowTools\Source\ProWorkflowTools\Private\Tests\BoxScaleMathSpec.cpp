// Copyright © 2026 Trey McNair. All rights reserved.

#include "BoxScale/BoxScaleMath.h"

#include "Misc/AutomationTest.h"

#if WITH_DEV_AUTOMATION_TESTS

namespace BoxScaleMathSpec
{
	constexpr float Tolerance = 1.0e-3f;
	constexpr double ScalarTolerance = 1.0e-3;

	FBoxScaleSite MakeSite(const int8 X, const int8 Y, const int8 Z)
	{
		FBoxScaleSite Site;
		Site.SX = X;
		Site.SY = Y;
		Site.SZ = Z;
		return Site;
	}

	/** Local point of a cage site on unscaled bounds; independent of the solve under test. */
	FVector LocalSitePoint(const FBoxScaleSite& Site, const FBox& Bounds, const FVector& Scale)
	{
		FVector Point = Bounds.GetCenter();
		const FVector Extent = Bounds.GetExtent();
		for (int32 Axis = 0; Axis < 3; ++Axis)
		{
			const double ScaleSign = Scale[Axis] < 0.0 ? -1.0 : 1.0;
			Point[Axis] += Extent[Axis] * static_cast<double>(Site.Get(Axis)) * ScaleSign;
		}
		return Point;
	}
}

DEFINE_SPEC(FBoxScaleMathSpec, "ProWorkflowTools.Math.BoxScale",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::ProductFilter)

void FBoxScaleMathSpec::Define()
{
	using namespace BoxScaleMathSpec;

	const FBox Cube(FVector(-50.0), FVector(50.0));
	// Corner pivot, non-uniform, rotated: catches any centre/pivot or axis mix-up.
	const FBox CornerBox(FVector(0.0), FVector(100.0, 40.0, 20.0));
	const FTransform Rotated(FRotator(0.0, 90.0, 0.0), FVector(100.0, 0.0, 0.0), FVector(2.0, 1.0, 1.0));

	Describe("GetSiteWorldPosition", [this, Cube]()
	{
		It("places a face site on the scaled, rotated bounds", [this, Cube]()
		{
			const FTransform Transform(FRotator(0.0, 90.0, 0.0), FVector(100.0, 0.0, 0.0), FVector(2.0));
			TestEqual(TEXT("+X face"), BoxScaleMath::GetSiteWorldPosition(MakeSite(1, 0, 0), Cube.GetCenter(), Cube.GetExtent(), Transform), FVector(100.0, 100.0, 0.0), Tolerance);
		});
	});

	Describe("MakeDragFrame", [this, Cube]()
	{
		It("rejects the invalid centre site", [this, Cube]()
		{
			FBoxScaleDragFrame Frame;
			TestFalse(TEXT("centre site"), BoxScaleMath::MakeDragFrame(FBoxScaleSite(), Cube, FTransform::Identity, 0.05f, Frame));
		});

		It("anchors the opposite face and measures the full span", [this, Cube]()
		{
			FBoxScaleDragFrame Frame;
			TestTrue(TEXT("valid"), BoxScaleMath::MakeDragFrame(MakeSite(1, 0, 0), Cube, FTransform::Identity, 0.05f, Frame));
			TestEqual(TEXT("anchor"), Frame.AnchorWorld, FVector(-50.0, 0.0, 0.0), Tolerance);
			TestEqual(TEXT("handle"), Frame.HandleStartWorld, FVector(50.0, 0.0, 0.0), Tolerance);
			TestEqual(TEXT("span"), Frame.StartSpan.X, 100.0, ScalarTolerance);
		});

		It("rejects a face whose only axis is flat, but keeps a corner", [this]()
		{
			const FBox Slab(FVector(-50.0, -50.0, -1.0), FVector(50.0, 50.0, 1.0));
			FBoxScaleDragFrame Frame;
			TestFalse(TEXT("flat face"), BoxScaleMath::MakeDragFrame(MakeSite(0, 0, 1), Slab, FTransform::Identity, 0.05f, Frame));
			TestTrue(TEXT("corner"), BoxScaleMath::MakeDragFrame(MakeSite(1, 1, 1), Slab, FTransform::Identity, 0.05f, Frame));
			TestTrue(TEXT("Z flagged flat"), Frame.bAxisFlat[2]);
		});
	});

	Describe("SolveDrag", [this, Cube, CornerBox, Rotated]()
	{
		It("moves the dragged face to the handle and keeps the anchor", [this, CornerBox, Rotated]()
		{
			for (const FBoxScaleSite Site : { MakeSite(1, 0, 0), MakeSite(-1, 1, 0), MakeSite(1, -1, 1) })
			{
				FBoxScaleDragFrame Frame;
				TestTrue(TEXT("frame"), BoxScaleMath::MakeDragFrame(Site, CornerBox, Rotated, 0.0f, Frame));

				FVector Offset = FVector::ZeroVector;
				for (int32 Axis = 0; Axis < 3; ++Axis)
				{
					Offset += Frame.AxisWorld[Axis] * (static_cast<double>(Site.Get(Axis)) * 30.0);
				}
				const FVector Handle = Frame.HandleStartWorld + Offset;
				const FBoxScaleSolve Solve = BoxScaleMath::SolveDrag(Frame, Handle, false, false, 0.0);
				const FTransform Result(Frame.Rotation, Solve.Location, Solve.Scale);

				TestEqual(TEXT("dragged site follows the handle"), Result.TransformPosition(LocalSitePoint(Site, CornerBox, Solve.Scale)), Handle, Tolerance);
				TestEqual(TEXT("anchor fixed"), Result.TransformPosition(LocalSitePoint(Site.Opposite(), CornerBox, Solve.Scale)), Frame.AnchorWorld, Tolerance);
			}
		});

		It("leaves axes the site does not move untouched", [this, Cube]()
		{
			FBoxScaleDragFrame Frame;
			BoxScaleMath::MakeDragFrame(MakeSite(1, 0, 0), Cube, FTransform::Identity, 0.05f, Frame);
			const FBoxScaleSolve Solve = BoxScaleMath::SolveDrag(Frame, FVector(150.0, 999.0, -999.0), false, false, 0.0);
			TestEqual(TEXT("scale"), Solve.Scale, FVector(2.0, 1.0, 1.0), Tolerance);
			TestEqual(TEXT("location"), Solve.Location, FVector(50.0, 0.0, 0.0), Tolerance);
		});

		It("keeps the centre fixed in centre mode", [this, CornerBox, Rotated]()
		{
			FBoxScaleDragFrame Frame;
			BoxScaleMath::MakeDragFrame(MakeSite(1, 0, 0), CornerBox, Rotated, 0.0f, Frame);
			const FVector Handle = Frame.HandleStartWorld + Frame.AxisWorld[0] * 100.0;
			const FBoxScaleSolve Solve = BoxScaleMath::SolveDrag(Frame, Handle, true, false, 0.0);
			const FTransform Result(Frame.Rotation, Solve.Location, Solve.Scale);

			// Half-span 100 -> 200, full span 200 -> 400.
			TestEqual(TEXT("scale X"), Solve.Scale.X, 4.0, ScalarTolerance);
			TestEqual(TEXT("centre fixed"), Result.TransformPosition(CornerBox.GetCenter()), Frame.CenterWorld, Tolerance);
		});

		It("flips to negative scale when dragged past the anchor", [this, Cube]()
		{
			FBoxScaleDragFrame Frame;
			BoxScaleMath::MakeDragFrame(MakeSite(1, 0, 0), Cube, FTransform::Identity, 0.05f, Frame);
			const FBoxScaleSolve Solve = BoxScaleMath::SolveDrag(Frame, FVector(-150.0, 0.0, 0.0), false, false, 0.0);
			TestEqual(TEXT("scale X"), Solve.Scale.X, -1.0, ScalarTolerance);
			const FTransform Result(Frame.Rotation, Solve.Location, Solve.Scale);
			TestEqual(TEXT("anchor fixed"), Result.TransformPosition(FVector(-50.0, 0.0, 0.0)), Frame.AnchorWorld, Tolerance);
		});

		It("clamps the span at MinDragSpan", [this, Cube]()
		{
			FBoxScaleDragFrame Frame;
			BoxScaleMath::MakeDragFrame(MakeSite(1, 0, 0), Cube, FTransform::Identity, 0.05f, Frame);
			const FBoxScaleSolve Solve = BoxScaleMath::SolveDrag(Frame, Frame.AnchorWorld, false, false, 0.0);
			TestEqual(TEXT("scale X"), Solve.Scale.X, BoxScaleMath::MinDragSpan / 100.0, ScalarTolerance);
		});

		It("snaps free-axis scale to the step, never to zero", [this, Cube]()
		{
			FBoxScaleDragFrame Frame;
			BoxScaleMath::MakeDragFrame(MakeSite(1, 1, 1), Cube, FTransform::Identity, 0.05f, Frame);
			const FBoxScaleSolve Snapped = BoxScaleMath::SolveDrag(Frame, FVector(80.0), false, false, 0.25);
			TestEqual(TEXT("1.3 -> 1.25"), Snapped.Scale, FVector(1.25), Tolerance);

			const FBoxScaleSolve Tiny = BoxScaleMath::SolveDrag(Frame, FVector(-45.0), false, false, 0.25);
			TestEqual(TEXT("0.05 -> step"), Tiny.Scale, FVector(0.25), Tolerance);
		});

		It("keeps a flat axis at its start scale", [this]()
		{
			const FBox Slab(FVector(-50.0, -50.0, -1.0), FVector(50.0, 50.0, 1.0));
			FBoxScaleDragFrame Frame;
			BoxScaleMath::MakeDragFrame(MakeSite(1, 1, 1), Slab, FTransform::Identity, 0.05f, Frame);
			const FBoxScaleSolve Solve = BoxScaleMath::SolveDrag(Frame, FVector(150.0, 150.0, 500.0), false, false, 0.0);
			TestEqual(TEXT("Z scale"), Solve.Scale.Z, 1.0, ScalarTolerance);
		});

		It("uniform: scales every axis by one factor about the opposite corner", [this, CornerBox, Rotated]()
		{
			const FBoxScaleSite Site = MakeSite(1, -1, 1);
			FBoxScaleDragFrame Frame;
			BoxScaleMath::MakeDragFrame(Site, CornerBox, Rotated, 0.0f, Frame);
			const FVector Diagonal = Frame.HandleStartWorld - Frame.AnchorWorld;
			// Off-diagonal travel is ignored: only the projection onto the diagonal counts.
			const FVector Sideways = FVector::CrossProduct(Diagonal, FVector::UpVector).GetSafeNormal() * 40.0;
			const FVector Handle = Frame.HandleStartWorld + Diagonal * 0.5 + Sideways;
			const FBoxScaleSolve Solve = BoxScaleMath::SolveDrag(Frame, Handle, false, true, 0.0);
			const FTransform Result(Frame.Rotation, Solve.Location, Solve.Scale);

			TestEqual(TEXT("scale"), Solve.Scale, Rotated.GetScale3D() * 1.5, Tolerance);
			TestEqual(TEXT("anchor fixed"), Result.TransformPosition(LocalSitePoint(Site.Opposite(), CornerBox, Solve.Scale)), Frame.AnchorWorld, Tolerance);
			TestEqual(TEXT("corner on the diagonal"), Result.TransformPosition(LocalSitePoint(Site, CornerBox, Solve.Scale)), Frame.HandleStartWorld + Diagonal * 0.5, Tolerance);
		});

		It("uniform: a face drag scales the other axes too", [this, Cube]()
		{
			FBoxScaleDragFrame Frame;
			BoxScaleMath::MakeDragFrame(MakeSite(1, 0, 0), Cube, FTransform::Identity, 0.05f, Frame);
			const FBoxScaleSolve Solve = BoxScaleMath::SolveDrag(Frame, FVector(150.0, 0.0, 0.0), false, true, 0.0);
			TestEqual(TEXT("scale"), Solve.Scale, FVector(2.0), Tolerance);
			TestEqual(TEXT("location"), Solve.Location, FVector(50.0, 0.0, 0.0), Tolerance);
		});

		It("uniform + centre: keeps the centre fixed", [this, CornerBox, Rotated]()
		{
			FBoxScaleDragFrame Frame;
			BoxScaleMath::MakeDragFrame(MakeSite(1, 1, 1), CornerBox, Rotated, 0.0f, Frame);
			const FVector Handle = Frame.CenterWorld + (Frame.HandleStartWorld - Frame.CenterWorld) * 2.0;
			const FBoxScaleSolve Solve = BoxScaleMath::SolveDrag(Frame, Handle, true, true, 0.0);
			const FTransform Result(Frame.Rotation, Solve.Location, Solve.Scale);

			TestEqual(TEXT("scale"), Solve.Scale, Rotated.GetScale3D() * 2.0, Tolerance);
			TestEqual(TEXT("centre fixed"), Result.TransformPosition(CornerBox.GetCenter()), Frame.CenterWorld, Tolerance);
		});

		It("uniform: snaps the factor and never flips", [this, Cube]()
		{
			FBoxScaleDragFrame Frame;
			BoxScaleMath::MakeDragFrame(MakeSite(1, 1, 1), Cube, FTransform::Identity, 0.05f, Frame);
			const FBoxScaleSolve Snapped = BoxScaleMath::SolveDrag(Frame, FVector(80.0), false, true, 0.25);
			TestEqual(TEXT("1.3 -> 1.25"), Snapped.Scale, FVector(1.25), Tolerance);

			const FBoxScaleSolve Past = BoxScaleMath::SolveDrag(Frame, FVector(-150.0), false, true, 0.0);
			TestTrue(TEXT("positive"), Past.Scale.X > 0.0 && Past.Scale.Y > 0.0 && Past.Scale.Z > 0.0);
		});
	});

	Describe("ShouldDrawSite", [this]()
	{
		It("hides sites on a flat axis and honours the per-kind toggles", [this]()
		{
			const FVector SlabExtent(50.0, 50.0, 1.0);
			TestFalse(TEXT("flat face"), BoxScaleMath::ShouldDrawSite(MakeSite(0, 0, 1), SlabExtent, true, true, true, 0.05f));
			TestTrue(TEXT("rectangle corner on the mid layer"), BoxScaleMath::ShouldDrawSite(MakeSite(1, 1, 0), SlabExtent, true, true, true, 0.05f));
			TestFalse(TEXT("edges off"), BoxScaleMath::ShouldDrawSite(MakeSite(1, 1, 0), SlabExtent, true, false, true, 0.05f));
		});
	});
}

#endif
