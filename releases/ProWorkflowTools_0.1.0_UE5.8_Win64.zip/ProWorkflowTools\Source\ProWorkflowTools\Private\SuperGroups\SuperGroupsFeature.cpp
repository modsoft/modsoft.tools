// Copyright © 2026 Trey McNair. All rights reserved.

#include "SuperGroups/SuperGroupsFeature.h"

#include "SuperGroups/SuperGroupSubsystem.h"
#include "SuperGroups/SuperGroups.h"
#include "SuperGroups/SuperGroupsCommands.h"
#include "ProWorkflowToolsSettings.h"

#include "ActorGroupingUtils.h"
#include "Containers/BitArray.h"
#include "CanvasItem.h"
#include "CanvasTypes.h"
#include "Debug/DebugDrawService.h"
#include "Editor.h"
#include "Editor/GroupActor.h"
#include "Editor/UnrealEdEngine.h"
#include "UnrealEdGlobals.h"
#include "EditorModeManager.h"
#include "Engine/Canvas.h"
#include "Engine/Selection.h"
#include "Engine/Texture2D.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "LevelEditor.h"
#include "LevelEditorActions.h"
#include "ObjectTools.h"
#include "SceneInterface.h"
#include "SceneView.h"
#include "ScopedTransaction.h"
#include "ShowFlags.h"
#include "Styling/AppStyle.h"
#include "TextureResource.h"
#include "ToolMenus.h"
#include "Modules/ModuleManager.h"
#include "UI/SProWorkflowToolHud.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Text/STextBlock.h"

#define LOCTEXT_NAMESPACE "SuperGroupsModule"

DEFINE_LOG_CATEGORY(LogSuperGroups);

namespace SuperGroupsModuleHelpers
{
	/** Custom editor show flag: Show > Advanced > Group Pivot Icons (toggle with other viewport show flags). */
	const TCHAR* GroupPivotShowFlagName = TEXT("SuperGroupPivots");

	/** AGroupActor::GetParentForActor reads this field; it is not exported from UnrealEd. */
	static AGroupActor* GetParentGroup(const AActor* Actor)
	{
		return Actor ? Cast<AGroupActor>(Actor->GroupActor) : nullptr;
	}

	static void CollectGroupsForActor(AActor* Actor, TSet<AGroupActor*>& OutGroups)
	{
		if (!Actor)
		{
			return;
		}

		if (AGroupActor* AsGroup = Cast<AGroupActor>(Actor))
		{
			OutGroups.Add(AsGroup);
		}

		AGroupActor* Group = GetParentGroup(Actor);
		while (Group)
		{
			OutGroups.Add(Group);
			Group = GetParentGroup(Group);
		}
	}

	static void GatherLeafLocations(AGroupActor& Group, TArray<FVector>& OutLeaves)
	{
		OutLeaves.Reset();
		TArray<AActor*> Children;
		Group.GetAllChildren(Children, /*bRecurse=*/true);
		for (AActor* Child : Children)
		{
			if (Child && !Child->IsA<AGroupActor>())
			{
				OutLeaves.Add(Child->GetActorLocation());
			}
		}
	}

	static int32 CountDirectMembers(const AGroupActor& Group)
	{
		TArray<AActor*> Members;
		Group.GetGroupActors(Members, /*bRecurse=*/false);
		return Members.Num();
	}

	static FVector AverageLocation(const TArray<FVector>& Locations)
	{
		FVector Sum = FVector::ZeroVector;
		for (const FVector& Location : Locations)
		{
			Sum += Location;
		}
		return Locations.Num() > 0 ? Sum / static_cast<double>(Locations.Num()) : FVector::ZeroVector;
	}

	static bool LeafSetsMatch(const TArray<FVector>& NewLeaves, const TArray<FVector>& SourceLeaves, const FVector& Delta, const float Tolerance)
	{
		if (NewLeaves.Num() == 0 || NewLeaves.Num() != SourceLeaves.Num())
		{
			return false;
		}

		TBitArray<> Used(false, SourceLeaves.Num());
		for (const FVector& NewLoc : NewLeaves)
		{
			bool bFound = false;
			for (int32 Index = 0; Index < SourceLeaves.Num(); ++Index)
			{
				if (!Used[Index] && NewLoc.Equals(SourceLeaves[Index] + Delta, Tolerance))
				{
					Used[Index] = true;
					bFound = true;
					break;
				}
			}
			if (!bFound)
			{
				return false;
			}
		}
		return true;
	}

	/** Same billboard texture Empty Actors use in the editor viewport. */
	const TCHAR* GroupPivotSpritePath = TEXT("/Engine/EditorResources/EmptyActor");

	static FName MakeUniqueGroupFolderPath(UWorld* World, AActor* PivotActor)
	{
		FString AssetName = PivotActor ? PivotActor->GetActorLabel() : TEXT("Selection");
		AssetName = ObjectTools::SanitizeObjectName(AssetName);

		TSet<FName> UsedFolderPaths;
		if (World)
		{
			for (TActorIterator<AActor> It(World); It; ++It)
			{
				if (AActor* Actor = *It; Actor->IsListedInSceneOutliner() && !Actor->GetFolderPath().IsNone())
				{
					UsedFolderPaths.Add(Actor->GetFolderPath());
				}
			}
		}

		for (int32 Suffix = 1; Suffix < 1000; ++Suffix)
		{
			const FName Candidate(*FString::Printf(TEXT("Group_%s_%02d"), *AssetName, Suffix));
			if (!UsedFolderPaths.Contains(Candidate))
			{
				return Candidate;
			}
		}

		return FName(*FString::Printf(TEXT("Group_%s_%02d"), *AssetName, FMath::RandRange(1, 99)));
	}
	static USuperGroupSubsystem* GetEditorSubsystem()
	{
		if (GEditor)
		{
			if (UWorld* World = GEditor->GetEditorWorldContext().World())
			{
				return World->GetSubsystem<USuperGroupSubsystem>();
			}
		}
		return nullptr;
	}

	/** Saves the setting; OnSettingChanged applies it (FSuperGroupsFeature::OnSettingsChanged). */
	static void PersistBoolSetting(bool UProWorkflowToolsSettings::* Member, const bool bValue)
	{
		UProWorkflowToolsSettings* Settings = GetMutableDefault<UProWorkflowToolsSettings>();
		if (Settings->*Member == bValue)
		{
			return;
		}

		Settings->*Member = bValue;
		Settings->NotifyAndPersist();
	}

	/**
	 * Resolves the group to enter from the current selection. A directly selected group actor wins;
	 * otherwise we walk up from any selected member. When a locked group's member is clicked, Unreal
	 * selects the members but not the group actor itself, so this lets Enter still work in that case.
	 */
	static AGroupActor* ResolveSelectedGroup()
	{
		if (!GEditor)
		{
			return nullptr;
		}

		for (FSelectionIterator It(GEditor->GetSelectedActorIterator()); It; ++It)
		{
			if (AGroupActor* Group = Cast<AGroupActor>(*It))
			{
				return Group;
			}
		}

		for (FSelectionIterator It(GEditor->GetSelectedActorIterator()); It; ++It)
		{
			if (AActor* Actor = Cast<AActor>(*It))
			{
				if (AGroupActor* Root = AGroupActor::GetRootForActor(Actor))
				{
					return Root;
				}
			}
		}

		return nullptr;
	}

	/** Converts a world-space extent at Location into canvas pixels (must use UCanvas::Project, not raw SceneView::Project). */
	static float WorldSizeToScreenPixels(const UCanvas* Canvas, const FVector& WorldLocation, float WorldSize)
	{
		if (!Canvas || !Canvas->SceneView)
		{
			return WorldSize;
		}

		const FVector WorldOffset = WorldLocation + Canvas->SceneView->GetViewRight() * WorldSize;
		const FVector ScreenCenter = Canvas->Project(WorldLocation);
		const FVector ScreenOffset = Canvas->Project(WorldOffset);
		return FVector2D::Distance(FVector2D(ScreenCenter), FVector2D(ScreenOffset));
	}
}

void FSuperGroupsFeature::Startup()
{
	FSuperGroupsCommands::Register();

	UToolMenus::RegisterStartupCallback(FSimpleMulticastDelegate::FDelegate::CreateRaw(this, &FSuperGroupsFeature::RegisterMenus));

	// Only take over the group commands when the feature is enabled; toggling the setting
	// at runtime installs/removes the overrides without an editor restart.
	ApplyEnabledState();
	SettingsChangedHandle = GetMutableDefault<UProWorkflowToolsSettings>()->OnSettingChanged().AddRaw(
		this, &FSuperGroupsFeature::OnSettingsChanged);
	EditingChangedHandle = USuperGroupSubsystem::OnEditingChanged().AddRaw(this, &FSuperGroupsFeature::OnEditingChanged);
	DuplicateBeginHandle = FEditorDelegates::OnDuplicateActorsBegin.AddRaw(this, &FSuperGroupsFeature::OnDuplicateActorsBegin);
	DuplicateEndHandle = FEditorDelegates::OnDuplicateActorsEnd.AddRaw(this, &FSuperGroupsFeature::OnDuplicateActorsEnd);

	// Show > Advanced > Group Pivot Icons — on in the editor by default; DrawGroupIcons also
	// early-outs when EngineShowFlags.Game is set (Game View / G).
	FEngineShowFlags::RegisterCustomShowFlag(
		SuperGroupsModuleHelpers::GroupPivotShowFlagName,
		/*DefaultEnabled=*/true,
		SFG_Advanced,
		LOCTEXT("SuperGroupPivotsShowFlag", "Group Pivot Icons"));

	DebugDrawHandle = UDebugDrawService::Register(
		SuperGroupsModuleHelpers::GroupPivotShowFlagName,
		FDebugDrawDelegate::CreateRaw(this, &FSuperGroupsFeature::DrawGroupIcons));
}

void FSuperGroupsFeature::Shutdown()
{
	if (USuperGroupSubsystem* Subsystem = SuperGroupsModuleHelpers::GetEditorSubsystem())
	{
		Subsystem->ExitEdit();
	}

	USuperGroupSubsystem::OnEditingChanged().Remove(EditingChangedHandle);
	FEditorDelegates::OnDuplicateActorsBegin.Remove(DuplicateBeginHandle);
	FEditorDelegates::OnDuplicateActorsEnd.Remove(DuplicateEndHandle);
	PendingDuplicateGroupPivots.Reset();
	EditHud.Hide();

	if (UObjectInitialized())
	{
		if (UProWorkflowToolsSettings* Settings = GetMutableDefault<UProWorkflowToolsSettings>())
		{
			Settings->OnSettingChanged().Remove(SettingsChangedHandle);
		}
	}

	if (DebugDrawHandle.IsValid())
	{
		UDebugDrawService::Unregister(DebugDrawHandle);
		DebugDrawHandle.Reset();
	}

	RestoreGroupCommands();

	UToolMenus::UnRegisterStartupCallback(this);

	// Guard against engine/UObject teardown order: the ToolMenus singleton may already be gone on exit.
	if (UObjectInitialized() && !IsEngineExitRequested())
	{
		UnregisterMenus();
		UToolMenus::UnregisterOwner(this);
	}

	FSuperGroupsCommands::Unregister();
}

void FSuperGroupsFeature::ApplyEnabledState()
{
	const bool bEnabled = GetDefault<UProWorkflowToolsSettings>()->bEnableSuperGroups;
	if (bEnabled && !bCommandsOverridden)
	{
		OverrideGroupCommands();
	}
	else if (!bEnabled && bCommandsOverridden)
	{
		if (USuperGroupSubsystem* Subsystem = SuperGroupsModuleHelpers::GetEditorSubsystem())
		{
			Subsystem->ExitEdit();
		}
		RestoreGroupCommands();
	}
}

void FSuperGroupsFeature::OnSettingsChanged(UObject* Settings, FPropertyChangedEvent& PropertyChangedEvent)
{
	ApplyEnabledState();

	if (USuperGroupSubsystem* Subsystem = SuperGroupsModuleHelpers::GetEditorSubsystem())
	{
		Subsystem->RefreshEditingVisuals();
	}

	if (GEditor)
	{
		GEditor->RedrawLevelEditingViewports();
	}
}

void FSuperGroupsFeature::OverrideGroupCommands()
{
	FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>("LevelEditor");
	const TSharedRef<FUICommandList>& CommandList = LevelEditorModule.GetGlobalLevelEditorActions();
	const FSuperGroupsCommands& Commands = FSuperGroupsCommands::Get();

	CommandList->MapAction(
		Commands.EnterGroup,
		FExecuteAction::CreateRaw(this, &FSuperGroupsFeature::OnEnterGroup),
		FCanExecuteAction::CreateRaw(this, &FSuperGroupsFeature::CanEnterSelectedGroup));

	CommandList->MapAction(
		Commands.ExitGroup,
		FExecuteAction::CreateRaw(this, &FSuperGroupsFeature::OnExitGroup),
		FCanExecuteAction::CreateRaw(this, &FSuperGroupsFeature::CanExitGroup));

	// Take over stock Group / Regroup (RMB Group + Ctrl+G) so create uses Super Groups pivot/folder options.
	// When those options are off, OnCreateGroup still ends in native GroupSelected().
	CommandList->UnmapAction(FLevelEditorCommands::Get().RegroupActors);
	CommandList->MapAction(
		FLevelEditorCommands::Get().RegroupActors,
		FExecuteAction::CreateRaw(this, &FSuperGroupsFeature::OnCreateGroup),
		FCanExecuteAction::CreateRaw(this, &FSuperGroupsFeature::CanCreateGroup));

	CommandList->UnmapAction(FLevelEditorCommands::Get().GroupActors);
	CommandList->MapAction(
		FLevelEditorCommands::Get().GroupActors,
		FExecuteAction::CreateRaw(this, &FSuperGroupsFeature::OnCreateGroup),
		FCanExecuteAction::CreateRaw(this, &FSuperGroupsFeature::CanCreateGroup));

	bCommandsOverridden = true;
}

void FSuperGroupsFeature::RestoreGroupCommands()
{
	if (!bCommandsOverridden || !FModuleManager::Get().IsModuleLoaded("LevelEditor"))
	{
		return;
	}

	FLevelEditorModule& LevelEditorModule = FModuleManager::GetModuleChecked<FLevelEditorModule>("LevelEditor");
	const TSharedRef<FUICommandList>& CommandList = LevelEditorModule.GetGlobalLevelEditorActions();

	CommandList->UnmapAction(FSuperGroupsCommands::Get().EnterGroup);
	CommandList->UnmapAction(FSuperGroupsCommands::Get().ExitGroup);

	// Restore native Group / Regroup. Stock leaves GroupActors unmapped; RegroupActors is Ctrl+G.
	CommandList->UnmapAction(FLevelEditorCommands::Get().GroupActors);

	CommandList->UnmapAction(FLevelEditorCommands::Get().RegroupActors);
	CommandList->MapAction(
		FLevelEditorCommands::Get().RegroupActors,
		FExecuteAction::CreateStatic(&FLevelEditorActionCallbacks::RegroupActor_Clicked),
		FCanExecuteAction::CreateStatic(&FLevelEditorActionCallbacks::GroupActors_CanExecute));

	bCommandsOverridden = false;
}

void FSuperGroupsFeature::RegisterMenus()
{
	FToolMenuOwnerScoped OwnerScoped(this);

	UToolMenu* ActorContextMenu = UToolMenus::Get()->ExtendMenu("LevelEditor.ActorContextMenu");
	FToolMenuSection& Section = ActorContextMenu->FindOrAddSection("SuperGroups");
	Section.Label = LOCTEXT("SuperGroupsSection", "Super Groups");

	const auto IsFeatureEnabled = [](const FToolMenuContext&) { return GetDefault<UProWorkflowToolsSettings>()->bEnableSuperGroups; };

	FToolUIAction EnterAction;
	EnterAction.ExecuteAction.BindLambda([this](const FToolMenuContext&) { OnEnterGroup(); });
	EnterAction.CanExecuteAction.BindLambda([this](const FToolMenuContext&) { return CanEnterSelectedGroup(); });
	EnterAction.IsActionVisibleDelegate.BindLambda(IsFeatureEnabled);

	Section.AddMenuEntry(
		"SuperGroups_EnterGroup",
		LOCTEXT("EnterGroup", "Enter Group"),
		LOCTEXT("EnterGroupTooltip", "Unlock the selected group and edit its members (Enter)."),
		FSlateIcon(),
		EnterAction);

	FToolUIAction ExitAction;
	ExitAction.ExecuteAction.BindLambda([this](const FToolMenuContext&) { OnExitGroup(); });
	ExitAction.CanExecuteAction.BindLambda([this](const FToolMenuContext&) { return CanExitGroup(); });
	ExitAction.IsActionVisibleDelegate.BindLambda(IsFeatureEnabled);

	Section.AddMenuEntry(
		"SuperGroups_ExitGroup",
		LOCTEXT("ExitGroup", "Exit Group"),
		LOCTEXT("ExitGroupTooltip", "Leave group editing and lock the group again (Shift+Enter)."),
		FSlateIcon(),
		ExitAction);
}

void FSuperGroupsFeature::UnregisterMenus()
{
	if (UToolMenus* ToolMenus = UToolMenus::TryGet())
	{
		ToolMenus->RemoveSection("LevelEditor.ActorContextMenu", "SuperGroups");
	}
}

void FSuperGroupsFeature::OnEnterGroup()
{
	if (!GEditor)
	{
		return;
	}

	USuperGroupSubsystem* Subsystem = SuperGroupsModuleHelpers::GetEditorSubsystem();
	if (!Subsystem)
	{
		return;
	}

	if (AGroupActor* Group = SuperGroupsModuleHelpers::ResolveSelectedGroup())
	{
		Subsystem->EnterEdit(Group);
	}
}

bool FSuperGroupsFeature::CanEnterSelectedGroup() const
{
	return GetDefault<UProWorkflowToolsSettings>()->bEnableSuperGroups
		&& SuperGroupsModuleHelpers::ResolveSelectedGroup() != nullptr;
}

void FSuperGroupsFeature::OnExitGroup()
{
	if (USuperGroupSubsystem* Subsystem = SuperGroupsModuleHelpers::GetEditorSubsystem())
	{
		Subsystem->ExitEdit();
	}
}

bool FSuperGroupsFeature::CanExitGroup() const
{
	if (!GetDefault<UProWorkflowToolsSettings>()->bEnableSuperGroups)
	{
		return false;
	}

	const USuperGroupSubsystem* Subsystem = SuperGroupsModuleHelpers::GetEditorSubsystem();
	return Subsystem && Subsystem->IsEditing();
}

void FSuperGroupsFeature::OnEditingChanged(const bool bEditing)
{
	if (!bEditing)
	{
		EditHud.Hide();
		return;
	}

	EditHud.Show([this]()
	{
		return SNew(SProWorkflowToolHud)
			.Model_Raw(this, &FSuperGroupsFeature::BuildEditHudModel)
			.bPanelHitTestable(true)
			.Header(MakeExitGroupButton());
	});
}

FProWorkflowToolHudModel FSuperGroupsFeature::BuildEditHudModel() const
{
	const UProWorkflowToolsSettings* Settings = GetDefault<UProWorkflowToolsSettings>();
	const USuperGroupSubsystem* Subsystem = SuperGroupsModuleHelpers::GetEditorSubsystem();
	const AGroupActor* Group = Subsystem ? Subsystem->GetEditingGroup() : nullptr;

	FProWorkflowToolHudModel Model;
	Model.Title = Group ? FText::FromString(Group->GetActorLabel()) : FText::GetEmpty();
	Model.Fields.Add(MakeHudCheckField(
		TEXT("Visualize"),
		LOCTEXT("EditHudVisualize", "Visualize Editing"),
		Settings->bUseLevelInstanceEditingVisuals,
		[](const bool bChecked)
		{
			SuperGroupsModuleHelpers::PersistBoolSetting(&UProWorkflowToolsSettings::bUseLevelInstanceEditingVisuals, bChecked);
		}));
	Model.Fields.Add(MakeHudCheckField(
		TEXT("Restrict"),
		LOCTEXT("EditHudRestrict", "Restrict Selection"),
		Settings->bRestrictSelectionWhileEditing,
		[](const bool bChecked)
		{
			SuperGroupsModuleHelpers::PersistBoolSetting(&UProWorkflowToolsSettings::bRestrictSelectionWhileEditing, bChecked);
		}));
	return Model;
}

TSharedRef<SWidget> FSuperGroupsFeature::MakeExitGroupButton()
{
	FSlateFontInfo Font = FAppStyle::GetFontStyle("SmallText");
	Font.TypefaceFontName = TEXT("Bold");

	return SNew(SButton)
		.ButtonStyle(&FAppStyle::Get().GetWidgetStyle<FButtonStyle>("PrimaryButton"))
		.ContentPadding(FMargin(10.0f, 2.0f))
		.ToolTipText_Lambda([]()
		{
			return FText::Format(
				LOCTEXT("EditHudExitTooltip", "Leave group editing and lock the group again ({0})."),
				FSuperGroupsCommands::Get().ExitGroup->GetInputText());
		})
		.OnClicked_Lambda([this]()
		{
			OnExitGroup();
			return FReply::Handled();
		})
		[
			SNew(STextBlock)
			.Font(Font)
			.Text(LOCTEXT("EditHudExit", "Exit Group"))
		];
}

void FSuperGroupsFeature::OnCreateGroup()
{
	if (!GEditor)
	{
		return;
	}

	const bool bUsePivot = GetDefault<UProWorkflowToolsSettings>()->bUseLastSelectedActorAsPivot;

	// Selection order is preserved, so the last non-group actor in the iterator is the most recently selected.
	AActor* LastSelectedActor = nullptr;
	for (FSelectionIterator It(GEditor->GetSelectedActorIterator()); It; ++It)
	{
		if (AActor* Actor = Cast<AActor>(*It))
		{
			if (!Actor->IsA<AGroupActor>())
			{
				LastSelectedActor = Actor;
			}
		}
	}

	const bool bApplyPivot = bUsePivot && LastSelectedActor != nullptr;
	const FVector PivotLocation = bApplyPivot ? LastSelectedActor->GetActorLocation() : FVector::ZeroVector;

	// Wrap the native grouping and the pivot adjustment in a single transaction so one undo reverts both.
	const FScopedTransaction Transaction(LOCTEXT("CreateGroupTransaction", "Create Group"));

	AGroupActor* NewGroup = UActorGroupingUtils::Get()->GroupSelected();
	if (NewGroup)
	{
		if (bApplyPivot)
		{
			NewGroup->Modify();
			// SetActorLocation on a group only repositions its pivot; it does not move the child actors.
			NewGroup->SetActorLocation(PivotLocation, false);
		}

		if (GetDefault<UProWorkflowToolsSettings>()->bNestGroupInFolderOnCreate)
		{
			NestGroupInFolder(NewGroup, LastSelectedActor);
		}

		// Refresh locked-group selection and move the transform gizmo to the (possibly adjusted) group pivot.
		GEditor->SelectGroup(NewGroup, /*bForceSelection=*/false, /*bInSelected=*/true, /*bNotify=*/false);
		GEditor->NoteSelectionChange();
		GLevelEditorModeTools().SetPivotLocation(NewGroup->GetActorLocation(), /*bSnapToGrid=*/false);
	}

	// Grouping churns the selection/mode state and can drop the editor into "No Active Mode"
	// (hiding the gizmo). Re-assert the default Selection mode, mirroring enter/exit.
	if (USuperGroupSubsystem* Subsystem = SuperGroupsModuleHelpers::GetEditorSubsystem())
	{
		Subsystem->RestoreSelectionModeSoon();
	}
}

bool FSuperGroupsFeature::CanCreateGroup() const
{
	return UActorGroupingUtils::Get()->CanGroupSelectedActors();
}

void FSuperGroupsFeature::OnDuplicateActorsBegin()
{
	PendingDuplicateGroupPivots.Reset();
	if (!GetDefault<UProWorkflowToolsSettings>()->bEnableSuperGroups || !GEditor)
	{
		return;
	}

	TSet<AGroupActor*> Groups;
	for (FSelectionIterator It(GEditor->GetSelectedActorIterator()); It; ++It)
	{
		SuperGroupsModuleHelpers::CollectGroupsForActor(Cast<AActor>(*It), Groups);
	}

	for (AGroupActor* Group : Groups)
	{
		FDuplicatedGroupPivot Record;
		Record.SourceGroup = Group;
		Record.Pivot = Group->GetActorTransform();
		Record.DirectMemberCount = SuperGroupsModuleHelpers::CountDirectMembers(*Group);
		SuperGroupsModuleHelpers::GatherLeafLocations(*Group, Record.LeafLocations);
		if (Record.LeafLocations.Num() > 0)
		{
			PendingDuplicateGroupPivots.Add(MoveTemp(Record));
		}
	}
}

void FSuperGroupsFeature::OnDuplicateActorsEnd()
{
	if (PendingDuplicateGroupPivots.IsEmpty() || !GEditor)
	{
		PendingDuplicateGroupPivots.Reset();
		return;
	}

	UWorld* World = GEditor->GetEditorWorldContext().World();
	if (!World)
	{
		PendingDuplicateGroupPivots.Reset();
		return;
	}

	TSet<AGroupActor*> SourceGroups;
	for (const FDuplicatedGroupPivot& Record : PendingDuplicateGroupPivots)
	{
		if (AGroupActor* Source = Record.SourceGroup.Get())
		{
			SourceGroups.Add(Source);
		}
	}

	TArray<AGroupActor*> NewGroups;
	for (const TObjectPtr<AActor>& ActiveActor : World->ActiveGroupActors)
	{
		AGroupActor* Group = Cast<AGroupActor>(ActiveActor);
		if (Group && !SourceGroups.Contains(Group))
		{
			NewGroups.Add(Group);
		}
	}

	NewGroups.Sort([](const AGroupActor& A, const AGroupActor& B)
	{
		return SuperGroupsModuleHelpers::CountDirectMembers(A)
			< SuperGroupsModuleHelpers::CountDirectMembers(B);
	});

	TBitArray<> UsedSnapshots(false, PendingDuplicateGroupPivots.Num());
	bool bRestored = false;
	for (AGroupActor* NewGroup : NewGroups)
	{
		TArray<FVector> NewLeaves;
		SuperGroupsModuleHelpers::GatherLeafLocations(*NewGroup, NewLeaves);
		if (NewLeaves.Num() == 0)
		{
			continue;
		}

		const FVector NewCentroid = SuperGroupsModuleHelpers::AverageLocation(NewLeaves);
		int32 BestIndex = INDEX_NONE;
		for (int32 Index = 0; Index < PendingDuplicateGroupPivots.Num(); ++Index)
		{
			if (UsedSnapshots[Index])
			{
				continue;
			}

			const FDuplicatedGroupPivot& Record = PendingDuplicateGroupPivots[Index];
			if (Record.DirectMemberCount != SuperGroupsModuleHelpers::CountDirectMembers(*NewGroup)
				|| Record.LeafLocations.Num() != NewLeaves.Num())
			{
				continue;
			}

			const FVector Delta = NewCentroid - SuperGroupsModuleHelpers::AverageLocation(Record.LeafLocations);
			if (SuperGroupsModuleHelpers::LeafSetsMatch(NewLeaves, Record.LeafLocations, Delta, 1.0f))
			{
				BestIndex = Index;
				break;
			}
		}

		if (BestIndex == INDEX_NONE)
		{
			continue;
		}

		UsedSnapshots[BestIndex] = true;
		const FDuplicatedGroupPivot& Record = PendingDuplicateGroupPivots[BestIndex];
		const FVector Delta = NewCentroid - SuperGroupsModuleHelpers::AverageLocation(Record.LeafLocations);

		NewGroup->Modify();
		NewGroup->SetActorLocation(Record.Pivot.GetLocation() + Delta, false);
		NewGroup->SetActorRotation(Record.Pivot.GetRotation());
		bRestored = true;
	}

	PendingDuplicateGroupPivots.Reset();

	if (bRestored)
	{
		if (GUnrealEd)
		{
			GUnrealEd->UpdatePivotLocationForSelection();
		}
		GEditor->RedrawLevelEditingViewports();
	}
}

void FSuperGroupsFeature::NestGroupInFolder(AGroupActor* Group, AActor* PivotActor) const
{
	if (!Group)
	{
		return;
	}

	UWorld* World = Group->GetWorld();
	const FName FolderPath = SuperGroupsModuleHelpers::MakeUniqueGroupFolderPath(World, PivotActor);

	Group->SetFolderPath(FolderPath);

	TArray<AActor*> Children;
	Group->GetAllChildren(Children, /*bRecurse*/true);
	for (AActor* Child : Children)
	{
		if (Child)
		{
			Child->SetFolderPath(FolderPath);
		}
	}
}

void FSuperGroupsFeature::DrawGroupPivotIcon(UCanvas* Canvas, const FVector& WorldLocation, const UProWorkflowToolsSettings& Settings) const
{
	if (!Canvas || !Canvas->SceneView)
	{
		return;
	}

	const FVector Projected = Canvas->Project(WorldLocation);
	if (Projected.Z <= 0.0f)
	{
		return;
	}

	// Match Empty Actor editor billboard (/Engine/EditorResources/EmptyActor).
	static TWeakObjectPtr<UTexture2D> CachedSprite;
	UTexture2D* Sprite = CachedSprite.Get();
	if (!Sprite)
	{
		Sprite = LoadObject<UTexture2D>(nullptr, SuperGroupsModuleHelpers::GroupPivotSpritePath);
		CachedSprite = Sprite;
	}
	if (!Sprite || !Sprite->GetResource())
	{
		return;
	}

	const float ScreenDiameter = FMath::Max(
		SuperGroupsModuleHelpers::WorldSizeToScreenPixels(Canvas, WorldLocation, Settings.GroupPivotIconWorldSize),
		4.0f);
	const FVector2D Size(ScreenDiameter, ScreenDiameter);
	const FVector2D Position(Projected.X - Size.X * 0.5f, Projected.Y - Size.Y * 0.5f);

	FCanvasTileItem TileItem(Position, Sprite->GetResource(), Size, Settings.GroupPivotIconColor);
	TileItem.BlendMode = SE_BLEND_Translucent;
	Canvas->DrawItem(TileItem);
}

void FSuperGroupsFeature::DrawGroupIcons(UCanvas* Canvas, APlayerController* /*PC*/)
{
	const UProWorkflowToolsSettings* Settings = GetDefault<UProWorkflowToolsSettings>();
	if (!Settings->bEnableSuperGroups || !Settings->bShowGroupPivotIcon || !Canvas || !Canvas->SceneView || !GEditor)
	{
		return;
	}

	// Game View (G): hide like other editor helpers.
	if (Canvas->SceneView->Family->EngineShowFlags.Game)
	{
		return;
	}

	// Only draw for the editor world (skip PIE / other viewports).
	UWorld* EditorWorld = GEditor->GetEditorWorldContext().World();
	if (!EditorWorld || Canvas->SceneView->Family->Scene->GetWorld() != EditorWorld)
	{
		return;
	}

	const USuperGroupSubsystem* Subsystem = EditorWorld->GetSubsystem<USuperGroupSubsystem>();
	const AGroupActor* EditingGroup = Subsystem ? Subsystem->GetEditingGroup() : nullptr;

	for (const TObjectPtr<AActor>& ActiveActor : EditorWorld->ActiveGroupActors)
	{
		AGroupActor* Group = Cast<AGroupActor>(ActiveActor);
		if (!Group)
		{
			continue;
		}

		if (!Settings->bShowAllGroupPivotIcons)
		{
			// Selected (locked) group or the group currently being edited only.
			if (!Group->IsSelected() && Group != EditingGroup)
			{
				continue;
			}
		}

		const FVector PivotLocation = Group->GetActorLocation();
		DrawGroupPivotIcon(Canvas, PivotLocation, *Settings);
	}
}

#undef LOCTEXT_NAMESPACE

