// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "CoreMinimal.h"

PROWORKFLOWTOOLS_API DECLARE_LOG_CATEGORY_EXTERN(LogSuperGroups, Log, All);

