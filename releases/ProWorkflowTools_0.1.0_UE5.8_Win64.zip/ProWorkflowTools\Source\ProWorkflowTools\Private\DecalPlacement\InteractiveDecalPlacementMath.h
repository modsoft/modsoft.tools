// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "DecalPlacement/InteractiveDecalPlacementTypes.h"

class UDecalComponent;

namespace InteractiveDecalPlacement
{
	/**
	 * Decals we author keep the engine's default DecalSize and carry their footprint in actor scale,
	 * the same shape a decal dragged in from the Content Browser and scaled by hand ends up with.
	 * Everything in the editor's transform stack works on scale and is blind to DecalSize.
	 */
	inline const FVector DefaultDecalSize(128.0, 256.0, 256.0);

	/** Actor scale that puts a default-size decal at these half-extents (cm); a negative axis mirrors it. */
	FVector MakeDecalScaleForHalfExtents(const FVector& SignedHalfExtentsCm);

	/** Half-extents of any scene decal in world cm: DecalSize * world scale, sign carrying any mirror. */
	FVector GetDecalSignedHalfExtents(const UDecalComponent& Decal);

	FInteractiveDecalTangentFrame MakeTangentFrameFromHit(const FVector& Position, const FVector& Normal, const FVector& ViewDirection);

	/** Rotates the frame's tangent/bitangent around its normal by AngleRad. */
	FInteractiveDecalTangentFrame RotateFrameInPlane(const FInteractiveDecalTangentFrame& Frame, float AngleRad);

	bool RayPlaneIntersection(
		const FVector& RayOrigin,
		const FVector& RayDirection,
		const FVector& PlaneOrigin,
		const FVector& PlaneNormal,
		FVector& OutIntersection);

	/** Builds actor rotation so projection (+X) points into the surface and width/height align to the tangent frame. */
	FQuat MakeDecalActorRotation(const FVector& Normal, const FVector& Tangent);

	FInteractiveDecalPlacementResult ComputePlacementFromDrag(
		const FInteractiveDecalTangentFrame& AnchorFrame,
		const FVector& DragPlanePoint,
		bool bCenterScale,
		bool bLockAspectRatio,
		float TangentOverBitangentRatio,
		float ProjectionDepth,
		float MinExtent);

	//~ Fit Surface: re-orient a flat placement to the surface under its footprint.

	struct FSurfaceFitSample
	{
		FVector Location = FVector::ZeroVector;
		FVector Normal = FVector::UpVector;
	};

	/** The flat placement's in-plane center, corners and edge midpoints (9 points) in world space. */
	void GetPlacementSamplePoints(const FInteractiveDecalPlacementResult& Flat, TArray<FVector, TInlineAllocator<9>>& OutPoints);

	/**
	 * Fits Flat to the sampled surface: normal = mean sample normal, center = the flat center on the
	 * plane through the sample centroid, tangent kept. PinPoint (a point of the flat rect: the dragged
	 * corner, or the anchor) is then slid back onto its own view ray so it stays under the cursor.
	 *
	 * Samples are ignored when their normal is more than 60° from the flat normal (a wall seen from
	 * the floor) or they sit further off the flat plane than the rect's longest half-extent (a surface
	 * far behind the edge). Fewer than three usable samples leaves Flat unchanged.
	 * OutUsedSamples, when given, receives the locations that took part.
	 */
	FInteractiveDecalPlacementResult FitPlacementToSurface(
		const FInteractiveDecalPlacementResult& Flat,
		TConstArrayView<FSurfaceFitSample> Samples,
		const FVector& PinPoint,
		const FVector& ViewOrigin,
		const FVector& ViewDirection,
		bool bPerspective,
		TArray<FVector>* OutUsedSamples = nullptr);
}

