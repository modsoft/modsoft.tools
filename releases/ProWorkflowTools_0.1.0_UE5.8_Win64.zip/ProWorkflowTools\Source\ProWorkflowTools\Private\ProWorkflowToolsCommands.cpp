// Copyright © 2026 Trey McNair. All rights reserved.

#include "ProWorkflowToolsCommands.h"

#define LOCTEXT_NAMESPACE "ProWorkflowTools"

void FProWorkflowToolsCommands::RegisterCommands()
{
	UI_COMMAND(DuplicateWithLastAction,
		"Duplicate with Last Transform",
		"Duplicate and reapply the last move/rotate/scale. Repeat to chain offsets.",
		EUserInterfaceActionType::Button,
		FInputChord(EModifierKey::Shift, EKeys::D));

	UI_COMMAND(ToggleBoxScale,
		"Bounding Box Scale",
		"Bounds cage while the Scale widget is active. Ctrl scales uniformly, Alt scales from the center, Shift is precision, V snaps to a vertex.",
		EUserInterfaceActionType::ToggleButton,
		FInputChord(EKeys::B));

	UI_COMMAND(ToggleGridPaint,
		"Actor Grid Paint",
		"Paint edge-flush copies of the selected mesh or decal on its modular grid. Esc exits.",
		EUserInterfaceActionType::ToggleButton,
		FInputChord(EKeys::T));

	UI_COMMAND(ShowLastHidden,
		"Show Last Hidden",
		"Unhide the last Hide (H) batch. Press again for older ones.",
		EUserInterfaceActionType::Button,
		FInputChord(EModifierKey::Control | EModifierKey::Alt, EKeys::H));

	UI_COMMAND(OpenWelcomeSplash,
		"Pro Workflow Tools",
		"Open the welcome window.",
		EUserInterfaceActionType::Button,
		FInputChord());
}

#undef LOCTEXT_NAMESPACE
