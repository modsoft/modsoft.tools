// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "Elements/Framework/TypedElementHandle.h"
#include "Math/Box.h"

class FEditorViewportClient;
class FViewport;
struct FConvexVolume;
struct FMarqueeSelectSimilarFilter;

/** Marquee mode from modifiers at drag start. */
enum class EDccMarqueeMode : uint8
{
	Replace,
	Add,
	Subtract,
	SelectSimilar
};

namespace DccMarqueeSelection
{
	EDccMarqueeMode GetModeFromViewport(const FEditorViewportClient* ViewportClient);

	bool IsMarqueeGesture(const FEditorViewportClient* ViewportClient, FViewport* Viewport);

	bool CalculateFrustum(FEditorViewportClient* ViewportClient, const FVector& Start, const FVector& End, FConvexVolume& OutFrustum);

	bool CalculateOrthoBox(FEditorViewportClient* ViewportClient, const FVector& Start, const FVector& End, FBox& OutBox);

	TArray<FTypedElementHandle> GatherFrustumElements(FEditorViewportClient* ViewportClient,
		const FVector& Start, const FVector& End, const FConvexVolume& Frustum,
		const FMarqueeSelectSimilarFilter* SimilarFilter = nullptr);

	TArray<FTypedElementHandle> GatherFrustumElements(FEditorViewportClient* ViewportClient, const FConvexVolume& Frustum,
		const FMarqueeSelectSimilarFilter* SimilarFilter = nullptr);

	TArray<FTypedElementHandle> GatherBoxElements(FEditorViewportClient* ViewportClient, const FBox& Box,
		const FMarqueeSelectSimilarFilter* SimilarFilter = nullptr);

	bool ApplySelection(FEditorViewportClient* ViewportClient, EDccMarqueeMode Mode,
		const TArray<FTypedElementHandle>& Elements);
}

