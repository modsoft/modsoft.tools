// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "BoxScale/BoxScaleMath.h"
#include "HitProxies.h"
#include "ProWorkflowToolsEngineAdapter.h"
#include "UI/ProWorkflowToolHudOverlay.h"
#include "UI/ProWorkflowToolHudTypes.h"
#include "UObject/ObjectPtr.h"
#include "UObject/WeakObjectPtr.h"
#include "Viewport/WorkflowViewportTool.h"

class AActor;
class FEditorModeTools;
class FEditorViewportClient;
class FPrimitiveDrawInterface;
class FReferenceCollector;
class FSceneView;
class FViewport;
class SProWorkflowToolHud;
class UDecalComponent;
class UMaterialInstanceDynamic;
class UPrimitiveComponent;
class USceneComponent;

/** Hit proxy for one cage site (face / edge / corner). */
struct HBoxScaleHandle : public HHitProxy
{
	DECLARE_HIT_PROXY();

	FBoxScaleSite Site;

	explicit HBoxScaleHandle(const FBoxScaleSite& InSite)
		: HHitProxy(HPP_UI)
		, Site(InSite)
	{
	}

	virtual EMouseCursor::Type GetMouseCursor() override
	{
		return EMouseCursor::CardinalCross;
	}
};

/**
 * Bounding-box cage scale (face/edge/corner).
 * Default drag keeps the opposite site fixed. Alt keeps the bounds center fixed.
 * Owned by FProWorkflowToolsEdMode.
 */
class FBoxScaleTool : public FWorkflowViewportTool
{
public:
	/** Drop any shared transform-widget suppression this tool holds. */
	void ReleaseWidgetSuppression();

	/** Enabled, Scale widget mode, and a single scalable selection. */
	bool IsActive() const;

	virtual bool IsExclusive() const override { return bDraggingHandle; }
	virtual bool ReplacesTransformGizmo() const override { return bDraggingHandle || IsActive(); }
	virtual bool CapturesMouse() const override { return bDraggingHandle; }
	virtual bool BlocksViewportDragTool() const override;

	virtual EWorkflowToolTickViewport GetTickViewport() const override { return EWorkflowToolTickViewport::Focused; }
	virtual void Tick(FEditorViewportClient* ViewportClient, float DeltaTime) override;
	virtual void Exit() override;
	/** Ends any handle drag: commits it if it moved, otherwise cancels its transaction. */
	virtual void CancelTracking() override;

	virtual bool InputKey(FEditorViewportClient* ViewportClient, FViewport* Viewport, FKey Key, EInputEvent Event) override;
	virtual bool StartTracking(FEditorViewportClient* InViewportClient, FViewport* InViewport) override;
	virtual bool EndTracking(FEditorViewportClient* InViewportClient, FViewport* InViewport) override;
	virtual bool CapturedMouseMove(FEditorViewportClient* InViewportClient, FViewport* InViewport, int32 InMouseX, int32 InMouseY) override;
	virtual bool MouseMove(FEditorViewportClient* ViewportClient, FViewport* Viewport, int32 X, int32 Y) override;

	virtual void Render(const FSceneView* View, FViewport* Viewport, FPrimitiveDrawInterface* PDI) override;
	virtual void AddReferencedObjects(FReferenceCollector& Collector) override;

	void ShowHudOverlay();
	void HideHudOverlay();
	FProWorkflowToolHudModel BuildHudModel() const;

private:
	/**
	 * Alt+LMB on a cage handle starts the drag and takes the press, so the viewport
	 * does not orbit. Alt+LMB elsewhere returns false.
	 */
	bool TryConsumeAltHandlePress(FEditorViewportClient* ViewportClient, FViewport* Viewport);
	/** Ends any handle drag. True when the release must be consumed (Alt drags). */
	bool HandleLmbRelease(FEditorViewportClient* ViewportClient, FViewport* Viewport);

	/** Single selected actor (first mesh, else first decal) or one selected mesh/decal component. */
	static bool GetBoxScaleTarget(AActor*& OutActor, USceneComponent*& OutComponent, FBox& OutLocalBounds, bool& bOutComponentSpace);

	/** Extracts unscaled local-space bounds from a primitive component (static mesh, brush, or skeletal mesh). */
	static bool GetPrimitiveComponentLocalBounds(const UPrimitiveComponent* Component, FBox& OutBounds);

	/** Unscaled local box from UDecalComponent::DecalSize (half-extents). */
	static bool GetDecalComponentLocalBounds(const UDecalComponent* Component, FBox& OutBounds);

	/** Distance along the handle axis line (AxisOrigin, AxisDir) closest to the viewport mouse ray. */
	static bool ComputeAxisDragParam(
		FEditorViewportClient* ViewportClient,
		int32 MouseX,
		int32 MouseY,
		const FVector& AxisOrigin,
		const FVector& AxisDir,
		double& OutParam);

	/** Closest point on a plane (PointOnPlane, PlaneNormal) to the viewport mouse ray. */
	static bool ComputePlaneDragPoint(
		FEditorViewportClient* ViewportClient,
		int32 MouseX,
		int32 MouseY,
		const FVector& PointOnPlane,
		const FVector& PlaneNormal,
		FVector& OutPoint);

	void CreateHandleMaterials();

	/** Suppress TRS while handles are live (shared suppress/release). */
	void UpdateWidgetSuppression();

	// Box scale drag state
	bool bDraggingHandle = false;
	FBoxScaleDragFrame DragFrame;
	TWeakObjectPtr<AActor> DragActor;
	TWeakObjectPtr<USceneComponent> DragComponent;
	/** True when this drag writes the selected component, not the actor. */
	bool bDragComponentSpace = false;
	/** Alt+LMB on a handle started this drag, so this tool owns the capture and the release. */
	bool bAltPressOwnsDrag = false;
	/** Previous Alt state from Tick. A mid-drag change reapplies the current handle position. */
	bool bAltHeldForAnchor = false;
	/** Previous Ctrl state from Tick. A mid-drag change reapplies the current handle position. */
	bool bCtrlHeldForUniform = false;
	/** 1-axis: line param at drag start. */
	double DragStartParam = 0.0;
	/** Multi-axis: plane normal used for mouse projection. */
	FVector DragPlaneNormal = FVector::UpVector;
	/** Multi-axis: handle projection on the drag plane at start. */
	FVector DragStartPlanePoint = FVector::ZeroVector;
	/** Transaction index from BeginTransaction, so an empty click can be cancelled. */
	int32 DragTransactionIndex = INDEX_NONE;
	bool bDragApplied = false;

	/**
	 * Shift = precision: scale mouse deltas while held (including mid-drag).
	 * Incremental so toggling Shift doesn't jump.
	 */
	double DragLastRawParam = 0.0;
	double DragAppliedDistance = 0.0;
	FVector DragLastRawPlanePoint = FVector::ZeroVector;
	FVector DragAppliedPlaneDelta = FVector::ZeroVector;

	/** Engine vertex search is once per frame while V is held. */
	ProWorkflowTools::FVertexSnapFrameQuery VertexSnapQuery;
	bool bVertexSnapKeyHeld = false;

	// Hover feedback
	FBoxScaleSite HoveredSite;
	bool bHasHoveredSite = false;

	/** True while this tool holds a shared transform-widget suppression. */
	bool bHoldingWidgetSuppression = false;

	TProWorkflowToolHudOverlay<SProWorkflowToolHud> HudOverlay;

	// Handle materials (kept alive via AddReferencedObjects)
	TObjectPtr<UMaterialInstanceDynamic> AxisMaterials[3] = { nullptr, nullptr, nullptr };
	TObjectPtr<UMaterialInstanceDynamic> CurrentAxisMaterial = nullptr;
	TObjectPtr<UMaterialInstanceDynamic> WhiteHandleMaterial = nullptr;
	TObjectPtr<UMaterialInstanceDynamic> AnchorGhostMaterial = nullptr;
};
