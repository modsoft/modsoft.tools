// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "CoreMinimal.h"

class FEditorViewportClient;
class FSceneView;

namespace ProWorkflowTools
{
	struct FViewportSurfaceHit
	{
		FVector Location = FVector::ZeroVector;
		/** Faces the cursor ray. */
		FVector Normal = FVector::UpVector;
	};

	/**
	 * The surface drawn under the cursor. The hit proxy picks the primitive, so collision setup does
	 * not matter and translucent surfaces follow Allow Translucent Selection, as click-select does.
	 * Static meshes and their instances are tested against LOD0 render triangles (Nanite meshes
	 * against their fallback mesh). Other primitives use their actor's complex collision, which is
	 * where landscape keeps its heightfield; BSP uses its model component.
	 */
	bool TraceSurfaceUnderCursor(FEditorViewportClient* ViewportClient, FViewportSurfaceHit& OutHit);

	/** Same test at any viewport pixel, with the ray taken from a view the caller already built. */
	bool TraceSurfaceAtPixel(FEditorViewportClient* ViewportClient, const FSceneView& View, const FIntPoint& Pixel, FViewportSurfaceHit& OutHit);
}
