// Copyright © 2026 Trey McNair. All rights reserved.

#include "UI/ProWorkflowToolHudOverlay.h"

#include "IAssetViewport.h"
#include "LevelEditor.h"
#include "Modules/ModuleManager.h"

namespace ProWorkflowToolHudOverlay::Private
{
	struct FShownHud
	{
		TWeakPtr<SWidget> Widget;
		EVisibility Visibility;
	};

	/** Shown HUDs, oldest first. All share the bottom-centre slot, so only the newest is visible. */
	TArray<FShownHud> ShownHuds;

	void ShowNewestOnly()
	{
		ShownHuds.RemoveAll([](const FShownHud& Hud) { return !Hud.Widget.IsValid(); });
		for (int32 Index = 0; Index < ShownHuds.Num(); ++Index)
		{
			ShownHuds[Index].Widget.Pin()->SetVisibility(
				Index == ShownHuds.Num() - 1 ? ShownHuds[Index].Visibility : EVisibility::Collapsed);
		}
	}
}

TWeakPtr<IAssetViewport> ProWorkflowToolHudOverlay::Add(const TSharedRef<SWidget>& Widget)
{
	using namespace ProWorkflowToolHudOverlay::Private;

	FLevelEditorModule* LevelEditorModule = FModuleManager::GetModulePtr<FLevelEditorModule>(TEXT("LevelEditor"));
	const TSharedPtr<IAssetViewport> Viewport = LevelEditorModule ? LevelEditorModule->GetFirstActiveViewport() : nullptr;
	if (!Viewport.IsValid())
	{
		return nullptr;
	}

	Viewport->AddOverlayWidget(Widget);
	ShownHuds.Add({ Widget, Widget->GetVisibility() });
	ShowNewestOnly();
	return Viewport;
}

void ProWorkflowToolHudOverlay::Remove(const TWeakPtr<IAssetViewport>& HostViewport, const TSharedRef<SWidget>& Widget)
{
	using namespace ProWorkflowToolHudOverlay::Private;

	if (const TSharedPtr<IAssetViewport> Viewport = HostViewport.Pin())
	{
		Viewport->RemoveOverlayWidget(Widget);
	}

	ShownHuds.RemoveAll([&Widget](const FShownHud& Hud) { return Hud.Widget.HasSameObject(&Widget.Get()); });
	ShowNewestOnly();
}
