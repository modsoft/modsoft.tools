// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "Runtime/Launch/Resources/Version.h"

#define PWT_ENGINE_AT_LEAST(Major, Minor) \
	((ENGINE_MAJOR_VERSION > (Major)) || ((ENGINE_MAJOR_VERSION == (Major)) && (ENGINE_MINOR_VERSION >= (Minor))))

/** 5.7 restored SetIsTemporarilyHiddenInEditor hide and the QualityLevel GetUsedTextures. */
#define PWT_UE_5_7_OR_LATER PWT_ENGINE_AT_LEAST(5, 7)

/** Shared-source compile seams for 5.8 APIs that do not exist on 5.6/5.7. */
#define PWT_UE_5_8_OR_LATER PWT_ENGINE_AT_LEAST(5, 8)
