// Copyright © 2026 Trey McNair. All rights reserved.

#include "Viewport/DccMarqueeSelection.h"

#include "SelectSimilar/MarqueeSelectSimilarFilter.h"

#include "Editor.h"
#include "EditorViewportClient.h"
#include "ProWorkflowToolsEngineVersion.h"
#include "Elements/Framework/EngineElementsLibrary.h"
#include "Elements/Framework/TypedElementRegistry.h"
#include "Elements/Framework/TypedElementSelectionSet.h"
#include "Elements/Interfaces/TypedElementWorldInterface.h"
#include "EngineUtils.h"
#include "GameFramework/Actor.h"
#include "GameFramework/Volume.h"
#include "LevelEditorSubsystem.h"
#include "LevelEditorViewport.h"
#include "SceneView.h"
#include "ScopedTransaction.h"
#include "Settings/LevelEditorViewportSettings.h"
#include "Subsystems/BrushEditingSubsystem.h"

#define LOCTEXT_NAMESPACE "ProWorkflowTools"

namespace DccMarqueeSelection
{
	namespace Private
	{
		bool IsActorSelectable(const AActor* Actor, const FLevelEditorViewportClient* LevelViewportClient)
		{
			if (!Actor || Actor->IsHiddenEd())
			{
				return false;
			}

			static const TArray<FName> NoHiddenLayers;
			const TArray<FName>& HiddenLayers = LevelViewportClient ? LevelViewportClient->ViewHiddenLayers : NoHiddenLayers;
			for (const FName& Layer : Actor->Layers)
			{
				if (HiddenLayers.Contains(Layer))
				{
					return false;
				}
			}

			if (LevelViewportClient && Actor->IsA<AVolume>() && !LevelViewportClient->IsVolumeVisibleInViewport(*Actor))
			{
				return false;
			}

			return true;
		}

		TArray<FTypedElementHandle> GetElementsIntersectingFrustum(const AActor* Actor,
			const FConvexVolume& InFrustum,
			const FEditorViewportClient* EditorViewport,
			const FLevelEditorViewportClient* LevelViewport,
			const FWorldSelectionElementArgs& SelectionArgs)
		{
			if (Actor && (!EditorViewport || !Actor->IsA(AVolume::StaticClass())
				|| (LevelViewport ? !LevelViewport->IsVolumeVisibleInViewport(*Actor) : false)))
			{
				if (FTypedElementHandle ActorHandle = UEngineElementsLibrary::AcquireEditorActorElementHandle(Actor))
				{
					if (TTypedElement<ITypedElementWorldInterface> WorldElement =
						UTypedElementRegistry::GetInstance()->GetElement<ITypedElementWorldInterface>(ActorHandle))
					{
						return WorldElement.GetSelectionElementsInConvexVolume(InFrustum, SelectionArgs);
					}
				}
			}

			return {};
		}

		TArray<FTypedElementHandle> GetElementsIntersectingBox(const AActor* Actor,
			const FBox& InBox,
			const FEditorViewportClient* InEditorViewport,
			const FLevelEditorViewportClient* InLevelViewport,
			const FWorldSelectionElementArgs& SelectionArgs)
		{
			if (Actor && (!InEditorViewport || !Actor->IsA(AVolume::StaticClass())
				|| (InLevelViewport ? !InLevelViewport->IsVolumeVisibleInViewport(*Actor) : false)))
			{
				if (FTypedElementHandle ActorHandle = UEngineElementsLibrary::AcquireEditorActorElementHandle(Actor))
				{
					if (TTypedElement<ITypedElementWorldInterface> WorldElement =
						UTypedElementRegistry::GetInstance()->GetElement<ITypedElementWorldInterface>(ActorHandle))
					{
						return WorldElement.GetSelectionElementsInBox(InBox, SelectionArgs);
					}
				}
			}

			return {};
		}

		FWorldSelectionElementArgs MakeSelectionArgs(FEditorViewportClient* ViewportClient, UTypedElementSelectionSet* SelectionSet,
			const FTypedElementSelectionOptions& SelectionOptions)
		{
			UBrushEditingSubsystem* BrushSubsystem = GEditor ? GEditor->GetEditorSubsystem<UBrushEditingSubsystem>() : nullptr;
			const bool bGeometryMode = BrushSubsystem && BrushSubsystem->IsGeometryEditorModeActive();

			return FWorldSelectionElementArgs
			{
				SelectionSet,
				ETypedElementSelectionMethod::Primary,
				SelectionOptions,
				ViewportClient ? &ViewportClient->EngineShowFlags : nullptr,
				static_cast<bool>(GetDefault<ULevelEditorViewportSettings>()->bStrictBoxSelection),
				bGeometryMode
			};
		}

		bool PassesSimilarFilter(const AActor* Actor, const FMarqueeSelectSimilarFilter* SimilarFilter)
		{
			return !SimilarFilter || SimilarFilter->IsEmpty() || SimilarFilter->MatchesActor(Actor);
		}
	}

	EDccMarqueeMode GetModeFromViewport(const FEditorViewportClient* ViewportClient)
	{
		if (!ViewportClient)
		{
			return EDccMarqueeMode::Replace;
		}

		if (ViewportClient->IsCtrlPressed() && ViewportClient->IsShiftPressed())
		{
			return EDccMarqueeMode::SelectSimilar;
		}
		if (ViewportClient->IsCtrlPressed())
		{
			return EDccMarqueeMode::Subtract;
		}
		if (ViewportClient->IsShiftPressed())
		{
			return EDccMarqueeMode::Add;
		}

		return EDccMarqueeMode::Replace;
	}

	bool IsMarqueeGesture(const FEditorViewportClient* ViewportClient, FViewport* Viewport)
	{
		if (!ViewportClient || !Viewport || !ViewportClient->IsLevelEditorClient())
		{
			return false;
		}

		if (!Viewport->KeyState(EKeys::LeftMouseButton)
			|| Viewport->KeyState(EKeys::RightMouseButton)
			|| Viewport->KeyState(EKeys::MiddleMouseButton))
		{
			return false;
		}

		if (ViewportClient->IsAltPressed() || ViewportClient->ShouldOrbitCamera())
		{
			return false;
		}

		return true;
	}

	bool CalculateFrustum(FEditorViewportClient* ViewportClient, const FVector& Start, const FVector& End, FConvexVolume& OutFrustum)
	{
		if (!ViewportClient || !ViewportClient->Viewport)
		{
			return false;
		}

		FSceneViewFamilyContext ViewFamily(FSceneViewFamily::ConstructionValues(
			ViewportClient->Viewport,
			ViewportClient->GetScene(),
			ViewportClient->EngineShowFlags)
			.SetRealtimeUpdate(ViewportClient->IsRealtime()));

		FSceneView* SceneView = ViewportClient->CalcSceneView(&ViewFamily);
		if (!SceneView)
		{
			return false;
		}

		const FVector& CamPoint = ViewportClient->GetViewLocation();

		const double DX = Start.X == End.X ? 0.5 : 0.0;
		const double Left = FMath::Min(Start.X, End.X) - DX;
		const double Right = FMath::Max(Start.X, End.X) + DX;
		const double DY = Start.Y == End.Y ? 0.5 : 0.0;
		const double Bottom = FMath::Min(Start.Y, End.Y) - DY;
		const double Top = FMath::Max(Start.Y, End.Y) + DY;

		const FVector2D Point1(Left, Bottom);
		const FVector2D Point2(Right, Bottom);
		const FVector2D Point3(Right, Top);
		const FVector2D Point4(Left, Top);

		FVector BoxPoint1, BoxPoint2, BoxPoint3, BoxPoint4;
		FVector WorldDir1, WorldDir2, WorldDir3, WorldDir4;
		SceneView->DeprojectFVector2D(Point1, BoxPoint1, WorldDir1);
		SceneView->DeprojectFVector2D(Point2, BoxPoint2, WorldDir2);
		SceneView->DeprojectFVector2D(Point3, BoxPoint3, WorldDir3);
		SceneView->DeprojectFVector2D(Point4, BoxPoint4, WorldDir4);

		auto MakePlane = [](const FVector& A, const FVector& B, const FVector& C)
		{
			static constexpr double SmallNumberCubed = UE_SMALL_NUMBER * UE_SMALL_NUMBER * UE_SMALL_NUMBER;
			const FVector Normal = (B - A ^ C - A).GetSafeNormal(SmallNumberCubed);
			const double W = A | Normal;
			return FPlane(Normal, W);
		};

		OutFrustum.Planes.Empty();
		OutFrustum.Planes.Emplace(MakePlane(BoxPoint1, BoxPoint2, CamPoint));
		OutFrustum.Planes.Emplace(MakePlane(BoxPoint2, BoxPoint3, CamPoint));
		OutFrustum.Planes.Emplace(MakePlane(BoxPoint3, BoxPoint4, CamPoint));
		OutFrustum.Planes.Emplace(MakePlane(BoxPoint4, BoxPoint1, CamPoint));

#if PWT_UE_5_8_OR_LATER
		const FMatrix& WorldToClip = SceneView->ViewMatrices.GetWorldToClip();
#else
		const FMatrix& WorldToClip = SceneView->ViewMatrices.GetViewProjectionMatrix();
#endif
		FPlane NearPlane;
		if (WorldToClip.GetFrustumNearPlane(NearPlane))
		{
			OutFrustum.Planes.Emplace(MoveTemp(NearPlane));
		}
		FPlane FarPlane;
		if (WorldToClip.GetFrustumFarPlane(FarPlane))
		{
			OutFrustum.Planes.Emplace(MoveTemp(FarPlane));
		}

		OutFrustum.Init();
		return true;
	}

	bool CalculateOrthoBox(FEditorViewportClient* ViewportClient, const FVector& Start, const FVector& End, FBox& OutBox)
	{
		if (!ViewportClient || !ViewportClient->Viewport)
		{
			return false;
		}

		FSceneViewFamilyContext ViewFamily(FSceneViewFamily::ConstructionValues(
			ViewportClient->Viewport,
			ViewportClient->GetScene(),
			ViewportClient->EngineShowFlags)
			.SetRealtimeUpdate(ViewportClient->IsRealtime()));

		FSceneView* View = ViewportClient->CalcSceneView(&ViewFamily);
		if (!View)
		{
			return false;
		}

		const FVector3f StartFloat(Start);
		const FVector3f EndFloat(End);

		const FVector TransformedStart = View->ScreenToWorld(View->PixelToScreen(StartFloat.X, StartFloat.Y, 0.5f));
		const FVector TransformedEnd = View->ScreenToWorld(View->PixelToScreen(EndFloat.X, EndFloat.Y, 0.5f));

		OutBox.Init();
		OutBox += TransformedStart;
		OutBox += TransformedEnd;

		switch (ViewportClient->ViewportType)
		{
		case LVT_OrthoXY:
		case LVT_OrthoNegativeXY:
			OutBox.Min.Z = -WORLD_MAX;
			OutBox.Max.Z = WORLD_MAX;
			break;
		case LVT_OrthoXZ:
		case LVT_OrthoNegativeXZ:
			OutBox.Min.Y = -WORLD_MAX;
			OutBox.Max.Y = WORLD_MAX;
			break;
		case LVT_OrthoYZ:
		case LVT_OrthoNegativeYZ:
			OutBox.Min.X = -WORLD_MAX;
			OutBox.Max.X = WORLD_MAX;
			break;
		default:
			break;
		}

		return OutBox.IsValid != 0;
	}

	TArray<FTypedElementHandle> GatherFrustumElements(FEditorViewportClient* ViewportClient, const FConvexVolume& Frustum,
		const FMarqueeSelectSimilarFilter* SimilarFilter)
	{
		return GatherFrustumElements(ViewportClient, FVector::ZeroVector, FVector::ZeroVector, Frustum, SimilarFilter);
	}

	TArray<FTypedElementHandle> GatherFrustumElements(FEditorViewportClient* ViewportClient,
		const FVector& Start, const FVector& End, const FConvexVolume& Frustum,
		const FMarqueeSelectSimilarFilter* SimilarFilter)
	{
		TArray<FTypedElementHandle> ElementsToSelect;
		if (!ViewportClient || !GEditor || !ViewportClient->Viewport)
		{
			return ElementsToSelect;
		}

		UTypedElementSelectionSet* SelectionSet = GEditor->GetEditorSubsystem<ULevelEditorSubsystem>()->GetSelectionSet();
		if (!SelectionSet)
		{
			return ElementsToSelect;
		}

		const FTypedElementSelectionOptions SelectionOptions;
		const FWorldSelectionElementArgs SelectionArgs = Private::MakeSelectionArgs(ViewportClient, SelectionSet, SelectionOptions);

		const bool bStrictDragSelection = GetDefault<ULevelEditorViewportSettings>()->bStrictBoxSelection;
		const bool bTransparentBoxSelection = GetDefault<ULevelEditorViewportSettings>()->bTransparentBoxSelection;

		FLevelEditorViewportClient* LevelViewportClient =
			ViewportClient->IsLevelEditorClient() ? static_cast<FLevelEditorViewportClient*>(ViewportClient) : nullptr;

		const bool bHasScreenRect = !Start.Equals(End, UE_KINDA_SMALL_NUMBER);
		const bool bUseActorIterator = bTransparentBoxSelection || (SimilarFilter && !SimilarFilter->IsEmpty()) || !bHasScreenRect;

		if (bUseActorIterator)
		{
			for (FActorIterator It(ViewportClient->GetWorld()); It; ++It)
			{
				AActor* Actor = *It;
				if (!Private::IsActorSelectable(Actor, LevelViewportClient) || !Private::PassesSimilarFilter(Actor, SimilarFilter))
				{
					continue;
				}

				ElementsToSelect.Append(Private::GetElementsIntersectingFrustum(Actor, Frustum, ViewportClient, LevelViewportClient, SelectionArgs));
			}
			return ElementsToSelect;
		}

		FVector NormalizedStart = Start;
		FVector NormalizedEnd = End;
		if (NormalizedStart.X > NormalizedEnd.X) { Swap(NormalizedStart.X, NormalizedEnd.X); }
		if (NormalizedStart.Y > NormalizedEnd.Y) { Swap(NormalizedStart.Y, NormalizedEnd.Y); }

		const int32 ViewportSizeX = ViewportClient->Viewport->GetSizeXY().X;
		const int32 ViewportSizeY = ViewportClient->Viewport->GetSizeXY().Y;

		const int32 MinX = UE::LWC::FloatToIntCastChecked<int32>(FMath::Max<double>(0.0, NormalizedStart.X));
		const int32 MinY = UE::LWC::FloatToIntCastChecked<int32>(FMath::Max<double>(0.0, NormalizedStart.Y));
		const int32 MaxX = FMath::Min(ViewportSizeX, FMath::TruncToInt32(NormalizedEnd.X + 1.0));
		const int32 MaxY = FMath::Min(ViewportSizeY, FMath::TruncToInt32(NormalizedEnd.Y + 1.0));
		const FIntRect BoxRect{ FIntPoint(MinX, MinY), FIntPoint(MaxX, MaxY) };

		FTypedElementListRef ElementList = UTypedElementRegistry::GetInstance()->CreateElementList();
		ViewportClient->Viewport->GetElementHandlesInRect(BoxRect, ElementList);

		if (bStrictDragSelection)
		{
			ElementList->ForEachElement<ITypedElementWorldInterface>([&Frustum, bStrictDragSelection, SelectionSet, &ElementsToSelect]
				(const TTypedElement<ITypedElementWorldInterface>& InElement)
				{
					if (InElement.IsElementInConvexVolume(Frustum, bStrictDragSelection))
					{
						ElementsToSelect.Add(SelectionSet->GetSelectionElement(InElement, ETypedElementSelectionMethod::Primary));
					}
					return true;
				});
		}
		else
		{
			ElementList->ForEachElementHandle([&SelectionSet, &ElementsToSelect](const FTypedElementHandle& InHandle)
				{
					ElementsToSelect.Add(SelectionSet->GetSelectionElement(InHandle, ETypedElementSelectionMethod::Primary));
					return true;
				});
		}

		return ElementsToSelect;
	}

	TArray<FTypedElementHandle> GatherBoxElements(FEditorViewportClient* ViewportClient, const FBox& Box,
		const FMarqueeSelectSimilarFilter* SimilarFilter)
	{
		TArray<FTypedElementHandle> Handles;
		if (!ViewportClient || !GEditor)
		{
			return Handles;
		}

		UTypedElementSelectionSet* SelectionSet = GEditor->GetEditorSubsystem<ULevelEditorSubsystem>()->GetSelectionSet();
		if (!SelectionSet)
		{
			return Handles;
		}

		const FTypedElementSelectionOptions SelectionOptions;
		const FWorldSelectionElementArgs SelectionArgs = Private::MakeSelectionArgs(ViewportClient, SelectionSet, SelectionOptions);

		FLevelEditorViewportClient* LevelViewportClient =
			ViewportClient->IsLevelEditorClient() ? static_cast<FLevelEditorViewportClient*>(ViewportClient) : nullptr;

		for (FActorIterator It(ViewportClient->GetWorld()); It; ++It)
		{
			AActor* Actor = *It;
			if (!Private::IsActorSelectable(Actor, LevelViewportClient) || !Private::PassesSimilarFilter(Actor, SimilarFilter))
			{
				continue;
			}

			Handles.Append(Private::GetElementsIntersectingBox(Actor, Box, ViewportClient, LevelViewportClient, SelectionArgs));
		}

		return Handles;
	}

	bool ApplySelection(FEditorViewportClient* ViewportClient, EDccMarqueeMode Mode,
		const TArray<FTypedElementHandle>& Elements)
	{
		if (!GEditor || !ViewportClient)
		{
			return false;
		}

		UTypedElementSelectionSet* SelectionSet = GEditor->GetEditorSubsystem<ULevelEditorSubsystem>()->GetSelectionSet();
		if (!SelectionSet)
		{
			return false;
		}

		if (Mode == EDccMarqueeMode::SelectSimilar && Elements.IsEmpty())
		{
			return true;
		}

		const FScopedTransaction Transaction(NSLOCTEXT("ProWorkflowTools", "DccMarqueeSelect", "Marquee Select"));
		SelectionSet->Modify();

		const FTypedElementSelectionOptions SelectionOptions;

		switch (Mode)
		{
		case EDccMarqueeMode::Replace:
			SelectionSet->SetSelection(Elements, SelectionOptions);
			break;
		case EDccMarqueeMode::Add:
		case EDccMarqueeMode::SelectSimilar:
			SelectionSet->SelectElements(Elements, SelectionOptions);
			break;
		case EDccMarqueeMode::Subtract:
			SelectionSet->DeselectElements(Elements, SelectionOptions);
			break;
		default:
			break;
		}

		GEditor->NoteSelectionChange();
		return true;
	}
}

#undef LOCTEXT_NAMESPACE

