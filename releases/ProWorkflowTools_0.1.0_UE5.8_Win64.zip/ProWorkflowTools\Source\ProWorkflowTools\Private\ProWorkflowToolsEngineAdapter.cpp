// Copyright © 2026 Trey McNair. All rights reserved.

#include "ProWorkflowToolsEngineAdapter.h"

#include "Components/StaticMeshComponent.h"
#include "Editor.h"
#include "GameFramework/Actor.h"
#include "UObject/UObjectGlobals.h"
#if !PWT_UE_5_7_OR_LATER
#include "Elements/Columns/TypedElementMiscColumns.h"
#include "Elements/Columns/TypedElementVisibilityColumns.h"
#include "Elements/Common/EditorDataStorageFeatures.h"
#include "Elements/Interfaces/TypedElementDataStorageCompatibilityInterface.h"
#include "Elements/Interfaces/TypedElementDataStorageInterface.h"
#endif
#include "BaseGizmos/GizmoElementGroup.h"
#include "EditorGizmos/EditorTransformGizmoUtil.h"
#include "EditorGizmos/TransformGizmo.h"
#include "EditorInteractiveGizmoManager.h"
#include "EditorModeManager.h"
#include "EditorViewportClient.h"
#if PWT_UE_5_8_OR_LATER
#include "ViewportClientNavigationHelper.h"
#include "ViewportInteractions/ViewportInteraction.h"
#include "ViewportInteractions/ViewportInteractionsBehaviorSource.h"
#endif
#include "Engine/StaticMesh.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "HAL/IConsoleManager.h"
#include "InputCoreTypes.h"
#include "InputRouter.h"
#include "LevelEditor.h"
#include "LevelEditorViewport.h"
#include "SnappingUtils.h"
#include "StaticMeshResources.h"
#include "Modules/ModuleManager.h"
#include "Tools/EdModeInteractiveToolsContext.h"
#include "PrimitiveSceneProxy.h"
#include "UnrealClient.h"
#include "UnrealWidget.h"
#include "UnrealWidgetFwd.h"
#include "Materials/MaterialInterface.h"

#if PLATFORM_WINDOWS
#include "Windows/AllowWindowsPlatformTypes.h"
#include <windows.h>
#include "Windows/HideWindowsPlatformTypes.h"
#endif

DEFINE_LOG_CATEGORY_STATIC(LogProWorkflowGizmo, Log, All);

namespace ProWorkflowTools::Private
{
	static TAutoConsoleVariable<bool> CVarLogGizmoState(
		TEXT("ProWorkflowTools.LogGizmoState"),
		false,
		TEXT("Log the transform gizmo state (LogProWorkflowGizmo) each time a tool hides or restores it."));

	/** Nested suppress count. Only 0→1 clears bShowWidget; only last→0 restores it. */
	static int32 GizmoSuppressCount = 0;

	/** True after we cleared the persistent flag (so we only restore what we hid). */
	static bool bClearedShowWidget = false;

	static bool IsLevelEditorReady()
	{
		if (!GEditor || IsEngineExitRequested())
		{
			return false;
		}

		const FLevelEditorModule* LevelEditorModule = FModuleManager::GetModulePtr<FLevelEditorModule>("LevelEditor");
		return LevelEditorModule && LevelEditorModule->GetFirstLevelEditor().IsValid();
	}

	static bool IsEditorWorldStable()
	{
		if (!GEditor)
		{
			return false;
		}

		UWorld* EditorWorld = GEditor->GetEditorWorldContext(/*bEnsureIsGWorld=*/false).World();
		return EditorWorld
			&& !EditorWorld->bIsTearingDown
			&& !EditorWorld->IsBeingCleanedUp();
	}

	/** True if the gizmo had been destroyed and was created again. */
	static bool RestoreEditorTransformGizmoIfDestroyed()
	{
		FEditorModeTools& ModeTools = GLevelEditorModeTools();
		if (!ProWorkflowTools::AreEditorGizmosAllowed(&ModeTools))
		{
			return false;
		}

		UModeManagerInteractiveToolsContext* ToolsContext = ModeTools.GetInteractiveToolsContext();
		if (!ToolsContext || !ToolsContext->ToolManager)
		{
			return false;
		}

		if (UE::EditorTransformGizmoUtil::FindDefaultTransformGizmo(ToolsContext->ToolManager))
		{
			return false;
		}

		UTransformGizmo* Gizmo = UE::EditorTransformGizmoUtil::GetDefaultTransformGizmo(ToolsContext->ToolManager);
		if (Gizmo)
		{
			Gizmo->SetVisibility(true);
		}
		return Gizmo != nullptr;
	}

	static const TCHAR* WidgetModeName(UE::Widget::EWidgetMode Mode)
	{
		switch (Mode)
		{
		case UE::Widget::WM_Translate: return TEXT("Translate");
		case UE::Widget::WM_Rotate: return TEXT("Rotate");
		case UE::Widget::WM_Scale: return TEXT("Scale");
		case UE::Widget::WM_TranslateRotateZ: return TEXT("TranslateRotateZ");
		case UE::Widget::WM_2D: return TEXT("2D");
		default: return TEXT("Other");
		}
	}

	static void LogGizmoState(const TCHAR* Event)
	{
		if (!CVarLogGizmoState.GetValueOnGameThread())
		{
			return;
		}

		FEditorModeTools& ModeTools = GLevelEditorModeTools();
		UTransformGizmo* Gizmo = nullptr;
		if (UModeManagerInteractiveToolsContext* ToolsContext = ModeTools.GetInteractiveToolsContext())
		{
			if (ToolsContext->ToolManager)
			{
				Gizmo = UE::EditorTransformGizmoUtil::FindDefaultTransformGizmo(ToolsContext->ToolManager);
			}
		}

		const FEditorViewportClient* ViewportClient = GCurrentLevelEditingViewportClient;
		const int32 ViewportShow = ViewportClient ? (ViewportClient->GetShowWidget() ? 1 : 0) : -1;
		const int32 ModeWidgets = (ViewportClient && ViewportClient->EngineShowFlags.ModeWidgets) ? 1 : 0;

		UE_LOG(LogProWorkflowGizmo, Log,
			TEXT("%s toolsShow=%d viewportShow=%d modeWidgets=%d mode=%s tracking=%d count=%d axes=%d gizmo=%s visible=%d"),
			Event,
			ModeTools.GetShowWidget() ? 1 : 0,
			ViewportShow,
			ModeWidgets,
			WidgetModeName(ModeTools.GetWidgetMode()),
			ModeTools.IsTracking() ? 1 : 0,
			GizmoSuppressCount,
			static_cast<int32>(ModeTools.GetWidgetAxisToDraw(ModeTools.GetWidgetMode())),
			Gizmo ? TEXT("yes") : TEXT("no"),
			(Gizmo && Gizmo->bVisible) ? 1 : 0);
	}
}

void ProWorkflowTools::SuppressTransformWidget()
{
	using namespace ProWorkflowTools::Private;

	++GizmoSuppressCount;
	if (GizmoSuppressCount != 1)
	{
		return;
	}

	if (!IsLevelEditorReady())
	{
		return;
	}

	GLevelEditorModeTools().SetShowWidget(false);
	bClearedShowWidget = true;
	LogGizmoState(TEXT("suppress"));
}

void ProWorkflowTools::ReleaseTransformWidget()
{
	using namespace ProWorkflowTools::Private;

	if (GizmoSuppressCount <= 0)
	{
		GizmoSuppressCount = 0;
		return;
	}

	--GizmoSuppressCount;
	if (GizmoSuppressCount > 0)
	{
		return;
	}

	if (!bClearedShowWidget)
	{
		return;
	}

	bClearedShowWidget = false;

	if (!IsLevelEditorReady())
	{
		return;
	}

	GLevelEditorModeTools().SetShowWidget(true);
	LogGizmoState(RestoreEditorTransformGizmoIfDestroyed() ? TEXT("release gizmo-recreated") : TEXT("release"));

	if (IsEditorWorldStable() && GEditor)
	{
		GEditor->RedrawLevelEditingViewports();
	}
}

void ProWorkflowTools::ReleaseAllTransformWidgetSuppressions()
{
	using namespace ProWorkflowTools::Private;

	if (GizmoSuppressCount <= 0 && !bClearedShowWidget)
	{
		GizmoSuppressCount = 0;
		return;
	}

	GizmoSuppressCount = 0;

	if (!bClearedShowWidget)
	{
		return;
	}

	bClearedShowWidget = false;

	if (!IsLevelEditorReady())
	{
		return;
	}

	GLevelEditorModeTools().SetShowWidget(true);
	LogGizmoState(RestoreEditorTransformGizmoIfDestroyed() ? TEXT("release-all gizmo-recreated") : TEXT("release-all"));
}

void ProWorkflowTools::RestoreTransformWidgetForEditorExit()
{
	using namespace ProWorkflowTools::Private;

	GizmoSuppressCount = 0;
	if (!bClearedShowWidget)
	{
		return;
	}
	bClearedShowWidget = false;

	// The level editor is gone by now; the mode tools live until FCoreDelegates::OnExit.
	FEditorModeTools& ModeTools = GLevelEditorModeTools();
	ModeTools.SetShowWidget(true);
	ModeTools.SaveConfig();
}

void ProWorkflowTools::EnsureSelectionModeActive()
{
	using namespace ProWorkflowTools::Private;

	if (!IsLevelEditorReady() || !IsEditorWorldStable())
	{
		return;
	}

	FEditorModeTools& ModeTools = GLevelEditorModeTools();

	// EM_Default is a fan-out ID, not a real active mode — IsModeActive(EM_Default) is always false.
	if (!ModeTools.IsDefaultModeActive())
	{
		ModeTools.ActivateDefaultMode();
	}
}

void ProWorkflowTools::TerminateInteractiveToolsMouseCapture(FEditorViewportClient* ViewportClient)
{
	if (!ViewportClient)
	{
		return;
	}

	FEditorModeTools* ModeTools = ViewportClient->GetModeTools();
	if (!ModeTools)
	{
		return;
	}

	UModeManagerInteractiveToolsContext* ToolsContext = ModeTools->GetInteractiveToolsContext();
	if (!ToolsContext || !ToolsContext->InputRouter)
	{
		return;
	}

	if (!ToolsContext->InputRouter->HasActiveMouseCapture())
	{
		return;
	}

	// Force-ending the capture also ends mouse-look (OnForceEndCapture → SetIsMouseLooking(false)).
	ToolsContext->InputRouter->ForceTerminateAll();

#if PWT_UE_5_8_OR_LATER
	// A camera capture writes navigation deltas that are only consumed next frame; drop them.
	if (FViewportClientNavigationHelper* Navigation = ViewportClient->GetViewportNavigationHelper())
	{
		Navigation->LocationDelta = FVector::ZeroVector;
		Navigation->RotationDelta = FRotator::ZeroRotator;
		Navigation->OrbitDelta = FVector::ZeroVector;
	}
#endif
}

void ProWorkflowTools::SuspendCameraInteractions(FEditorViewportClient* ViewportClient, FCameraInteractionsSuspension& Out)
{
	ResumeCameraInteractions(Out);

#if PWT_UE_5_8_OR_LATER
	FEditorModeTools* ModeTools = ViewportClient ? ViewportClient->GetModeTools() : nullptr;
	UModeManagerInteractiveToolsContext* ToolsContext = ModeTools ? ModeTools->GetInteractiveToolsContext() : nullptr;
	UViewportInteractionsBehaviorSource* Source = ToolsContext ? ToolsContext->GetViewportInteractionsBehaviorSource() : nullptr;
	if (!Source)
	{
		return;
	}

	using namespace UE::Editor::ViewportInteractions;
	const FName CameraInteractions[] = {
		Zoom, Orbit, PerspectiveViewAngle, PerspectiveDolly, PerspectivePan, PerspectiveMoveYaw,
		OrthographicPan, CameraTranslate, CameraRotate, FOV, DragMovesCamera };
	for (const FName& Name : CameraInteractions)
	{
		UViewportInteraction* Interaction = Source->FindInteraction(Name);
		if (Interaction && Interaction->IsEnabled())
		{
			Interaction->SetEnabled(false);
			Out.Disabled.Add(Interaction);
		}
	}
#endif
}

void ProWorkflowTools::ResumeCameraInteractions(FCameraInteractionsSuspension& InOut)
{
#if PWT_UE_5_8_OR_LATER
	for (const TWeakObjectPtr<UViewportInteraction>& Weak : InOut.Disabled)
	{
		if (UViewportInteraction* Interaction = Weak.Get())
		{
			Interaction->SetEnabled(true);
		}
	}
#endif
	InOut.Disabled.Reset();
}

bool ProWorkflowTools::IsCursorOnTransformGizmo(FEditorViewportClient* ViewportClient, FViewport* Viewport)
{
	FEditorModeTools* ModeTools = ViewportClient ? ViewportClient->GetModeTools() : nullptr;
	if (!ModeTools || !Viewport)
	{
		return false;
	}

	if (!AreEditorGizmosAllowed(ModeTools))
	{
		const HHitProxy* HitProxy = Viewport->GetHitProxy(Viewport->GetMouseX(), Viewport->GetMouseY());
		return HitProxy && HitProxy->IsA(HWidgetAxis::StaticGetType());
	}

	const UModeManagerInteractiveToolsContext* ToolsContext = ModeTools->GetInteractiveToolsContext();
	const UTransformGizmo* Gizmo = ToolsContext && ToolsContext->ToolManager
		? UE::EditorTransformGizmoUtil::FindDefaultTransformGizmo(ToolsContext->ToolManager)
		: nullptr;
	if (!Gizmo || !Gizmo->bVisible || !Gizmo->HitTarget)
	{
		return false;
	}

	const FViewportCursorLocation Cursor = ViewportClient->GetCursorWorldLocationFromMousePos();
	const FInputDeviceRay DeviceRay(
		FRay(Cursor.GetOrigin(), Cursor.GetDirection(), /*bDirectionIsNormalized=*/true),
		FVector2D(Viewport->GetMouseX(), Viewport->GetMouseY()));
	return Gizmo->HitTarget->IsHit(DeviceRay).bHit;
}

bool ProWorkflowTools::AreEditorGizmosAllowed(const FEditorModeTools* ModeTools)
{
#if PWT_UE_5_8_OR_LATER
	return UEditorInteractiveGizmoManager::AreEditorGizmosAllowed(ModeTools);
#else
	(void)ModeTools;
	return UEditorInteractiveGizmoManager::UsesNewTRSGizmos();
#endif
}

namespace ProWorkflowTools::Private
{
	EAxisList::Type TransformGizmoPartAxis(const ETransformGizmoPartIdentifier Part)
	{
		switch (Part)
		{
		case ETransformGizmoPartIdentifier::TranslateAll:
		case ETransformGizmoPartIdentifier::RotateAll:
		case ETransformGizmoPartIdentifier::RotateArcball:
		case ETransformGizmoPartIdentifier::ScaleAll:
		case ETransformGizmoPartIdentifier::ScaleUniform:
			return EAxisList::XYZ;
		case ETransformGizmoPartIdentifier::TranslateScreenSpace:
		case ETransformGizmoPartIdentifier::RotateScreenSpace:
			return EAxisList::Screen;
		case ETransformGizmoPartIdentifier::TranslateXAxis:
		case ETransformGizmoPartIdentifier::RotateXAxis:
		case ETransformGizmoPartIdentifier::RotateXGimbal:
		case ETransformGizmoPartIdentifier::ScaleXAxis:
			return EAxisList::X;
		case ETransformGizmoPartIdentifier::TranslateYAxis:
		case ETransformGizmoPartIdentifier::RotateYAxis:
		case ETransformGizmoPartIdentifier::RotateYGimbal:
		case ETransformGizmoPartIdentifier::ScaleYAxis:
			return EAxisList::Y;
		case ETransformGizmoPartIdentifier::TranslateZAxis:
		case ETransformGizmoPartIdentifier::RotateZAxis:
		case ETransformGizmoPartIdentifier::RotateZGimbal:
		case ETransformGizmoPartIdentifier::ScaleZAxis:
			return EAxisList::Z;
		case ETransformGizmoPartIdentifier::TranslateXYPlanar:
		case ETransformGizmoPartIdentifier::ScaleXYPlanar:
			return EAxisList::XY;
		case ETransformGizmoPartIdentifier::TranslateYZPlanar:
		case ETransformGizmoPartIdentifier::ScaleYZPlanar:
			return EAxisList::YZ;
		case ETransformGizmoPartIdentifier::TranslateXZPlanar:
		case ETransformGizmoPartIdentifier::ScaleXZPlanar:
			return EAxisList::XZ;
		default:
			return EAxisList::None;
		}
	}
}

EAxisList::Type ProWorkflowTools::GetLiveTransformGizmoAxis(
	FTransformGizmoHandleTracker& Tracker, FEditorViewportClient* ViewportClient, FViewport* Viewport, const FEditorModeTools* ModeTools)
{
	if (!AreEditorGizmosAllowed(ModeTools))
	{
		Tracker.Axis = ViewportClient ? ViewportClient->GetCurrentWidgetAxis() : EAxisList::None;
		return Tracker.Axis;
	}

	const UModeManagerInteractiveToolsContext* ToolsContext = ModeTools->GetInteractiveToolsContext();
	const UTransformGizmo* Gizmo = ToolsContext && ToolsContext->ToolManager
		? UE::EditorTransformGizmoUtil::FindDefaultTransformGizmo(ToolsContext->ToolManager)
		: nullptr;
	if (!Gizmo || !Gizmo->bVisible || !Gizmo->HitTarget || !ViewportClient || !Viewport)
	{
		Tracker.Axis = EAxisList::None;
		return Tracker.Axis;
	}

	// A drag holds whichever handle was under the cursor when it began; the cursor leaves the
	// handle as soon as the drag moves, so the hit test is only consulted between drags.
	if (Gizmo->bInInteraction)
	{
		return Tracker.Axis;
	}

	const FViewportCursorLocation Cursor = ViewportClient->GetCursorWorldLocationFromMousePos();
	const FInputDeviceRay DeviceRay(
		FRay(Cursor.GetOrigin(), Cursor.GetDirection(), /*bDirectionIsNormalized=*/true),
		FVector2D(Viewport->GetMouseX(), Viewport->GetMouseY()));
	const FInputRayHit Hit = Gizmo->HitTarget->IsHit(DeviceRay);
	Tracker.Axis = Hit.bHit
		? Private::TransformGizmoPartAxis(static_cast<ETransformGizmoPartIdentifier>(Hit.HitIdentifier))
		: EAxisList::None;
	return Tracker.Axis;
}

void ProWorkflowTools::EndVertexSnap(FVertexSnapFrameQuery& Query)
{
	Query.FrameNumber = MAX_uint64;
	Query.bHasResult = false;
	if (Query.bHelpersDrawn)
	{
		Query.bHelpersDrawn = false;
		FSnappingUtils::ClearSnappingHelpers(/*bClearImmediately=*/true);
	}
}

bool ProWorkflowTools::QueryVertexSnapOncePerFrame(
	FVertexSnapFrameQuery& Query,
	FVector& InOutLocation,
	const FVector2D& MouseLocation,
	FEditorViewportClient* ViewportClient,
	const TSet<TWeakObjectPtr<AActor>>& ActorsToIgnore)
{
	if (!ViewportClient)
	{
		return false;
	}

	if (Query.FrameNumber == GFrameCounter)
	{
		if (Query.bHasResult)
		{
			InOutLocation = Query.Location;
		}
		return Query.bHasResult;
	}

	Query.FrameNumber = GFrameCounter;
	Query.bHasResult = false;
	Query.bHelpersDrawn = true;
	FVector Normal = FVector::ZeroVector;
#if PWT_UE_5_8_OR_LATER
	Query.bHasResult = FSnappingUtils::SnapLocationToNearestVertex(
		InOutLocation,
		MouseLocation,
		ViewportClient,
		Normal,
		/*bDrawVertHelpers=*/true,
		ActorsToIgnore);
#else
	FLevelEditorViewportClient* LevelClient = ViewportClient->IsLevelEditorClient()
		? static_cast<FLevelEditorViewportClient*>(ViewportClient)
		: nullptr;
	if (!LevelClient)
	{
		return false;
	}
	(void)ActorsToIgnore;
	Query.bHasResult = FSnappingUtils::SnapLocationToNearestVertex(
		InOutLocation,
		MouseLocation,
		LevelClient,
		Normal,
		/*bDrawVertHelpers=*/true);
#endif
	Query.Location = InOutLocation;
	return Query.bHasResult;
}

bool ProWorkflowTools::IsSpaceKeyDown(const FViewport* Viewport)
{
#if PLATFORM_WINDOWS
	(void)Viewport;
	return (::GetAsyncKeyState(VK_SPACE) & 0x8000) != 0;
#else
	return Viewport && Viewport->KeyState(EKeys::SpaceBar);
#endif
}

void ProWorkflowTools::SetLevelViewportsCursorOverride(const bool bOverride, const EMouseCursor::Type Cursor)
{
	if (!GEditor)
	{
		return;
	}
	for (FLevelEditorViewportClient* ViewportClient : GEditor->GetLevelViewportClients())
	{
		if (ViewportClient)
		{
			ViewportClient->SetRequiredCursorOverride(bOverride, bOverride ? Cursor : EMouseCursor::Default);
		}
	}
}

int32 ProWorkflowTools::GetHitProxyMaterialIndex(const HActor& Proxy)
{
	const UPrimitiveComponent* Component = Proxy.PrimComponent.Get();
	if (!Component)
	{
		return INDEX_NONE;
	}

	int32 MaterialIndex = Proxy.MaterialIndex;
	const UStaticMeshComponent* StaticMeshComponent = Cast<UStaticMeshComponent>(Component);
	if (StaticMeshComponent && StaticMeshComponent->SceneProxy && StaticMeshComponent->SceneProxy->IsNaniteMesh())
	{
		const UStaticMesh* StaticMesh = StaticMeshComponent->GetStaticMesh();
		const FStaticMeshRenderData* RenderData = StaticMesh ? StaticMesh->GetRenderData() : nullptr;
		if (!RenderData || RenderData->LODResources.IsEmpty()
			|| !RenderData->LODResources[0].Sections.IsValidIndex(Proxy.SectionIndex))
		{
			return INDEX_NONE;
		}
		MaterialIndex = RenderData->LODResources[0].Sections[Proxy.SectionIndex].MaterialIndex;
	}

	return MaterialIndex >= 0 && MaterialIndex < Component->GetNumMaterials() ? MaterialIndex : INDEX_NONE;
}

bool ProWorkflowTools::HasSelectionMovementLocked()
{
	if (!GEditor)
	{
		return false;
	}

#if PWT_UE_5_8_OR_LATER
	PRAGMA_DISABLE_EXPERIMENTAL_WARNINGS
	return GEditor->HasSelectedMovementLockedItems();
	PRAGMA_ENABLE_EXPERIMENTAL_WARNINGS
#else
	return GEditor->HasLockedActors();
#endif
}

void ProWorkflowTools::AdjustPercentageBasedScale(FVector& InOutScale)
{
#if PWT_UE_5_8_OR_LATER
	FSnappingUtils::AdjustPercentageBasedScale(InOutScale);
#else
	if (!InOutScale.IsNearlyZero() && GEditor && GEditor->UsePercentageBasedScaling())
	{
		InOutScale /= 100.0f;
	}
#endif
}

void ProWorkflowTools::GetMaterialUsedTextures(const UMaterialInterface* Material, TArray<UTexture*>& OutTextures)
{
	OutTextures.Reset();
	if (!Material)
	{
		return;
	}

#if PWT_UE_5_7_OR_LATER
	Material->GetUsedTextures(OutTextures, EMaterialQualityLevel::High);
#else
	Material->GetUsedTextures(OutTextures, EMaterialQualityLevel::High, false, ERHIFeatureLevel::SM5, true);
#endif
}

void ProWorkflowTools::SetActorVisibleInEditor(AActor* Actor, bool bVisible)
{
	if (!Actor)
	{
		return;
	}

	// UUnrealEdEngine::SetActorVisibility: transaction only, do not Modify / dirty the package.
	SaveToTransactionBuffer(Actor, false);

#if PWT_UE_5_7_OR_LATER
	Actor->SetIsTemporarilyHiddenInEditor(!bVisible);
#else
	using namespace UE::Editor::DataStorage;

	if (const ICompatibilityProvider* DataStoreCompat = GetDataStorageFeature<ICompatibilityProvider>(CompatibilityFeatureName))
	{
		const RowHandle Row = DataStoreCompat->FindRowWithCompatibleObject(Actor);
		if (ICoreProvider* DataStore = GetMutableDataStorageFeature<ICoreProvider>(StorageFeatureName))
		{
			if (FVisibleInEditorColumn* VisibilityColumn = DataStore->GetColumn<FVisibleInEditorColumn>(Row))
			{
				VisibilityColumn->bIsVisibleInEditor = bVisible;
			}
			DataStore->AddColumn<FTypedElementSyncBackToWorldTag>(Row);
		}
	}
#endif
}

bool ProWorkflowTools::IsActorVisibleInEditor(const AActor* Actor)
{
	if (!Actor)
	{
		return false;
	}

#if PWT_UE_5_7_OR_LATER
	return !Actor->IsHiddenEd();
#else
	using namespace UE::Editor::DataStorage;

	if (const ICompatibilityProvider* DataStoreCompat = GetDataStorageFeature<ICompatibilityProvider>(CompatibilityFeatureName))
	{
		const RowHandle Row = DataStoreCompat->FindRowWithCompatibleObject(Actor);
		if (ICoreProvider* DataStore = GetMutableDataStorageFeature<ICoreProvider>(StorageFeatureName))
		{
			if (const FVisibleInEditorColumn* VisibilityColumn = DataStore->GetColumn<FVisibleInEditorColumn>(Row))
			{
				return VisibilityColumn->bIsVisibleInEditor;
			}
		}
	}

	return !Actor->IsHiddenEd();
#endif
}
