// Copyright © 2026 Trey McNair. All rights reserved.

#include "GridPaint/GridPaintTool.h"
#include "GridPaint/GridPaintToolPrivate.h"
#include "GridPaint/GridPaintTileBoundsUserData.h"
#include "ProWorkflowToolsEngineAdapter.h"
#include "ProWorkflowToolsSettings.h"
#include "Viewport/ViewportOverlayStyle.h"

#include "Components/DecalComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Editor.h"
#include "EditorViewportClient.h"
#include "Engine/DecalActor.h"
#include "Engine/StaticMesh.h"
#include "EngineUtils.h"
#include "PrimitiveDrawingUtils.h"
#include "SceneView.h"
#include "SnappingUtils.h"

#define LOCTEXT_NAMESPACE "ProWorkflowTools"

///////////////////////////////////////////////////////////////////////////////
// Tile bounds edit (B)

FVector FGridPaintTool::WorldToGridCm(const FVector& World) const
{
	return Context.GridRotation.UnrotateVector(World - Context.PivotWorld);
}

FVector FGridPaintTool::GridCmToWorld(const FVector& GridCm) const
{
	return Context.PivotWorld + Context.GridRotation.RotateVector(GridCm);
}

FVector FGridPaintTool::GetEditBoundsFaceCenterWorld(int32 Axis, int32 Sign) const
{
	FVector Local = EditBoundsGridLocal.GetCenter();
	Local[Axis] = (Sign > 0) ? EditBoundsGridLocal.Max[Axis] : EditBoundsGridLocal.Min[Axis];
	return GridCmToWorld(Local);
}

bool FGridPaintTool::ComputeAxisDragParam(
	FEditorViewportClient* ViewportClient,
	int32 MouseX,
	int32 MouseY,
	const FVector& AxisOrigin,
	const FVector& AxisDir,
	double& OutParam) const
{
	if (!ViewportClient || !ViewportClient->Viewport)
	{
		return false;
	}

	FSceneViewFamilyContext ViewFamily(FSceneViewFamily::ConstructionValues(
		ViewportClient->Viewport,
		ViewportClient->GetScene(),
		ViewportClient->EngineShowFlags)
		.SetRealtimeUpdate(ViewportClient->IsRealtime()));
	FSceneView* View = ViewportClient->CalcSceneView(&ViewFamily);
	if (!View)
	{
		return false;
	}

	const FViewportCursorLocation Cursor(View, ViewportClient, MouseX, MouseY);
	const FVector RayOrigin = Cursor.GetOrigin();
	const FVector RayDir = Cursor.GetDirection();

	const FVector W0 = AxisOrigin - RayOrigin;
	const double B = FVector::DotProduct(AxisDir, RayDir);
	const double D = FVector::DotProduct(AxisDir, W0);
	const double E = FVector::DotProduct(RayDir, W0);
	const double Denom = 1.0 - B * B;
	if (FMath::Abs(Denom) < UE_DOUBLE_SMALL_NUMBER)
	{
		return false;
	}

	OutParam = (E * B - D) / Denom;
	return true;
}

bool FGridPaintTool::PickEditBoundsFace(
	FEditorViewportClient* ViewportClient,
	int32 MouseX,
	int32 MouseY,
	int32& OutAxis,
	int32& OutSign) const
{
	OutAxis = INDEX_NONE;
	OutSign = 0;
	if (!ViewportClient || !ViewportClient->Viewport || !EditBoundsGridLocal.IsValid)
	{
		return false;
	}

	FSceneViewFamilyContext ViewFamily(FSceneViewFamily::ConstructionValues(
		ViewportClient->Viewport,
		ViewportClient->GetScene(),
		ViewportClient->EngineShowFlags)
		.SetRealtimeUpdate(ViewportClient->IsRealtime()));
	FSceneView* View = ViewportClient->CalcSceneView(&ViewFamily);
	if (!View)
	{
		return false;
	}

	const FVector2D Mouse(MouseX, MouseY);
	float BestDistSq = FMath::Square(GridPaint::Private::BoundsEditFacePickPixels);
	bool bFound = false;

	for (int32 Axis = 0; Axis < 3; ++Axis)
	{
		for (int32 Sign = -1; Sign <= 1; Sign += 2)
		{
			const FVector World = GetEditBoundsFaceCenterWorld(Axis, Sign);
			FVector2D Screen;
			if (!View->WorldToPixel(World, Screen))
			{
				continue;
			}
			const float DistSq = FVector2D::DistSquared(Screen, Mouse);
			if (DistSq < BestDistSq)
			{
				BestDistSq = DistSq;
				OutAxis = Axis;
				OutSign = Sign;
				bFound = true;
			}
		}
	}
	return bFound;
}

void FGridPaintTool::EnterBoundsEdit()
{
	if (!bActive || bStrokeActive || bBoundsEditActive)
	{
		return;
	}

	EditBoundsGridLocal = Context.MeshBoundsGridLocal.IsValid
		? Context.MeshBoundsGridLocal
		: FBox(-Context.CellSize * 0.5, Context.CellSize * 0.5);
	bBoundsEditActive = true;
	bBoundsFaceDrag = false;
	BoundsHoverAxis = INDEX_NONE;
	BoundsHoverSign = 0;
	BoundsEditUndoStack.Reset();
	BoundsEditRedoStack.Reset();
	SetGhostVisible(false);
	if (GEditor)
	{
		GEditor->RedrawLevelEditingViewports();
	}
}

void FGridPaintTool::ResetBoundsEditToSourceGeometry()
{
	if (!bBoundsEditActive || bBoundsFaceDrag)
	{
		return;
	}

	AActor* Source = Context.SourceActor.Get();
	if (!Source)
	{
		return;
	}

	auto AccumulateGridLocalBox = [this](const FBox& LocalBounds, const FTransform& CompWorld) -> FBox
	{
		FBox GridLocal(ForceInit);
		const FVector Corners[8] = {
			FVector(LocalBounds.Min.X, LocalBounds.Min.Y, LocalBounds.Min.Z),
			FVector(LocalBounds.Min.X, LocalBounds.Min.Y, LocalBounds.Max.Z),
			FVector(LocalBounds.Min.X, LocalBounds.Max.Y, LocalBounds.Min.Z),
			FVector(LocalBounds.Min.X, LocalBounds.Max.Y, LocalBounds.Max.Z),
			FVector(LocalBounds.Max.X, LocalBounds.Min.Y, LocalBounds.Min.Z),
			FVector(LocalBounds.Max.X, LocalBounds.Min.Y, LocalBounds.Max.Z),
			FVector(LocalBounds.Max.X, LocalBounds.Max.Y, LocalBounds.Min.Z),
			FVector(LocalBounds.Max.X, LocalBounds.Max.Y, LocalBounds.Max.Z),
		};
		for (const FVector& LocalCorner : Corners)
		{
			const FVector World = CompWorld.TransformPosition(LocalCorner);
			GridLocal += Context.GridRotation.UnrotateVector(World - Context.PivotWorld);
		}
		return GridLocal;
	};

	FBox ResetBox(ForceInit);
	if (Context.bIsDecalSource)
	{
		if (UDecalComponent* Decal = GetSourceDecalComponent(Source))
		{
			const FVector AbsHalfExtents = Decal->DecalSize.GetAbs();
			ResetBox = AccumulateGridLocalBox(FBox(-AbsHalfExtents, AbsHalfExtents), Decal->GetComponentTransform());
		}
	}
	else if (UStaticMeshComponent* MeshComp = GetSourceStaticMeshComponent(Source))
	{
		if (UStaticMesh* Mesh = MeshComp->GetStaticMesh())
		{
			// Geometric mesh AABB only — do not read UGridPaintTileBoundsUserData.
			ResetBox = AccumulateGridLocalBox(Mesh->GetBounds().GetBox(), MeshComp->GetComponentTransform());
		}
	}

	if (!ResetBox.IsValid)
	{
		ResetBox = FBox(-Context.CellSize * 0.5, Context.CellSize * 0.5);
	}

	if (!(ResetBox == EditBoundsGridLocal))
	{
		RecordBoundsEditStep(EditBoundsGridLocal);
	}
	EditBoundsGridLocal = ResetBox;
	BoundsHoverAxis = INDEX_NONE;
	BoundsHoverSign = 0;
	FeedbackLabel.Show(
		Context.bIsDecalSource ? LOCTEXT("GridPaintBoundsResetDecal", "Reset to decal") : LOCTEXT("GridPaintBoundsResetMesh", "Reset to mesh"),
		GridPaint::Private::BoundsEditWireColor);
}

void FGridPaintTool::RecordBoundsEditStep(const FBox& Before)
{
	if (BoundsEditUndoStack.Num() >= GridPaint::Private::MaxBoundsEditHistory)
	{
		BoundsEditUndoStack.RemoveAt(0);
	}
	BoundsEditUndoStack.Push(Before);
	BoundsEditRedoStack.Reset();
}

void FGridPaintTool::StepBoundsEditHistory(const bool bRedo)
{
	TArray<FBox>& From = bRedo ? BoundsEditRedoStack : BoundsEditUndoStack;
	TArray<FBox>& To = bRedo ? BoundsEditUndoStack : BoundsEditRedoStack;
	if (From.IsEmpty())
	{
		FeedbackLabel.Show(
			bRedo ? LOCTEXT("GridPaintBoundsNothingToRedo", "Nothing to redo") : LOCTEXT("GridPaintBoundsNothingToUndo", "Nothing to undo"),
			ProWorkflowTools::OverlayStyle::Neutral);
		return;
	}

	To.Push(EditBoundsGridLocal);
	EditBoundsGridLocal = From.Pop();
	BoundsHoverAxis = INDEX_NONE;
	BoundsHoverSign = 0;
	FeedbackLabel.Show(
		bRedo ? LOCTEXT("GridPaintBoundsRedo", "Redo") : LOCTEXT("GridPaintBoundsUndo", "Undo"),
		GridPaint::Private::BoundsEditWireColor);
}

void FGridPaintTool::ExitBoundsEdit(bool bCommit)
{
	if (!bBoundsEditActive)
	{
		return;
	}

	if (bBoundsFaceDrag)
	{
		EndBoundsFaceDrag();
	}

	if (bCommit && EditBoundsGridLocal.IsValid)
	{
		Context.MeshBoundsGridLocal = EditBoundsGridLocal;
		const FVector Size = EditBoundsGridLocal.GetSize();
		Context.CellSize = FVector(
			FMath::Max(Size.X, GridPaint::Private::MinCellSize),
			FMath::Max(Size.Y, GridPaint::Private::MinCellSize),
			FMath::Max(Size.Z, GridPaint::Private::MinCellSize));

		// Mesh AssetUserData write is one editor Ctrl+Z step. Draft face drags and resets have their
		// own history inside bounds edit and are discarded with it.
		if (GetSourceStaticMeshComponent(Context.SourceActor.Get()))
		{
			FScopedTransaction Transaction(LOCTEXT("GridPaintTileBoundsTransaction", "Grid Paint Tile Bounds"));
			SaveTileBoundsToSourceMesh();
		}

		CellBlockedCache.Reset();
		FeedbackLabel.Show(LOCTEXT("GridPaintBoundsAppliedLabel", "Bounds applied"), ProWorkflowTools::OverlayStyle::Accent());
	}

	bBoundsEditActive = false;
	bBoundsFaceDrag = false;
	BoundsHoverAxis = INDEX_NONE;
	BoundsHoverSign = 0;
	EditBoundsGridLocal = FBox(ForceInit);
	if (GEditor)
	{
		GEditor->RedrawLevelEditingViewports();
	}
}

void FGridPaintTool::UpdateBoundsFaceHover(FEditorViewportClient* ViewportClient, int32 MouseX, int32 MouseY)
{
	if (bBoundsFaceDrag)
	{
		return;
	}
	int32 Axis = INDEX_NONE;
	int32 Sign = 0;
	if (PickEditBoundsFace(ViewportClient, MouseX, MouseY, Axis, Sign))
	{
		BoundsHoverAxis = Axis;
		BoundsHoverSign = Sign;
	}
	else
	{
		BoundsHoverAxis = INDEX_NONE;
		BoundsHoverSign = 0;
	}
}

bool FGridPaintTool::BeginBoundsFaceDrag(FEditorViewportClient* ViewportClient, FViewport* Viewport)
{
	if (!bBoundsEditActive || bBoundsFaceDrag || !ViewportClient || !Viewport)
	{
		return false;
	}

	int32 Axis = INDEX_NONE;
	int32 Sign = 0;
	if (!PickEditBoundsFace(ViewportClient, Viewport->GetMouseX(), Viewport->GetMouseY(), Axis, Sign))
	{
		return false;
	}

	BoundsDragAxis = Axis;
	BoundsDragSign = Sign;
	BoundsDragAxisWorld = Context.GridRotation.RotateVector(
		FVector(Axis == 0 ? 1.0 : 0.0, Axis == 1 ? 1.0 : 0.0, Axis == 2 ? 1.0 : 0.0));
	BoundsDragHandleStartWorld = GetEditBoundsFaceCenterWorld(Axis, Sign);
	BoundsDragAnchorGridCm = (Sign > 0)
		? EditBoundsGridLocal.Min[Axis]
		: EditBoundsGridLocal.Max[Axis];

	if (!ComputeAxisDragParam(
		ViewportClient,
		Viewport->GetMouseX(),
		Viewport->GetMouseY(),
		BoundsDragHandleStartWorld,
		BoundsDragAxisWorld,
		BoundsDragStartParam))
	{
		return false;
	}

	bBoundsFaceDrag = true;
	BoundsDragStartBox = EditBoundsGridLocal;
	BoundsHoverAxis = Axis;
	BoundsHoverSign = Sign;
	return true;
}

void FGridPaintTool::UpdateBoundsFaceDrag(FEditorViewportClient* ViewportClient, int32 MouseX, int32 MouseY)
{
	if (!bBoundsFaceDrag || !ViewportClient || BoundsDragAxis == INDEX_NONE)
	{
		return;
	}

	double FaceGridCm = 0.0;
	const bool bVertexSnap = ViewportClient->Viewport
		&& ViewportClient->Viewport->KeyState(EKeys::V);

	if (!bVertexSnap)
	{
		ProWorkflowTools::EndVertexSnap(BoundsVertexSnapQuery);

		double Param = 0.0;
		if (!ComputeAxisDragParam(
			ViewportClient,
			MouseX,
			MouseY,
			BoundsDragHandleStartWorld,
			BoundsDragAxisWorld,
			Param))
		{
			return;
		}

		double DragDistance = Param - BoundsDragStartParam;
		// Same as Box Scale: honor editor translation grid snap along the face axis.
		if (GEditor && FSnappingUtils::IsSnapToGridEnabled())
		{
			DragDistance = FMath::GridSnap(DragDistance, (double)GEditor->GetGridSize());
		}
		const FVector NewHandleWorld = BoundsDragHandleStartWorld + BoundsDragAxisWorld * DragDistance;
		FaceGridCm = WorldToGridCm(NewHandleWorld)[BoundsDragAxis];
	}
	else
	{
		// Hold V: snap the dragged face to the nearest mesh vertex (projected onto this axis).
		FVector SnapLocation = BoundsDragHandleStartWorld;
		TSet<TWeakObjectPtr<AActor>> Ignore;
		if (AActor* Ghost = GhostActor.Get())
		{
			Ignore.Add(Ghost);
		}
		const bool bSnapped = ProWorkflowTools::QueryVertexSnapOncePerFrame(
			BoundsVertexSnapQuery,
			SnapLocation,
			FVector2D(MouseX, MouseY),
			ViewportClient,
			Ignore);
		if (!bSnapped)
		{
			return;
		}
		FaceGridCm = WorldToGridCm(SnapLocation)[BoundsDragAxis];
	}

	const double MinSpan = GridPaint::Private::MinCellSize;
	if (BoundsDragSign > 0)
	{
		EditBoundsGridLocal.Max[BoundsDragAxis] = FMath::Max(FaceGridCm, BoundsDragAnchorGridCm + MinSpan);
	}
	else
	{
		EditBoundsGridLocal.Min[BoundsDragAxis] = FMath::Min(FaceGridCm, BoundsDragAnchorGridCm - MinSpan);
	}
}

void FGridPaintTool::EndBoundsFaceDrag()
{
	if (!(EditBoundsGridLocal == BoundsDragStartBox))
	{
		RecordBoundsEditStep(BoundsDragStartBox);
	}
	ProWorkflowTools::EndVertexSnap(BoundsVertexSnapQuery);
	bBoundsFaceDrag = false;
	BoundsDragAxis = INDEX_NONE;
	BoundsDragSign = 0;
}

void FGridPaintTool::DrawBoundsEditPreview(const FSceneView* View, FPrimitiveDrawInterface* PDI) const
{
	if (!PDI || !EditBoundsGridLocal.IsValid)
	{
		return;
	}

	const FVector Radii = EditBoundsGridLocal.GetExtent();
	const FVector WorldCenter = GridCmToWorld(EditBoundsGridLocal.GetCenter());
	const FVector AxisX = Context.GridRotation.RotateVector(FVector::ForwardVector);
	const FVector AxisY = Context.GridRotation.RotateVector(FVector::RightVector);
	const FVector AxisZ = Context.GridRotation.RotateVector(FVector::UpVector);

	const FLinearColor Wire = GridPaint::Private::BoundsEditWireColor;
	const FLinearColor XRay = Wire.CopyWithNewOpacity(Wire.A * GridPaint::Private::OverlayXRayOpacityScale);
	DrawOrientedWireBox(
		PDI, WorldCenter, AxisX, AxisY, AxisZ, Radii, Wire, SDPG_World, GridPaint::Private::BoundsEditWireThickness, 0.0f, /*bScreenSpace=*/true);
	DrawOrientedWireBox(
		PDI, WorldCenter, AxisX, AxisY, AxisZ, Radii, XRay, SDPG_Foreground, GridPaint::Private::BoundsEditWireThickness, 0.0f, /*bScreenSpace=*/true);

	for (int32 Axis = 0; Axis < 3; ++Axis)
	{
		for (int32 Sign = -1; Sign <= 1; Sign += 2)
		{
			const bool bHot = (Axis == BoundsHoverAxis && Sign == BoundsHoverSign)
				|| (bBoundsFaceDrag && Axis == BoundsDragAxis && Sign == BoundsDragSign);
			const FLinearColor HandleColor = bHot
				? GridPaint::Private::BoundsEditHoverFaceColor
				: Wire;
			const float Size = bHot
				? GridPaint::Private::BoundsEditHandleSize * 1.35f
				: GridPaint::Private::BoundsEditHandleSize;
			const FVector FaceCenter = GetEditBoundsFaceCenterWorld(Axis, Sign);
			PDI->DrawPoint(FaceCenter, HandleColor, Size, SDPG_Foreground);
		}
	}
}

FBox FGridPaintTool::ResolveMeshLocalTileBounds(const UStaticMeshComponent* MeshComp)
{
	if (!MeshComp || !MeshComp->GetStaticMesh())
	{
		return FBox(ForceInit);
	}

	UStaticMesh* Mesh = MeshComp->GetStaticMesh();
	if (const UGridPaintTileBoundsUserData* Stored =
		Cast<UGridPaintTileBoundsUserData>(Mesh->GetAssetUserDataOfClass(UGridPaintTileBoundsUserData::StaticClass())))
	{
		const FBox StoredBox = Stored->GetBox();
		if (StoredBox.IsValid)
		{
			return StoredBox;
		}
	}

	return Mesh->GetBounds().GetBox();
}

void FGridPaintTool::ReloadTileBoundsFromSourceMesh()
{
	if (Context.bIsDecalSource)
	{
		return;
	}

	AActor* Source = Context.SourceActor.Get();
	UStaticMeshComponent* MeshComp = GetSourceStaticMeshComponent(Source);
	if (!MeshComp || !MeshComp->GetStaticMesh())
	{
		return;
	}

	const FBox MeshLocalBounds = ResolveMeshLocalTileBounds(MeshComp);
	const FVector LocalBoundsSize = MeshLocalBounds.GetSize();
	const FVector AbsScale = MeshComp->GetComponentTransform().GetScale3D().GetAbs();
	Context.CellSize = FVector(
		FMath::Max(LocalBoundsSize.X * AbsScale.X, GridPaint::Private::MinCellSize),
		FMath::Max(LocalBoundsSize.Y * AbsScale.Y, GridPaint::Private::MinCellSize),
		FMath::Max(LocalBoundsSize.Z * AbsScale.Z, GridPaint::Private::MinCellSize));

	FBox GridLocalBounds(ForceInit);
	const FTransform CompWorld = MeshComp->GetComponentTransform();
	const FVector Corners[8] = {
		FVector(MeshLocalBounds.Min.X, MeshLocalBounds.Min.Y, MeshLocalBounds.Min.Z),
		FVector(MeshLocalBounds.Min.X, MeshLocalBounds.Min.Y, MeshLocalBounds.Max.Z),
		FVector(MeshLocalBounds.Min.X, MeshLocalBounds.Max.Y, MeshLocalBounds.Min.Z),
		FVector(MeshLocalBounds.Min.X, MeshLocalBounds.Max.Y, MeshLocalBounds.Max.Z),
		FVector(MeshLocalBounds.Max.X, MeshLocalBounds.Min.Y, MeshLocalBounds.Min.Z),
		FVector(MeshLocalBounds.Max.X, MeshLocalBounds.Min.Y, MeshLocalBounds.Max.Z),
		FVector(MeshLocalBounds.Max.X, MeshLocalBounds.Max.Y, MeshLocalBounds.Min.Z),
		FVector(MeshLocalBounds.Max.X, MeshLocalBounds.Max.Y, MeshLocalBounds.Max.Z),
	};
	for (const FVector& LocalCorner : Corners)
	{
		const FVector World = CompWorld.TransformPosition(LocalCorner);
		GridLocalBounds += Context.GridRotation.UnrotateVector(World - Context.PivotWorld);
	}
	Context.MeshBoundsGridLocal = GridLocalBounds;
	CellBlockedCache.Reset();
}

void FGridPaintTool::SaveTileBoundsToSourceMesh() const
{
	AActor* Source = Context.SourceActor.Get();
	UStaticMeshComponent* MeshComp = GetSourceStaticMeshComponent(Source);
	UStaticMesh* Mesh = MeshComp ? MeshComp->GetStaticMesh() : nullptr;
	if (!Mesh || !Context.MeshBoundsGridLocal.IsValid)
	{
		return;
	}

	// Convert grid-local cm AABB → mesh local (same space as UStaticMesh bounds).
	FBox MeshLocal(ForceInit);
	const FTransform CompWorld = MeshComp->GetComponentTransform();
	const FVector Mins = Context.MeshBoundsGridLocal.Min;
	const FVector Maxs = Context.MeshBoundsGridLocal.Max;
	const FVector Corners[8] = {
		FVector(Mins.X, Mins.Y, Mins.Z), FVector(Mins.X, Mins.Y, Maxs.Z),
		FVector(Mins.X, Maxs.Y, Mins.Z), FVector(Mins.X, Maxs.Y, Maxs.Z),
		FVector(Maxs.X, Mins.Y, Mins.Z), FVector(Maxs.X, Mins.Y, Maxs.Z),
		FVector(Maxs.X, Maxs.Y, Mins.Z), FVector(Maxs.X, Maxs.Y, Maxs.Z),
	};
	for (const FVector& GridCm : Corners)
	{
		MeshLocal += CompWorld.InverseTransformPosition(GridCmToWorld(GridCm));
	}
	if (!MeshLocal.IsValid)
	{
		return;
	}

	Mesh->Modify();
	UGridPaintTileBoundsUserData* UserData = Cast<UGridPaintTileBoundsUserData>(
		Mesh->GetAssetUserDataOfClass(UGridPaintTileBoundsUserData::StaticClass()));
	if (!UserData)
	{
		UserData = NewObject<UGridPaintTileBoundsUserData>(Mesh, NAME_None, RF_Public | RF_Transactional);
		Mesh->AddAssetUserData(UserData);
	}
	UserData->Modify();
	UserData->SetBox(MeshLocal);
	Mesh->MarkPackageDirty();
}

#undef LOCTEXT_NAMESPACE
