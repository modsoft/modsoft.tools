// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "CoreMinimal.h"

class FCanvas;

/** The short-lived text label tools draw next to the cursor after an action. One style for every tool. */
namespace ProWorkflowTools::CursorLabel
{
	/** Total lifetime; the last FadeSeconds fade out. */
	constexpr float VisibleSeconds = 1.0f;
	constexpr float FadeSeconds = 0.3f;

	struct FLine
	{
		FText Text;
		FLinearColor Color;
	};

	/** Opacity for a label shown ElapsedSeconds ago; 0 once expired. */
	float GetAlpha(float ElapsedSeconds);

	/** Readout number: rounded to 0.1, no trailing ".0" (128, 12.5). */
	FString FormatAmount(double Value);

	/** Draws Lines top to bottom, down-right of MousePixel (viewport pixels). */
	void Draw(FCanvas* Canvas, const FIntPoint& MousePixel, TConstArrayView<FLine> Lines, float Alpha);

	/** One label slot that fades out after Show(). The text is fixed when shown. */
	class FFadingLabel
	{
	public:
		void Show(const FText& Text, const FLinearColor& Color);
		void Show(TConstArrayView<FLine> InLines);
		void Clear();

		/**
		 * Call once per tick. True while the label is visible and on the tick it expires, so
		 * Realtime-off viewports redraw the frame that removes it.
		 */
		bool TickNeedsRedraw();

		void Draw(FCanvas* Canvas, const FIntPoint& MousePixel) const;

	private:
		TArray<FLine, TInlineAllocator<2>> Lines;
		double StartSeconds = -1.0;
	};
}
