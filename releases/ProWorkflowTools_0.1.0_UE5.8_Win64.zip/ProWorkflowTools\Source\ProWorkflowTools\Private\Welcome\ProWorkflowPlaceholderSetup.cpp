// Copyright © 2026 Trey McNair. All rights reserved.

#include "Welcome/ProWorkflowPlaceholderSetup.h"

#include "AssetToolsModule.h"
#include "CollectionManagerModule.h"
#include "CollectionManagerTypes.h"
#include "DecalPlacement/InteractiveDecalPlacementCollectionUtils.h"
#include "Factories/MaterialFactoryNew.h"
#include "IAssetTools.h"
#include "ICollectionContainer.h"
#include "ICollectionManager.h"
#include "ISourceControlModule.h"
#include "MaterialDomain.h"
#include "MaterialEditingLibrary.h"
#include "Materials/Material.h"
#include "Materials/MaterialExpressionConstant.h"
#include "Materials/MaterialExpressionConstant3Vector.h"
#include "Misc/PackageName.h"
#include "ProWorkflowToolsSettings.h"
#include "UObject/Package.h"
#include "UObject/SavePackage.h"

#define LOCTEXT_NAMESPACE "ProWorkflowPlaceholderSetup"

namespace ProWorkflowPlaceholderSetup
{
	namespace Private
	{
		static const FName ExampleCollectionName(TEXT("PWF_ExampleDecals"));
		static const FString ProjectExamplePackageDir(TEXT("/Game/ProWorkflowTools"));
		static const FString ExampleMaterialAssetName(TEXT("M_PWF_ExampleDecal"));
		static const FString ProjectExampleMaterialPath(TEXT("/Game/ProWorkflowTools/M_PWF_ExampleDecal"));

		static void NotifySettingsChanged(UProWorkflowToolsUserSettings& Settings, FProperty* Property)
		{
			Settings.NotifyAndPersist(Property);
		}

		static bool IsFullyLoadedMaterial(const UMaterial* Material)
		{
			const UPackage* Package = Material ? Material->GetOutermost() : nullptr;
			return Package && Package->IsFullyLoaded();
		}

		static UMaterial* TryLoadFullyLoadedMaterial(const FString& ObjectPath)
		{
			UMaterial* Material = LoadObject<UMaterial>(nullptr, *ObjectPath, nullptr, LOAD_NoWarn | LOAD_Quiet);
			return IsFullyLoadedMaterial(Material) ? Material : nullptr;
		}

		static void EnsureDecalDomain(UMaterial& Material)
		{
			if (Material.MaterialDomain != MD_DeferredDecal)
			{
				Material.MaterialDomain = MD_DeferredDecal;
				Material.BlendMode = BLEND_Translucent;
				Material.MarkPackageDirty();
			}
		}

		static void SaveIfFullyLoaded(UMaterial& Material)
		{
			UPackage* Package = Material.GetOutermost();
			if (!Package || !Package->IsFullyLoaded())
			{
				return;
			}

			const FString PackageFilename = FPackageName::LongPackageNameToFilename(
				Package->GetName(),
				FPackageName::GetAssetPackageExtension());
			FSavePackageArgs SaveArgs;
			SaveArgs.TopLevelFlags = RF_Public | RF_Standalone;
			UPackage::SavePackage(Package, &Material, *PackageFilename, SaveArgs);
		}

		static UMaterial* CreateProjectExampleDecalMaterial(FText* OutStatusMessage)
		{
			IAssetTools& AssetTools = FModuleManager::LoadModuleChecked<FAssetToolsModule>("AssetTools").Get();
			UMaterialFactoryNew* Factory = NewObject<UMaterialFactoryNew>();
			UObject* NewAsset = AssetTools.CreateAsset(
				ExampleMaterialAssetName,
				ProjectExamplePackageDir,
				UMaterial::StaticClass(),
				Factory);

			UMaterial* Material = Cast<UMaterial>(NewAsset);
			if (!Material || !IsFullyLoadedMaterial(Material))
			{
				if (OutStatusMessage)
				{
					*OutStatusMessage = LOCTEXT(
						"CreateMaterialFailed",
						"Could not create /Game/ProWorkflowTools/M_PWF_ExampleDecal.");
				}
				return nullptr;
			}

			Material->MaterialDomain = MD_DeferredDecal;
			Material->BlendMode = BLEND_Translucent;

			UMaterialExpressionConstant3Vector* ColorExpr = Cast<UMaterialExpressionConstant3Vector>(
				UMaterialEditingLibrary::CreateMaterialExpression(
					Material,
					UMaterialExpressionConstant3Vector::StaticClass(),
					-300,
					0));
			if (ColorExpr)
			{
				ColorExpr->Constant = FLinearColor(0.85f, 0.45f, 0.15f);
				UMaterialEditingLibrary::ConnectMaterialProperty(ColorExpr, TEXT(""), MP_BaseColor);
			}

			UMaterialExpressionConstant* OpacityExpr = Cast<UMaterialExpressionConstant>(
				UMaterialEditingLibrary::CreateMaterialExpression(
					Material,
					UMaterialExpressionConstant::StaticClass(),
					-300,
					160));
			if (OpacityExpr)
			{
				OpacityExpr->R = 0.75f;
				UMaterialEditingLibrary::ConnectMaterialProperty(OpacityExpr, TEXT(""), MP_Opacity);
			}

			UMaterialEditingLibrary::LayoutMaterialExpressions(Material);
			UMaterialEditingLibrary::RecompileMaterial(Material);
			Material->MarkPackageDirty();
			SaveIfFullyLoaded(*Material);
			return Material;
		}

		static UMaterial* LoadOrCreateExampleDecalMaterial(FText* OutStatusMessage)
		{
			// Host project owns this asset. Plugin Content is shared across engine versions;
			// loading or saving a 5.8 uasset there from 5.6 is a partial-load fatal.
			if (UMaterial* Existing = TryLoadFullyLoadedMaterial(ProjectExampleMaterialPath))
			{
				EnsureDecalDomain(*Existing);
				return Existing;
			}

			return CreateProjectExampleDecalMaterial(OutStatusMessage);
		}

		static bool EnsureCollectionContainsMaterial(UMaterial& Material, ECollectionShareType::Type& OutShareType, FText* OutStatusMessage)
		{
			if (!FCollectionManagerModule::IsModuleAvailable())
			{
				if (OutStatusMessage)
				{
					*OutStatusMessage = LOCTEXT("NoCollectionManager", "Collection Manager is not available.");
				}
				return false;
			}

			const TSharedRef<ICollectionContainer>& Container =
				FCollectionManagerModule::GetModule().Get().GetProjectCollectionContainer();

			// Reuse any existing scope. A new collection is Shared (lives in Content/Collections with the
			// project) when revision control is on; the engine refuses to save Shared or Private collections
			// without it, so otherwise it is Local (Saved/Collections, this machine only).
			ECollectionShareType::Type ShareType = ISourceControlModule::Get().IsEnabled()
				? ECollectionShareType::CST_Shared
				: ECollectionShareType::CST_Local;
			const ECollectionShareType::Type ExistingShareTypes[] =
			{
				ECollectionShareType::CST_Shared,
				ECollectionShareType::CST_Local,
				ECollectionShareType::CST_Private
			};
			bool bExists = false;
			for (const ECollectionShareType::Type ExistingShareType : ExistingShareTypes)
			{
				if (Container->CollectionExists(ExampleCollectionName, ExistingShareType))
				{
					ShareType = ExistingShareType;
					bExists = true;
					break;
				}
			}

			if (!bExists)
			{
				FText CreateError;
				if (!Container->CreateCollection(
					ExampleCollectionName,
					ShareType,
					ECollectionStorageMode::Static,
					&CreateError))
				{
					if (OutStatusMessage)
					{
						*OutStatusMessage = CreateError.IsEmpty()
							? LOCTEXT("CreateCollectionFailed", "Could not create collection PWF_ExampleDecals.")
							: CreateError;
					}
					return false;
				}
			}

			OutShareType = ShareType;

			const FSoftObjectPath MaterialPath(&Material);
			TArray<FSoftObjectPath> ExistingPaths;
			if (Container->GetAssetsInCollection(
				ExampleCollectionName,
				ShareType,
				ExistingPaths,
				ECollectionRecursionFlags::Self)
				&& ExistingPaths.Contains(MaterialPath))
			{
				return true;
			}

			FText AddError;
			if (!Container->AddToCollection(ExampleCollectionName, ShareType, MaterialPath, &AddError))
			{
				if (OutStatusMessage)
				{
					*OutStatusMessage = AddError.IsEmpty()
						? LOCTEXT("AddToCollectionFailed", "Could not add example decal to PWF_ExampleDecals.")
						: AddError;
				}
				return false;
			}

			return true;
		}

		static void WireCollectionIntoSettings()
		{
			UProWorkflowToolsUserSettings* Settings = GetMutableDefault<UProWorkflowToolsUserSettings>();
			if (!Settings)
			{
				return;
			}

			Settings->ImportProjectCollectionEntriesIfNeeded();
			for (const FInteractiveDecalCollectionEntry& Entry : Settings->CollectionEntries)
			{
				if (Entry.CollectionName == ExampleCollectionName)
				{
					return;
				}
			}

			FInteractiveDecalCollectionEntry NewEntry;
			NewEntry.bEnabled = true;
			NewEntry.CollectionName = ExampleCollectionName;
			NewEntry.bIncludeChildCollections = false;
			Settings->CollectionEntries.Add(NewEntry);

			FProperty* Property = FindFProperty<FProperty>(
				UProWorkflowToolsUserSettings::StaticClass(),
				GET_MEMBER_NAME_CHECKED(UProWorkflowToolsUserSettings, CollectionEntries));
			NotifySettingsChanged(*Settings, Property);
		}
	}

	bool EnsureExampleDecalCollection(FText* OutStatusMessage)
	{
		UMaterial* Material = Private::LoadOrCreateExampleDecalMaterial(OutStatusMessage);
		if (!Material)
		{
			return false;
		}

		ECollectionShareType::Type ShareType = ECollectionShareType::CST_Local;
		if (!Private::EnsureCollectionContainsMaterial(*Material, ShareType, OutStatusMessage))
		{
			return false;
		}

		Private::WireCollectionIntoSettings();

		if (OutStatusMessage)
		{
			*OutStatusMessage = ShareType == ECollectionShareType::CST_Local
				? LOCTEXT("SetupOkLocal", "Ready: example decal material + Local collection PWF_ExampleDecals (Shared needs revision control).")
				: LOCTEXT("SetupOk", "Ready: example decal material + collection PWF_ExampleDecals.");
		}
		return true;
	}
}

#undef LOCTEXT_NAMESPACE
