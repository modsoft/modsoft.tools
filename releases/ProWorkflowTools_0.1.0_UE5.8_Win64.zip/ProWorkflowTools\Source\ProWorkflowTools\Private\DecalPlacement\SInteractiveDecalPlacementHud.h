// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "Widgets/SCompoundWidget.h"

class FInteractiveDecalPlacementEdMode;
class SProWorkflowToolHud;
struct FProWorkflowToolHudModel;

/**
 * Decal Placement HUD: composes SProWorkflowToolHud with a Collections popover
 * and a static keycap model (same labels in preview and drag).
 */
class SInteractiveDecalPlacementHud : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SInteractiveDecalPlacementHud) {}
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs);

	/** True when the absolute cursor position is over the visible HUD panel border. */
	bool IsPointerOverPanel() const;

private:
	FInteractiveDecalPlacementEdMode* GetPlacementMode() const;
	FProWorkflowToolHudModel BuildHudModel() const;

	TSharedRef<SWidget> MakeCollectionsButton() const;
	TSharedRef<SWidget> MakeCollectionsMenu() const;
	TSharedRef<SWidget> MakeCategoryMenu() const;
	TSharedRef<SWidget> MakeDecalMenu() const;

	TSharedPtr<SProWorkflowToolHud> ToolHud;
};
