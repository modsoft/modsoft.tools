// Copyright © 2026 Trey McNair. All rights reserved.

#include "SuperGroups/SuperGroupsCommands.h"

#include "Framework/Commands/InputChord.h"
#include "InputCoreTypes.h"
#include "Styling/AppStyle.h"

#define LOCTEXT_NAMESPACE "SuperGroupsCommands"

FSuperGroupsCommands::FSuperGroupsCommands()
	: TCommands<FSuperGroupsCommands>(
		TEXT("SuperGroups"),
		NSLOCTEXT("SuperGroups", "SuperGroupsCommands", "Super Groups"),
		NAME_None,
		FAppStyle::GetAppStyleSetName())
{
}

void FSuperGroupsCommands::RegisterCommands()
{
	UI_COMMAND(EnterGroup, "Enter Group", "Unlock the selected group and edit its members.", EUserInterfaceActionType::Button, FInputChord(EKeys::Enter));
	UI_COMMAND(ExitGroup, "Exit Group", "Leave group editing and lock the group again.", EUserInterfaceActionType::Button, FInputChord(EKeys::Enter, EModifierKey::Shift));
}

#undef LOCTEXT_NAMESPACE

