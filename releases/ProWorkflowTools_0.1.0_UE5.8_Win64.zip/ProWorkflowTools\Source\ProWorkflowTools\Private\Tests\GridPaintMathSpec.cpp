// Copyright © 2026 Trey McNair. All rights reserved.

#include "GridPaint/GridPaintMath.h"

#include "Misc/AutomationTest.h"

#if WITH_DEV_AUTOMATION_TESTS

namespace GridPaintMathSpec
{
	constexpr float Tolerance = 1.0e-3f;

	FGridPaintContext MakeContext(const FVector& CellSize, const FBox& Bounds = FBox(ForceInit))
	{
		FGridPaintContext Context;
		Context.CellSize = CellSize;
		Context.MeshBoundsGridLocal = Bounds;
		Context.ThinAxisFloorCm = 12.5f;
		Context.ThinAxisRelativeRatio = 0.12f;
		return Context;
	}

	TArray<FIntPoint> Walk(const FIntPoint From, const FIntPoint To)
	{
		TArray<FIntPoint> Cells;
		GridPaintMath::WalkCells2D(From, To, [&Cells](const FIntPoint Cell) { Cells.Add(Cell); });
		return Cells;
	}
}

DEFINE_SPEC(FGridPaintMathSpec, "ProWorkflowTools.Math.GridPaint",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::ProductFilter)

void FGridPaintMathSpec::Define()
{
	using namespace GridPaintMathSpec;

	Describe("WorldToGrid / GridToWorld", [this]()
	{
		It("round-trips a cell through a rotated, offset grid", [this]()
		{
			FGridPaintContext Context = MakeContext(FVector(100.0, 50.0, 25.0));
			Context.PivotWorld = FVector(10.0, 20.0, 30.0);
			Context.GridRotation = FRotator(0.0, 30.0, 0.0).Quaternion();

			const FIntVector Cell(3, -2, 1);
			TestEqual(TEXT("grid coords"), GridPaintMath::WorldToGrid(Context, GridPaintMath::GridToWorld(Context, Cell)), FVector(3.0, -2.0, 1.0), Tolerance);
		});
	});

	Describe("IsThinCellAxis", [this]()
	{
		It("uses the larger of the absolute floor and the relative ratio", [this]()
		{
			const FGridPaintContext Floor = MakeContext(FVector(100.0, 100.0, 10.0));
			TestTrue(TEXT("10 cm slab"), GridPaintMath::IsThinCellAxis(Floor, 2));
			TestFalse(TEXT("100 cm side"), GridPaintMath::IsThinCellAxis(Floor, 0));

			const FGridPaintContext BigSlab = MakeContext(FVector(400.0, 400.0, 40.0));
			TestTrue(TEXT("40 cm under 12% of 400"), GridPaintMath::IsThinCellAxis(BigSlab, 2));

			TestFalse(TEXT("out of range"), GridPaintMath::IsThinCellAxis(Floor, 3));
		});
	});

	Describe("PickPlaneAxis", [this]()
	{
		It("forces the thin axis as the plane normal", [this]()
		{
			TestEqual(TEXT("slab"), GridPaintMath::PickPlaneAxis(MakeContext(FVector(100.0, 100.0, 10.0)), FVector::ForwardVector), 2);
		});

		It("follows the view on a cube, with hysteresis", [this]()
		{
			const FGridPaintContext Cube = MakeContext(FVector(100.0));
			const FVector NearDiagonal = FVector(0.72, 0.69, 0.0).GetSafeNormal();
			TestEqual(TEXT("immediate pick"), GridPaintMath::PickPlaneAxis(Cube, NearDiagonal), 0);
			TestEqual(TEXT("held inside the margin"), GridPaintMath::PickPlaneAxis(Cube, NearDiagonal, 1), 1);
			TestEqual(TEXT("switches past the margin"), GridPaintMath::PickPlaneAxis(Cube, FVector(0.9, 0.3, 0.0).GetSafeNormal(), 1), 0);
		});
	});

	Describe("GridCoordsToFootprintCell", [this]()
	{
		It("tiles from the bounds min for a corner pivot", [this]()
		{
			const FGridPaintContext Context = MakeContext(FVector(100.0), FBox(FVector(0.0), FVector(100.0)));
			TestTrue(TEXT("(0.5, 1.5) -> (0, 1)"), GridPaintMath::GridCoordsToFootprintCell(Context, FVector(0.5, 1.5, 7.0), 2) == FIntVector(0, 1, 0));
			TestTrue(TEXT("(-0.1, 0) -> (-1, 0)"), GridPaintMath::GridCoordsToFootprintCell(Context, FVector(-0.1, 0.0, 0.0), 2) == FIntVector(-1, 0, 0));
		});

		It("splits at half a cell for a centred pivot", [this]()
		{
			const FGridPaintContext Context = MakeContext(FVector(100.0), FBox(FVector(-50.0), FVector(50.0)));
			TestTrue(TEXT("0.4 -> 0"), GridPaintMath::GridCoordsToFootprintCell(Context, FVector(0.4, -0.4, 0.0), 2) == FIntVector(0, 0, 0));
			TestTrue(TEXT("0.6 -> 1"), GridPaintMath::GridCoordsToFootprintCell(Context, FVector(0.6, -0.6, 0.0), 2) == FIntVector(1, -1, 0));
		});

		It("never stacks along a thin in-plane axis", [this]()
		{
			const FGridPaintContext Slab = MakeContext(FVector(100.0, 100.0, 10.0), FBox(FVector(-50.0, -50.0, -5.0), FVector(50.0, 50.0, 5.0)));
			TestTrue(TEXT("edge-on plane X"), GridPaintMath::GridCoordsToFootprintCell(Slab, FVector(0.0, 2.2, 4.0), 0) == FIntVector(0, 2, 0));
		});
	});

	Describe("WalkCells2D", [this]()
	{
		It("visits each cell after From up to and including To", [this]()
		{
			TestTrue(TEXT("row"), Walk(FIntPoint(0, 0), FIntPoint(3, 0)) == TArray<FIntPoint>({ FIntPoint(1, 0), FIntPoint(2, 0), FIntPoint(3, 0) }));
			TestTrue(TEXT("diagonal"), Walk(FIntPoint(0, 0), FIntPoint(-2, 2)) == TArray<FIntPoint>({ FIntPoint(-1, 1), FIntPoint(-2, 2) }));
			TestEqual(TEXT("same cell"), Walk(FIntPoint(4, 4), FIntPoint(4, 4)).Num(), 0);
		});
	});

	Describe("IsExactAxisAlignedLine", [this]()
	{
		It("accepts rows and columns on the same layer only", [this]()
		{
			TestTrue(TEXT("row"), GridPaintMath::IsExactAxisAlignedLine(FIntVector(0, 0, 0), FIntVector(4, 0, 0), 2));
			TestTrue(TEXT("column"), GridPaintMath::IsExactAxisAlignedLine(FIntVector(0, 0, 0), FIntVector(0, -3, 0), 2));
			TestFalse(TEXT("diagonal"), GridPaintMath::IsExactAxisAlignedLine(FIntVector(0, 0, 0), FIntVector(2, 2, 0), 2));
			TestFalse(TEXT("same cell"), GridPaintMath::IsExactAxisAlignedLine(FIntVector(1, 1, 0), FIntVector(1, 1, 0), 2));
			TestFalse(TEXT("other layer"), GridPaintMath::IsExactAxisAlignedLine(FIntVector(0, 0, 0), FIntVector(3, 0, 1), 2));
		});
	});
}

#endif
