// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "CoreMinimal.h"

/**
 * One site on the scale cage (3×3×3 minus center).
 * Per axis: -1 = min, 0 = mid, +1 = max. Free axes are the nonzero components (1=face, 2=edge, 3=corner).
 */
struct FBoxScaleSite
{
	int8 SX = 0;
	int8 SY = 0;
	int8 SZ = 0;

	int8 Get(const int32 Axis) const
	{
		return Axis == 0 ? SX : (Axis == 1 ? SY : SZ);
	}

	void Set(const int32 Axis, const int8 Value)
	{
		if (Axis == 0) { SX = Value; }
		else if (Axis == 1) { SY = Value; }
		else { SZ = Value; }
	}

	bool IsValid() const
	{
		return SX != 0 || SY != 0 || SZ != 0;
	}

	int32 NumFreeAxes() const
	{
		return (SX != 0 ? 1 : 0) + (SY != 0 ? 1 : 0) + (SZ != 0 ? 1 : 0);
	}

	/** Opposite cage site (negate free-axis signs; mids stay mid). */
	FBoxScaleSite Opposite() const
	{
		FBoxScaleSite Result;
		Result.SX = static_cast<int8>(-SX);
		Result.SY = static_cast<int8>(-SY);
		Result.SZ = static_cast<int8>(-SZ);
		return Result;
	}

	bool Equals(const FBoxScaleSite& Other) const
	{
		return SX == Other.SX && SY == Other.SY && SZ == Other.SZ;
	}

	/** Dominant axis color for mixed sites (first free axis). */
	int32 PrimaryAxis() const
	{
		if (SX != 0) { return 0; }
		if (SY != 0) { return 1; }
		return 2;
	}
};

/** Constants of one handle drag, fixed when it starts. */
struct FBoxScaleDragFrame
{
	FBoxScaleSite Site;
	/** Unscaled local bounds. */
	FVector LocalCenter = FVector::ZeroVector;
	FVector LocalExtent = FVector::ZeroVector;
	FVector StartScale = FVector::OneVector;
	FQuat Rotation = FQuat::Identity;
	/** Rotated unit axes. */
	FVector AxisWorld[3] = { FVector::XAxisVector, FVector::YAxisVector, FVector::ZAxisVector };
	/** Axes thinner than the flat ratio. Their scale stays at StartScale. */
	bool bAxisFlat[3] = { false, false, false };
	/** Dragged site at start. */
	FVector HandleStartWorld = FVector::ZeroVector;
	/** Opposite site; fixed during a one-sided drag. */
	FVector AnchorWorld = FVector::ZeroVector;
	/** Bounds center; fixed while Alt is held. */
	FVector CenterWorld = FVector::ZeroVector;
	/** Signed full span from anchor to handle along each free axis (at least MinDragSpan). */
	FVector StartSpan = FVector::ZeroVector;
};

struct FBoxScaleSolve
{
	FVector Scale = FVector::OneVector;
	FVector Location = FVector::ZeroVector;
};

namespace BoxScaleMath
{
	/** Minimum world-space size of the scaled bounds along each free axis. */
	constexpr double MinDragSpan = 1.0;

	/** World position of a cage site for unscaled local bounds under Transform. */
	FVector GetSiteWorldPosition(const FBoxScaleSite& Site, const FVector& LocalCenter, const FVector& LocalExtent, const FTransform& Transform);

	/** Local point that maps to the anchor under component-wise scale (for the location rewrite). */
	FVector GetLocalAnchorPoint(const FBoxScaleSite& DragSite, const FVector& LocalCenter, const FVector& LocalExtent, const FVector& StartScale);

	/** Zero-thickness axis. */
	bool IsAxisCollapsed(const FVector& ScaledExtent, int32 Axis);

	/** Collapsed, or thinner than FlatAxisRatio × the longest side. The longest side is never flat. */
	bool IsAxisFlat(const FVector& ScaledExtent, int32 Axis, float FlatAxisRatio);

	/**
	 * Whether a site gets a handle. A site that uses a flat or collapsed axis sits on a lower-dimension
	 * site, so it is hidden; mid sites on a thin axis stay.
	 */
	bool ShouldDrawSite(const FBoxScaleSite& Site, const FVector& ScaledExtent, bool bShowFaceHandles, bool bShowEdgeHandles, bool bShowCornerHandles, float FlatAxisRatio);

	/** False when the site is invalid or every axis it moves is flat. */
	bool MakeDragFrame(const FBoxScaleSite& Site, const FBox& LocalBounds, const FTransform& Transform, float FlatAxisRatio, FBoxScaleDragFrame& OutFrame);

	/**
	 * Scale and location that put the dragged site at HandleWorld while the anchor (or, with
	 * bFromCenter, the bounds center) stays fixed. bUniform scales all three axes by one factor taken
	 * along the fixed point -> handle line. ScaleSnapStep > 0 steps the free axes' scale, or the factor.
	 */
	FBoxScaleSolve SolveDrag(const FBoxScaleDragFrame& Frame, const FVector& HandleWorld, bool bFromCenter, bool bUniform, double ScaleSnapStep);
}
