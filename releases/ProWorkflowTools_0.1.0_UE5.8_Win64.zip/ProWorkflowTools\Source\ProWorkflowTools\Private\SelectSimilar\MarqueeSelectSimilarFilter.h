// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectPtr.h"

class AActor;
class USkeletalMesh;
class UStaticMesh;

/**
 * Marquee Select Similar filter from the current selection (Shift+E mesh rules;
 * actor-class fallback when there is no mesh).
 */
struct FMarqueeSelectSimilarFilter
{
	void Reset();

	void BuildFromSelection();

	bool IsEmpty() const;

	bool MatchesActor(const AActor* InActor) const;

private:
	TSet<TObjectPtr<UStaticMesh>> StaticMeshes;
	TSet<TObjectPtr<USkeletalMesh>> SkeletalMeshes;
	TSet<TObjectPtr<UClass>> ActorClasses;
};

