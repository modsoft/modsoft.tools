// Copyright © 2026 Trey McNair. All rights reserved.

#include "Viewport/DccMarqueeTool.h"

#include "BoxScale/BoxScaleTool.h"
#include "DecalPlacement/InteractiveDecalPlacementEdMode.h"
#include "ProWorkflowToolsEngineAdapter.h"
#include "ProWorkflowToolsModule.h"
#include "ProWorkflowToolsSettings.h"
#include "SelectSimilar/MarqueeSelectSimilarFilter.h"
#include "Viewport/ViewportOverlayStyle.h"

#include "CanvasItem.h"
#include "CanvasTypes.h"
#include "Editor.h"
#include "EditorModeManager.h"
#include "EditorViewportClient.h"
#include "Engine/Selection.h"
#include "EngineUtils.h"
#include "GameFramework/Actor.h"
#include "HitProxies.h"
#include "LevelEditorViewport.h"
#include "MouseDeltaTracker.h"
#include "UnrealWidget.h"

namespace DccMarqueeTool::Private
{
	bool ShouldUseCustomMarqueeDrag(const FEditorViewportClient* ViewportClient)
	{
		if (!ViewportClient)
		{
			return false;
		}

		// Custom LMB marquee is the selection drag. Landscape, Modeling, and other
		// tool modes deactivate the default selection mode and own that button.
		if (!GLevelEditorModeTools().IsDefaultModeActive())
		{
			return false;
		}

		// Interactive Decal Placement runs beside the selection mode and owns LMB while active.
		if (GLevelEditorModeTools().IsModeActive(FInteractiveDecalPlacementEdMode::EM_InteractiveDecalPlacement))
		{
			return false;
		}

		// Perspective: always use custom marquee (replaces LMB camera dolly).
		if (!ViewportClient->IsOrtho())
		{
			return true;
		}

		// Ortho: plain/shift LMB box marquee is handled by UE; Ctrl chords trigger selection moves.
		return ViewportClient->IsCtrlPressed();
	}

	void SuppressWidgetDragForMarquee(FEditorViewportClient* ViewportClient)
	{
		if (!ViewportClient)
		{
			return;
		}

		ViewportClient->SetCurrentWidgetAxis(EAxisList::None);
		ViewportClient->bWidgetAxisControlledByDrag = false;
	}

	bool ShouldInterceptCtrlMarqueePress(FEditorViewportClient* ViewportClient, FViewport* Viewport)
	{
		return ViewportClient
			&& Viewport
			&& ViewportClient->IsCtrlPressed()
			&& ShouldUseCustomMarqueeDrag(ViewportClient);
	}
}

bool FDccMarqueeTool::IsDccControlsEnabled()
{
	const FProWorkflowToolsModule* Module = FProWorkflowToolsModule::GetPtr();
	return Module && Module->IsDccControlsEnabled();
}

bool FDccMarqueeTool::BlocksViewportDragTool() const
{
	if (!IsDccControlsEnabled())
	{
		return false;
	}

	if (bMarqueeActive)
	{
		return true;
	}

	FEditorViewportClient* ViewportClient = GCurrentLevelEditingViewportClient;
	return ViewportClient
		&& ViewportClient->Viewport
		&& DccMarqueeSelection::IsMarqueeGesture(ViewportClient, ViewportClient->Viewport)
		&& DccMarqueeTool::Private::ShouldUseCustomMarqueeDrag(ViewportClient);
}

void FDccMarqueeTool::Exit()
{
	CancelTracking();
	ResultLabel.Clear();
}

void FDccMarqueeTool::CancelTracking()
{
	bMarqueeActive = false;
	bMarqueeDragging = false;
	bMarqueeFromInputKey = false;
}

void FDccMarqueeTool::Tick(FEditorViewportClient* ViewportClient, float DeltaTime)
{
	if (ViewportClient && ResultLabel.TickNeedsRedraw())
	{
		ViewportClient->Invalidate(false, false);
	}
}

bool FDccMarqueeTool::IsSelectSimilarFeedbackEnabled()
{
	const UProWorkflowToolsSettings* Settings = GetDefault<UProWorkflowToolsSettings>();
	return Settings && Settings->bSelectSimilarFeedback;
}

void FDccMarqueeTool::ShowSelectSimilarResult(const int32 MatchCount)
{
	if (!IsSelectSimilarFeedbackEnabled())
	{
		return;
	}

	ResultLabel.Show(
		FText::Format(NSLOCTEXT("ProWorkflowTools", "SelectSimilarResult", "{0} similar"), FText::AsNumber(MatchCount)),
		ProWorkflowTools::OverlayStyle::Accent());
}

bool FDccMarqueeTool::CanBeginDrag(FEditorViewportClient* ViewportClient, FViewport* Viewport) const
{
	if (!IsDccControlsEnabled() || !ViewportClient || !Viewport)
	{
		return false;
	}

	if (!DccMarqueeSelection::IsMarqueeGesture(ViewportClient, Viewport)
		|| !DccMarqueeTool::Private::ShouldUseCustomMarqueeDrag(ViewportClient))
	{
		return false;
	}

	// A press on the transform gizmo or a Box Scale handle belongs to that handle.
	const HHitProxy* HitProxy = Viewport->GetHitProxy(Viewport->GetMouseX(), Viewport->GetMouseY());
	if (HitProxy && HitProxy->IsA(HBoxScaleHandle::StaticGetType()))
	{
		return false;
	}
	return !ProWorkflowTools::IsCursorOnTransformGizmo(ViewportClient, Viewport);
}

void FDccMarqueeTool::SnapshotFilterIfNeeded(FEditorViewportClient* ViewportClient)
{
	FProWorkflowToolsModule* Module = FProWorkflowToolsModule::GetPtr();
	if (!ViewportClient || !Module)
	{
		return;
	}

	if (IsDccControlsEnabled() && DccMarqueeSelection::GetModeFromViewport(ViewportClient) == EDccMarqueeMode::SelectSimilar)
	{
		Module->SnapshotMarqueeFilterForDrag();
	}
}

void FDccMarqueeTool::BeginDrag(FEditorViewportClient* ViewportClient, FViewport* Viewport, bool bFromInputKey)
{
	if (!ViewportClient || !Viewport)
	{
		return;
	}

	DccMarqueeTool::Private::SuppressWidgetDragForMarquee(ViewportClient);

	// Only the Ctrl chords fight the TRS gizmo's ITF capture. Terminating it for plain/shift
	// gestures would also swallow the engine's single-click selection.
	if (bFromInputKey)
	{
		ProWorkflowTools::TerminateInteractiveToolsMouseCapture(ViewportClient);
	}

	FIntPoint MousePos;
	Viewport->GetMousePos(MousePos);

	bMarqueeActive = true;
	bMarqueeDragging = false;
	bMarqueeFromInputKey = bFromInputKey;
	MarqueeMode = DccMarqueeSelection::GetModeFromViewport(ViewportClient);
	MarqueeStart = FVector(MousePos);
	MarqueeEnd = MarqueeStart;
}

void FDccMarqueeTool::UpdateDrag(FEditorViewportClient* ViewportClient, int32 MouseX, int32 MouseY)
{
	if (!bMarqueeActive)
	{
		return;
	}

	DccMarqueeTool::Private::SuppressWidgetDragForMarquee(ViewportClient);

	// Keep cancelling the gizmo's ITF capture only for the Ctrl chords (see BeginDrag).
	if (bMarqueeFromInputKey)
	{
		ProWorkflowTools::TerminateInteractiveToolsMouseCapture(ViewportClient);
	}

	MarqueeEnd = FVector(MouseX, MouseY, 0.0);

	const FVector Delta = MarqueeEnd - MarqueeStart;
	if (!bMarqueeDragging && Delta.SizeSquared() > MOUSE_CLICK_DRAG_DELTA)
	{
		bMarqueeDragging = true;
	}

	if (bMarqueeDragging && ViewportClient)
	{
		ViewportClient->Invalidate(false, false);
	}
}

void FDccMarqueeTool::Finish(FEditorViewportClient* ViewportClient, FViewport* Viewport)
{
	if (bMarqueeDragging)
	{
		Commit(ViewportClient);
	}
	else if (bMarqueeFromInputKey && ViewportClient && Viewport && GEditor
		&& ViewportClient->IsCtrlPressed() && !ViewportClient->IsShiftPressed() && !ViewportClient->IsAltPressed())
	{
		// Ctrl+LMB without a drag is a single-click deselect.
		HHitProxy* HitProxy = Viewport->GetHitProxy(Viewport->GetMouseX(), Viewport->GetMouseY());
		if (HitProxy && HitProxy->IsA(HActor::StaticGetType()))
		{
			AActor* Actor = static_cast<HActor*>(HitProxy)->Actor;
			if (Actor && GEditor->GetSelectedActors()->IsSelected(Actor))
			{
				GEditor->SelectActor(Actor, /*bSelect=*/false, /*bNotify=*/true);
				GEditor->NoteSelectionChange();
			}
		}
	}

	bMarqueeActive = false;
	bMarqueeDragging = false;
	bMarqueeFromInputKey = false;

	if (ViewportClient && Viewport)
	{
		// Refresh the restore point in case the cursor was hidden before our override applied.
		Viewport->SetPreCaptureMousePosFromSlateCursor();
		ViewportClient->Invalidate(false, false);
	}
}

void FDccMarqueeTool::Commit(FEditorViewportClient* ViewportClient)
{
	if (!ViewportClient || !bMarqueeDragging)
	{
		return;
	}

	const FProWorkflowToolsModule* Module = FProWorkflowToolsModule::GetPtr();
	const FMarqueeSelectSimilarFilter* SimilarFilter = nullptr;
	if (MarqueeMode == EDccMarqueeMode::SelectSimilar && Module)
	{
		// Shared SelectSimilar gather path (same helpers as BoxSelect / FrustumSelect).
		SimilarFilter = &Module->GetMarqueeFilter();
		if (SimilarFilter->IsEmpty())
		{
			return;
		}
	}

	if (ViewportClient->IsOrtho())
	{
		FBox SelectionBox(ForceInit);
		if (!DccMarqueeSelection::CalculateOrthoBox(ViewportClient, MarqueeStart, MarqueeEnd, SelectionBox))
		{
			return;
		}

		const TArray<FTypedElementHandle> Elements =
			DccMarqueeSelection::GatherBoxElements(ViewportClient, SelectionBox, SimilarFilter);
		DccMarqueeSelection::ApplySelection(ViewportClient, MarqueeMode, Elements);
		if (SimilarFilter)
		{
			ShowSelectSimilarResult(Elements.Num());
		}
		return;
	}

	FConvexVolume Frustum;
	if (!DccMarqueeSelection::CalculateFrustum(ViewportClient, MarqueeStart, MarqueeEnd, Frustum))
	{
		return;
	}

	const TArray<FTypedElementHandle> Elements =
		DccMarqueeSelection::GatherFrustumElements(ViewportClient, MarqueeStart, MarqueeEnd, Frustum, SimilarFilter);
	DccMarqueeSelection::ApplySelection(ViewportClient, MarqueeMode, Elements);
	if (SimilarFilter)
	{
		ShowSelectSimilarResult(Elements.Num());
	}
}

bool FDccMarqueeTool::InputKey(FEditorViewportClient* ViewportClient, FViewport* Viewport, FKey Key, EInputEvent Event)
{
	if (!IsDccControlsEnabled() || Key != EKeys::LeftMouseButton || !ViewportClient || !Viewport)
	{
		return false;
	}

	if (Event == IE_Pressed)
	{
		SnapshotFilterIfNeeded(ViewportClient);

		if (DccMarqueeTool::Private::ShouldInterceptCtrlMarqueePress(ViewportClient, Viewport)
			&& CanBeginDrag(ViewportClient, Viewport))
		{
			BeginDrag(ViewportClient, Viewport, /*bFromInputKey=*/true);
			return true;
		}
	}
	else if (Event == IE_Released && bMarqueeActive && bMarqueeFromInputKey)
	{
		// Only Ctrl-chord marquees are started here (press consumed), so they also end here.
		// Plain/shift marquees run through the normal tracking flow, whose release path still needs to
		// reach ProcessClick for single-click selection, so their release is not consumed.
		ProWorkflowTools::TerminateInteractiveToolsMouseCapture(ViewportClient);
		Finish(ViewportClient, Viewport);
		return true;
	}

	return false;
}

bool FDccMarqueeTool::StartTracking(FEditorViewportClient* ViewportClient, FViewport* Viewport)
{
	if (!CanBeginDrag(ViewportClient, Viewport))
	{
		return false;
	}

	BeginDrag(ViewportClient, Viewport, /*bFromInputKey=*/false);
	return true;
}

bool FDccMarqueeTool::CapturedMouseMove(FEditorViewportClient* ViewportClient, FViewport* Viewport, int32 MouseX, int32 MouseY)
{
	if (!bMarqueeActive || !Viewport)
	{
		return false;
	}

	UpdateDrag(ViewportClient, MouseX, MouseY);
	return true;
}

bool FDccMarqueeTool::MouseMove(FEditorViewportClient* ViewportClient, FViewport* Viewport, int32 MouseX, int32 MouseY)
{
	if (!bMarqueeActive || !Viewport || !Viewport->KeyState(EKeys::LeftMouseButton))
	{
		return false;
	}

	UpdateDrag(ViewportClient, MouseX, MouseY);
	return true;
}

bool FDccMarqueeTool::EndTracking(FEditorViewportClient* ViewportClient, FViewport* Viewport)
{
	if (!bMarqueeActive)
	{
		return false;
	}

	// LMB release ends the marquee. With ITF viewport interactions, any key event (including Ctrl
	// auto-repeat) ends mode tracking once the ITF capture is gone.
	if (Viewport && Viewport->KeyState(EKeys::LeftMouseButton))
	{
		return true;
	}

	Finish(ViewportClient, Viewport);
	return true;
}

bool FDccMarqueeTool::HandleClick(FEditorViewportClient* ViewportClient, HHitProxy* HitProxy, const FViewportClick& Click)
{
	// Its own setting: this QoL click works with or without the DCC marquee controls.
	const UProWorkflowToolsSettings* Settings = GetDefault<UProWorkflowToolsSettings>();
	if (!Settings || !Settings->bShiftClickSetsActiveActor
		|| Click.GetKey() != EKeys::LeftMouseButton
		|| !Click.IsShiftDown()
		|| Click.IsControlDown()
		|| Click.IsAltDown()
		|| !HitProxy
		|| !HitProxy->IsA(HActor::StaticGetType())
		|| !GEditor)
	{
		return false;
	}

	AActor* Actor = static_cast<HActor*>(HitProxy)->Actor;
	if (!Actor || !GEditor->GetSelectedActors()->IsSelected(Actor))
	{
		return false;
	}

	// Bump to end of selection order so Ctrl+G "last selected pivot" uses this actor.
	GEditor->SelectActor(Actor, /*bInSelected=*/false, /*bNotify=*/false);
	GEditor->SelectActor(Actor, /*bInSelected=*/true, /*bNotify=*/true);

	if (FEditorModeTools* ModeTools = ViewportClient ? ViewportClient->GetModeTools() : nullptr)
	{
		ModeTools->SetPivotLocation(Actor->GetActorLocation(), false);
	}
	GEditor->RedrawLevelEditingViewports();
	return true;
}

bool FDccMarqueeTool::BoxSelect(FBox& Box, bool bSelect)
{
	if (!IsDccControlsEnabled())
	{
		return false;
	}

	FEditorViewportClient* ViewportClient = GCurrentLevelEditingViewportClient;
	const EDccMarqueeMode Mode = ViewportClient
		? DccMarqueeSelection::GetModeFromViewport(ViewportClient)
		: EDccMarqueeMode::Replace;

	// Ortho replace/add/subtract is the engine box drag tool's job.
	if (Mode != EDccMarqueeMode::SelectSimilar)
	{
		return false;
	}

	const FProWorkflowToolsModule* Module = FProWorkflowToolsModule::GetPtr();
	const FMarqueeSelectSimilarFilter* SimilarFilter = Module ? &Module->GetMarqueeFilter() : nullptr;
	if (!SimilarFilter || SimilarFilter->IsEmpty())
	{
		// Nothing to match against: fall through to stock ortho marquee.
		return false;
	}

	const TArray<FTypedElementHandle> Elements = DccMarqueeSelection::GatherBoxElements(ViewportClient, Box, SimilarFilter);
	const bool bApplied = DccMarqueeSelection::ApplySelection(ViewportClient, Mode, Elements);
	ShowSelectSimilarResult(Elements.Num());
	return bApplied;
}

bool FDccMarqueeTool::FrustumSelect(const FConvexVolume& Frustum, FEditorViewportClient* ViewportClient, bool bSelect)
{
	if (!IsDccControlsEnabled() || !ViewportClient)
	{
		return false;
	}

	const EDccMarqueeMode Mode = DccMarqueeSelection::GetModeFromViewport(ViewportClient);
	const FProWorkflowToolsModule* Module = FProWorkflowToolsModule::GetPtr();
	const FMarqueeSelectSimilarFilter* SimilarFilter = nullptr;

	if (Mode == EDccMarqueeMode::SelectSimilar && Module)
	{
		SimilarFilter = &Module->GetMarqueeFilter();
		if (SimilarFilter->IsEmpty())
		{
			return true;
		}
	}

	const TArray<FTypedElementHandle> Elements = DccMarqueeSelection::GatherFrustumElements(ViewportClient, Frustum, SimilarFilter);
	const bool bApplied = DccMarqueeSelection::ApplySelection(ViewportClient, Mode, Elements);
	if (SimilarFilter)
	{
		ShowSelectSimilarResult(Elements.Num());
	}
	return bApplied;
}

bool FDccMarqueeTool::GetOverrideCursorVisibility(bool& bWantsOverride, bool& bHardwareCursorVisible, bool bSoftwareCursorVisible) const
{
	// UE hides the hardware cursor during LMB drags that don't use a drag tool, then restores it to the
	// press location on release. Keep the cursor visible during the marquee so it stays at the drag end.
	if (!IsDccControlsEnabled() || !bMarqueeActive)
	{
		return false;
	}

	bWantsOverride = true;
	bHardwareCursorVisible = true;
	return true;
}

void FDccMarqueeTool::DrawHUD(FEditorViewportClient* ViewportClient, FViewport* Viewport, const FSceneView* View, FCanvas* Canvas)
{
	if (!Canvas)
	{
		return;
	}

	if (Viewport)
	{
		ResultLabel.Draw(Canvas, FIntPoint(Viewport->GetMouseX(), Viewport->GetMouseY()));
	}

	if (!bMarqueeDragging)
	{
		return;
	}

	// Select-similar is the one marquee that does something other than a plain box select; it shows it.
	const bool bSimilar = MarqueeMode == EDccMarqueeMode::SelectSimilar && IsSelectSimilarFeedbackEnabled();
	const FVector2D StartPos(MarqueeStart.X, MarqueeStart.Y);
	const FVector2D Size(MarqueeEnd.X - MarqueeStart.X, MarqueeEnd.Y - MarqueeStart.Y);
	FCanvasBoxItem BoxItem(StartPos / Canvas->GetDPIScale(), Size / Canvas->GetDPIScale());
	BoxItem.SetColor(bSimilar ? ProWorkflowTools::OverlayStyle::Accent() : FLinearColor::White);
	Canvas->DrawItem(BoxItem);
}
