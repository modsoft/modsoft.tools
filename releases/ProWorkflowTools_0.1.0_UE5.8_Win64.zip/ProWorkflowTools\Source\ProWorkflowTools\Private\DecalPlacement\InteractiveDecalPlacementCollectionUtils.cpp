// Copyright © 2026 Trey McNair. All rights reserved.

#include "InteractiveDecalPlacementCollectionUtils.h"

#include "AssetRegistry/AssetData.h"
#include "AssetRegistry/IAssetRegistry.h"
#include "CollectionManagerModule.h"
#include "ICollectionContainer.h"
#include "ICollectionManager.h"
#include "ProWorkflowToolsEngineAdapter.h"
#include "ProWorkflowToolsSettings.h"
#include "MaterialDomain.h"
#include "Materials/Material.h"
#include "Materials/MaterialInstance.h"
#include "Materials/MaterialInterface.h"
#include "Engine/Texture.h"
#include "Misc/PackageName.h"

#define LOCTEXT_NAMESPACE "ProWorkflowTools"

namespace InteractiveDecalPlacement
{
	namespace Private
	{
		TArray<FDecalBrowseCategory> CachedBrowseCategories;
		bool bBrowseCategoriesDirty = true;
		bool bCollectionUpdateBound = false;
		FDelegateHandle CollectionUpdatedHandle;

		/** Collections unchecked in the HUD accordion for this editor process (default: none). */
		TSet<FName> SessionDisabledCollectionNames;

		void EnsureCollectionUpdateBinding()
		{
			if (bCollectionUpdateBound || !FCollectionManagerModule::IsModuleAvailable())
			{
				return;
			}

			const TSharedRef<ICollectionContainer>& CollectionContainer =
				FCollectionManagerModule::GetModule().Get().GetProjectCollectionContainer();
			CollectionUpdatedHandle = CollectionContainer->OnCollectionUpdated().AddLambda(
				[](ICollectionContainer& /*Container*/, const FCollectionNameType& /*Collection*/)
				{
					InvalidateBrowseCategoryCache();
				});
			bCollectionUpdateBound = true;
		}
	}

	static const TSharedRef<ICollectionContainer>& GetCollectionContainer()
	{
		return FCollectionManagerModule::GetModule().Get().GetProjectCollectionContainer();
	}

	void InvalidateBrowseCategoryCache()
	{
		Private::bBrowseCategoriesDirty = true;
	}

	bool IsCollectionEnabledForSession(const FName CollectionName)
	{
		return !CollectionName.IsNone() && !Private::SessionDisabledCollectionNames.Contains(CollectionName);
	}

	void SetCollectionEnabledForSession(const FName CollectionName, const bool bEnabled)
	{
		if (CollectionName.IsNone())
		{
			return;
		}

		const bool bWasEnabled = IsCollectionEnabledForSession(CollectionName);
		if (bEnabled == bWasEnabled)
		{
			return;
		}

		if (bEnabled)
		{
			Private::SessionDisabledCollectionNames.Remove(CollectionName);
		}
		else
		{
			Private::SessionDisabledCollectionNames.Add(CollectionName);
		}

		InvalidateBrowseCategoryCache();
	}

	void SetAllSessionCollectionsEnabled(const bool bEnabled)
	{
		TArray<FDecalBrowseCategory> SessionCategories;
		GetSessionUiBrowseCategories(SessionCategories);

		bool bChanged = false;
		for (const FDecalBrowseCategory& Category : SessionCategories)
		{
			if (Category.CollectionName.IsNone())
			{
				continue;
			}

			const bool bWasEnabled = IsCollectionEnabledForSession(Category.CollectionName);
			if (bEnabled == bWasEnabled)
			{
				continue;
			}

			if (bEnabled)
			{
				Private::SessionDisabledCollectionNames.Remove(Category.CollectionName);
			}
			else
			{
				Private::SessionDisabledCollectionNames.Add(Category.CollectionName);
			}
			bChanged = true;
		}

		if (bChanged)
		{
			InvalidateBrowseCategoryCache();
		}
	}

	TArray<const FInteractiveDecalCollectionEntry*> GetEnabledCollectionEntries()
	{
		TArray<const FInteractiveDecalCollectionEntry*> EnabledEntries;
		UProWorkflowToolsUserSettings* Settings = GetMutableDefault<UProWorkflowToolsUserSettings>();
		Settings->ImportProjectCollectionEntriesIfNeeded();
		for (const FInteractiveDecalCollectionEntry& Entry : Settings->CollectionEntries)
		{
			if (Entry.bEnabled && !Entry.CollectionName.IsNone())
			{
				EnabledEntries.Add(&Entry);
			}
		}
		return EnabledEntries;
	}

	static bool CollectionHasLoadableDecals(const FName CollectionName)
	{
		return !CollectionName.IsNone() && !GetDecalMaterialsInCollection(CollectionName).IsEmpty();
	}

	static void TryAddBrowseCategory(
		const FName CollectionName,
		const bool bFilterBySession,
		TSet<FName>& SeenNames,
		TArray<FDecalBrowseCategory>& OutCategories)
	{
		if (CollectionName.IsNone() || SeenNames.Contains(CollectionName))
		{
			return;
		}

		SeenNames.Add(CollectionName);

		// Omit empty parents / categories with no direct (Self) loadable decals.
		if (!CollectionHasLoadableDecals(CollectionName))
		{
			return;
		}

		if (!bFilterBySession || IsCollectionEnabledForSession(CollectionName))
		{
			OutCategories.Add(FDecalBrowseCategory{ CollectionName, CollectionName });
		}
	}

	static void AppendDescendantCategories(
		const FName ParentName,
		const ECollectionShareType::Type ParentShareType,
		const bool bFilterBySession,
		TSet<FName>& SeenNames,
		TArray<FDecalBrowseCategory>& OutCategories)
	{
		const TSharedRef<ICollectionContainer>& CollectionContainer = GetCollectionContainer();

		TArray<FCollectionNameType> ChildCollections;
		CollectionContainer->GetChildCollections(ParentName, ParentShareType, ChildCollections);

		ChildCollections.Sort([](const FCollectionNameType& A, const FCollectionNameType& B)
		{
			return A.Name.LexicalLess(B.Name);
		});

		for (const FCollectionNameType& Child : ChildCollections)
		{
			if (Child.Name.IsNone())
			{
				continue;
			}

			TryAddBrowseCategory(Child.Name, bFilterBySession, SeenNames, OutCategories);
			AppendDescendantCategories(Child.Name, Child.Type, bFilterBySession, SeenNames, OutCategories);
		}
	}

	static void BuildBrowseCategories(const bool bFilterBySession, TArray<FDecalBrowseCategory>& OutCategories)
	{
		OutCategories.Reset();
		TSet<FName> SeenNames;

		for (const FInteractiveDecalCollectionEntry* Entry : GetEnabledCollectionEntries())
		{
			if (!Entry || Entry->CollectionName.IsNone())
			{
				continue;
			}

			TryAddBrowseCategory(Entry->CollectionName, bFilterBySession, SeenNames, OutCategories);

			if (Entry->bIncludeChildCollections)
			{
				// Parent name can exist in multiple scopes with different children — union them.
				const ECollectionShareType::Type ShareTypes[] =
				{
					ECollectionShareType::CST_Local,
					ECollectionShareType::CST_Private,
					ECollectionShareType::CST_Shared
				};
				const TSharedRef<ICollectionContainer>& CollectionContainer = GetCollectionContainer();
				for (const ECollectionShareType::Type ShareType : ShareTypes)
				{
					if (CollectionContainer->CollectionExists(Entry->CollectionName, ShareType))
					{
						AppendDescendantCategories(
							Entry->CollectionName,
							ShareType,
							bFilterBySession,
							SeenNames,
							OutCategories);
					}
				}
			}
		}
	}

	const TArray<FDecalBrowseCategory>& GetBrowseCategories()
	{
		Private::EnsureCollectionUpdateBinding();

		if (!Private::bBrowseCategoriesDirty)
		{
			return Private::CachedBrowseCategories;
		}

		BuildBrowseCategories(/*bFilterBySession=*/true, Private::CachedBrowseCategories);
		Private::bBrowseCategoriesDirty = false;
		return Private::CachedBrowseCategories;
	}

	void GetSessionUiBrowseCategories(TArray<FDecalBrowseCategory>& OutCategories)
	{
		Private::EnsureCollectionUpdateBinding();
		BuildBrowseCategories(/*bFilterBySession=*/false, OutCategories);
	}

	void GetAllCollectionNames(TArray<FName>& OutCollectionNames)
	{
		OutCollectionNames.Reset();
		const TSharedRef<ICollectionContainer>& CollectionContainer = GetCollectionContainer();

		TSet<FName> UniqueNames;
		const ECollectionShareType::Type ShareTypes[] =
		{
			ECollectionShareType::CST_Local,
			ECollectionShareType::CST_Private,
			ECollectionShareType::CST_Shared
		};

		for (const ECollectionShareType::Type ShareType : ShareTypes)
		{
			TArray<FName> NamesForScope;
			CollectionContainer->GetCollectionNames(ShareType, NamesForScope);
			for (const FName& Name : NamesForScope)
			{
				UniqueNames.Add(Name);
			}
		}

		OutCollectionNames = UniqueNames.Array();
		OutCollectionNames.Sort(FNameLexicalLess());
	}

	bool IsDecalMaterialAsset(const FAssetData& InAssetData)
	{
		static const FString DecalDomain = StaticEnum<EMaterialDomain>()->GetNameStringByValue(MD_DeferredDecal);
		const IAssetRegistry& AssetRegistry = IAssetRegistry::GetChecked();

		// Material instances carry only their parent; the domain lives on the base material.
		constexpr int32 MaxParentDepth = 32;
		FAssetData AssetData = InAssetData;
		for (int32 Depth = 0; Depth < MaxParentDepth && AssetData.IsValid(); ++Depth)
		{
			if (AssetData.IsInstanceOf(UMaterial::StaticClass()))
			{
				FString Domain;
				return AssetData.GetTagValue(GET_MEMBER_NAME_CHECKED(UMaterial, MaterialDomain), Domain) && Domain == DecalDomain;
			}

			FString ParentPath;
			if (!AssetData.IsInstanceOf(UMaterialInstance::StaticClass())
				|| !AssetData.GetTagValue(GET_MEMBER_NAME_CHECKED(UMaterialInstance, Parent), ParentPath))
			{
				return false;
			}
			AssetData = AssetRegistry.GetAssetByObjectPath(FSoftObjectPath(FPackageName::ExportTextPathToObjectPath(ParentPath)));
		}
		return false;
	}

	bool IsDecalMaterial(UMaterialInterface* Material)
	{
		if (!Material)
		{
			return false;
		}

		const UMaterial* BaseMaterial = Material->GetMaterial();
		return BaseMaterial && BaseMaterial->MaterialDomain == MD_DeferredDecal;
	}

	float GetMaterialAspectRatio(const UMaterialInterface* Material)
	{
		if (!Material)
		{
			return 1.0f;
		}

		const UMaterial* BaseMaterial = Material->GetMaterial();
		if (!BaseMaterial)
		{
			return 1.0f;
		}

		TArray<UTexture*> UsedTextures;
		ProWorkflowTools::GetMaterialUsedTextures(BaseMaterial, UsedTextures);
		for (const UTexture* Texture : UsedTextures)
		{
			if (Texture && Texture->GetSurfaceWidth() > 0 && Texture->GetSurfaceHeight() > 0)
			{
				return static_cast<float>(Texture->GetSurfaceWidth()) / static_cast<float>(Texture->GetSurfaceHeight());
			}
		}

		return 1.0f;
	}

	TArray<FSoftObjectPath> GetDecalMaterialsInCollection(const FName CollectionName)
	{
		TArray<FSoftObjectPath> DecalPaths;
		if (CollectionName.IsNone())
		{
			return DecalPaths;
		}

		const TSharedRef<ICollectionContainer>& CollectionContainer = GetCollectionContainer();
		const ECollectionShareType::Type ShareTypes[] =
		{
			ECollectionShareType::CST_Local,
			ECollectionShareType::CST_Private,
			ECollectionShareType::CST_Shared
		};

		// Union assets from every scope where this collection name exists. The same
		// display name can exist in Local/Private/Shared with different contents.
		// Always Self only — subcategories are separate browse categories.
		TSet<FString> SeenAssetPaths;
		TArray<FSoftObjectPath> AssetPaths;
		for (const ECollectionShareType::Type ShareType : ShareTypes)
		{
			if (!CollectionContainer->CollectionExists(CollectionName, ShareType))
			{
				continue;
			}

			AssetPaths.Reset();
			if (!CollectionContainer->GetAssetsInCollection(
				CollectionName,
				ShareType,
				AssetPaths,
				ECollectionRecursionFlags::Self))
			{
				continue;
			}

			for (const FSoftObjectPath& AssetPath : AssetPaths)
			{
				SeenAssetPaths.Add(AssetPath.GetAssetPathString());
			}
		}

		const IAssetRegistry& AssetRegistry = IAssetRegistry::GetChecked();
		for (const FString& AssetPathString : SeenAssetPaths)
		{
			const FSoftObjectPath AssetPath(AssetPathString);
			if (IsDecalMaterialAsset(AssetRegistry.GetAssetByObjectPath(AssetPath)))
			{
				DecalPaths.Add(AssetPath);
			}
		}

		DecalPaths.Sort([](const FSoftObjectPath& A, const FSoftObjectPath& B)
		{
			return A.GetAssetPathString() < B.GetAssetPathString();
		});

		return DecalPaths;
	}
}

#undef LOCTEXT_NAMESPACE

