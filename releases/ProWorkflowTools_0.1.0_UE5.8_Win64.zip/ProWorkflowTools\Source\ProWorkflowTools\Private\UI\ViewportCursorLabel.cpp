// Copyright © 2026 Trey McNair. All rights reserved.

#include "UI/ViewportCursorLabel.h"

#include "CanvasItem.h"
#include "CanvasTypes.h"
#include "Engine/Engine.h"
#include "Engine/Font.h"
#include "UnrealClient.h"

namespace ProWorkflowTools::CursorLabel
{
	namespace
	{
		constexpr float CursorOffset = 16.0f;
	}

	float GetAlpha(const float ElapsedSeconds)
	{
		if (ElapsedSeconds < 0.0f)
		{
			return 0.0f;
		}
		return FMath::Clamp((VisibleSeconds - ElapsedSeconds) / FadeSeconds, 0.0f, 1.0f);
	}

	FString FormatAmount(const double Value)
	{
		return FString::SanitizeFloat(FMath::RoundToDouble(Value * 10.0) / 10.0, 0);
	}

	void Draw(FCanvas* Canvas, const FIntPoint& MousePixel, const TConstArrayView<FLine> Lines, const float Alpha)
	{
		const UFont* Font = GEngine ? GEngine->GetSmallFont() : nullptr;
		if (!Canvas || !Font || Alpha <= 0.0f)
		{
			return;
		}

		// Canvas units are DPI-scaled by FCanvas; only mouse and render-target pixels need dividing.
		const float DPI = FMath::Max(Canvas->GetDPIScale(), 0.01f);
		const float LineHeight = Font->GetMaxCharHeight();

		float BlockWidth = 0.0f;
		for (const FLine& Line : Lines)
		{
			BlockWidth = FMath::Max(BlockWidth, static_cast<float>(Font->GetStringSize(*Line.Text.ToString())));
		}
		const float BlockHeight = LineHeight * Lines.Num();

		// Down-right of the cursor; mirrored to the other side on any axis where it would leave the viewport.
		const FVector2D Mouse(MousePixel.X / DPI, MousePixel.Y / DPI);
		FVector2D Position(Mouse.X + CursorOffset, Mouse.Y + CursorOffset);
		if (const FRenderTarget* RenderTarget = Canvas->GetRenderTarget())
		{
			const FVector2D ViewSize = FVector2D(RenderTarget->GetSizeXY()) / DPI;
			if (Position.X + BlockWidth > ViewSize.X)
			{
				Position.X = Mouse.X - CursorOffset - BlockWidth;
			}
			if (Position.Y + BlockHeight > ViewSize.Y)
			{
				Position.Y = Mouse.Y - CursorOffset - BlockHeight;
			}
		}

		for (const FLine& Line : Lines)
		{
			if (!Line.Text.IsEmpty())
			{
				FLinearColor Color = Line.Color;
				Color.A *= Alpha;
				FCanvasTextItem Item(Position, Line.Text, Font, Color);
				Item.EnableShadow(FLinearColor(0.0f, 0.0f, 0.0f, Color.A));
				Canvas->DrawItem(Item);
			}
			Position.Y += LineHeight;
		}
	}

	void FFadingLabel::Show(const FText& Text, const FLinearColor& Color)
	{
		const FLine Line{ Text, Color };
		Show(MakeArrayView(&Line, 1));
	}

	void FFadingLabel::Show(const TConstArrayView<FLine> InLines)
	{
		Lines.Reset();
		Lines.Append(InLines.GetData(), InLines.Num());
		StartSeconds = FPlatformTime::Seconds();
	}

	void FFadingLabel::Clear()
	{
		Lines.Reset();
		StartSeconds = -1.0;
	}

	bool FFadingLabel::TickNeedsRedraw()
	{
		if (StartSeconds < 0.0)
		{
			return false;
		}
		if (GetAlpha(static_cast<float>(FPlatformTime::Seconds() - StartSeconds)) <= 0.0f)
		{
			Clear();
		}
		return true;
	}

	void FFadingLabel::Draw(FCanvas* Canvas, const FIntPoint& MousePixel) const
	{
		if (StartSeconds < 0.0)
		{
			return;
		}
		CursorLabel::Draw(Canvas, MousePixel, Lines, GetAlpha(static_cast<float>(FPlatformTime::Seconds() - StartSeconds)));
	}
}
