// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "Engine/EngineBaseTypes.h"
#include "GenericPlatform/ICursor.h"
#include "GridPaint/GridPaintMath.h"
#include "ProWorkflowToolsEngineAdapter.h"
#include "InputCoreTypes.h"
#include "ScopedTransaction.h"
#include "Templates/UniquePtr.h"
#include "UI/ProWorkflowToolHudOverlay.h"
#include "UI/ViewportCursorLabel.h"
#include "UObject/ObjectPtr.h"
#include "UObject/WeakObjectPtr.h"
#include "Viewport/WorkflowViewportTool.h"

class AActor;
class AStaticMeshActor;
class FEditorViewportClient;
class FPrimitiveDrawInterface;
class FSceneView;
class FViewport;
class SProWorkflowToolHud;
class SWidget;
class UDecalComponent;
class UStaticMesh;
class UStaticMeshComponent;
struct FProWorkflowToolHudModel;

/**
 * Paint edge-flush copies of one selected mesh/decal across its modular grid.
 * Driven by FProWorkflowToolsEdMode.
 */
class FGridPaintTool : public FWorkflowViewportTool
{
public:
	bool IsActive() const { return bActive; }

	/** The session owns the viewport while active. */
	virtual bool IsExclusive() const override { return bActive; }
	virtual bool ReplacesTransformGizmo() const override { return bActive; }
	/**
	 * A paint stroke, bounds-face drag, or line-fill click owns the mouse. Hovering alone does not,
	 * so MMB/RMB/Alt camera navigation can still reframe mid-session.
	 */
	virtual bool CapturesMouse() const override { return bStrokeActive || bBoundsFaceDrag || bLineFillCapture; }
	virtual bool BlocksViewportDragTool() const override { return bActive; }

	/** Returns true when the event was consumed (toggle key, Esc, or LMB while active). */
	virtual bool InputKey(FEditorViewportClient* ViewportClient, FViewport* Viewport, FKey Key, EInputEvent Event) override;
	virtual bool MouseMove(FEditorViewportClient* ViewportClient, FViewport* Viewport, int32 X, int32 Y) override;
	virtual bool CapturedMouseMove(FEditorViewportClient* ViewportClient, FViewport* Viewport, int32 X, int32 Y) override;
	/**
	 * Claims LMB tracking while active (not while Alt is held): starts a stroke if needed so
	 * DisallowMouseDeltaTracking engages and the camera cannot pan/orbit from this drag.
	 * Alt+LMB is left alone so DCC/editor orbit can reframe mid-session.
	 */
	virtual bool StartTracking(FEditorViewportClient* ViewportClient, FViewport* Viewport) override;
	/** Ends an in-flight stroke if the engine tears tracking down before the LMB release reaches us. */
	virtual bool EndTracking(FEditorViewportClient* ViewportClient, FViewport* Viewport) override;
	/** Owns LMB (including Shift+LMB erase): click-select / pivot reassignment must not steal the source. */
	virtual bool HandleClick(FEditorViewportClient* ViewportClient, HHitProxy* HitProxy, const FViewportClick& Click) override;

	virtual EWorkflowToolTickViewport GetTickViewport() const override { return EWorkflowToolTickViewport::Hovered; }
	virtual void Tick(FEditorViewportClient* ViewportClient, float DeltaTime) override;
	virtual void Render(const FSceneView* View, FViewport* Viewport, FPrimitiveDrawInterface* PDI) override;
	virtual void DrawHUD(FEditorViewportClient* ViewportClient, FViewport* Viewport, const FSceneView* View, FCanvas* Canvas) override;
	virtual void Exit() override { Deactivate(); }

	/** Exits the tool (Esc, invalid selection, or mode teardown). Safe to call when inactive. */
	void Deactivate();

	/** True for the rest of the frame that called HandleToggleKeyPressed and entered. */
	bool DidToggleOnThisFrame() const { return bActive && ActivatedFrame == GFrameCounter; }

	/** Selection validation + toasts, then activation. Returns true (key consumed) whenever the feature is on. */
	bool HandleToggleKeyPressed(FEditorViewportClient* ViewportClient);
	/**
	 * Reloads tile bounds and drops the overlap cache; occupancy is queried live so it needs no rebuild.
	 * Called from the module's PostUndoRedo bind (not AddRaw on this tool — Live Coding safe).
	 */
	void NotifyPostUndoRedo();

private:
	/** Cursor ray vs the paint plane -> grid cell. False when the ray is near-parallel or hits behind the camera. */
	bool ComputeCellUnderCursor(FEditorViewportClient* ViewportClient, int32 PlaneAxis, FIntVector& OutCell) const;

	void BeginStroke(FEditorViewportClient* ViewportClient);
	void UpdateStroke(FEditorViewportClient* ViewportClient);
	void EndStroke(FEditorViewportClient* ViewportClient = nullptr);
	/** Spawns a duplicate (skips occupied/intersect cells). */
	void PaintCell(const FIntVector& Cell);
	/**
	 * Destroys the matching actor in the cell (session spawn or world occupant; never the source).
	 * Clears occupancy so the cell can be painted again.
	 */
	void EraseCell(const FIntVector& Cell);
	void SpawnDuplicateAtCell(const FIntVector& Cell);
	/** Applies PaintCell or EraseCell for the current stroke mode. */
	void ApplyStrokeToCell(const FIntVector& Cell);

	// --- Ctrl line fill (exact axis-aligned only) ---

	/** Ctrl held, not Shift / bounds edit — line-fill preview + commit. */
	bool IsLineFillIntent(const FEditorViewportClient* ViewportClient) const;
	/** True when Anchor→Target shares the paint plane and differs on exactly one in-plane axis. */
	FIntVector GetLineFillAnchor() const;
	/**
	 * Empty, unblocked cells on the current exact axis-aligned Ctrl line (anchor excluded).
	 * OverlapTestBudget >= 0 caps Prevent Intersect queries from the hover end (preview);
	 * INDEX_NONE tests the whole run (commit).
	 */
	void CollectLineFillCells(TArray<FIntVector>& OutCells, int32 OverlapTestBudget);
	/** Rebuild LineFillPreviewCells from anchor→hover when line-fill intent is active. */
	void UpdateLineFillPreview(FEditorViewportClient* ViewportClient);
	/** Paint all preview cells in one undo transaction; updates LastPaintedCell. */
	void CommitLineFill(FEditorViewportClient* ViewportClient);
	void DrawLineFillPreview(const FSceneView* View, FPrimitiveDrawInterface* PDI) const;
	/** Anchor dot + faint in-plane axis guides through the line-fill anchor while Ctrl is held. */
	void DrawLineFillAnchor(const FSceneView* View, FPrimitiveDrawInterface* PDI) const;

	// --- Viewport feedback (cell pulses, fading cursor label) ---

	void AddCellPulse(const FIntVector& Cell, bool bErase);
	void DrawCellPulses(const FSceneView* View, FPrimitiveDrawInterface* PDI) const;
	/** Drops expired pulses / label; true while any were live this tick (the frame that clears them included). */
	bool UpdateFeedbackAnimations();
	/** Before the stroke's first cell applies: if the click would change nothing, says why (occupied, blocked, nothing to erase). */
	void ShowRefusedClickLabel(const FIntVector& Cell);
	/** Small red minus badge up-right of the cursor while erase intent is on. */
	void DrawEraseCursorBadge(FCanvas* Canvas, const FIntPoint& MousePixel) const;
	/**
	 * Owns the level viewports' pointer override: open hand over a bounds face handle, closed hand
	 * while dragging one. Re-applied every tick because the viewport drops it on focus / tracking changes.
	 */
	void UpdatePointerOverride();
	void ReleasePointerOverride();
	/** Paint-plane normal facing the camera, scaled to the overlay lift. */
	FVector GetOverlayLift(const FSceneView* View, int32 PlaneAxis) const;

	// --- Overlap prevention / occupancy ---

	/** Same static mesh or same decal material as the paint source (excludes preview actors). */
	bool DoesActorMatchSourceAsset(const AActor* Candidate) const;
	/** Location/rotation/scale within tolerance of the expected cell pose (paint / erase authority). */
	bool DoesActorMatchCellPose(const AActor* Actor, const FIntVector& Cell) const;
	/**
	 * Same-type actor at this cell's paint pose: this session's spawn, else one live collision query.
	 * Never returns the source at (0,0,0). Occupancy / erase share this path.
	 */
	AActor* FindErasableActorInCell(const FIntVector& Cell) const;
	/**
	 * Live same-type actor whose pose matches the cell (collision query around the cell pivot).
	 * Actors without WorldStatic collision are not found; that is the accepted limit.
	 */
	AActor* QueryMatchingActorAtCell(const FIntVector& Cell) const;
	/**
	 * Always on: source origin or a matching same-type actor already at this cell pose.
	 * Independent of Prevent Intersect.
	 */
	bool IsCellOccupied(const FIntVector& Cell) const;

	/** Cached per-cell Prevent Intersect result (true = foreign geo clips the cell OBB). */
	bool IsCellOverlapping(const FIntVector& Cell);
	/**
	 * Prevent Intersect only: inset paint-cell OBB vs triangle (complex) collision.
	 * Ignores same-type assets (occupancy owns those). Blocks on any other hit.
	 */
	bool ComputeCellOverlap(const FIntVector& Cell) const;

	/**
	 * Forces the editor selection back onto the paint source (sole selected actor).
	 * Used so click-select / DuplicateActor never ejects the paint session.
	 */
	void EnsureSourceSelected();

	void UpdateHover(FEditorViewportClient* ViewportClient);

	void EnsureGhostActor();
	void EnsureMeshGhostActor(AActor* Source, UStaticMeshComponent* SourceComponent, UWorld* World);
	void EnsureDecalGhostActor(AActor* Source, UDecalComponent* SourceDecal, UWorld* World);
	void DestroyGhostActor();
	void MoveGhostToCell(const FIntVector& Cell);
	void SetGhostVisible(bool bVisible);
	/** Hides the ghost while Shift is held or an erase stroke is active; restores on paint hover. */
	void UpdateGhostEraseVisibility(FEditorViewportClient* ViewportClient);

	/** Neutral hairline grid on the paint plane around the hover cell, fading with world distance. */
	void DrawGridLines(const FSceneView* View, FPrimitiveDrawInterface* PDI) const;

	/**
	 * Hover-cell outline on the paint plane: red = erase intent, else orange = intersect-blocked,
	 * slate = occupied, accent = paintable.
	 */
	void DrawHoverCellOutline(const FSceneView* View, FPrimitiveDrawInterface* PDI);

	/** Faint red corner brackets at the box of the actor Shift / an erase stroke would remove. */
	void DrawEraseTargetBrackets(FPrimitiveDrawInterface* PDI) const;

	/** True when Shift/erase-stroke hover is over an erasable matching actor in the cell. */
	bool HasEraseHoverTarget() const;

	// --- Tile bounds edit (B) ---

	void EnterBoundsEdit();
	/** Commit=true writes Context + mesh AssetUserData; false discards the edit draft. */
	void ExitBoundsEdit(bool bCommit);
	/** Reset the edit draft to the source mesh/decal geometric AABB (ignores saved AssetUserData). */
	void ResetBoundsEditToSourceGeometry();
	/** Pushes the draft as it was before a face drag or reset; clears redo. */
	void RecordBoundsEditStep(const FBox& Before);
	/** Ctrl+Z / Ctrl+Y inside bounds edit: swaps the draft with the top of the undo or redo stack. */
	void StepBoundsEditHistory(bool bRedo);
	void UpdateBoundsFaceHover(FEditorViewportClient* ViewportClient, int32 MouseX, int32 MouseY);
	bool BeginBoundsFaceDrag(FEditorViewportClient* ViewportClient, FViewport* Viewport);
	void UpdateBoundsFaceDrag(FEditorViewportClient* ViewportClient, int32 MouseX, int32 MouseY);
	void EndBoundsFaceDrag();
	void DrawBoundsEditPreview(const FSceneView* View, FPrimitiveDrawInterface* PDI) const;
	/** Pivot-relative cm along grid axes (not CellSize-normalized). */
	FVector WorldToGridCm(const FVector& World) const;
	FVector GridCmToWorld(const FVector& GridCm) const;
	bool ComputeAxisDragParam(
		FEditorViewportClient* ViewportClient,
		int32 MouseX,
		int32 MouseY,
		const FVector& AxisOrigin,
		const FVector& AxisDir,
		double& OutParam) const;
	/** Face center of EditBoundsGridLocal in world (Axis 0..2, Sign ±1). */
	FVector GetEditBoundsFaceCenterWorld(int32 Axis, int32 Sign) const;
	/** Closest face center under the cursor; false if none within pick radius. */
	bool PickEditBoundsFace(
		FEditorViewportClient* ViewportClient,
		int32 MouseX,
		int32 MouseY,
		int32& OutAxis,
		int32& OutSign) const;
	/** Mesh-local tile box: AssetUserData if present, else mesh AABB. */
	static FBox ResolveMeshLocalTileBounds(const UStaticMeshComponent* MeshComp);
	/** Convert current Context.MeshBoundsGridLocal → mesh local and store on the static mesh. */
	void SaveTileBoundsToSourceMesh() const;
	/** Re-read mesh tile bounds into Context (after undo of a bounds apply). No-op for decals. */
	void ReloadTileBoundsFromSourceMesh();

	void ShowHudOverlay();
	void HideHudOverlay();
	FProWorkflowToolHudModel BuildHudModel();
	/** True when the cursor is over the hit-testable HUD panel (checkbox / padding). */
	bool IsPointerOverHud() const;
	/** Clears overlap cache and forces a viewport redraw after the setting toggles. */
	void RefreshOverlapStateAfterSettingChange();

	/**
	 * Planar rectangle for a cell: mesh/decal bounds projected onto the paint plane (4 corners),
	 * lifted slightly toward the camera. Not a pivot-centered CellSize box.
	 */
	void GetCellPlaneCorners(
		const FIntVector& Cell,
		int32 PlaneAxis,
		const FVector& Lift,
		FVector& OutC00,
		FVector& OutC10,
		FVector& OutC11,
		FVector& OutC01) const;

	/**
	 * Oriented box matching MeshBoundsGridLocal at the cell (same AABB the paint/intersect tests use).
	 * OutBoxToWorld is rotation+translation at the bounds center; OutRadii are half-extents.
	 */
	bool GetCellOrientedBox(const FIntVector& Cell, FMatrix& OutBoxToWorld, FVector& OutRadii) const;

	int32 GetActivePlaneAxis() const { return bStrokeActive ? LockedPlaneAxis : CurrentPlaneAxis; }

	static UStaticMeshComponent* GetSourceStaticMeshComponent(const AActor* Actor);
	/** ADecalActor::GetDecal(), or first UDecalComponent on the actor. */
	static UDecalComponent* GetSourceDecalComponent(const AActor* Actor);

	// Mode state
	bool bActive = false;
	/** GFrameCounter when this session was entered. Same-frame toggle-off is the other handler of that press. */
	uint64 ActivatedFrame = MAX_uint64;
	FGridPaintContext Context;
	/** Actor scale applied to duplicates (kept identical to the source). */
	FVector SourceScale = FVector::OneVector;
	/** World scale of the source's static mesh component (used by the root-SMC ghost). */
	FVector GhostScale = FVector::OneVector;
	/** Plane normal axis: camera-picked for meshes while hovering; always 0 (local X) for decals. */
	int32 CurrentPlaneAxis = 2;
	bool bHasHoverCell = false;
	FIntVector HoverCell = FIntVector::ZeroValue;
	int32 NextLabelIndex = 1;

	// Session state (T-press -> Esc)
	/** Session-spawned duplicates by cell (excludes the source at 0,0,0); preferred erase targets. */
	TMap<FIntVector, TWeakObjectPtr<AActor>> SessionSpawnedActors;
	/** Recent per-cell overlap results; reset on spawn, plane change, session start/end, and a size cap. */
	TMap<FIntVector, bool> CellBlockedCache;

	// Stroke state
	bool bStrokeActive = false;
	/** True when the stroke began with Shift held; frozen for the whole stroke (paint vs erase). */
	bool bEraseStroke = false;
	/**
	 * True while Shift is held or an erase stroke is active (not merely occupied hover).
	 * Drives red erase PDI / HUD ERASE chip; separate from bHideGhostForErase.
	 */
	bool bEraseIntent = false;
	/**
	 * True while erase intent is active or hover is on an occupied cell —
	 * ghost stays hidden so the real asset (or empty cell) is visible.
	 */
	bool bHideGhostForErase = false;
	/** Plane axis frozen at drag start for the duration of the stroke. */
	int32 LockedPlaneAxis = 2;
	TOptional<FIntVector> LastCell;
	/** One undo transaction per stroke; created lazily on the first spawn/erase so empty strokes leave no undo entry. */
	TUniquePtr<FScopedTransaction> StrokeTransaction;
	/**
	 * Last successfully painted cell this session (not the source). Line-fill anchors here when set;
	 * otherwise anchors at origin (0,0,0).
	 */
	TOptional<FIntVector> LastPaintedCell;
	/** Paintable cells on the current exact axis-aligned Ctrl line (empty if none / off-axis). */
	TArray<FIntVector> LineFillPreviewCells;
	/** True from Ctrl+LMB press until release so camera delta stays blocked without a freehand stroke. */
	bool bLineFillCapture = false;
	/** Line-fill intent (Ctrl) with a hover cell; set by UpdateLineFillPreview, drives the anchor guides. */
	bool bLineFillIntentActive = false;

	struct FCellPulse
	{
		FIntVector Cell = FIntVector::ZeroValue;
		int32 PlaneAxis = 2;
		double StartSeconds = 0.0;
		bool bErase = false;
	};
	/** Paint pops / erase shrinks, oldest first. */
	TArray<FCellPulse> CellPulses;
	/** Fading cursor label for plane auto-switch and bounds apply. */
	ProWorkflowTools::CursorLabel::FFadingLabel FeedbackLabel;
	/** Pointer currently forced on the level viewports; Default = no override. */
	EMouseCursor::Type AppliedPointer = EMouseCursor::Default;
	/** Hovered viewport from the last Tick (compared, never dereferenced); the cursor label draws only there. */
	const FEditorViewportClient* LastTickViewportClient = nullptr;

	// Bounds edit (B)
	bool bBoundsEditActive = false;
	/** Draft tile AABB in grid-local cm; committed into Context on B apply. */
	FBox EditBoundsGridLocal = FBox(ForceInit);
	int32 BoundsHoverAxis = INDEX_NONE;
	int32 BoundsHoverSign = 0;
	bool bBoundsFaceDrag = false;
	int32 BoundsDragAxis = INDEX_NONE;
	int32 BoundsDragSign = 0;
	FVector BoundsDragAxisWorld = FVector::ZeroVector;
	FVector BoundsDragHandleStartWorld = FVector::ZeroVector;
	double BoundsDragStartParam = 0.0;
	/** Draft at drag start; a drag that changed it becomes one undo step. */
	FBox BoundsDragStartBox = FBox(ForceInit);
	/** Draft history for this bounds edit only; reset on enter. */
	TArray<FBox> BoundsEditUndoStack;
	TArray<FBox> BoundsEditRedoStack;
	/** Engine vertex search is once per frame while V is held on a bounds face. */
	ProWorkflowTools::FVertexSnapFrameQuery BoundsVertexSnapQuery;
	double BoundsDragAnchorGridCm = 0.0;

	// Ghost preview (transient, never transacted) — static mesh or decal actor.
	TWeakObjectPtr<AActor> GhostActor;

	/** Bottom-left Slate HUD while the tool is active (typed for IsPointerOverPanel). */
	TProWorkflowToolHudOverlay<SProWorkflowToolHud> HudOverlay;
};
