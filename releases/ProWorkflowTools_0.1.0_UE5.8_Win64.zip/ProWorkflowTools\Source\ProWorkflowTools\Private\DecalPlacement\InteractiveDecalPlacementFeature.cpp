// Copyright © 2026 Trey McNair. All rights reserved.
// Plugin module for interactive decal placement in the level viewport.

#include "DecalPlacement/InteractiveDecalPlacementFeature.h"

#include "EditorModeManager.h"
#include "EditorModeRegistry.h"
#include "InteractiveDecalPlacementCollectionEntryCustomization.h"
#include "InteractiveDecalPlacementCollectionUtils.h"
#include "DecalPlacement/InteractiveDecalPlacementCommands.h"
#include "InteractiveDecalPlacementEdMode.h"
#include "ProWorkflowToolsEngineAdapter.h"
#include "ProWorkflowToolsModule.h"
#include "ProWorkflowToolsSettings.h"
#include "Framework/Commands/UICommandList.h"
#include "LevelEditor.h"
#include "Modules/ModuleManager.h"
#include "PropertyEditorModule.h"

#define LOCTEXT_NAMESPACE "InteractiveDecalPlacementFeature"

void FInteractiveDecalPlacementFeature::Startup()
{
	FInteractiveDecalPlacementCommands::Register();
	RegisterSettings();
	BindCommands();

	SettingsChangedHandle = GetMutableDefault<UProWorkflowToolsSettings>()->OnSettingChanged().AddRaw(
		this, &FInteractiveDecalPlacementFeature::OnSettingsChanged);

	FEditorModeRegistry::Get().RegisterMode<FInteractiveDecalPlacementEdMode>(
		FInteractiveDecalPlacementEdMode::EM_InteractiveDecalPlacement,
		LOCTEXT("PlacementModeName", "Interactive Decal Placement"),
		FSlateIcon(),
		/*bVisible=*/false);
}

void FInteractiveDecalPlacementFeature::Shutdown()
{
	if (UObjectInitialized())
	{
		if (UProWorkflowToolsSettings* Settings = GetMutableDefault<UProWorkflowToolsSettings>())
		{
			Settings->OnSettingChanged().Remove(SettingsChangedHandle);
		}
	}

	// Mode tools may already be torn down on exit; only touch them while UObject + Level Editor remain.
	if (UObjectInitialized() && GEditor)
	{
		if (const FLevelEditorModule* LevelEditorModule = FModuleManager::GetModulePtr<FLevelEditorModule>("LevelEditor"))
		{
			if (LevelEditorModule->GetFirstLevelEditor().IsValid())
			{
				FEditorModeTools& ModeTools = GLevelEditorModeTools();
				if (ModeTools.IsModeActive(FInteractiveDecalPlacementEdMode::EM_InteractiveDecalPlacement))
				{
					ModeTools.DeactivateMode(FInteractiveDecalPlacementEdMode::EM_InteractiveDecalPlacement);
				}
			}
		}
	}

	FEditorModeRegistry::Get().UnregisterMode(FInteractiveDecalPlacementEdMode::EM_InteractiveDecalPlacement);
	UnregisterSettings();

	if (FLevelEditorModule* LevelEditorModule = FModuleManager::GetModulePtr<FLevelEditorModule>("LevelEditor"))
	{
		if (FInteractiveDecalPlacementCommands::IsRegistered())
		{
			const FInteractiveDecalPlacementCommands& Commands = FInteractiveDecalPlacementCommands::Get();
			const TSharedRef<FUICommandList> CommandList = LevelEditorModule->GetGlobalLevelEditorActions();
			CommandList->UnmapAction(Commands.StartPlacement);
		}
	}

	FInteractiveDecalPlacementCommands::Unregister();
}

void FInteractiveDecalPlacementFeature::StartPlacement()
{
	if (FProWorkflowToolsModule* Module = FProWorkflowToolsModule::GetPtr())
	{
		Module->ReleaseViewportToolsExcept(EProWorkflowViewportTool::DecalPlacement);
	}

	// Keep Selection alive next to Decal mode (EM_Default is not a real IsModeActive id).
	ProWorkflowTools::EnsureSelectionModeActive();

	FEditorModeTools& ModeTools = GLevelEditorModeTools();
	if (!ModeTools.IsModeActive(FInteractiveDecalPlacementEdMode::EM_InteractiveDecalPlacement))
	{
		ModeTools.ActivateMode(FInteractiveDecalPlacementEdMode::EM_InteractiveDecalPlacement);
	}

	if (FInteractiveDecalPlacementEdMode* PlacementMode = GetActivePlacementMode())
	{
		PlacementMode->BeginPlacement();
	}
}

FInteractiveDecalPlacementEdMode* FInteractiveDecalPlacementFeature::GetActivePlacementMode() const
{
	FEditorModeTools& ModeTools = GLevelEditorModeTools();
	return static_cast<FInteractiveDecalPlacementEdMode*>(
		ModeTools.GetActiveMode(FInteractiveDecalPlacementEdMode::EM_InteractiveDecalPlacement));
}

void FInteractiveDecalPlacementFeature::RegisterSettings()
{
	// Settings live on the shared Pro Workflow Tools page (registered by the ProWorkflowTools
	// module); we only add the row customization for decal collection entries.
	FPropertyEditorModule& PropertyModule = FModuleManager::LoadModuleChecked<FPropertyEditorModule>("PropertyEditor");
	PropertyModule.RegisterCustomClassLayout(
		UProWorkflowToolsSettings::StaticClass()->GetFName(),
		FOnGetDetailCustomizationInstance::CreateStatic(&FProWorkflowToolsSettingsCustomization::MakeInstance));
	PropertyModule.RegisterCustomPropertyTypeLayout(
		FInteractiveDecalCollectionEntry::StaticStruct()->GetFName(),
		FOnGetPropertyTypeCustomizationInstance::CreateStatic(&FInteractiveDecalCollectionEntryCustomization::MakeInstance));
}

void FInteractiveDecalPlacementFeature::UnregisterSettings()
{
	if (FPropertyEditorModule* PropertyModule = FModuleManager::GetModulePtr<FPropertyEditorModule>("PropertyEditor"))
	{
		PropertyModule->UnregisterCustomClassLayout(UProWorkflowToolsSettings::StaticClass()->GetFName());
		PropertyModule->UnregisterCustomPropertyTypeLayout(FInteractiveDecalCollectionEntry::StaticStruct()->GetFName());
	}
}

void FInteractiveDecalPlacementFeature::BindCommands()
{
	FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>("LevelEditor");
	const TSharedRef<FUICommandList> CommandList = LevelEditorModule.GetGlobalLevelEditorActions();
	const FInteractiveDecalPlacementCommands& Commands = FInteractiveDecalPlacementCommands::Get();

	CommandList->MapAction(
		Commands.StartPlacement,
		FExecuteAction::CreateRaw(this, &FInteractiveDecalPlacementFeature::StartPlacement),
		FCanExecuteAction::CreateRaw(this, &FInteractiveDecalPlacementFeature::CanStartPlacement));
}

bool FInteractiveDecalPlacementFeature::CanStartPlacement() const
{
	return GetDefault<UProWorkflowToolsSettings>()->bEnableInteractiveDecalPlacement
		&& GEditor && GEditor->GetEditorWorldContext().World() != nullptr;
}

void FInteractiveDecalPlacementFeature::OnSettingsChanged(UObject* /*Settings*/, FPropertyChangedEvent& /*PropertyChangedEvent*/)
{
	InteractiveDecalPlacement::InvalidateBrowseCategoryCache();

	if (!GetDefault<UProWorkflowToolsSettings>()->bEnableInteractiveDecalPlacement && GEditor)
	{
		FEditorModeTools& ModeTools = GLevelEditorModeTools();
		if (ModeTools.IsModeActive(FInteractiveDecalPlacementEdMode::EM_InteractiveDecalPlacement))
		{
			ModeTools.DeactivateMode(FInteractiveDecalPlacementEdMode::EM_InteractiveDecalPlacement);
		}
	}
}

#undef LOCTEXT_NAMESPACE

