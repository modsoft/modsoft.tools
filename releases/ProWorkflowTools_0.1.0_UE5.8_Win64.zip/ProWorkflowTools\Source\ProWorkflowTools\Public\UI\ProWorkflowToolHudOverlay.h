// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "Templates/SharedPointer.h"
#include "Widgets/SWidget.h"

class IAssetViewport;

namespace ProWorkflowToolHudOverlay
{
	/** Adds Widget to the first active level-editor viewport overlay. Returns that viewport (invalid if none). */
	PROWORKFLOWTOOLS_API TWeakPtr<IAssetViewport> Add(const TSharedRef<SWidget>& Widget);

	/** Removes Widget from the viewport it was added to. No-op if that viewport is gone. */
	PROWORKFLOWTOOLS_API void Remove(const TWeakPtr<IAssetViewport>& HostViewport, const TSharedRef<SWidget>& Widget);
}

/**
 * One tool HUD on a level-editor viewport overlay. Removes from the viewport it was added to;
 * Show re-attaches a fresh widget when that viewport was destroyed (layout change).
 */
template <typename WidgetType>
class TProWorkflowToolHudOverlay
{
public:
	/** MakeWidget returns TSharedRef<WidgetType>. Only called when the HUD is not already shown. */
	template <typename FactoryType>
	void Show(FactoryType&& MakeWidget)
	{
		if (Widget.IsValid() && HostViewport.IsValid())
		{
			return;
		}

		Hide();
		const TSharedRef<WidgetType> NewWidget = MakeWidget();
		HostViewport = ProWorkflowToolHudOverlay::Add(NewWidget);
		if (HostViewport.IsValid())
		{
			Widget = NewWidget;
		}
	}

	void Hide()
	{
		if (Widget.IsValid())
		{
			ProWorkflowToolHudOverlay::Remove(HostViewport, Widget.ToSharedRef());
		}
		Widget.Reset();
		HostViewport.Reset();
	}

	bool IsValid() const { return Widget.IsValid(); }
	WidgetType* operator->() const { return Widget.Get(); }

private:
	TSharedPtr<WidgetType> Widget;
	TWeakPtr<IAssetViewport> HostViewport;
};
