// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "Containers/Ticker.h"
#include "Subsystems/WorldSubsystem.h"
#include "SuperGroupSubsystem.generated.h"

class AGroupActor;

/**
 * Transient enter/exit edit state for native AGroupActor (no custom persisted data).
 */
UCLASS()
class PROWORKFLOWTOOLS_API USuperGroupSubsystem : public UWorldSubsystem
{
	GENERATED_BODY()

public:
	virtual bool DoesSupportWorldType(EWorldType::Type WorldType) const override;
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;

#if WITH_EDITOR
	bool EnterEdit(AGroupActor* InGroup);
	bool ExitEdit();
	bool IsEditing() const { return EditingGroupActor.IsValid(); }
	AGroupActor* GetEditingGroup() const;

	bool IsActorInEditingHierarchy(const AActor* InActor) const;
	bool CanEnterEdit(AGroupActor* InGroup, FText* OutReason = nullptr) const;
	bool CanExitEdit(FText* OutReason = nullptr) const;

	/** Re-assert Selection mode now and next tick (recover from "No Active Mode"). */
	void RestoreSelectionModeSoon();

	/** Re-apply the focus mask from settings. No-op when not editing. */
	void RefreshEditingVisuals();

	DECLARE_MULTICAST_DELEGATE_OneParam(FOnEditingChanged, bool /*bEditing*/);
	/** Group edit started or ended, in any editor world. */
	static FOnEditingChanged& OnEditingChanged();
#endif

private:
#if WITH_EDITOR
	void ApplyEditingVisuals();
	void RestoreEditingVisuals();

	void RefreshMemberEditingState();

	void SetViewportEditingMask(bool bEnabled);

	bool TickEditing(float DeltaTime);

	void CancelEditState();

	void EnsureLevelEditorSelectionMode();

	void OnSelectionChanged(UObject* NewSelection);
	void OnPostUndoRedo();
	void OnLevelActorDeleted(AActor* InActor);
	void OnLevelActorAdded(AActor* InActor);

	void BindEditorModeChangedDelegate();
	void UnbindEditorModeChangedDelegate();

	TWeakObjectPtr<AGroupActor> EditingGroupActor;
	bool bWasLockedBeforeEdit = true;
	bool bIsAdjustingSelection = false;
	bool bMemberVisualsDirty = false;
	TArray<TWeakObjectPtr<AActor>> ActorsWithEditingVisualState;

	FTSTicker::FDelegateHandle EditingTickerHandle;
	FDelegateHandle SelectionChangedHandle;
	FDelegateHandle PostUndoRedoHandle;
	FDelegateHandle LevelActorDeletedHandle;
	FDelegateHandle LevelActorAddedHandle;
	FDelegateHandle EditorModeIDChangedHandle;

	/** Accumulator for a cheap periodic Selection-mode guard while editing (not every tick). */
	float SelectionModeCheckAccumulator = 0.0f;
	static constexpr float SelectionModeCheckIntervalSeconds = 0.5f;
#endif
};

