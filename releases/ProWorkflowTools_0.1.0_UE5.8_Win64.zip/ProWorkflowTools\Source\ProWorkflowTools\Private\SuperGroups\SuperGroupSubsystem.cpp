// Copyright © 2026 Trey McNair. All rights reserved.

#include "SuperGroups/SuperGroupSubsystem.h"
#include "SuperGroups/SuperGroups.h"
#include "ProWorkflowToolsSettings.h"

#if WITH_EDITOR
#include "ActorGroupingUtils.h"
#include "Editor.h"
#include "Editor/GroupActor.h"
#include "EditorModeManager.h"
#include "Engine/Engine.h"
#include "Engine/Selection.h"
#include "LevelEditorViewport.h"
#endif

#include UE_INLINE_GENERATED_CPP_BY_NAME(SuperGroupSubsystem)

bool USuperGroupSubsystem::DoesSupportWorldType(EWorldType::Type WorldType) const
{
	return WorldType == EWorldType::Editor;
}

void USuperGroupSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);

#if WITH_EDITOR
	SelectionChangedHandle = USelection::SelectionChangedEvent.AddUObject(this, &USuperGroupSubsystem::OnSelectionChanged);
	PostUndoRedoHandle = FEditorDelegates::PostUndoRedo.AddUObject(this, &USuperGroupSubsystem::OnPostUndoRedo);
	if (GEngine)
	{
		LevelActorDeletedHandle = GEngine->OnLevelActorDeleted().AddUObject(this, &USuperGroupSubsystem::OnLevelActorDeleted);
		LevelActorAddedHandle = GEngine->OnLevelActorAdded().AddUObject(this, &USuperGroupSubsystem::OnLevelActorAdded);
	}
#endif
}

void USuperGroupSubsystem::Deinitialize()
{
#if WITH_EDITOR
	if (IsEditing())
	{
		ExitEdit();
	}

	if (SelectionChangedHandle.IsValid())
	{
		USelection::SelectionChangedEvent.Remove(SelectionChangedHandle);
		SelectionChangedHandle.Reset();
	}

	if (PostUndoRedoHandle.IsValid())
	{
		FEditorDelegates::PostUndoRedo.Remove(PostUndoRedoHandle);
		PostUndoRedoHandle.Reset();
	}

	if (GEngine)
	{
		if (LevelActorDeletedHandle.IsValid())
		{
			GEngine->OnLevelActorDeleted().Remove(LevelActorDeletedHandle);
			LevelActorDeletedHandle.Reset();
		}
		if (LevelActorAddedHandle.IsValid())
		{
			GEngine->OnLevelActorAdded().Remove(LevelActorAddedHandle);
			LevelActorAddedHandle.Reset();
		}
	}

	UnbindEditorModeChangedDelegate();
#endif

	Super::Deinitialize();
}

#if WITH_EDITOR

bool USuperGroupSubsystem::EnterEdit(AGroupActor* InGroup)
{
	FText Reason;
	if (!CanEnterEdit(InGroup, &Reason))
	{
		UE_LOG(LogSuperGroups, Warning, TEXT("Cannot enter group edit: %s"), *Reason.ToString());
		return false;
	}

	if (IsEditing())
	{
		ExitEdit();
	}

	EditingGroupActor = InGroup;
	bWasLockedBeforeEdit = InGroup->IsLocked();

	if (GEditor)
	{
		// Unlock the group so its members can be selected and edited individually.
		if (bWasLockedBeforeEdit)
		{
			GEditor->SelectNone(false, true, false);
			GEditor->SelectActor(InGroup, true, false);
			UActorGroupingUtils::Get()->UnlockSelectedGroups();
		}

		// Select the group's members so it's clear you're now "inside" the group.
		GEditor->SelectNone(false, true, false);

		TArray<AActor*> Members;
		InGroup->GetGroupActors(Members);
		for (AActor* Member : Members)
		{
			if (Member)
			{
				GEditor->SelectActor(Member, true, false);
			}
		}
		GEditor->NoteSelectionChange();
	}

	ApplyEditingVisuals();

	// Keep the default Selecting mode active so the gizmo stays available while editing.
	EnsureLevelEditorSelectionMode();

	OnEditingChanged().Broadcast(true);
	return true;
}

bool USuperGroupSubsystem::ExitEdit()
{
	FText Reason;
	if (!CanExitEdit(&Reason))
	{
		UE_LOG(LogSuperGroups, Warning, TEXT("Cannot exit group edit: %s"), *Reason.ToString());
		return false;
	}

	AGroupActor* GroupBeingEdited = EditingGroupActor.Get();
	const bool bRelock = bWasLockedBeforeEdit;

	// Clear edit state first so selection/tick hooks become inert during teardown.
	EditingGroupActor.Reset();
	bWasLockedBeforeEdit = true;

	RestoreEditingVisuals();

	if (GroupBeingEdited && GEditor)
	{
		GEditor->SelectNone(false, true, false);
		GEditor->SelectActor(GroupBeingEdited, true, false);

		if (bRelock)
		{
			UActorGroupingUtils::Get()->LockSelectedGroups();
		}
		else
		{
			UActorGroupingUtils::Get()->UnlockSelectedGroups();
		}

		// Reselect the group as a unit (native locked-group behavior).
		GEditor->SelectNone(false, true, false);
		GEditor->SelectActor(GroupBeingEdited, true, true);
	}

	// Restore the default Selecting mode (and again next tick, since mode transitions can defer a frame).
	RestoreSelectionModeSoon();

	OnEditingChanged().Broadcast(false);
	return true;
}

void USuperGroupSubsystem::RefreshEditingVisuals()
{
	if (!IsEditing())
	{
		return;
	}

	RestoreEditingVisuals();
	ApplyEditingVisuals();
}

USuperGroupSubsystem::FOnEditingChanged& USuperGroupSubsystem::OnEditingChanged()
{
	static FOnEditingChanged Delegate;
	return Delegate;
}

AGroupActor* USuperGroupSubsystem::GetEditingGroup() const
{
	return EditingGroupActor.Get();
}

bool USuperGroupSubsystem::IsActorInEditingHierarchy(const AActor* InActor) const
{
	const AGroupActor* EditingGroup = EditingGroupActor.Get();
	if (!EditingGroup || !InActor)
	{
		return false;
	}

	if (InActor == EditingGroup)
	{
		return true;
	}

	TArray<AActor*> Children;
	const_cast<AGroupActor*>(EditingGroup)->GetAllChildren(Children, true);
	return Children.Contains(const_cast<AActor*>(InActor));
}

bool USuperGroupSubsystem::CanEnterEdit(AGroupActor* InGroup, FText* OutReason) const
{
	if (!InGroup)
	{
		if (OutReason)
		{
			*OutReason = NSLOCTEXT("SuperGroups", "InvalidGroup", "No group specified.");
		}
		return false;
	}

	if (IsEditing() && EditingGroupActor.Get() == InGroup)
	{
		if (OutReason)
		{
			*OutReason = NSLOCTEXT("SuperGroups", "AlreadyEditing", "Already editing this group.");
		}
		return false;
	}

	return true;
}

bool USuperGroupSubsystem::CanExitEdit(FText* OutReason) const
{
	if (!IsEditing())
	{
		if (OutReason)
		{
			*OutReason = NSLOCTEXT("SuperGroups", "NotEditing", "Not currently editing a group.");
		}
		return false;
	}

	return true;
}

void USuperGroupSubsystem::ApplyEditingVisuals()
{
	if (!GetDefault<UProWorkflowToolsSettings>()->bUseLevelInstanceEditingVisuals)
	{
		return;
	}

	if (!EditingGroupActor.IsValid())
	{
		return;
	}

	RefreshMemberEditingState();

	SetViewportEditingMask(true);

	if (!EditingTickerHandle.IsValid())
	{
		EditingTickerHandle = FTSTicker::GetCoreTicker().AddTicker(
			FTickerDelegate::CreateUObject(this, &USuperGroupSubsystem::TickEditing), 0.0f);
	}

	BindEditorModeChangedDelegate();
	SelectionModeCheckAccumulator = 0.0f;

	if (GEditor)
	{
		GEditor->RedrawAllViewports();
	}
}

void USuperGroupSubsystem::RestoreEditingVisuals()
{
	UnbindEditorModeChangedDelegate();
	SelectionModeCheckAccumulator = 0.0f;

	if (EditingTickerHandle.IsValid())
	{
		FTSTicker::GetCoreTicker().RemoveTicker(EditingTickerHandle);
		EditingTickerHandle.Reset();
	}

	for (const TWeakObjectPtr<AActor>& WeakActor : ActorsWithEditingVisualState)
	{
		if (AActor* Actor = WeakActor.Get())
		{
			Actor->PushLevelInstanceEditingStateToProxies(false);
		}
	}
	ActorsWithEditingVisualState.Reset();
	bMemberVisualsDirty = false;

	SetViewportEditingMask(false);

	if (GEditor)
	{
		GEditor->RedrawAllViewports();
	}
}

void USuperGroupSubsystem::RefreshMemberEditingState()
{
	AGroupActor* EditingGroup = EditingGroupActor.Get();
	if (!EditingGroup)
	{
		return;
	}

	// Clear state on the previous set (handles members that were removed) then re-apply to the current set.
	for (const TWeakObjectPtr<AActor>& WeakActor : ActorsWithEditingVisualState)
	{
		if (AActor* Actor = WeakActor.Get())
		{
			Actor->PushLevelInstanceEditingStateToProxies(false);
		}
	}
	ActorsWithEditingVisualState.Reset();

	EditingGroup->ForEachActorInGroup([this](AActor* Actor, AGroupActor* /*GroupActor*/)
	{
		if (Actor)
		{
			Actor->PushLevelInstanceEditingStateToProxies(true);
			ActorsWithEditingVisualState.Add(Actor);
		}
	});

	bMemberVisualsDirty = false;
}

void USuperGroupSubsystem::SetViewportEditingMask(bool bEnabled)
{
	if (!GEditor)
	{
		return;
	}

	for (FLevelEditorViewportClient* LevelVC : GEditor->GetLevelViewportClients())
	{
		if (!LevelVC)
		{
			continue;
		}

		// Reuse the Level Instance editing visualization: focused actors stay lit, the rest is greyed.
		// EditingLevelInstance is transient; VisualizeLevelInstanceEditing is the user's saved Show
		// toggle for that visualization and stays theirs (same pattern as FLevelInstanceEditorMode).
		LevelVC->EngineShowFlags.EditingLevelInstance = bEnabled;
		LevelVC->LastEngineShowFlags.EditingLevelInstance = bEnabled;
	}
}

bool USuperGroupSubsystem::TickEditing(float DeltaTime)
{
	if (!IsEditing())
	{
		EditingTickerHandle.Reset();
		return false;
	}

	SetViewportEditingMask(true);

	// Selection-mode guard: enter-edit + mode-changed callback cover the common cases.
	// Keep a cheap periodic check so deferred "No Active Mode" still recovers without
	// calling EnsureLevelEditorSelectionMode every tick.
	SelectionModeCheckAccumulator += DeltaTime;
	if (SelectionModeCheckAccumulator >= SelectionModeCheckIntervalSeconds)
	{
		SelectionModeCheckAccumulator = 0.0f;
		EnsureLevelEditorSelectionMode();
	}

	// Deferred by a tick so freshly duplicated/added actors have registered their render proxies.
	if (bMemberVisualsDirty)
	{
		RefreshMemberEditingState();
		if (GEditor)
		{
			GEditor->RedrawAllViewports();
		}
	}

	return true;
}

void USuperGroupSubsystem::EnsureLevelEditorSelectionMode()
{
	FEditorModeTools& ModeTools = GLevelEditorModeTools();
	if (!ModeTools.IsDefaultModeActive())
	{
		// Activating the default mode restores the "Selection" mode + transform gizmo.
		ModeTools.ActivateDefaultMode();
	}
}

void USuperGroupSubsystem::RestoreSelectionModeSoon()
{
	EnsureLevelEditorSelectionMode();

	// Some mode transitions are deferred to the next tick, so re-assert once more then.
	FTSTicker::GetCoreTicker().AddTicker(
		FTickerDelegate::CreateWeakLambda(this, [this](float) { EnsureLevelEditorSelectionMode(); return false; }), 0.0f);
}

void USuperGroupSubsystem::BindEditorModeChangedDelegate()
{
	if (EditorModeIDChangedHandle.IsValid())
	{
		return;
	}

	EditorModeIDChangedHandle = GLevelEditorModeTools().OnEditorModeIDChanged().AddWeakLambda(
		this,
		[this](const FEditorModeID& /*ModeID*/, bool /*bIsEnteringMode*/)
		{
			if (!IsEditing())
			{
				return;
			}

			// Mode churn while editing can drop the default Selection mode (hides the gizmo).
			EnsureLevelEditorSelectionMode();
		});
}

void USuperGroupSubsystem::UnbindEditorModeChangedDelegate()
{
	if (!EditorModeIDChangedHandle.IsValid())
	{
		return;
	}

	GLevelEditorModeTools().OnEditorModeIDChanged().Remove(EditorModeIDChangedHandle);
	EditorModeIDChangedHandle.Reset();
}

void USuperGroupSubsystem::CancelEditState()
{
	if (!IsEditing())
	{
		return;
	}

	EditingGroupActor.Reset();
	bWasLockedBeforeEdit = true;

	RestoreEditingVisuals();

	OnEditingChanged().Broadcast(false);
}

void USuperGroupSubsystem::OnSelectionChanged(UObject* /*NewSelection*/)
{
	if (!IsEditing() || bIsAdjustingSelection || !GEditor)
	{
		return;
	}

	if (!GetDefault<UProWorkflowToolsSettings>()->bRestrictSelectionWhileEditing)
	{
		return;
	}

	USelection* SelectedActors = GEditor->GetSelectedActors();
	if (!SelectedActors)
	{
		return;
	}

	TArray<AActor*> ToDeselect;
	for (FSelectionIterator It(*SelectedActors); It; ++It)
	{
		if (AActor* Actor = Cast<AActor>(*It))
		{
			if (!IsActorInEditingHierarchy(Actor))
			{
				ToDeselect.Add(Actor);
			}
		}
	}

	if (ToDeselect.Num() == 0)
	{
		return;
	}

	// Strip out-of-group actors (e.g. from a marquee select) without recursing back into this handler.
	TGuardValue<bool> Guard(bIsAdjustingSelection, true);
	SelectedActors->BeginBatchSelectOperation();
	for (AActor* Actor : ToDeselect)
	{
		GEditor->SelectActor(Actor, false, false);
	}
	SelectedActors->EndBatchSelectOperation();
	GEditor->NoteSelectionChange();
}

void USuperGroupSubsystem::OnPostUndoRedo()
{
	if (!IsEditing())
	{
		return;
	}

	// If undo/redo destroyed the group or restored its locked state, the isolated edit is no longer valid.
	const AGroupActor* Group = EditingGroupActor.Get();
	if (!Group || Group->IsLocked())
	{
		CancelEditState();
	}
}

void USuperGroupSubsystem::OnLevelActorDeleted(AActor* InActor)
{
	if (IsEditing() && InActor == EditingGroupActor.Get())
	{
		CancelEditState();
	}
}

void USuperGroupSubsystem::OnLevelActorAdded(AActor* InActor)
{
	AGroupActor* EditingGroup = EditingGroupActor.Get();
	if (!EditingGroup || bIsAdjustingSelection || !InActor)
	{
		return;
	}

	// GEngine broadcasts globally — only adopt actors spawned into this editor world.
	if (InActor->GetWorld() != GetWorld())
	{
		return;
	}

	// Skip editor preview/ghost actors (e.g. Interactive Decal Placement's RF_Transient preview).
	if (InActor->bIsEditorPreviewActor)
	{
		return;
	}

	// Only capture user-facing actors added while inside the group (e.g. duplicated or newly placed).
	if (!InActor->IsListedInSceneOutliner() || InActor == EditingGroup)
	{
		return;
	}

	// Anything created while "inside" the group joins the group, mirroring Level Instance editing.
	if (!IsActorInEditingHierarchy(InActor))
	{
		EditingGroup->Add(*InActor);
	}

	// Keep folder nesting consistent: new members inherit the group's folder when that option is on.
	// Callers that set a deliberate folder after spawn (e.g. Decals/<category>) overwrite this.
	if (GetDefault<UProWorkflowToolsSettings>()->bNestGroupInFolderOnCreate)
	{
		InActor->SetFolderPath(EditingGroup->GetFolderPath());
	}

	// Defer the render-state push to the next tick so the actor's proxies exist.
	bMemberVisualsDirty = true;
}

#endif

