// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "Engine/EngineBaseTypes.h"
#include "InputCoreTypes.h"

class FCanvas;
class FEditorModeTools;
class FEditorViewportClient;
class FPrimitiveDrawInterface;
class FReferenceCollector;
class FSceneView;
class FViewport;
class HHitProxy;
struct FConvexVolume;
struct FViewportClick;

/** What FProWorkflowToolsEdMode exposes to the tools it hosts. */
class IWorkflowToolHost
{
public:
	virtual ~IWorkflowToolHost() = default;

	virtual FEditorModeTools* GetModeTools() const = 0;

	/** Some hosted tool is standing in for the transform gizmo (Box Scale cage, Grid Paint session). */
	virtual bool IsTransformGizmoReplaced() const = 0;
};

/** Which of the viewports the mode ticks drives this tool's Tick. */
enum class EWorkflowToolTickViewport : uint8
{
	None,
	/** Keyboard-driven state (key state and cursor are per viewport). */
	Focused,
	/** Cursor-driven previews. */
	Hovered,
};

/**
 * One tool hosted by FProWorkflowToolsEdMode. The mode walks its tools in a fixed priority order for
 * every viewport hook, and the first tool that handles an event takes it. While a tool is exclusive,
 * it is the only tool that receives input.
 */
class FWorkflowViewportTool
{
public:
	virtual ~FWorkflowViewportTool() = default;

	void SetHost(IWorkflowToolHost& InHost) { Host = &InHost; }

	/** A session, stroke, drag or press-release gesture is in progress and owns the viewport. */
	virtual bool IsExclusive() const { return false; }

	/** Draws its own transform affordance in place of the transform gizmo. */
	virtual bool ReplacesTransformGizmo() const { return false; }

	/** Owns the mouse: the viewport's mouse-delta camera path must not run. */
	virtual bool CapturesMouse() const { return false; }

	/** The engine's LMB drag tool (ortho box select) must not start. */
	virtual bool BlocksViewportDragTool() const { return false; }

	virtual EWorkflowToolTickViewport GetTickViewport() const { return EWorkflowToolTickViewport::None; }
	virtual void Tick(FEditorViewportClient* ViewportClient, float DeltaTime) {}

	/** The hosting mode is exiting. */
	virtual void Exit() {}

	/**
	 * Another tool took the mouse press this tool's tracking started for. With ITF viewport interactions
	 * mode tracking starts before InputKey sees the press, so that tracking is void and must not resume.
	 */
	virtual void CancelTracking() {}

	virtual bool InputKey(FEditorViewportClient* ViewportClient, FViewport* Viewport, FKey Key, EInputEvent Event) { return false; }
	virtual bool StartTracking(FEditorViewportClient* ViewportClient, FViewport* Viewport) { return false; }
	virtual bool CapturedMouseMove(FEditorViewportClient* ViewportClient, FViewport* Viewport, int32 MouseX, int32 MouseY) { return false; }
	virtual bool MouseMove(FEditorViewportClient* ViewportClient, FViewport* Viewport, int32 MouseX, int32 MouseY) { return false; }
	virtual bool EndTracking(FEditorViewportClient* ViewportClient, FViewport* Viewport) { return false; }
	virtual bool HandleClick(FEditorViewportClient* ViewportClient, HHitProxy* HitProxy, const FViewportClick& Click) { return false; }
	virtual bool InputDelta(FEditorViewportClient* ViewportClient, FViewport* Viewport, FVector& Drag, FRotator& Rot, FVector& Scale) { return false; }
	virtual bool BoxSelect(FBox& Box, bool bSelect) { return false; }
	virtual bool FrustumSelect(const FConvexVolume& Frustum, FEditorViewportClient* ViewportClient, bool bSelect) { return false; }

	virtual bool GetOverrideCursorVisibility(bool& bWantsOverride, bool& bHardwareCursorVisible, bool bSoftwareCursorVisible) const { return false; }

	virtual void Render(const FSceneView* View, FViewport* Viewport, FPrimitiveDrawInterface* PDI) {}
	virtual void DrawHUD(FEditorViewportClient* ViewportClient, FViewport* Viewport, const FSceneView* View, FCanvas* Canvas) {}

	virtual void AddReferencedObjects(FReferenceCollector& Collector) {}

protected:
	FEditorModeTools* GetModeTools() const { return Host ? Host->GetModeTools() : nullptr; }
	bool IsTransformGizmoReplaced() const { return Host && Host->IsTransformGizmoReplaced(); }

private:
	IWorkflowToolHost* Host = nullptr;
};
