// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "Materials/MaterialInterface.h"

struct FInteractiveDecalCollectionEntry;

namespace InteractiveDecalPlacement
{
	/** One Tab+Scroll browse category (a configured collection, or an expanded subcategory). */
	struct FDecalBrowseCategory
	{
		/** Label shown in the HUD / used for Outliner folder nesting. */
		FName DisplayName;
		/** Collection to load materials from (Self only — subcategories are expanded separately). */
		FName CollectionName;
	};

	/** Returns settings-enabled collection entries in configured order (ignores session toggles). */
	TArray<const FInteractiveDecalCollectionEntry*> GetEnabledCollectionEntries();

	/**
	 * Cached Tab+Scroll category list. When an entry has Include Subcategories enabled,
	 * each descendant child collection with loadable decals becomes its own category.
	 * Parents/children with no direct (Self) loadable decal assets are omitted.
	 * Session-disabled categories are omitted. Rebuilds after InvalidateBrowseCategoryCache().
	 */
	const TArray<FDecalBrowseCategory>& GetBrowseCategories();

	/** Marks the browse-category cache dirty so the next GetBrowseCategories() rebuilds. */
	void InvalidateBrowseCategoryCache();

	/**
	 * Full browse-category list for HUD session checkboxes: same expansion as GetBrowseCategories()
	 * (settings-enabled + Include Subcategories, empty-parent exclusion), but ignores session
	 * enable/disable so unchecked rows stay visible. Each parent/child with Self assets appears
	 * as its own row (DisplayName).
	 */
	void GetSessionUiBrowseCategories(TArray<FDecalBrowseCategory>& OutCategories);

	/** Session-only filter for Tab+Scroll browse (default: all enabled). Not persisted to config. */
	bool IsCollectionEnabledForSession(FName CollectionName);
	void SetCollectionEnabledForSession(FName CollectionName, bool bEnabled);
	/** Enable or disable every category currently shown in the session UI list. */
	void SetAllSessionCollectionsEnabled(bool bEnabled);

	/** Lists collection names across local, private, and shared scopes (for settings UI). */
	void GetAllCollectionNames(TArray<FName>& OutCollectionNames);

	/** Decal materials in a collection (Self only, no child merge), from the asset registry without loading. */
	TArray<FSoftObjectPath> GetDecalMaterialsInCollection(FName CollectionName);

	/** Deferred decal domain from asset registry tags, following material instance parents. Loads nothing. */
	bool IsDecalMaterialAsset(const FAssetData& AssetData);
	bool IsDecalMaterial(UMaterialInterface* Material);
	float GetMaterialAspectRatio(const UMaterialInterface* Material);
}

