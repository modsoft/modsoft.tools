// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "Framework/Commands/Commands.h"
#include "Styling/AppStyle.h"

/** Level editor commands (rebind under Keyboard Shortcuts → Pro Workflow Tools). */
class FProWorkflowToolsCommands : public TCommands<FProWorkflowToolsCommands>
{
public:
	FProWorkflowToolsCommands()
		: TCommands<FProWorkflowToolsCommands>(
			TEXT("ProWorkflowTools"),
			NSLOCTEXT("ProWorkflowTools", "CommandsContext", "Pro Workflow Tools"),
			TEXT("LevelEditor"),
			FAppStyle::GetAppStyleSetName())
	{
	}

	virtual void RegisterCommands() override;

	TSharedPtr<FUICommandInfo> DuplicateWithLastAction;
	TSharedPtr<FUICommandInfo> ToggleBoxScale;
	TSharedPtr<FUICommandInfo> ToggleGridPaint;
	TSharedPtr<FUICommandInfo> ShowLastHidden;
	TSharedPtr<FUICommandInfo> OpenWelcomeSplash;
};
