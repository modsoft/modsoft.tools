// Copyright © 2026 Trey McNair. All rights reserved.

#include "GridPaint/GridPaintTool.h"
#include "GridPaint/GridPaintToolPrivate.h"
#include "ProWorkflowToolsSettings.h"
#include "UI/ProWorkflowToolHudOverlay.h"
#include "UI/ProWorkflowToolHudTypes.h"
#include "UI/SProWorkflowToolHud.h"
#include "UI/ViewportCursorLabel.h"
#include "Viewport/ViewportOverlayStyle.h"

#include "CanvasItem.h"
#include "CanvasTypes.h"
#include "Editor.h"
#include "EditorViewportClient.h"
#include "Framework/Application/SlateApplication.h"
#include "PrimitiveDrawingUtils.h"
#include "SceneView.h"
#include "Widgets/DeclarativeSyntaxSupport.h"

#define LOCTEXT_NAMESPACE "ProWorkflowTools"

///////////////////////////////////////////////////////////////////////////////
// Render / HUD

void FGridPaintTool::GetCellPlaneCorners(
	const FIntVector& Cell,
	int32 PlaneAxis,
	const FVector& Lift,
	FVector& OutC00,
	FVector& OutC10,
	FVector& OutC11,
	FVector& OutC01) const
{
	const int32 AxisU = (PlaneAxis + 1) % 3;
	const int32 AxisV = (PlaneAxis + 2) % 3;

	const FVector DirU = Context.GridRotation.RotateVector(
		FVector(AxisU == 0 ? 1.0 : 0.0, AxisU == 1 ? 1.0 : 0.0, AxisU == 2 ? 1.0 : 0.0));
	const FVector DirV = Context.GridRotation.RotateVector(
		FVector(AxisV == 0 ? 1.0 : 0.0, AxisV == 1 ? 1.0 : 0.0, AxisV == 2 ? 1.0 : 0.0));

	// Mesh AABB in grid-local space — Min/Max on the plane axes (not ±CellSize/2 on the pivot).
	const FBox& Bounds = Context.MeshBoundsGridLocal;
	const bool bHasBounds = Bounds.IsValid != 0;
	const double MinU = bHasBounds ? Bounds.Min[AxisU] : -Context.CellSize[AxisU] * 0.5;
	const double MaxU = bHasBounds ? Bounds.Max[AxisU] : Context.CellSize[AxisU] * 0.5;
	const double MinV = bHasBounds ? Bounds.Min[AxisV] : -Context.CellSize[AxisV] * 0.5;
	const double MaxV = bHasBounds ? Bounds.Max[AxisV] : Context.CellSize[AxisV] * 0.5;

	const FVector Origin = GridPaintMath::GridToWorld(Context, Cell) + Lift;
	OutC00 = Origin + DirU * MinU + DirV * MinV;
	OutC10 = Origin + DirU * MaxU + DirV * MinV;
	OutC11 = Origin + DirU * MaxU + DirV * MaxV;
	OutC01 = Origin + DirU * MinU + DirV * MaxV;
}

bool FGridPaintTool::GetCellOrientedBox(const FIntVector& Cell, FMatrix& OutBoxToWorld, FVector& OutRadii) const
{
	const FBox& Bounds = Context.MeshBoundsGridLocal;
	if (!Bounds.IsValid)
	{
		// Pivot-centered CellSize box when bounds are unavailable.
		OutRadii = Context.CellSize * 0.5;
		const FVector WorldCenter = GridPaintMath::GridToWorld(Context, Cell);
		OutBoxToWorld = FRotationTranslationMatrix(Context.GridRotation.Rotator(), WorldCenter);
		return OutRadii.GetAbsMin() > GridPaint::Private::MinCellSize * 0.5;
	}

	OutRadii = Bounds.GetExtent();
	const FVector WorldCenter = GridPaintMath::GridToWorld(Context, Cell)
		+ Context.GridRotation.RotateVector(Bounds.GetCenter());
	OutBoxToWorld = FRotationTranslationMatrix(Context.GridRotation.Rotator(), WorldCenter);
	return OutRadii.GetAbsMin() > KINDA_SMALL_NUMBER;
}

void FGridPaintTool::DrawGridLines(const FSceneView* View, FPrimitiveDrawInterface* PDI) const
{
	const int32 PlaneAxis = GetActivePlaneAxis();
	const int32 AxisU = (PlaneAxis + 1) % 3;
	const int32 AxisV = (PlaneAxis + 2) % 3;
	const FVector Lift = GetOverlayLift(View, PlaneAxis);

	// The fade is a circle in world space; elongated cells show more cells along their short axis.
	const double CellU = Context.CellSize[AxisU];
	const double CellV = Context.CellSize[AxisV];
	const double RadiusWorld = GridPaint::Private::GridRadiusCells * FMath::Sqrt(CellU * CellV);
	const int32 MaxReach = GridPaint::Private::GridRadiusCells * 3;
	const int32 ReachU = FMath::Clamp(FMath::CeilToInt32(RadiusWorld / CellU), 1, MaxReach);
	const int32 ReachV = FMath::Clamp(FMath::CeilToInt32(RadiusWorld / CellV), 1, MaxReach);

	FVector H00, H10, H11, H01;
	GetCellPlaneCorners(HoverCell, PlaneAxis, Lift, H00, H10, H11, H01);
	const FVector Center = (H00 + H10 + H11 + H01) * 0.25;

	using namespace ProWorkflowTools::OverlayStyle;
	auto DrawEdge = [&](const FVector& A, const FVector& B)
	{
		const double T = 1.0 - FVector::Dist((A + B) * 0.5, Center) / RadiusWorld;
		if (T <= 0.0)
		{
			return;
		}
		const FLinearColor Color = Neutral.CopyWithNewOpacity(GridPaint::Private::GridLineOpacity * float(T * T));
		WithXRay(Color, [&](const FLinearColor& PassColor, const uint8 Depth)
		{
			PDI->DrawTranslucentLine(A, B, PassColor, Depth, GridPaint::Private::GridLineThickness, 0.0f, /*bScreenSpace=*/true);
		});
	};

	// Each cell contributes its min-U and min-V edges, so shared edges are drawn once; the extra
	// row and column close the far side.
	for (int32 DeltaV = -ReachV; DeltaV <= ReachV + 1; ++DeltaV)
	{
		for (int32 DeltaU = -ReachU; DeltaU <= ReachU + 1; ++DeltaU)
		{
			FIntVector Cell = HoverCell;
			Cell[AxisU] += DeltaU;
			Cell[AxisV] += DeltaV;

			FVector C00, C10, C11, C01;
			GetCellPlaneCorners(Cell, PlaneAxis, Lift, C00, C10, C11, C01);
			if (DeltaU <= ReachU)
			{
				DrawEdge(C00, C10);
			}
			if (DeltaV <= ReachV)
			{
				DrawEdge(C00, C01);
			}
		}
	}
}

void FGridPaintTool::DrawHoverCellOutline(const FSceneView* View, FPrimitiveDrawInterface* PDI)
{
	const int32 PlaneAxis = GetActivePlaneAxis();
	FVector C00, C10, C11, C01;
	GetCellPlaneCorners(HoverCell, PlaneAxis, GetOverlayLift(View, PlaneAxis), C00, C10, C11, C01);

	FLinearColor Color;
	if (bEraseIntent)
	{
		Color = ProWorkflowTools::OverlayStyle::Erase.CopyWithNewOpacity(GridPaint::Private::EraseOutlineOpacity);
	}
	else
	{
		// Occupied = a matching asset already sits in the cell (the source's own cell excluded).
		// Intersect = other geometry is in the way; only checked with Prevent Intersect on.
		const bool bOccupied = HoverCell != FIntVector::ZeroValue && IsCellOccupied(HoverCell);
		const bool bIntersect = !bOccupied
			&& GetDefault<UProWorkflowToolsUserSettings>()->bPreventOverlappingPaint
			&& IsCellOverlapping(HoverCell);
		Color = bIntersect
			? GridPaint::Private::IntersectOutlineColor
			: (bOccupied ? GridPaint::Private::OccupiedOutlineColor : GridPaint::Private::HoverAccentColor());
	}

	using namespace ProWorkflowTools::OverlayStyle;
	WithXRay(Color, [&](const FLinearColor& PassColor, const uint8 Depth)
	{
		DrawOutline(PDI, C00, C10, C11, C01, PassColor, Depth, GridPaint::Private::HoverOutlineThickness);
	});
}

void FGridPaintTool::DrawEraseTargetBrackets(FPrimitiveDrawInterface* PDI) const
{
	if (!HasEraseHoverTarget())
	{
		return;
	}

	using namespace ProWorkflowTools::OverlayStyle;

	FMatrix BoxToWorld;
	FVector Radii;
	if (GetCellOrientedBox(HoverCell, BoxToWorld, Radii))
	{
		const FVector AxisX = Context.GridRotation.RotateVector(FVector::ForwardVector);
		const FVector AxisY = Context.GridRotation.RotateVector(FVector::RightVector);
		const FVector AxisZ = Context.GridRotation.RotateVector(FVector::UpVector);
		WithXRay(Erase.CopyWithNewOpacity(GridPaint::Private::EraseBracketOpacity), [&](const FLinearColor& PassColor, const uint8 Depth)
		{
			DrawBoxCornerBrackets(PDI, BoxToWorld.GetOrigin(), AxisX, AxisY, AxisZ, Radii, PassColor, Depth,
				1.0f, GridPaint::Private::EraseBracketFraction, GridPaint::Private::EraseBracketMaxCm);
		});
	}
}

bool FGridPaintTool::HandleClick(FEditorViewportClient* ViewportClient, HHitProxy* HitProxy, const FViewportClick& Click)
{
	return bActive && Click.GetKey() == EKeys::LeftMouseButton;
}

void FGridPaintTool::Render(const FSceneView* View, FViewport* Viewport, FPrimitiveDrawInterface* PDI)
{
	if (!bActive || !PDI)
	{
		return;
	}

	if (bBoundsEditActive)
	{
		DrawBoundsEditPreview(View, PDI);
		return;
	}

	if (bHasHoverCell && View)
	{
		DrawGridLines(View, PDI);
		DrawHoverCellOutline(View, PDI);
		DrawEraseTargetBrackets(PDI);
	}

	if (LineFillPreviewCells.Num() > 0)
	{
		DrawLineFillPreview(View, PDI);
	}
	DrawLineFillAnchor(View, PDI);
	DrawCellPulses(View, PDI);
}

void FGridPaintTool::DrawHUD(FEditorViewportClient* ViewportClient, FViewport* Viewport, const FSceneView* View, FCanvas* Canvas)
{
	using namespace ProWorkflowTools;

	if (!bActive || !Viewport || !Canvas || ViewportClient != LastTickViewportClient || IsPointerOverHud())
	{
		return;
	}

	const FIntPoint MousePixel(Viewport->GetMouseX(), Viewport->GetMouseY());

	if (bEraseIntent && bHasHoverCell && !bBoundsEditActive)
	{
		DrawEraseCursorBadge(Canvas, MousePixel);
	}

	// Live readouts own the label slot while their interaction runs.
	if (bBoundsEditActive && bBoundsFaceDrag && EditBoundsGridLocal.IsValid && BoundsDragAxis >= 0 && BoundsDragAxis < 3)
	{
		static const TCHAR* AxisNames[3] = { TEXT("X"), TEXT("Y"), TEXT("Z") };
		const CursorLabel::FLine Line{
			FText::FromString(FString::Printf(TEXT("%s  %s cm"),
				AxisNames[BoundsDragAxis], *CursorLabel::FormatAmount(EditBoundsGridLocal.GetSize()[BoundsDragAxis]))),
			GridPaint::Private::BoundsEditWireColor };
		CursorLabel::Draw(Canvas, MousePixel, MakeArrayView(&Line, 1), 1.0f);
		return;
	}

	if (!LineFillPreviewCells.IsEmpty())
	{
		const CursorLabel::FLine Line{
			FText::FromString(FString::Printf(TEXT("+%d"), LineFillPreviewCells.Num())),
			OverlayStyle::Accent() };
		CursorLabel::Draw(Canvas, MousePixel, MakeArrayView(&Line, 1), 1.0f);
		return;
	}

	FeedbackLabel.Draw(Canvas, MousePixel);
}

void FGridPaintTool::DrawEraseCursorBadge(FCanvas* Canvas, const FIntPoint& MousePixel) const
{
	using namespace GridPaint::Private;

	// Up-right of the pointer, clear of the label slot (down-right).
	const float DPI = FMath::Max(Canvas->GetDPIScale(), 0.01f);
	const FVector2D Center = FVector2D(MousePixel) / DPI + FVector2D(EraseBadgeOffsetPx, -EraseBadgeOffsetPx);
	const FLinearColor Color = ProWorkflowTools::OverlayStyle::Erase.CopyWithNewOpacity(EraseBadgeOpacity);

	auto DrawLine = [Canvas, &Color](const FVector2D& From, const FVector2D& To)
	{
		FCanvasLineItem Line(From, To);
		Line.SetColor(Color);
		Line.LineThickness = EraseBadgeThicknessPx;
		Canvas->DrawItem(Line);
	};

	FVector2D Previous = Center + FVector2D(EraseBadgeRadiusPx, 0.0);
	for (int32 Segment = 1; Segment <= EraseBadgeSegments; ++Segment)
	{
		const double Angle = UE_TWO_PI * Segment / EraseBadgeSegments;
		const FVector2D Next = Center + FVector2D(FMath::Cos(Angle), FMath::Sin(Angle)) * EraseBadgeRadiusPx;
		DrawLine(Previous, Next);
		Previous = Next;
	}

	const FVector2D HalfBar(EraseBadgeRadiusPx * 0.5, 0.0);
	DrawLine(Center - HalfBar, Center + HalfBar);
}

FProWorkflowToolHudModel FGridPaintTool::BuildHudModel()
{
	FProWorkflowToolHudModel Model;
	Model.Title = LOCTEXT("GridPaintHudTitle", "Actor Grid Paint");

	const int32 PlaneAxis = bStrokeActive ? LockedPlaneAxis : CurrentPlaneAxis;
	Model.Fields.Add(MakeHudTextField(
		TEXT("Plane"),
		LOCTEXT("GridPaintHudPlane", "Plane"),
		FText::FromString(GridPaint::Private::GetPlaneName(PlaneAxis)),
		28.0f,
		true));

	if (bBoundsEditActive)
	{
		const FVector Size = EditBoundsGridLocal.IsValid
			? EditBoundsGridLocal.GetSize()
			: Context.CellSize;
		Model.Fields.Add(MakeHudTextField(
			TEXT("Cell"),
			LOCTEXT("GridPaintHudCell", "Cell"),
			FText::FromString(FString::Printf(TEXT("%.0f × %.0f × %.0f"), Size.X, Size.Y, Size.Z)),
			110.0f,
			false,
			false,
			true));
		Model.Fields.Add(MakeHudTextField(
			TEXT("Status"),
			FText::GetEmpty(),
			LOCTEXT("GridPaintStatusEditBounds", "Edit Bounds"),
			88.0f,
			true,
			false,
			true));

		AddHudKeycap(Model.Keycaps, LOCTEXT("GridPaintKeyLmbFace", "LMB"), LOCTEXT("GridPaintActDragFace", "Drag Face"));
		AddHudKeycap(Model.Keycaps, LOCTEXT("GridPaintKeyV", "V"), LOCTEXT("GridPaintActVertSnap", "Vertex Snap"));
		AddHudKeycap(Model.Keycaps, LOCTEXT("GridPaintKeyBackspace", "Backspace"), LOCTEXT("GridPaintActResetBounds", "Reset"));
		AddHudKeycap(Model.Keycaps, LOCTEXT("GridPaintKeyCtrlZ", "Ctrl+Z"), LOCTEXT("GridPaintActUndoBounds", "Undo"));
		AddHudKeycap(Model.Keycaps, LOCTEXT("GridPaintKeyBApply", "B"), LOCTEXT("GridPaintActApplyBounds", "Apply"));
		AddHudKeycap(Model.Keycaps, LOCTEXT("GridPaintKeyEscCancel", "Esc"), LOCTEXT("GridPaintActCancelBounds", "Cancel"));
		return Model;
	}

	Model.Fields.Add(MakeHudTextField(
		TEXT("Cell"),
		LOCTEXT("GridPaintHudCellPaint", "Cell"),
		FText::FromString(FString::Printf(
			TEXT("%.0f × %.0f × %.0f"),
			Context.CellSize.X, Context.CellSize.Y, Context.CellSize.Z)),
		110.0f,
		false,
		false,
		true));

	const bool bPreventIntersect = GetDefault<UProWorkflowToolsUserSettings>()->bPreventOverlappingPaint;

	const bool bErase = bEraseIntent;
	Model.Fields.Add(MakeHudTextField(
		TEXT("Status"),
		FText::GetEmpty(),
		bErase
			? LOCTEXT("GridPaintStatusErase", "Erase")
			: LOCTEXT("GridPaintStatusPaint", "Paint"),
		48.0f,
		!bErase,
		bErase,
		true));

	Model.Fields.Add(MakeHudCheckField(
		TEXT("PreventIntersect"),
		LOCTEXT("GridPaintPreventIntersect", "Prevent Intersect"),
		bPreventIntersect,
		[this](const bool bChecked)
		{
			UProWorkflowToolsUserSettings* UserSettings = GetMutableDefault<UProWorkflowToolsUserSettings>();
			UserSettings->bPreventOverlappingPaint = bChecked;
			UserSettings->SaveConfig();
			RefreshOverlapStateAfterSettingChange();
		},
		true));

	AddHudKeycap(Model.Keycaps, LOCTEXT("GridPaintKeyLmb", "LMB"), LOCTEXT("GridPaintActPaint", "Paint"));
	AddHudKeycap(Model.Keycaps, LOCTEXT("GridPaintKeyShiftLmb", "Shift+LMB"), LOCTEXT("GridPaintActErase", "Erase"));
	AddHudKeycap(Model.Keycaps, LOCTEXT("GridPaintKeyCtrlLmb", "Ctrl+LMB"), LOCTEXT("GridPaintActLineFill", "Line Fill"));
	AddHudKeycap(Model.Keycaps, LOCTEXT("GridPaintKeyB", "B"), LOCTEXT("GridPaintActEditBounds", "Edit Bounds"));
	AddHudKeycap(Model.Keycaps, LOCTEXT("GridPaintKeyEsc", "Esc"), LOCTEXT("GridPaintActExit", "Exit"));

	return Model;
}

bool FGridPaintTool::IsPointerOverHud() const
{
	return HudOverlay.IsValid() && HudOverlay->IsPointerOverPanel();
}

void FGridPaintTool::RefreshOverlapStateAfterSettingChange()
{
	CellBlockedCache.Reset();

	// The checkbox is a Slate click, not viewport input, so this change redraws itself.
	if (GEditor)
	{
		GEditor->RedrawLevelEditingViewports();
	}
}

void FGridPaintTool::ShowHudOverlay()
{
	HudOverlay.Show([this]()
	{
		return SNew(SProWorkflowToolHud)
			.bPanelHitTestable(true)
			.Model_Lambda([this]()
			{
				return BuildHudModel();
			});
	});
}

void FGridPaintTool::HideHudOverlay()
{
	HudOverlay.Hide();
}

void FGridPaintTool::UpdatePointerOverride()
{
	EMouseCursor::Type Desired = EMouseCursor::Default;
	if (bBoundsEditActive && bBoundsFaceDrag)
	{
		Desired = EMouseCursor::GrabHandClosed;
	}
	else if (bBoundsEditActive && BoundsHoverAxis != INDEX_NONE)
	{
		Desired = EMouseCursor::GrabHand;
	}

	if (Desired == EMouseCursor::Default)
	{
		ReleasePointerOverride();
		return;
	}

	ProWorkflowTools::SetLevelViewportsCursorOverride(true, Desired);
	if (Desired != AppliedPointer)
	{
		AppliedPointer = Desired;
		// Slate only re-queries the cursor on mouse movement; a press or release changes it too.
		if (FSlateApplication::IsInitialized())
		{
			FSlateApplication::Get().QueryCursor();
		}
	}
}

void FGridPaintTool::ReleasePointerOverride()
{
	if (AppliedPointer == EMouseCursor::Default)
	{
		return;
	}

	AppliedPointer = EMouseCursor::Default;
	ProWorkflowTools::SetLevelViewportsCursorOverride(false, EMouseCursor::Default);
	if (FSlateApplication::IsInitialized())
	{
		FSlateApplication::Get().QueryCursor();
	}
}

#undef LOCTEXT_NAMESPACE
