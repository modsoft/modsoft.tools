// Copyright © 2026 Trey McNair. All rights reserved.

#include "UI/SProWorkflowToolHud.h"

#include "Brushes/SlateRoundedBoxBrush.h"
#include "Containers/Set.h"
#include "Framework/Application/SlateApplication.h"
#include "Framework/Text/TextLayout.h"
#include "Input/Reply.h"
#include "Styling/AppStyle.h"
#include "Types/SlateStructs.h"
#include "Widgets/Input/SCheckBox.h"
#include "Widgets/Input/SComboButton.h"
#include "Widgets/Input/SEditableTextBox.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Layout/SWrapBox.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/SOverlay.h"
#include "Widgets/Text/STextBlock.h"

namespace ProWorkflowToolHudStyle
{
	const FLinearColor InfoBarFill(0.014f, 0.014f, 0.014f, 0.94f);
	const FLinearColor KeyBarFill(0.0f, 0.0f, 0.0f, 0.96f);
	const FLinearColor PrimaryText(0.92f, 0.92f, 0.92f, 1.0f);
	const FLinearColor TitleText(1.0f, 1.0f, 1.0f, 1.0f);
	const FLinearColor MutedText(0.62f, 0.62f, 0.62f, 1.0f);
	const FLinearColor Divider(0.16f, 0.16f, 0.16f, 1.0f);
	const FLinearColor AccentCyan(0.349f, 0.78f, 1.0f, 1.0f);

	constexpr float FlashSeconds = 0.22f;
	/** A disabled field or keycap keeps its slot and dims to this; the bars never reflow between tool states. */
	constexpr float DisabledOpacity = 0.38f;
	constexpr float BarRadius = 7.0f;
	constexpr float ViewportEdgePad = 16.0f;
	constexpr float ViewportBottomPad = 20.0f;

	FSlateFontInfo MakeScaledFont(const FName StyleName, const float SizeScale)
	{
		FSlateFontInfo Font = FAppStyle::GetFontStyle(StyleName);
		Font.Size = FMath::Max(1, FMath::RoundToInt(static_cast<float>(Font.Size) * SizeScale) + 1);
		return Font;
	}

	/**
	 * Wraps a field's text box. The HUD lives inside the viewport widget, so any key the box leaves
	 * unhandled would bubble into the viewport and run the tool's hotkeys; this ends the bubble.
	 * Esc is the one key it acts on: the box only reverts on Esc when the text changed.
	 */
	class SFieldEditKeySink : public SCompoundWidget
	{
	public:
		SLATE_BEGIN_ARGS(SFieldEditKeySink) {}
			SLATE_DEFAULT_SLOT(FArguments, Content)
			SLATE_EVENT(FSimpleDelegate, OnEscape)
		SLATE_END_ARGS()

		void Construct(const FArguments& InArgs)
		{
			OnEscape = InArgs._OnEscape;
			ChildSlot
			[
				InArgs._Content.Widget
			];
		}

		virtual FReply OnKeyDown(const FGeometry&, const FKeyEvent& KeyEvent) override
		{
			if (KeyEvent.GetKey() == EKeys::Escape)
			{
				OnEscape.ExecuteIfBound();
			}
			return FReply::Handled();
		}
		virtual FReply OnKeyUp(const FGeometry&, const FKeyEvent&) override { return FReply::Handled(); }
		virtual FReply OnKeyChar(const FGeometry&, const FCharacterEvent&) override { return FReply::Handled(); }

	private:
		FSimpleDelegate OnEscape;
	};
}

void SProWorkflowToolHud::Construct(const FArguments& InArgs)
{
	using namespace ProWorkflowToolHudStyle;

	ModelAttr = InArgs._Model;
	RefreshModel();
	const bool bPanelHitTestable = InArgs._bPanelHitTestable;
	const TSharedPtr<SWidget> Header = InArgs._Header;
	const TSharedPtr<SWidget> Footer = InArgs._Footer;

	SetVisibility(EVisibility::SelfHitTestInvisible);
	SetCanTick(true);

	InfoBarBrush = MakeShared<FSlateRoundedBoxBrush>(InfoBarFill, BarRadius);
	KeyBarBrush = MakeShared<FSlateRoundedBoxBrush>(KeyBarFill, BarRadius);

	const EVisibility PanelVisibility = bPanelHitTestable
		? EVisibility::Visible
		: EVisibility::SelfHitTestInvisible;

	auto ConsumeIfHitTestable = [bPanelHitTestable](const FGeometry&, const FPointerEvent&) -> FReply
	{
		return bPanelHitTestable ? FReply::Handled() : FReply::Unhandled();
	};

	TSharedRef<SBorder> PanelBorder = SNew(SBorder)
		.Visibility(PanelVisibility)
		.BorderImage(FAppStyle::GetBrush("NoBorder"))
		.Padding(FMargin(0.0f))
		.OnMouseButtonDown_Lambda(ConsumeIfHitTestable)
		.OnMouseButtonUp_Lambda(ConsumeIfHitTestable)
		.OnMouseDoubleClick_Lambda(ConsumeIfHitTestable)
		.OnMouseMove_Lambda([bPanelHitTestable](const FGeometry&, const FPointerEvent&) -> FReply
		{
			return bPanelHitTestable ? FReply::Handled() : FReply::Unhandled();
		})
		[
			SNew(SVerticalBox)

			+ SVerticalBox::Slot()
			.AutoHeight()
			.HAlign(HAlign_Center)
			[
				SAssignNew(InfoStripWidget, SBorder)
				.BorderImage(InfoBarBrush.Get())
				.Padding(FMargin(6.0f, 0.0f, 10.0f, 0.0f))
				[
					MakeInfoStrip(Header, Footer)
				]
			]

			+ SVerticalBox::Slot()
			.AutoHeight()
			.HAlign(HAlign_Center)
			.Padding(FMargin(0.0f, 10.0f, 0.0f, 0.0f))
			[
				SNew(SBox)
				.Visibility_Lambda([this]()
				{
					return GetModel().Keycaps.Num() > 0 ? EVisibility::Visible : EVisibility::Collapsed;
				})
				.MaxDesiredWidth_Lambda([this]()
				{
					return GetKeyStripMaxWidth();
				})
				[
					SNew(SBorder)
					.BorderImage(KeyBarBrush.Get())
					.Padding(FMargin(10.0f, 3.0f, 12.0f, 3.0f))
					[
						MakeKeyStrip()
					]
				]
			]
		];

	PanelWidget = PanelBorder;

	ChildSlot
	.HAlign(HAlign_Center)
	.VAlign(VAlign_Bottom)
	.Padding(FMargin(ViewportEdgePad, 0.0f, ViewportEdgePad, ViewportBottomPad))
	[
		PanelBorder
	];
}

void SProWorkflowToolHud::Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime)
{
	SCompoundWidget::Tick(AllottedGeometry, InCurrentTime, InDeltaTime);

	using namespace ProWorkflowToolHudStyle;

	RefreshModel();
	const FProWorkflowToolHudModel& Model = GetModel();

	AvailableWidth = FMath::Max(0.0f, static_cast<float>(AllottedGeometry.GetLocalSize().X) - ViewportEdgePad * 2.0f);
	if (!bCollapseLowPriority && InfoStripWidget.IsValid())
	{
		FullInfoStripWidth = static_cast<float>(InfoStripWidget->GetDesiredSize().X);
	}
	bCollapseLowPriority = AvailableWidth > 0.0f && FullInfoStripWidth > AvailableWidth;

	for (int32 CapIndex = 0; CapIndex < KeycapSlots.Num(); ++CapIndex)
	{
		KeycapSlots[CapIndex]->SetForceNewLine(Model.Keycaps.IsValidIndex(CapIndex) && Model.Keycaps[CapIndex].bNewRow);
	}

	if (bFocusEditBoxOnTick)
	{
		bFocusEditBoxOnTick = false;
		if (FieldEditBoxes.IsValidIndex(EditingFieldIndex) && FieldEditBoxes[EditingFieldIndex].IsValid())
		{
			FSlateApplication::Get().SetKeyboardFocus(FieldEditBoxes[EditingFieldIndex], EFocusCause::SetDirectly);
			FieldEditBoxes[EditingFieldIndex]->SelectAllText();
		}
	}

	// The field being edited vanished from the model (tool state changed): drop the edit.
	if (EditingFieldIndex != INDEX_NONE && !FieldIsEditable(EditingFieldIndex))
	{
		EndFieldEdit(false, FString(), true);
	}

	const double Now = FPlatformTime::Seconds();
	TSet<FName> Seen;
	bool bAnyLiveFlash = false;

	for (const FProWorkflowHudField& Field : Model.Fields)
	{
		if (Field.Id.IsNone() || Field.bCheckbox)
		{
			continue;
		}

		Seen.Add(Field.Id);
		const FString Value = Field.Value.ToString();
		if (const FString* Prev = LastFieldValues.Find(Field.Id))
		{
			if (*Prev != Value)
			{
				FieldFlashUntil.Add(Field.Id, Now + FlashSeconds);
			}
		}
		LastFieldValues.Add(Field.Id, Value);

		if (const double* Until = FieldFlashUntil.Find(Field.Id))
		{
			if (*Until > Now)
			{
				bAnyLiveFlash = true;
			}
		}
	}

	for (auto It = LastFieldValues.CreateIterator(); It; ++It)
	{
		if (!Seen.Contains(It.Key()))
		{
			It.RemoveCurrent();
		}
	}

	if (bAnyLiveFlash)
	{
		Invalidate(EInvalidateWidgetReason::Paint);
	}
}

bool SProWorkflowToolHud::IsPointerOverPanel() const
{
	// Cached geometry outlives a collapse, so a covered HUD must not claim the cursor.
	if (!PanelWidget.IsValid() || !GetVisibility().IsVisible())
	{
		return false;
	}

	const FGeometry& PanelGeometry = PanelWidget->GetCachedGeometry();
	const FVector2D CursorPos = FSlateApplication::Get().GetCursorPos();
	return PanelGeometry.IsUnderLocation(CursorPos);
}

void SProWorkflowToolHud::RefreshModel()
{
	CachedModel = ModelAttr.IsSet() ? ModelAttr.Get() : FProWorkflowToolHudModel();
	ensureMsgf(CachedModel.Fields.Num() <= MaxFields && CachedModel.Keycaps.Num() <= MaxKeycaps,
		TEXT("HUD '%s' has %d fields / %d keycaps; slots beyond %d / %d are not shown."),
		*CachedModel.Title.ToString(), CachedModel.Fields.Num(), CachedModel.Keycaps.Num(), MaxFields, MaxKeycaps);
}

bool SProWorkflowToolHud::IsFieldShown(const int32 FieldIndex) const
{
	const FProWorkflowToolHudModel& Model = GetModel();
	return Model.Fields.IsValidIndex(FieldIndex) && !(bCollapseLowPriority && Model.Fields[FieldIndex].bLowPriority);
}

float SProWorkflowToolHud::GetKeyStripMaxWidth() const
{
	return AvailableWidth > 0.0f ? FMath::Max(240.0f, AvailableWidth) : 1200.0f;
}

FSlateColor SProWorkflowToolHud::GetFieldValueColor(const int32 FieldIndex) const
{
	using namespace ProWorkflowToolHudStyle;

	const FProWorkflowToolHudModel& Model = GetModel();
	if (!Model.Fields.IsValidIndex(FieldIndex))
	{
		return FSlateColor(PrimaryText);
	}

	const FProWorkflowHudField& Field = Model.Fields[FieldIndex];
	const FLinearColor Rest = Field.bAccent
		? AccentCyan
		: (Field.bMuted ? MutedText : PrimaryText);
	if (Field.bDisabled)
	{
		return FSlateColor(Rest.CopyWithNewOpacity(Rest.A * DisabledOpacity));
	}

	if (!Field.Id.IsNone())
	{
		if (const double* Until = FieldFlashUntil.Find(Field.Id))
		{
			const double Remaining = *Until - FPlatformTime::Seconds();
			if (Remaining > 0.0)
			{
				const float T = 1.0f - static_cast<float>(Remaining / FlashSeconds);
				return FSlateColor(FMath::Lerp(AccentCyan, Rest, FMath::Clamp(T, 0.0f, 1.0f)));
			}
		}
	}

	return FSlateColor(Rest);
}

TSharedRef<SWidget> SProWorkflowToolHud::MakeDivider(const float HeightPx) const
{
	using namespace ProWorkflowToolHudStyle;

	return SNew(SBox)
		.WidthOverride(1.0f)
		.HeightOverride(HeightPx)
		[
			SNew(SBorder)
			.BorderImage(FAppStyle::GetBrush("WhiteBrush"))
			.BorderBackgroundColor(FSlateColor(Divider))
			.Padding(0.0f)
		];
}

TSharedRef<SWidget> SProWorkflowToolHud::MakeTitle() const
{
	using namespace ProWorkflowToolHudStyle;

	FSlateFontInfo TitleFont = MakeScaledFont("SmallText", 1.0f);
	TitleFont.TypefaceFontName = TEXT("Bold");

	return SNew(STextBlock)
		.Visibility_Lambda([this]()
		{
			return GetModel().Title.IsEmpty() ? EVisibility::Collapsed : EVisibility::Visible;
		})
		.Font(TitleFont)
		.AutoWrapText(false)
		.ColorAndOpacity(FSlateColor(TitleText))
		.Text_Lambda([this]()
		{
			return GetModel().Title;
		});
}

bool SProWorkflowToolHud::FieldIsEditable(const int32 FieldIndex) const
{
	const FProWorkflowToolHudModel& Model = GetModel();
	return IsFieldShown(FieldIndex) && !Model.Fields[FieldIndex].bDisabled
		&& !Model.Fields[FieldIndex].bCheckbox && Model.Fields[FieldIndex].OnCommitText;
}

void SProWorkflowToolHud::BeginFieldEdit(const int32 FieldIndex)
{
	if (!FieldIsEditable(FieldIndex) || !FieldEditBoxes.IsValidIndex(FieldIndex) || !FieldEditBoxes[FieldIndex].IsValid())
	{
		return;
	}

	if (EditingFieldIndex != INDEX_NONE && EditingFieldIndex != FieldIndex)
	{
		EndFieldEdit(false, FString(), false);
	}

	FocusBeforeEdit = FSlateApplication::Get().GetKeyboardFocusedWidget();
	EditingFieldIndex = FieldIndex;
	FieldEditBoxes[FieldIndex]->SetText(GetModel().Fields[FieldIndex].Value);
	bFocusEditBoxOnTick = true;
}

void SProWorkflowToolHud::EndFieldEdit(const bool bCommit, const FString& Text, const bool bRestoreFocus)
{
	const int32 FieldIndex = EditingFieldIndex;
	// Cleared before anything else: the focus change below makes the box report a second commit.
	EditingFieldIndex = INDEX_NONE;
	bFocusEditBoxOnTick = false;

	const FProWorkflowToolHudModel& Model = GetModel();
	if (bCommit && Model.Fields.IsValidIndex(FieldIndex) && Model.Fields[FieldIndex].OnCommitText)
	{
		Model.Fields[FieldIndex].OnCommitText(Text);
	}

	if (bRestoreFocus)
	{
		if (const TSharedPtr<SWidget> Previous = FocusBeforeEdit.Pin())
		{
			FSlateApplication::Get().SetKeyboardFocus(Previous, EFocusCause::SetDirectly);
		}
		else
		{
			FSlateApplication::Get().ClearKeyboardFocus(EFocusCause::SetDirectly);
		}
	}
	FocusBeforeEdit.Reset();
}

TSharedRef<SWidget> SProWorkflowToolHud::MakeInfoStrip(const TSharedPtr<SWidget>& Header, const TSharedPtr<SWidget>& Footer)
{
	TSharedRef<SHorizontalBox> Row = SNew(SHorizontalBox);

	if (Header.IsValid())
	{
		Row->AddSlot()
			.AutoWidth()
			.VAlign(VAlign_Center)
			.Padding(FMargin(4.0f, 4.0f, 0.0f, 4.0f))
			[
				Header.ToSharedRef()
			];
	}

	Row->AddSlot()
		.AutoWidth()
		.VAlign(VAlign_Center)
		.Padding(FMargin(10.0f, 6.0f))
		[
			MakeTitle()
		];

	for (int32 FieldIndex = 0; FieldIndex < MaxFields; ++FieldIndex)
	{
		Row->AddSlot()
			.AutoWidth()
			.VAlign(VAlign_Center)
			[
				MakeField(FieldIndex)
			];
	}

	if (Footer.IsValid())
	{
		Row->AddSlot()
			.AutoWidth()
			.VAlign(VAlign_Center)
			.Padding(FMargin(0.0f, 0.0f, 0.0f, 0.0f))
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
				.AutoWidth()
				.VAlign(VAlign_Center)
				.Padding(FMargin(0.0f, 6.0f, 8.0f, 6.0f))
				[
					MakeDivider(16.0f)
				]
				+ SHorizontalBox::Slot()
				.AutoWidth()
				.VAlign(VAlign_Center)
				[
					Footer.ToSharedRef()
				]
			];
	}

	return Row;
}

TSharedRef<SWidget> SProWorkflowToolHud::MakeKeyStrip()
{
	using namespace ProWorkflowToolHudStyle;

	TSharedRef<SWrapBox> Wrap = SNew(SWrapBox)
		.UseAllottedSize(false)
		.HAlign(HAlign_Center)
		.PreferredSize_Lambda([this]()
		{
			return GetKeyStripMaxWidth();
		})
		.InnerSlotPadding(FVector2D(0.0f, 4.0f));

	KeycapSlots.Reset(MaxKeycaps);
	for (int32 CapIndex = 0; CapIndex < MaxKeycaps; ++CapIndex)
	{
		SWrapBox::FSlot* Slot = nullptr;
		Wrap->AddSlot()
			.Expose(Slot)
			.Padding(FMargin(0.0f))
			[
				MakeHintChip(CapIndex)
			];
		KeycapSlots.Add(Slot);
	}

	return Wrap;
}

TSharedRef<SWidget> SProWorkflowToolHud::MakeField(const int32 FieldIndex)
{
	using namespace ProWorkflowToolHudStyle;

	const FSlateFontInfo FieldFont = MakeScaledFont("SmallText", 1.0f);

	const TSharedRef<SWidget> Content = SNew(SHorizontalBox)
		+ SHorizontalBox::Slot()
		.AutoWidth()
		.VAlign(VAlign_Center)
		[
			SNew(SBox)
			.Visibility_Lambda([this, FieldIndex]()
			{
				const FProWorkflowToolHudModel& Model = GetModel();
				return Model.Fields.IsValidIndex(FieldIndex) && Model.Fields[FieldIndex].bCheckbox
					? EVisibility::Visible
					: EVisibility::Collapsed;
			})
			[
				SNew(SCheckBox)
				.IsEnabled_Lambda([this, FieldIndex]()
				{
					const FProWorkflowToolHudModel& Model = GetModel();
					return !(Model.Fields.IsValidIndex(FieldIndex) && Model.Fields[FieldIndex].bDisabled);
				})
				.IsChecked_Lambda([this, FieldIndex]()
				{
					const FProWorkflowToolHudModel& Model = GetModel();
					return (Model.Fields.IsValidIndex(FieldIndex) && Model.Fields[FieldIndex].bChecked)
						? ECheckBoxState::Checked
						: ECheckBoxState::Unchecked;
				})
				.OnCheckStateChanged_Lambda([this, FieldIndex](const ECheckBoxState NewState)
				{
					const FProWorkflowToolHudModel& Model = GetModel();
					if (Model.Fields.IsValidIndex(FieldIndex) && Model.Fields[FieldIndex].OnCheckChanged)
					{
						Model.Fields[FieldIndex].OnCheckChanged(NewState == ECheckBoxState::Checked);
					}
				})
				[
					SNew(STextBlock)
					.Font(FieldFont)
					.ColorAndOpacity_Lambda([this, FieldIndex]()
					{
						const FProWorkflowToolHudModel& Model = GetModel();
						const bool bDisabled = Model.Fields.IsValidIndex(FieldIndex) && Model.Fields[FieldIndex].bDisabled;
						return FSlateColor(bDisabled ? PrimaryText.CopyWithNewOpacity(PrimaryText.A * DisabledOpacity) : PrimaryText);
					})
					.Text_Lambda([this, FieldIndex]()
					{
						const FProWorkflowToolHudModel& Model = GetModel();
						return Model.Fields.IsValidIndex(FieldIndex)
							? Model.Fields[FieldIndex].Label
							: FText::GetEmpty();
					})
				]
			]
		]

		+ SHorizontalBox::Slot()
		.AutoWidth()
		.VAlign(VAlign_Center)
		[
			SNew(SHorizontalBox)
			.Visibility_Lambda([this, FieldIndex]()
			{
				const FProWorkflowToolHudModel& Model = GetModel();
				return Model.Fields.IsValidIndex(FieldIndex) && !Model.Fields[FieldIndex].bCheckbox
					? EVisibility::Visible
					: EVisibility::Collapsed;
			})

			+ SHorizontalBox::Slot()
			.AutoWidth()
			.VAlign(VAlign_Center)
			.Padding(FMargin(0.0f, 0.0f, 4.0f, 0.0f))
			[
				SNew(STextBlock)
				.Font(FieldFont)
				.ColorAndOpacity(FSlateColor(MutedText))
				.Visibility_Lambda([this, FieldIndex]()
				{
					const FProWorkflowToolHudModel& Model = GetModel();
					return Model.Fields.IsValidIndex(FieldIndex) && !Model.Fields[FieldIndex].Label.IsEmpty()
						? EVisibility::Visible
						: EVisibility::Collapsed;
				})
				.Text_Lambda([this, FieldIndex]()
				{
					const FProWorkflowToolHudModel& Model = GetModel();
					return Model.Fields.IsValidIndex(FieldIndex)
						? Model.Fields[FieldIndex].Label
						: FText::GetEmpty();
				})
			]

			+ SHorizontalBox::Slot()
			.AutoWidth()
			.VAlign(VAlign_Center)
			[
				SNew(SBox)
				.Visibility_Lambda([this, FieldIndex]()
				{
					return FieldHasMenu(FieldIndex) ? EVisibility::Collapsed : EVisibility::Visible;
				})
				[
					MakeFieldValueText(FieldIndex)
				]
			]

			+ SHorizontalBox::Slot()
			.AutoWidth()
			.VAlign(VAlign_Center)
			[
				SNew(SComboButton)
				.Visibility_Lambda([this, FieldIndex]()
				{
					return FieldHasMenu(FieldIndex) ? EVisibility::Visible : EVisibility::Collapsed;
				})
				.IsEnabled_Lambda([this, FieldIndex]()
				{
					const FProWorkflowToolHudModel& Model = GetModel();
					return !(Model.Fields.IsValidIndex(FieldIndex) && Model.Fields[FieldIndex].bDisabled);
				})
				.ButtonStyle(FAppStyle::Get(), "SimpleButton")
				.ContentPadding(FMargin(2.0f, 0.0f))
				.HasDownArrow(true)
				.ForegroundColor(FSlateColor(MutedText))
				.OnGetMenuContent_Lambda([this, FieldIndex]()
				{
					const FProWorkflowToolHudModel& Model = GetModel();
					return FieldHasMenu(FieldIndex) ? Model.Fields[FieldIndex].OnGetMenu() : SNullWidget::NullWidget;
				})
				.ButtonContent()
				[
					MakeFieldValueText(FieldIndex)
				]
			]
		];

	return SNew(SHorizontalBox)
		.Visibility_Lambda([this, FieldIndex]()
		{
			return IsFieldShown(FieldIndex) ? EVisibility::Visible : EVisibility::Collapsed;
		})

		+ SHorizontalBox::Slot()
		.AutoWidth()
		.VAlign(VAlign_Center)
		.Padding(FMargin(0.0f, 6.0f))
		[
			SNew(SBox)
			.Visibility_Lambda([this, FieldIndex]()
			{
				const FProWorkflowToolHudModel& Model = GetModel();
				return (FieldIndex > 0 || !Model.Title.IsEmpty())
					? EVisibility::Visible
					: EVisibility::Collapsed;
			})
			[
				MakeDivider(16.0f)
			]
		]

		+ SHorizontalBox::Slot()
		.AutoWidth()
		.VAlign(VAlign_Center)
		.Padding(FMargin(10.0f, 6.0f))
		[
			Content
		];
}

bool SProWorkflowToolHud::FieldHasMenu(const int32 FieldIndex) const
{
	const FProWorkflowToolHudModel& Model = GetModel();
	return Model.Fields.IsValidIndex(FieldIndex) && Model.Fields[FieldIndex].OnGetMenu;
}

TSharedRef<SWidget> SProWorkflowToolHud::MakeFieldValueText(const int32 FieldIndex)
{
	using namespace ProWorkflowToolHudStyle;

	const FSlateFontInfo FieldFont = MakeScaledFont("SmallText", 1.0f);

	// Dropdown fields build this twice (plain and inside the combo button); the edit box belongs to
	// the first build only, which is the one shown for editable fields.
	FieldEditBoxes.SetNum(MaxFields);
	TSharedPtr<SEditableTextBox> EditBox;
	if (!FieldEditBoxes[FieldIndex].IsValid())
	{
		SAssignNew(EditBox, SEditableTextBox)
			.Font(FieldFont)
			.Justification(ETextJustify::Center)
			.Padding(FMargin(3.0f, 0.0f))
			.SelectAllTextWhenFocused(true)
			.RevertTextOnEscape(true)
			.ClearKeyboardFocusOnCommit(false)
			.OnTextCommitted_Lambda([this, FieldIndex](const FText& Text, const ETextCommit::Type CommitType)
			{
				if (EditingFieldIndex != FieldIndex)
				{
					return;
				}
				switch (CommitType)
				{
				case ETextCommit::OnEnter:
					EndFieldEdit(true, Text.ToString(), true);
					break;
				case ETextCommit::OnCleared:
					EndFieldEdit(false, FString(), true);
					break;
				default:
					// Focus went elsewhere by the user's hand: keep the value, leave focus where they put it.
					EndFieldEdit(true, Text.ToString(), false);
					break;
				}
			});
		FieldEditBoxes[FieldIndex] = EditBox;
	}

	TSharedRef<SWidget> ValueText = SNew(SBorder)
		.BorderImage(FAppStyle::GetBrush("NoBorder"))
		.Padding(0.0f)
		.Visibility_Lambda([this, FieldIndex]()
		{
			return EditingFieldIndex == FieldIndex ? EVisibility::Collapsed : EVisibility::Visible;
		})
		.Cursor_Lambda([this, FieldIndex]()
		{
			return FieldIsEditable(FieldIndex) ? TOptional<EMouseCursor::Type>(EMouseCursor::TextEditBeam) : TOptional<EMouseCursor::Type>();
		})
		.OnMouseButtonDown_Lambda([this, FieldIndex](const FGeometry&, const FPointerEvent& Event) -> FReply
		{
			if (Event.GetEffectingButton() == EKeys::LeftMouseButton && FieldIsEditable(FieldIndex))
			{
				BeginFieldEdit(FieldIndex);
				return FReply::Handled();
			}
			return FReply::Unhandled();
		})
		[
			SNew(STextBlock)
			.Font(FieldFont)
			.OverflowPolicy(ETextOverflowPolicy::Ellipsis)
			.Justification_Lambda([this, FieldIndex]()
			{
				const FProWorkflowToolHudModel& Model = GetModel();
				return (Model.Fields.IsValidIndex(FieldIndex) && Model.Fields[FieldIndex].bAlignLeft)
					? ETextJustify::Left
					: ETextJustify::Center;
			})
			.ColorAndOpacity_Lambda([this, FieldIndex]()
			{
				return GetFieldValueColor(FieldIndex);
			})
			.Text_Lambda([this, FieldIndex]()
			{
				const FProWorkflowToolHudModel& Model = GetModel();
				return Model.Fields.IsValidIndex(FieldIndex)
					? Model.Fields[FieldIndex].Value
					: FText::GetEmpty();
			})
		];

	TSharedRef<SBox> Cell = SNew(SBox)
		.WidthOverride_Lambda([this, FieldIndex]()
		{
			const FProWorkflowToolHudModel& Model = GetModel();
			const float Width = Model.Fields.IsValidIndex(FieldIndex)
				? Model.Fields[FieldIndex].WidthPx
				: 0.0f;
			return Width > 0.0f ? FOptionalSize(Width) : FOptionalSize();
		});

	if (!EditBox.IsValid())
	{
		Cell->SetContent(ValueText);
		return Cell;
	}

	Cell->SetContent(
		SNew(SOverlay)
		+ SOverlay::Slot()
		[
			ValueText
		]
		+ SOverlay::Slot()
		[
			SNew(SFieldEditKeySink)
			.Visibility_Lambda([this, FieldIndex]()
			{
				return EditingFieldIndex == FieldIndex ? EVisibility::Visible : EVisibility::Collapsed;
			})
			.OnEscape_Lambda([this, FieldIndex]()
			{
				if (EditingFieldIndex == FieldIndex)
				{
					EndFieldEdit(false, FString(), true);
				}
			})
			[
				EditBox.ToSharedRef()
			]
		]);
	return Cell;
}

TSharedRef<SWidget> SProWorkflowToolHud::MakeHintChip(const int32 CapIndex) const
{
	using namespace ProWorkflowToolHudStyle;

	const FSlateFontInfo ChipFont = MakeScaledFont("SmallText", 0.92f);

	auto ChipColor = [this, CapIndex](const FLinearColor& Base)
	{
		const FProWorkflowToolHudModel& Model = GetModel();
		const bool bDisabled = Model.Keycaps.IsValidIndex(CapIndex) && Model.Keycaps[CapIndex].bDisabled;
		return FSlateColor(bDisabled ? Base.CopyWithNewOpacity(Base.A * DisabledOpacity) : Base);
	};

	return SNew(SHorizontalBox)
		.Visibility_Lambda([this, CapIndex]()
		{
			return GetModel().Keycaps.IsValidIndex(CapIndex)
				? EVisibility::Visible
				: EVisibility::Collapsed;
		})

		+ SHorizontalBox::Slot()
		.AutoWidth()
		.VAlign(VAlign_Center)
		.Padding(FMargin(0.0f, 2.0f))
		[
			SNew(SBox)
			.Visibility_Lambda([this, CapIndex]()
			{
				return CapIndex > 0 ? EVisibility::Visible : EVisibility::Collapsed;
			})
			[
				MakeDivider(11.0f)
			]
		]

		+ SHorizontalBox::Slot()
		.AutoWidth()
		.VAlign(VAlign_Center)
		.Padding(FMargin(8.0f, 1.0f))
		[
			SNew(STextBlock)
			.Font(ChipFont)
			.ColorAndOpacity_Lambda([ChipColor]() { return ChipColor(PrimaryText); })
			.Text_Lambda([this, CapIndex]()
			{
				const FProWorkflowToolHudModel& Model = GetModel();
				return Model.Keycaps.IsValidIndex(CapIndex)
					? Model.Keycaps[CapIndex].Key
					: FText::GetEmpty();
			})
		]

		+ SHorizontalBox::Slot()
		.AutoWidth()
		.VAlign(VAlign_Center)
		.Padding(FMargin(0.0f, 1.0f, 8.0f, 1.0f))
		[
			SNew(STextBlock)
			.Font(ChipFont)
			.ColorAndOpacity_Lambda([ChipColor]() { return ChipColor(MutedText); })
			.Text_Lambda([this, CapIndex]()
			{
				const FProWorkflowToolHudModel& Model = GetModel();
				return Model.Keycaps.IsValidIndex(CapIndex)
					? Model.Keycaps[CapIndex].Action
					: FText::GetEmpty();
			})
		];
}
