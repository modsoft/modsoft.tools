// Copyright © 2026 Trey McNair. All rights reserved.

#include "InteractiveDecalPlacementEdMode.h"

#include "CanvasItem.h"
#include "CanvasTypes.h"
#include "Components/ArrowComponent.h"
#include "Components/BillboardComponent.h"
#include "Components/DecalComponent.h"
#include "ComponentVisualizer.h"
#include "ContentBrowserModule.h"
#include "Editor.h"
#include "Editor/UnrealEdEngine.h"
#include "EditorModeManager.h"
#include "EditorViewportClient.h"
#include "Engine/Canvas.h"
#include "Engine/DecalActor.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "Engine/Selection.h"
#include "Framework/Notifications/NotificationManager.h"
#include "IContentBrowserSingleton.h"
#include "InteractiveDecalPlacementCollectionUtils.h"
#include "InteractiveDecalPlacementMath.h"
#include "ProWorkflowToolsSettings.h"
#include "ProWorkflowToolsEngineAdapter.h"
#include "Materials/MaterialInterface.h"
#include "Engine/EngineTypes.h"
#include "SInteractiveDecalPlacementHud.h"
#include "UI/ProWorkflowToolHudOverlay.h"
#include "UI/ViewportCursorLabel.h"
#include "Viewport/ViewportOverlayStyle.h"
#include "ScopedTransaction.h"
#include "SceneManagement.h"
#include "SceneView.h"
#include "SuperGroups/SuperGroupSubsystem.h"
#include "UnrealEdGlobals.h"
#include "Viewport/ViewportSurfaceTrace.h"
#include "Widgets/Notifications/SNotificationList.h"

#if WITH_EDITOR
#include "Editor/GroupActor.h"
#endif

#define LOCTEXT_NAMESPACE "InteractiveDecalPlacementEdMode"

DEFINE_LOG_CATEGORY_STATIC(LogDecalPlacement, Log, All);

const FEditorModeID FInteractiveDecalPlacementEdMode::EM_InteractiveDecalPlacement(TEXT("EM_InteractiveDecalPlacement"));

namespace
{
	/**
	 * Realtime-off viewports only redraw when invalidated. Call after any change that must
	 * be visible (preview pose, PDI ticks, scroll tweaks). No-op when Realtime is already on.
	 */
	void RequestViewportRefresh(FEditorViewportClient* ViewportClient)
	{
		if (ViewportClient && !ViewportClient->IsRealtime())
		{
			ViewportClient->Invalidate(false, false);
		}
	}

	/** Grab tolerances in screen pixels: corners first, then the outline edges. */
	constexpr float CornerPickPx = 10.0f;
	constexpr float EdgePickPx = 6.0f;

	/** Distance from P to segment AB, all in pixels. */
	float PixelDistanceToSegment(const FVector2D& P, const FVector2D& A, const FVector2D& B)
	{
		const FVector2D AB = B - A;
		const float LengthSq = AB.SizeSquared();
		const float T = LengthSq > KINDA_SMALL_NUMBER ? FMath::Clamp(FVector2D::DotProduct(P - A, AB) / LengthSq, 0.0f, 1.0f) : 0.0f;
		return FVector2D::Distance(P, A + AB * T);
	}
}

namespace InteractiveDecalPlacement::SessionBrowse
{
	/** Survives EdMode Exit/destroy for the editor process lifetime. */
	enum class ESource : uint8
	{
		None,
		ContentBrowser,
		Collection
	};

	ESource Source = ESource::None;
	/** Browse category DisplayName / CollectionName last used in Collection mode. */
	FName CategoryName;
	/** Soft path of the last active material (Collection or Content Browser). */
	FSoftObjectPath MaterialPath;
	/** Per-category last material, keyed by browse category DisplayName. */
	TMap<FName, FSoftObjectPath> MaterialPathByCategory;

	int32 FindCategoryIndex(const TArray<FDecalBrowseCategory>& BrowseCategories, const FName InCategoryName)
	{
		if (InCategoryName.IsNone())
		{
			return INDEX_NONE;
		}

		for (int32 Index = 0; Index < BrowseCategories.Num(); ++Index)
		{
			if (BrowseCategories[Index].DisplayName == InCategoryName
				|| BrowseCategories[Index].CollectionName == InCategoryName)
			{
				return Index;
			}
		}

		return INDEX_NONE;
	}

	int32 FindDecalIndex(const TArray<FSoftObjectPath>& Decals, const FSoftObjectPath& Path)
	{
		if (!Path.IsValid())
		{
			return INDEX_NONE;
		}

		return Decals.IndexOfByPredicate([&Path](const FSoftObjectPath& Candidate)
		{
			return Candidate == Path;
		});
	}
}

void FInteractiveDecalPlacementEdMode::Enter()
{
	FEdMode::Enter();
	SelectionChangedHandle = USelection::SelectionChangedEvent.AddRaw(this, &FInteractiveDecalPlacementEdMode::OnEditorSelectionChanged);
	SwapOutEngineDecalVisualizer();
	SetState(EInteractiveDecalPlacementState::Preview);
}

void FInteractiveDecalPlacementEdMode::SwapOutEngineDecalVisualizer()
{
	if (!GUnrealEd || ParkedDecalVisualizer.IsValid())
	{
		return;
	}

	// Unregister also drops the visualizer from the current selection's draw list, so the box goes
	// away without a selection change. Whatever was registered (engine or another plugin) comes back on Exit.
	const FName DecalClassName = UDecalComponent::StaticClass()->GetFName();
	ParkedDecalVisualizer = GUnrealEd->FindComponentVisualizer(DecalClassName);
	if (ParkedDecalVisualizer.IsValid())
	{
		GUnrealEd->UnregisterComponentVisualizer(DecalClassName);
	}
}

void FInteractiveDecalPlacementEdMode::RestoreEngineDecalVisualizer()
{
	if (GUnrealEd && ParkedDecalVisualizer.IsValid())
	{
		GUnrealEd->RegisterComponentVisualizer(UDecalComponent::StaticClass()->GetFName(), ParkedDecalVisualizer);
		// The per-selection visualizer list only rebuilds on a selection change; ask for one so the
		// box returns on the decal that is selected right now.
		GUnrealEd->NoteSelectionChange();
	}
	ParkedDecalVisualizer.Reset();
}

bool FInteractiveDecalPlacementEdMode::IsDraggingState() const
{
	return State == EInteractiveDecalPlacementState::Dragging || State == EInteractiveDecalPlacementState::EditDragging;
}

bool FInteractiveDecalPlacementEdMode::IsEditingPlacedDecal() const
{
	return State == EInteractiveDecalPlacementState::Edit || State == EInteractiveDecalPlacementState::EditDragging;
}

bool FInteractiveDecalPlacementEdMode::IsIdle() const
{
	return State == EInteractiveDecalPlacementState::Idle;
}

bool FInteractiveDecalPlacementEdMode::IsRestingState() const
{
	return State == EInteractiveDecalPlacementState::Idle
		|| State == EInteractiveDecalPlacementState::Preview
		|| State == EInteractiveDecalPlacementState::Edit;
}

void FInteractiveDecalPlacementEdMode::SetState(const EInteractiveDecalPlacementState NewState, FEditorViewportClient* ViewportClient)
{
	const bool bWasDragging = IsDraggingState();
	State = NewState;
	const bool bDragging = IsDraggingState();

	if (bDragging && !bWasDragging)
	{
		ProWorkflowTools::SuspendCameraInteractions(ViewportClient, DragCameraSuspension);
	}
	else if (bWasDragging && !bDragging)
	{
		ProWorkflowTools::ResumeCameraInteractions(DragCameraSuspension);
	}
}

void FInteractiveDecalPlacementEdMode::Exit()
{
	// Put everything down the way Esc would (an unfinished drag leaves the scene untouched, a target is
	// put down and the next decal's settings come back), remember the browse position, then tear down
	// what only Exit owns: the session's settings, the selection hook and the viewport pieces.
	EnterIdle(nullptr);
	PersistSessionBrowseSelection();
	USelection::SelectionChangedEvent.Remove(SelectionChangedHandle);
	SelectionChangedHandle.Reset();
	bSyncingSelection = false;
	// The tool leaves nothing selected: the last placed or edited decal is not carried out of the mode.
	if (GEditor)
	{
		GEditor->SelectNone(/*bNoteSelectionChange=*/true, /*bDeselectBSPSurfs=*/true, /*WarnAboutManyActors=*/false);
	}
	RestoreEngineDecalVisualizer();

	HideHudOverlay();
	DestroyPreviewActor();
	SetState(EInteractiveDecalPlacementState::Inactive);
	FeedbackLabel.Clear();
	AltTapStartSeconds = -1.0;
	StampFlashActor.Reset();
	StampFlashStartSeconds = -1.0;
	DepthGuideHighlightStartSeconds = -1.0;
	PreviewPingStartSeconds = -1.0;
	PickFlashActor.Reset();
	PickFlashStartSeconds = -1.0;
	bCameraTracking = false;
	PreviewRotationRad = 0.0f;
	DragRotationRad = 0.0f;
	bRandomRotationEnabled = false;
	bFlipHorizontal = false;
	bFlipVertical = false;
	bTabModifierHeld = false;
	bWModifierHeld = false;
	PreviewDecalColorAlpha = 1.0f;
	PreviewSortOrder = 0;
	bInheritedFromSelection = false;
	bHasLastPlacedSize = false;
	LastPlacedDecalSize = FVector::ZeroVector;
	CachedSceneDecals.Reset();
	SceneDecalCacheTimeSeconds = 0.0;
	ActiveMaterial.Reset();
	ActiveCollectionDecals.Reset();

	// Drop any leftover viewport mouse capture from mid-drag / StartTracking.
	if (GEditor)
	{
		if (FViewport* ActiveViewport = GEditor->GetActiveViewport())
		{
			ActiveViewport->CaptureMouse(false);
		}
	}

	FEdMode::Exit();

	if (bHoldingWidgetSuppression)
	{
		bHoldingWidgetSuppression = false;
		ProWorkflowTools::ReleaseTransformWidget();
	}
}

bool FInteractiveDecalPlacementEdMode::TogglePlacementOff()
{
	if (State == EInteractiveDecalPlacementState::Inactive)
	{
		return false;
	}
	if (IsRestingState())
	{
		CancelPlacement();
	}
	return true;
}

void FInteractiveDecalPlacementEdMode::BeginPlacement()
{
	const TArray<InteractiveDecalPlacement::FDecalBrowseCategory>& BrowseCategories = InteractiveDecalPlacement::GetBrowseCategories();
	bool bResolvedMaterial = false;

	// Prefer the last Collection browse selection across Exit/re-enter so a leftover
	// Content Browser asset selection does not wipe category/decal progress.
	if (InteractiveDecalPlacement::SessionBrowse::Source == InteractiveDecalPlacement::SessionBrowse::ESource::Collection
		&& !BrowseCategories.IsEmpty())
	{
		bResolvedMaterial = TryRestoreSessionBrowseSelection();
	}
	else if (InteractiveDecalPlacement::SessionBrowse::Source == InteractiveDecalPlacement::SessionBrowse::ESource::ContentBrowser)
	{
		if (TrySetMaterialFromContentBrowser())
		{
			SourceMode = EDecalSourceMode::ContentBrowser;
			ActiveCollectionIndex = INDEX_NONE;
			ActiveCollectionDecals.Reset();
			bResolvedMaterial = true;
		}
		else if (InteractiveDecalPlacement::SessionBrowse::MaterialPath.IsValid())
		{
			if (UMaterialInterface* Material = Cast<UMaterialInterface>(InteractiveDecalPlacement::SessionBrowse::MaterialPath.TryLoad()))
			{
				if (InteractiveDecalPlacement::IsDecalMaterial(Material))
				{
					ActiveMaterial = Material;
					CachedAspectRatio = InteractiveDecalPlacement::GetMaterialAspectRatio(Material);
					SourceMode = EDecalSourceMode::ContentBrowser;
					ActiveCollectionIndex = INDEX_NONE;
					ActiveCollectionDecals.Reset();
					bResolvedMaterial = true;
				}
			}
		}

		if (!bResolvedMaterial && !BrowseCategories.IsEmpty())
		{
			bResolvedMaterial = TryRestoreSessionBrowseSelection() || TryActivateFirstCollectionWithDecals();
			if (bResolvedMaterial)
			{
				SourceMode = EDecalSourceMode::Collection;
			}
		}
	}

	if (!bResolvedMaterial)
	{
		if (TrySetMaterialFromContentBrowser())
		{
			SourceMode = EDecalSourceMode::ContentBrowser;
			ActiveCollectionIndex = INDEX_NONE;
			ActiveCollectionDecals.Reset();
			bResolvedMaterial = true;
		}
		else if (!BrowseCategories.IsEmpty())
		{
			SourceMode = EDecalSourceMode::Collection;
			bResolvedMaterial = TryActivateFirstCollectionWithDecals();
			// If collections are empty of decals, still allow selection-inherit below.
		}
		// else: no CB / collections — selection-inherit may still enter.
	}

	// Persist browse baseline before selection-inherit overrides ActiveMaterial.
	if (bResolvedMaterial)
	{
		PersistSessionBrowseSelection();
	}

	// A single selected ADecalActor is edited in place. Its settings (or those of any other selected
	// decal-carrying actor) seed the next decal when the setting says so, or when nothing else could
	// supply a material; otherwise the session keeps what it had.
	bInheritedFromSelection = false;
	ADecalActor* SelectedDecalActor = nullptr;
	if (GEditor && GEditor->GetSelectedActorCount() == 1)
	{
		ADecalActor* Candidate = Cast<ADecalActor>(GEditor->GetSelectedActors()->GetTop<AActor>());
		SelectedDecalActor = (Candidate && !Candidate->bIsEditorPreviewActor) ? Candidate : nullptr;
	}
	const bool bSeedFromSelection = GetDefault<UProWorkflowToolsSettings>()->bInheritSelectedDecalOnEnter || !bResolvedMaterial;
	if (bSeedFromSelection && TryInheritFromSelectedDecal())
	{
		bResolvedMaterial = true;
	}

	if (!bResolvedMaterial)
	{
		FNotificationInfo NotifyInfo(LOCTEXT("NoDecalSelected", "Pick a deferred decal in the Content Browser, a collection, or a scene decal to copy."));
		NotifyInfo.ExpireDuration = 3.0f;
		NotifyInfo.bFireAndForget = true;
		FSlateNotificationManager::Get().AddNotification(NotifyInfo);
		CancelPlacement();
		return;
	}

	// Nothing is in hand or in flight here: either Enter() just ran, or CancelPlacement went dark and the
	// mode manager re-activated the still-pending mode without Enter(). Preview is set for the second case.
	SetState(EInteractiveDecalPlacementState::Preview);
	RefreshSceneDecalCache(true);
	EnsurePreviewActor();
	ShowHudOverlay();

	// ShouldDrawWidget() only hides the legacy widget; the ITF TRS gizmo follows the Show-Widget flag.
	if (!bHoldingWidgetSuppression)
	{
		bHoldingWidgetSuppression = true;
		ProWorkflowTools::SuppressTransformWidget();
	}

	FEditorViewportClient* ViewportClient = nullptr;
	if (GEditor)
	{
		if (FViewport* ActiveViewport = GEditor->GetActiveViewport())
		{
			ViewportClient = static_cast<FEditorViewportClient*>(ActiveViewport->GetClient());
		}
	}

	if (SelectedDecalActor)
	{
		EnterEditMode(SelectedDecalActor, ViewportClient);
		return;
	}

	// Seed the hover preview and refresh once so Realtime-off viewports show it immediately.
	if (ViewportClient)
	{
		UpdateHoverPreview(ViewportClient);
		RequestViewportRefresh(ViewportClient);
	}
}

bool FInteractiveDecalPlacementEdMode::ProjectCursorOntoAnchorPlane(FEditorViewportClient* ViewportClient, FVector& OutPlanePoint) const
{
	if (!ViewportClient || !ViewportClient->Viewport || !bHasAnchor)
	{
		return false;
	}

	const FViewportCursorLocation Cursor = ViewportClient->GetCursorWorldLocationFromMousePos();
	return InteractiveDecalPlacement::RayPlaneIntersection(
		Cursor.GetOrigin(),
		Cursor.GetDirection(),
		AnchorFrame.Position,
		AnchorFrame.Normal,
		OutPlanePoint);
}

void FInteractiveDecalPlacementEdMode::Tick(FEditorViewportClient* ViewportClient, float DeltaTime)
{
	FEdMode::Tick(ViewportClient, DeltaTime);

	// Modes tick once per visible viewport; the preview follows the viewport under the cursor.
	if (!Owner || ViewportClient != Owner->GetHoveredViewportClient())
	{
		return;
	}

	// The target's lifetime is read here and nowhere else: deleted or undone away, Edit ends.
	if (IsEditingPlacedDecal() && !EditTarget.IsValid())
	{
		LeaveEditMode(ViewportClient);
	}

	if (State == EInteractiveDecalPlacementState::Preview)
	{
		UpdateHoverPreview(ViewportClient);
	}
	else if (State == EInteractiveDecalPlacementState::Edit)
	{
		// Space arms the body grab without the mouse moving, so the hover (and with it the cursor) is
		// re-read on the key's edge here; MouseMove owns it otherwise.
		const bool bSpaceHeld = IsSpaceHeld(ViewportClient);
		if (bSpaceHeld != bEditSpaceHeldLastTick)
		{
			bEditSpaceHeldLastTick = bSpaceHeld;
			UpdateHoveredHandle(ViewportClient);
		}
	}
	else if (State == EInteractiveDecalPlacementState::Dragging)
	{
		UpdateDragPreview(ViewportClient);
	}
	else if (State == EInteractiveDecalPlacementState::EditDragging)
	{
		UpdateEditHandleDrag(ViewportClient);
	}

	if (State != EInteractiveDecalPlacementState::Inactive)
	{
		RefreshSceneDecalCache(false);
	}

	// Input events redraw; Tick only redraws while the cursor label, stamp flash, depth
	// guide highlight, preview ping or pick flash animates.
	const double Now = FPlatformTime::Seconds();
	const bool bLabelRedraw = FeedbackLabel.TickNeedsRedraw();
	const bool bFlashAnimating = StampFlashStartSeconds >= 0.0
		&& Now - StampFlashStartSeconds < ProWorkflowTools::OverlayStyle::PulseSeconds;
	const bool bDepthGuideSettling = DepthGuideHighlightStartSeconds >= 0.0
		&& Now - DepthGuideHighlightStartSeconds < ProWorkflowTools::OverlayStyle::SettleSeconds;
	const bool bPreviewPinging = PreviewPingStartSeconds >= 0.0
		&& Now - PreviewPingStartSeconds < ProWorkflowTools::OverlayStyle::SettleSeconds;
	const bool bPickFlashing = PickFlashStartSeconds >= 0.0
		&& Now - PickFlashStartSeconds < ProWorkflowTools::OverlayStyle::SettleSeconds;
	if (bLabelRedraw || bFlashAnimating || bDepthGuideSettling || bPreviewPinging || bPickFlashing)
	{
		RequestViewportRefresh(ViewportClient);
	}
}

void FInteractiveDecalPlacementEdMode::RefreshSceneDecalCache(const bool bForce)
{
	const double Now = FPlatformTime::Seconds();
	if (!bForce && (Now - SceneDecalCacheTimeSeconds) < SceneDecalCacheRefreshInterval)
	{
		return;
	}

	SceneDecalCacheTimeSeconds = Now;
	CachedSceneDecals.Reset();

	UWorld* World = GEditor ? GEditor->GetEditorWorldContext().World() : nullptr;
	if (!World)
	{
		return;
	}

	for (TActorIterator<ADecalActor> It(World); It; ++It)
	{
		ADecalActor* DecalActor = *It;
		if (!DecalActor || DecalActor == PreviewActor.Get())
		{
			continue;
		}

		CachedSceneDecals.Add(DecalActor);
	}
}

void FInteractiveDecalPlacementEdMode::ShowBrowseLabel()
{
	FString Detail = GetHudCategoryName();
	int32 IndexOneBased = 0;
	int32 Count = 0;
	if (TryGetHudDecalIndex(IndexOneBased, Count))
	{
		Detail += FString::Printf(TEXT("  %d / %d"), IndexOneBased, Count);
	}

	const ProWorkflowTools::CursorLabel::FLine Lines[] = {
		{ FText::FromString(GetHudDecalName()), ProWorkflowTools::OverlayStyle::Accent() },
		{ FText::FromString(Detail.TrimStartAndEnd()), ProWorkflowTools::OverlayStyle::Neutral }
	};
	FeedbackLabel.Show(Lines);
}

void FInteractiveDecalPlacementEdMode::ShowActionLabel(const FText& Text)
{
	FeedbackLabel.Show(Text, ProWorkflowTools::OverlayStyle::Accent());
}

void FInteractiveDecalPlacementEdMode::PingPreviewOutline()
{
	PreviewPingStartSeconds = FPlatformTime::Seconds();
}

void FInteractiveDecalPlacementEdMode::TrackAltTap(const FKey& Key, const EInputEvent Event)
{
	constexpr double AltTapMaxSeconds = 0.25;

	if (Key != EKeys::LeftAlt && Key != EKeys::RightAlt)
	{
		if (Event == IE_Pressed)
		{
			AltTapStartSeconds = -1.0;
		}
		return;
	}

	const double Now = FPlatformTime::Seconds();
	if (Event == IE_Pressed)
	{
		AltTapStartSeconds = Now;
	}
	else if (Event == IE_Released)
	{
		if (AltTapStartSeconds >= 0.0 && Now - AltTapStartSeconds <= AltTapMaxSeconds)
		{
			SetCenteredPlacementEnabled(!IsCenteredPlacementEnabled());
			ShowActionLabel(IsCenteredPlacementEnabled()
				? LOCTEXT("DecalLabelCentered", "Centered")
				: LOCTEXT("DecalLabelCorner", "Corner"));
		}
		AltTapStartSeconds = -1.0;
	}
}

bool FInteractiveDecalPlacementEdMode::TrySwitchToCollectionBrowsing()
{
	const TArray<InteractiveDecalPlacement::FDecalBrowseCategory>& BrowseCategories = InteractiveDecalPlacement::GetBrowseCategories();
	if (BrowseCategories.IsEmpty())
	{
		return false;
	}

	ClearSelectionInherit(/*bRestoreBrowseMaterial=*/false);

	if (!TryActivateFirstCollectionWithDecals())
	{
		return false;
	}

	SourceMode = EDecalSourceMode::Collection;
	PersistSessionBrowseSelection();
	EnsurePreviewActor();
	if (UDecalComponent* DecalComponent = PreviewActor.IsValid() ? PreviewActor->GetDecal() : nullptr)
	{
		DecalComponent->SetDecalMaterial(ActiveMaterial.Get());
	}
	return true;
}

bool FInteractiveDecalPlacementEdMode::HandleMouseWheelInput(FEditorViewportClient* ViewportClient, const int32 WheelDelta)
{
	if (!ViewportClient || State == EInteractiveDecalPlacementState::Inactive)
	{
		return false;
	}

	// One step per notch — callers must pass Sign only (±1), never raw WheelDelta magnitude.
	const int32 Step = (WheelDelta > 0) ? 1 : ((WheelDelta < 0) ? -1 : 0);
	if (Step == 0)
	{
		return false;
	}

	const bool bTDown = ViewportClient->Viewport && ViewportClient->Viewport->KeyState(EKeys::T);
	const bool bSDown = ViewportClient->Viewport && ViewportClient->Viewport->KeyState(EKeys::S);

	if (bTDown)
	{
		PreviewDecalColorAlpha = FMath::Clamp(
			PreviewDecalColorAlpha - static_cast<float>(Step) * DecalColorAlphaScrollStep,
			0.0f,
			1.0f);
		ApplyPreviewDecalProperties();
		PingPreviewOutline();
		ShowActionLabel(FText::Format(
			LOCTEXT("DecalLabelOpacity", "Opacity {0}%"),
			FText::AsNumber(FMath::RoundToInt(PreviewDecalColorAlpha * 100.0f))));
		return true;
	}

	if (bSDown)
	{
		PreviewSortOrder -= Step;
		ApplyPreviewDecalProperties();
		PingPreviewOutline();
		ShowActionLabel(FText::Format(LOCTEXT("DecalLabelSort", "Sort {0}"), FText::AsNumber(PreviewSortOrder)));
		return true;
	}

	// Priority: W+Scroll depth, else Tab category, else Shift size, else Ctrl rotate, else select.
	if (bWModifierHeld)
	{
		if (AdjustProjectionDepth(Step))
		{
			DepthGuideHighlightStartSeconds = FPlatformTime::Seconds();
			ShowActionLabel(FText::Format(
				LOCTEXT("DecalLabelDepth", "Depth {0} cm"),
				FText::FromString(ProWorkflowTools::CursorLabel::FormatAmount(GetActiveProjectionDepth()))));
			return true;
		}
		return false;
	}

	// Tab+Scroll always cycles categories when Tab is held (including mid-drag —
	// only swaps preview material/aspect; never commits).
	if (bTabModifierHeld)
	{
		if (SourceMode != EDecalSourceMode::Collection)
		{
			TrySwitchToCollectionBrowsing();
		}
		CycleCollection(Step);
		if (State == EInteractiveDecalPlacementState::Dragging)
		{
			UpdateDragPreview(ViewportClient);
		}
		else if (IsEditingPlacedDecal())
		{
			RewriteEditTargetPose();
		}
		return true;
	}

	// Shift+Scroll adjusts in-plane size by the configured interval.
	if (ViewportClient->IsShiftPressed())
	{
		if (AdjustActiveDecalSize(Step))
		{
			const FVector Size = GetCurrentInPlaneSize();
			ShowActionLabel(FText::Format(
				LOCTEXT("DecalLabelSize", "Size {0} × {1} cm"),
				FText::FromString(ProWorkflowTools::CursorLabel::FormatAmount(FMath::Abs(Size.Z))),
				FText::FromString(ProWorkflowTools::CursorLabel::FormatAmount(FMath::Abs(Size.Y)))));
			return true;
		}
		return false;
	}

	// Ctrl+Scroll rotates the preview orientation (used by click-stamps and as the drag's
	// starting rotation), or the edit target in its own plane. Ignored while dragging, where
	// Ctrl means rotate/scale around anchor.
	if (ViewportClient->IsCtrlPressed())
	{
		if (IsRestingState())
		{
			const float DeltaRad = Step * GetRotationIntervalRadians();
			if (State == EInteractiveDecalPlacementState::Edit)
			{
				RotateEditTarget(DeltaRad);
			}
			else
			{
				PreviewRotationRad += DeltaRad;
			}
			ShowActionLabel(FText::Format(
				LOCTEXT("DecalLabelRotation", "Rotation {0}°"),
				FText::FromString(ProWorkflowTools::CursorLabel::FormatAmount(
					FRotator::NormalizeAxis(FMath::RadiansToDegrees(PreviewRotationRad))))));
		}
		return true;
	}

	// If we started from a Content Browser selection, the first scroll switches to collection browsing.
	if (SourceMode != EDecalSourceMode::Collection && !TrySwitchToCollectionBrowsing())
	{
		return false;
	}

	// SelectDecal writes the edit target itself.
	CycleDecalInCollection(Step);
	if (State == EInteractiveDecalPlacementState::Dragging)
	{
		UpdateDragPreview(ViewportClient);
	}
	return true;
}

FVector FInteractiveDecalPlacementEdMode::GetCurrentInPlaneSize() const
{
	const UProWorkflowToolsSettings* Settings = GetDefault<UProWorkflowToolsSettings>();

	// While dragging, the live preview size is authoritative; so is the edit target's own footprint
	// (it can change under us through undo or the Details panel).
	if (State == EInteractiveDecalPlacementState::Dragging || IsEditingPlacedDecal())
	{
		const ADecalActor* Posed = GetPosedActor();
		if (const UDecalComponent* DecalComponent = Posed ? Posed->GetDecal() : nullptr)
		{
			return InteractiveDecalPlacement::GetDecalSignedHalfExtents(*DecalComponent).GetAbs();
		}
	}

	// In preview, prefer the session size so rapid Shift+Scroll ticks accumulate correctly.
	if (bHasLastPlacedSize)
	{
		return LastPlacedDecalSize;
	}

	const float Aspect = GetActiveMaterialAspectRatio();
	return FVector(
		Settings->DefaultProjectionDepth,
		Settings->PreviewPlaneExtent / Aspect,
		Settings->PreviewPlaneExtent);
}

bool FInteractiveDecalPlacementEdMode::AdjustActiveDecalSize(const int32 WheelDelta)
{
	const UProWorkflowToolsSettings* Settings = GetDefault<UProWorkflowToolsSettings>();
	const float Interval = FMath::Max(Settings->SizeScrollInterval, 0.1f);
	// Scroll up (WheelDelta < 0 from our handlers) increases size.
	const float SizeDelta = -static_cast<float>(WheelDelta) * Interval;

	const float Aspect = GetActiveMaterialAspectRatio();
	const FVector PreviousSize = GetCurrentInPlaneSize();
	const float PreviousExtent = FMath::Max(FMath::Abs(PreviousSize.Z), Settings->MinDragExtent);
	const float NewExtent = FMath::Max(PreviousExtent + SizeDelta, Settings->MinDragExtent);

	FVector Size;
	Size.X = GetActiveProjectionDepth();
	Size.Z = NewExtent;
	Size.Y = NewExtent / FMath::Max(Aspect, KINDA_SMALL_NUMBER);

	LastPlacedDecalSize = Size;
	bHasLastPlacedSize = true;

	if (State == EInteractiveDecalPlacementState::Dragging && bHasAnchor)
	{
		const FVector DragVec = LastDragPlanePoint - AnchorFrame.Position;
		if (DragVec.SizeSquared() > KINDA_SMALL_NUMBER && PreviousExtent > KINDA_SMALL_NUMBER)
		{
			const float Scale = NewExtent / PreviousExtent;
			LastDragPlanePoint = AnchorFrame.Position + DragVec * Scale;
			if (bSpacePanning)
			{
				SpacePanFrozenDragVector *= Scale;
			}
		}
	}

	if (const ADecalActor* Posed = GetPosedActor())
	{
		FInteractiveDecalPlacementResult Placement;
		Placement.ActorTransform = Posed->GetActorTransform();
		Placement.DecalSize = Size;
		ApplyPreviewTransform(Placement);
	}

	return true;
}

float FInteractiveDecalPlacementEdMode::GetActiveProjectionDepth() const
{
	const FVector Size = GetCurrentInPlaneSize();
	if (Size.X > KINDA_SMALL_NUMBER)
	{
		return Size.X;
	}

	return GetDefault<UProWorkflowToolsSettings>()->DefaultProjectionDepth;
}

bool FInteractiveDecalPlacementEdMode::AdjustProjectionDepth(const int32 WheelDelta)
{
	FVector Size = GetCurrentInPlaneSize();
	// Scroll up (WheelDelta < 0 from our handlers) increases projection depth.
	Size.X = FMath::Max(Size.X - static_cast<float>(WheelDelta) * ProjectionDepthScrollStepCm, 1.0f);

	LastPlacedDecalSize = Size;
	bHasLastPlacedSize = true;

	if (const ADecalActor* Posed = GetPosedActor())
	{
		FInteractiveDecalPlacementResult Placement;
		Placement.ActorTransform = Posed->GetActorTransform();
		Placement.DecalSize = Size;
		ApplyPreviewTransform(Placement);
	}

	return true;
}

bool FInteractiveDecalPlacementEdMode::IsCenteredFor(const FEditorViewportClient* ViewportClient) const
{
	// Alt before LMB is the camera's (orbit); Alt after the drag started inverts this drag. The hover
	// preview therefore never reads Alt: it would promise a placement that Alt+LMB does not make.
	const bool bAltInvertsDrag = IsDraggingState() && ViewportClient->IsAltPressed();
	return IsCenteredPlacementEnabled() != bAltInvertsDrag;
}

bool FInteractiveDecalPlacementEdMode::IsCenteredPlacementEnabled() const
{
	return GetDefault<UProWorkflowToolsUserSettings>()->bDecalPlaceCentered;
}

void FInteractiveDecalPlacementEdMode::SetCenteredPlacementEnabled(const bool bEnabled)
{
	UProWorkflowToolsUserSettings* UserSettings = GetMutableDefault<UProWorkflowToolsUserSettings>();
	UserSettings->bDecalPlaceCentered = bEnabled;
	UserSettings->SaveConfig();
}

bool FInteractiveDecalPlacementEdMode::IsFitSurfaceEnabled() const
{
	return GetDefault<UProWorkflowToolsUserSettings>()->bDecalFitSurface;
}

void FInteractiveDecalPlacementEdMode::SetFitSurfaceEnabled(const bool bEnabled)
{
	UProWorkflowToolsUserSettings* UserSettings = GetMutableDefault<UProWorkflowToolsUserSettings>();
	UserSettings->bDecalFitSurface = bEnabled;
	UserSettings->SaveConfig();
	FitSurfaceSamples.Reset();

	// A placed decal is not re-posed by hover; turning the fit on fits it where it sits.
	if (State == EInteractiveDecalPlacementState::Edit && bEnabled)
	{
		RefitEditTarget(Owner ? Owner->GetHoveredViewportClient() : nullptr);
	}
	RefreshPreviewPose();
}

void FInteractiveDecalPlacementEdMode::SetSessionSize(const FVector& Size)
{
	LastPlacedDecalSize = Size;
	bHasLastPlacedSize = true;

	if (const ADecalActor* Posed = GetPosedActor())
	{
		FInteractiveDecalPlacementResult Placement;
		Placement.ActorTransform = Posed->GetActorTransform();
		Placement.DecalSize = Size;
		ApplyPreviewTransform(Placement);
	}
}

void FInteractiveDecalPlacementEdMode::RefreshPreviewPose()
{
	FEditorViewportClient* ViewportClient = Owner ? Owner->GetHoveredViewportClient() : nullptr;
	if (!ViewportClient && GEditor && GEditor->GetActiveViewport())
	{
		ViewportClient = static_cast<FEditorViewportClient*>(GEditor->GetActiveViewport()->GetClient());
	}
	if (!ViewportClient)
	{
		return;
	}

	// Edit states hold no cursor-driven pose: the value edit already wrote the target.
	if (State == EInteractiveDecalPlacementState::Preview)
	{
		UpdateHoverPreview(ViewportClient);
	}
	else if (State == EInteractiveDecalPlacementState::Dragging)
	{
		UpdateDragPreview(ViewportClient);
	}
	RequestViewportRefresh(ViewportClient);
}

void FInteractiveDecalPlacementEdMode::SetHudInPlaneSize(const float WidthCm, const float HeightCm)
{
	const UProWorkflowToolsSettings* Settings = GetDefault<UProWorkflowToolsSettings>();
	const float Width = FMath::Max(WidthCm, Settings->MinDragExtent);
	const float Height = HeightCm > 0.0f
		? FMath::Max(HeightCm, Settings->MinDragExtent)
		: Width / FMath::Max(GetActiveMaterialAspectRatio(), KINDA_SMALL_NUMBER);

	SetSessionSize(FVector(GetActiveProjectionDepth(), Height, Width));
	PingPreviewOutline();
	RefreshPreviewPose();
}

void FInteractiveDecalPlacementEdMode::SetHudAngleDegrees(const float Degrees)
{
	const float Radians = FMath::DegreesToRadians(FRotator::NormalizeAxis(Degrees));
	if (IsEditingPlacedDecal())
	{
		RotateEditTarget(Radians - PreviewRotationRad);
		RefreshPreviewPose();
		return;
	}

	PreviewRotationRad = Radians;
	if (State == EInteractiveDecalPlacementState::Dragging)
	{
		DragRotationRad = Radians;
		bCtrlRotating = false;
	}
	RefreshPreviewPose();
}

void FInteractiveDecalPlacementEdMode::SetHudProjectionDepth(const float DepthCm)
{
	FVector Size = GetCurrentInPlaneSize();
	Size.X = FMath::Max(DepthCm, 1.0f);
	SetSessionSize(Size);
	DepthGuideHighlightStartSeconds = FPlatformTime::Seconds();
	RefreshPreviewPose();
}

void FInteractiveDecalPlacementEdMode::SetHudAlpha(const float Alpha)
{
	PreviewDecalColorAlpha = FMath::Clamp(Alpha, 0.0f, 1.0f);
	ApplyPreviewDecalProperties();
	PingPreviewOutline();
	RefreshPreviewPose();
}

void FInteractiveDecalPlacementEdMode::SetHudSortOrder(const int32 SortOrder)
{
	PreviewSortOrder = SortOrder;
	ApplyPreviewDecalProperties();
	PingPreviewOutline();
	RefreshPreviewPose();
}

bool FInteractiveDecalPlacementEdMode::IsSessionCollectionEnabled(const FName CollectionName) const
{
	return InteractiveDecalPlacement::IsCollectionEnabledForSession(CollectionName);
}

void FInteractiveDecalPlacementEdMode::SetAllSessionCollectionsEnabled(const bool bEnabled)
{
	InteractiveDecalPlacement::SetAllSessionCollectionsEnabled(bEnabled);

	if (State == EInteractiveDecalPlacementState::Inactive)
	{
		return;
	}

	PersistSessionBrowseSelection();

	if (SourceMode == EDecalSourceMode::Collection || SourceMode == EDecalSourceMode::ContentBrowser)
	{
		if (!TryRestoreSessionBrowseSelection())
		{
			if (!TryActivateFirstCollectionWithDecals())
			{
				ActiveMaterial.Reset();
				ActiveCollectionIndex = INDEX_NONE;
				ActiveCollectionDecals.Reset();
				SetPreviewVisible(false);
			}
			else
			{
				SourceMode = EDecalSourceMode::Collection;
			}
		}

		if (ActiveMaterial.IsValid())
		{
			EnsurePreviewActor();
			if (UDecalComponent* DecalComponent = PreviewActor.IsValid() ? PreviewActor->GetDecal() : nullptr)
			{
				DecalComponent->SetDecalMaterial(ActiveMaterial.Get());
			}
		}
	}
}

bool FInteractiveDecalPlacementEdMode::IsShowSceneBounds() const
{
	return bShowSceneBounds;
}

void FInteractiveDecalPlacementEdMode::SetShowSceneBounds(const bool bEnabled)
{
	bShowSceneBounds = bEnabled;
}

void FInteractiveDecalPlacementEdMode::SetSessionCollectionEnabled(const FName CollectionName, const bool bEnabled)
{
	InteractiveDecalPlacement::SetCollectionEnabledForSession(CollectionName, bEnabled);

	if (State == EInteractiveDecalPlacementState::Inactive)
	{
		return;
	}

	PersistSessionBrowseSelection();

	if (SourceMode == EDecalSourceMode::Collection || SourceMode == EDecalSourceMode::ContentBrowser)
	{
		if (!TryRestoreSessionBrowseSelection())
		{
			if (!TryActivateFirstCollectionWithDecals())
			{
				ActiveMaterial.Reset();
				ActiveCollectionIndex = INDEX_NONE;
				ActiveCollectionDecals.Reset();
				SetPreviewVisible(false);
			}
			else
			{
				SourceMode = EDecalSourceMode::Collection;
			}
		}

		if (ActiveMaterial.IsValid())
		{
			EnsurePreviewActor();
			if (UDecalComponent* DecalComponent = PreviewActor.IsValid() ? PreviewActor->GetDecal() : nullptr)
			{
				DecalComponent->SetDecalMaterial(ActiveMaterial.Get());
			}
		}
	}
}

void FInteractiveDecalPlacementEdMode::GetSessionUiBrowseCategories(
	TArray<InteractiveDecalPlacement::FDecalBrowseCategory>& OutCategories) const
{
	InteractiveDecalPlacement::GetSessionUiBrowseCategories(OutCategories);
}

bool FInteractiveDecalPlacementEdMode::IsPointerOverHud() const
{
	return HudOverlay.IsValid() && HudOverlay->IsPointerOverPanel();
}

void FInteractiveDecalPlacementEdMode::ResetPlacementTweaks()
{
	PreviewRotationRad = 0.0f;
	if (State == EInteractiveDecalPlacementState::Dragging)
	{
		DragRotationRad = 0.0f;
	}

	// Drop selection-inherit and restore the normal browse material when possible.
	ClearSelectionInherit(/*bRestoreBrowseMaterial=*/true);

	bHasLastPlacedSize = false;
	LastPlacedDecalSize = FVector::ZeroVector;
	PreviewDecalColorAlpha = 1.0f;
	PreviewSortOrder = 0;
	bFlipHorizontal = false;
	bFlipVertical = false;

	ApplyPreviewDecalProperties();

	if (const ADecalActor* Posed = GetPosedActor())
	{
		const FVector Size = GetCurrentInPlaneSize();
		FInteractiveDecalPlacementResult Placement;
		Placement.ActorTransform = Posed->GetActorTransform();
		Placement.DecalSize = Size;
		ApplyPreviewTransform(Placement);
	}
}

bool FInteractiveDecalPlacementEdMode::InputKey(FEditorViewportClient* ViewportClient, FViewport* Viewport, FKey Key, EInputEvent Event)
{
	if (State != EInteractiveDecalPlacementState::Inactive)
	{
		// Any key or wheel notch can change the preview, guides or label; this is the one input redraw.
		RequestViewportRefresh(ViewportClient);
		TrackAltTap(Key, Event);
	}

	// Esc steps back one level: a handle drag springs back to Edit; Edit puts the target down and
	// placing (hovering or mid-drag) puts the ghost down, both into Idle; Idle exits.
	if (Key == EKeys::Escape && Event == IE_Pressed)
	{
		if (State == EInteractiveDecalPlacementState::EditDragging)
		{
			EndEditHandleDrag(/*bKeep=*/false);
		}
		else if (State == EInteractiveDecalPlacementState::Edit)
		{
			LeaveEditMode(ViewportClient);
		}
		else if (State == EInteractiveDecalPlacementState::Preview || State == EInteractiveDecalPlacementState::Dragging)
		{
			EnterIdle(ViewportClient);
		}
		else
		{
			CancelPlacement();
		}
		return true;
	}

	// RMB held: the camera owns the viewport (fly, WASD, wheel speed, RMB+LMB dolly), so the resting
	// states handle nothing. Releases still clear the held-key flags: a key pressed before RMB must
	// not stay held once the flight ends.
	if (IsRestingState() && Viewport && Viewport->KeyState(EKeys::RightMouseButton))
	{
		if (Event == IE_Released)
		{
			if (Key == EKeys::W)
			{
				bWModifierHeld = false;
			}
			else if (Key == EKeys::Tab)
			{
				bTabModifierHeld = false;
			}
		}
		return FEdMode::InputKey(ViewportClient, Viewport, Key, Event);
	}

	// Single-key hotkeys never claim Ctrl chords, so Ctrl+Z / Ctrl+S / Ctrl+X reach the editor.
	const bool bHotkeyPress = Event == IE_Pressed
		&& State != EInteractiveDecalPlacementState::Inactive
		&& !ViewportClient->IsCtrlPressed();

	// Random rotation and Reset describe the next stamp; a placed decal has neither. Consumed so the
	// keys stay quiet in Edit rather than reaching other bindings.
	if ((Key == EKeys::R || Key == EKeys::BackSpace) && bHotkeyPress && IsEditingPlacedDecal())
	{
		return true;
	}

	if (Key == EKeys::R && bHotkeyPress)
	{
		bRandomRotationEnabled = !bRandomRotationEnabled;
		ShowActionLabel(bRandomRotationEnabled
			? LOCTEXT("DecalLabelRandomOn", "Random rotation on")
			: LOCTEXT("DecalLabelRandomOff", "Random rotation off"));
		return true;
	}

	if (Key == EKeys::C && bHotkeyPress)
	{
		SetFitSurfaceEnabled(!IsFitSurfaceEnabled());
		PingPreviewOutline();
		ShowActionLabel(IsFitSurfaceEnabled()
			? LOCTEXT("DecalLabelFitSurfaceOn", "Fit Surface on")
			: LOCTEXT("DecalLabelFitSurfaceOff", "Fit Surface off"));
		return true;
	}

	if (Key == EKeys::X && bHotkeyPress)
	{
		bFlipHorizontal = !bFlipHorizontal;
		PingPreviewOutline();
		ShowActionLabel(bFlipHorizontal
			? LOCTEXT("DecalLabelFlipHOn", "Flip H on")
			: LOCTEXT("DecalLabelFlipHOff", "Flip H off"));
		if (State == EInteractiveDecalPlacementState::Preview)
		{
			UpdateHoverPreview(ViewportClient);
		}
		else if (State == EInteractiveDecalPlacementState::Dragging)
		{
			UpdateDragPreview(ViewportClient);
		}
		else if (IsEditingPlacedDecal())
		{
			RewriteEditTargetPose();
		}
		return true;
	}

	if (Key == EKeys::Z && bHotkeyPress)
	{
		bFlipVertical = !bFlipVertical;
		PingPreviewOutline();
		ShowActionLabel(bFlipVertical
			? LOCTEXT("DecalLabelFlipVOn", "Flip V on")
			: LOCTEXT("DecalLabelFlipVOff", "Flip V off"));
		if (State == EInteractiveDecalPlacementState::Preview)
		{
			UpdateHoverPreview(ViewportClient);
		}
		else if (State == EInteractiveDecalPlacementState::Dragging)
		{
			UpdateDragPreview(ViewportClient);
		}
		else if (IsEditingPlacedDecal())
		{
			RewriteEditTargetPose();
		}
		return true;
	}

	if (Key == EKeys::BackSpace && bHotkeyPress)
	{
		ResetPlacementTweaks();
		PingPreviewOutline();
		ShowActionLabel(LOCTEXT("DecalLabelReset", "Reset"));
		if (State == EInteractiveDecalPlacementState::Preview)
		{
			UpdateHoverPreview(ViewportClient);
		}
		else if (State == EInteractiveDecalPlacementState::Dragging)
		{
			UpdateDragPreview(ViewportClient);
		}
		return true;
	}

	// MMB targets: the scene decal under the cursor becomes the edit target, empty space picks the ghost
	// up (Preview); Shift+MMB picks (inherits the decal into the ghost and starts placing it). Press
	// only, so a MMB drag still pans the camera. Alt+MMB is the camera pan, so Alt held means the press
	// is never ours. The same from Idle, Preview and Edit.
	if (Key == EKeys::MiddleMouseButton && Event == IE_Pressed && IsRestingState()
		&& Viewport && !IsPointerOverHud() && !ViewportClient->IsAltPressed())
	{
		if (ViewportClient->IsShiftPressed())
		{
			if (PickDecalUnderCursor(ViewportClient, Viewport))
			{
				return true;
			}
			return FEdMode::InputKey(ViewportClient, Viewport, Key, Event);
		}

		ADecalActor* Under = FindSceneDecalUnderCursor(ViewportClient);
		if (Under)
		{
			if (Under != EditTarget.Get())
			{
				EnterEditMode(Under, ViewportClient);
			}
			return true;
		}
		if (State != EInteractiveDecalPlacementState::Preview)
		{
			if (State == EInteractiveDecalPlacementState::Edit)
			{
				LeaveEditMode(ViewportClient);
			}
			BeginPreview(ViewportClient);
			return true;
		}
		return FEdMode::InputKey(ViewportClient, Viewport, Key, Event);
	}

	// LMB makes: a press on the grabbable outline resizes that decal (entering Edit for it first);
	// anywhere else it begins a stamp drag for a new decal, from Idle and Edit as much as from Preview.
	if (Key == EKeys::LeftMouseButton && Event == IE_Pressed && IsRestingState())
	{
		// HUD owns pointer hit-testing; do not start a drag when the cursor is over it.
		if (IsPointerOverHud())
		{
			return true;
		}

		// Alt before LMB is the camera orbit; Alt only modifies a drag once it has started.
		if (ViewportClient->IsAltPressed())
		{
			return FEdMode::InputKey(ViewportClient, Viewport, Key, Event);
		}

		if (Viewport)
		{
			const FInteractiveDecalEditHandle Handle = FindHandleAtPixel(ViewportClient, FIntPoint(Viewport->GetMouseX(), Viewport->GetMouseY()));
			ADecalActor* HandleDecal = Handle.IsValid() ? GetHandleDecal(ViewportClient) : nullptr;
			if (HandleDecal)
			{
				if (HandleDecal != EditTarget.Get())
				{
					EnterEditMode(HandleDecal, ViewportClient);
				}
				if (State == EInteractiveDecalPlacementState::Edit)
				{
					BeginEditHandleDrag(Handle, ViewportClient);
				}
				return true;
			}
		}

		if (BeginStampDrag(ViewportClient, Viewport))
		{
			return true;
		}
	}

	// LMB release ends the stamp drag (EndTracking does the same when capture was lost with LMB already up).
	if (Key == EKeys::LeftMouseButton && Event == IE_Released && State == EInteractiveDecalPlacementState::Dragging)
	{
		ReleaseStampDrag(ViewportClient);
		return true;
	}

	if (Key == EKeys::LeftMouseButton && Event == IE_Released && State == EInteractiveDecalPlacementState::EditDragging)
	{
		EndEditHandleDrag(/*bKeep=*/true);
		return true;
	}

	// The drag owns the other mouse buttons too: consumed, so the viewport neither restarts its
	// tracking (which would re-run StartTracking on every mode) nor opens the context menu.
	if ((Key == EKeys::RightMouseButton || Key == EKeys::MiddleMouseButton) && IsDraggingState())
	{
		return true;
	}

	// Consume Space while dragging, and in Edit where it arms the body grab, so it does not reach other
	// viewport bindings (the editor cycles the transform gizmo on Space). Held state is read from
	// IsSpaceHeld() (OS key state on Windows).
	if (Key == EKeys::SpaceBar && (IsDraggingState() || State == EInteractiveDecalPlacementState::Edit))
	{
		return true;
	}

	// Track Tab for category scroll; consume so editor focus navigation does not steal it.
	if (Key == EKeys::Tab && State != EInteractiveDecalPlacementState::Inactive)
	{
		if (Event == IE_Pressed || Event == IE_Repeat)
		{
			bTabModifierHeld = true;
		}
		else if (Event == IE_Released)
		{
			bTabModifierHeld = false;
		}
		return true;
	}

	// Track W for projection-depth scroll; consume so WASD camera move does not steal it.
	if (Key == EKeys::W && State != EInteractiveDecalPlacementState::Inactive)
	{
		if (Event == IE_Released)
		{
			bWModifierHeld = false;
			return true;
		}
		if (ViewportClient->IsCtrlPressed())
		{
			return FEdMode::InputKey(ViewportClient, Viewport, Key, Event);
		}
		bWModifierHeld = true;
		return true;
	}

	if ((Key == EKeys::T || Key == EKeys::S) && State != EInteractiveDecalPlacementState::Inactive
		&& !ViewportClient->IsCtrlPressed())
	{
		return true;
	}

	// Sole wheel path: MouseScrollUp/Down only. Do NOT also handle MouseWheelAxis in InputAxis —
	// Unreal fires both for one notch, which doubled every scroll step (1→3→5, rotate 2.5→5).
	if (Key == EKeys::MouseScrollUp && Event == IE_Pressed)
	{
		return HandleMouseWheelInput(ViewportClient, -1);
	}

	if (Key == EKeys::MouseScrollDown && Event == IE_Pressed)
	{
		return HandleMouseWheelInput(ViewportClient, 1);
	}

	return FEdMode::InputKey(ViewportClient, Viewport, Key, Event);
}

bool FInteractiveDecalPlacementEdMode::HandleClick(FEditorViewportClient* InViewportClient, HHitProxy* HitProxy, const FViewportClick& Click)
{
	// MMB is the tool's: the press already targeted or picked (or found nothing). The level viewport
	// would otherwise Shift-add whatever actor the click landed on, so the click ends here. Alt+MMB
	// stays the editor's pivot set.
	if (Click.GetKey() == EKeys::MiddleMouseButton && !Click.IsAltDown() && State != EInteractiveDecalPlacementState::Inactive)
	{
		return true;
	}
	return FEdMode::HandleClick(InViewportClient, HitProxy, Click);
}

bool FInteractiveDecalPlacementEdMode::InputAxis(
	FEditorViewportClient* ViewportClient,
	FViewport* Viewport,
	int32 ControllerId,
	FKey Key,
	float Delta,
	float DeltaTime)
{
	// Intentionally ignore MouseWheelAxis — InputKey(MouseScrollUp/Down) is the only consumer.
	return FEdMode::InputAxis(ViewportClient, Viewport, ControllerId, Key, Delta, DeltaTime);
}

bool FInteractiveDecalPlacementEdMode::StartTracking(FEditorViewportClient* InViewportClient, FViewport* InViewport)
{
	const bool bResting = IsRestingState();

	// Don't capture the viewport when the cursor is over the HUD — that would steal focus from
	// Slate and can still lead to placement on release.
	if (bResting && IsPointerOverHud())
	{
		return false;
	}

	// Camera gestures (Alt orbit/dolly/track, RMB fly) are the viewport's tracking; the preview
	// stays hidden until EndTracking so it does not trail the moving camera.
	if (bResting && InViewport
		&& (InViewportClient->IsAltPressed() || InViewport->KeyState(EKeys::RightMouseButton)))
	{
		bCameraTracking = true;
		SetPreviewVisible(false);
		RequestViewportRefresh(InViewportClient);
		return false;
	}

	if (State != EInteractiveDecalPlacementState::Inactive)
	{
		return true;
	}
	return FEdMode::StartTracking(InViewportClient, InViewport);
}

bool FInteractiveDecalPlacementEdMode::EndTracking(FEditorViewportClient* InViewportClient, FViewport* InViewport)
{
	if (bCameraTracking)
	{
		bCameraTracking = false;
		if (State == EInteractiveDecalPlacementState::Preview)
		{
			UpdateHoverPreview(InViewportClient);
			RequestViewportRefresh(InViewportClient);
		}
		return FEdMode::EndTracking(InViewportClient, InViewport);
	}

	if (State == EInteractiveDecalPlacementState::Dragging)
	{
		// Capture can drop while LMB is still held (Tab/focus). Keep the drag alive —
		// the LMB release ends it, or this does once LMB is already up.
		if (InViewport && InViewport->KeyState(EKeys::LeftMouseButton))
		{
			return true;
		}
		ReleaseStampDrag(InViewportClient);
		return true;
	}

	if (State == EInteractiveDecalPlacementState::EditDragging)
	{
		if (InViewport && InViewport->KeyState(EKeys::LeftMouseButton))
		{
			return true;
		}
		EndEditHandleDrag(/*bKeep=*/true);
		return true;
	}
	return FEdMode::EndTracking(InViewportClient, InViewport);
}

bool FInteractiveDecalPlacementEdMode::CapturedMouseMove(FEditorViewportClient* InViewportClient, FViewport* InViewport, int32 InMouseX, int32 InMouseY)
{
	if (State == EInteractiveDecalPlacementState::Preview)
	{
		UpdateHoverPreview(InViewportClient);
		RequestViewportRefresh(InViewportClient);
		return true;
	}

	if (State == EInteractiveDecalPlacementState::Dragging)
	{
		UpdateDragPreview(InViewportClient);
		RequestViewportRefresh(InViewportClient);
		return true;
	}

	if (State == EInteractiveDecalPlacementState::EditDragging)
	{
		UpdateEditHandleDrag(InViewportClient);
		RequestViewportRefresh(InViewportClient);
		return true;
	}

	return FEdMode::CapturedMouseMove(InViewportClient, InViewport, InMouseX, InMouseY);
}

bool FInteractiveDecalPlacementEdMode::MouseMove(FEditorViewportClient* ViewportClient, FViewport* Viewport, int32 x, int32 y)
{
	if (State == EInteractiveDecalPlacementState::Preview)
	{
		UpdateHoverPreview(ViewportClient);
		UpdateHoveredHandle(ViewportClient);
		RequestViewportRefresh(ViewportClient);
		return true;
	}

	if (State == EInteractiveDecalPlacementState::Edit)
	{
		UpdateHoveredHandle(ViewportClient);
		RequestViewportRefresh(ViewportClient);
		return true;
	}

	if (State == EInteractiveDecalPlacementState::Dragging)
	{
		UpdateDragPreview(ViewportClient);
		RequestViewportRefresh(ViewportClient);
		return true;
	}

	if (State == EInteractiveDecalPlacementState::EditDragging)
	{
		UpdateEditHandleDrag(ViewportClient);
		RequestViewportRefresh(ViewportClient);
		return true;
	}

	return FEdMode::MouseMove(ViewportClient, Viewport, x, y);
}

bool FInteractiveDecalPlacementEdMode::DisallowMouseDeltaTracking() const
{
	return IsDraggingState();
}

bool FInteractiveDecalPlacementEdMode::GetCursor(EMouseCursor::Type& OutCursor) const
{
	// The cursor is the one promise the widget makes before a press: a hand over the body (Space held),
	// a cross over a corner or edge. While dragging it reads from the handle being dragged.
	const bool bDragging = State == EInteractiveDecalPlacementState::EditDragging;
	const FInteractiveDecalEditHandle& Live = bDragging ? EditDragHandle : HoveredHandle;
	if (!Live.IsValid())
	{
		return false;
	}
	if (Live.IsBody())
	{
		OutCursor = bDragging ? EMouseCursor::GrabHandClosed : EMouseCursor::GrabHand;
	}
	else
	{
		OutCursor = EMouseCursor::CardinalCross;
	}
	return true;
}

void FInteractiveDecalPlacementEdMode::AddReferencedObjects(FReferenceCollector& Collector)
{
	FEdMode::AddReferencedObjects(Collector);
	Collector.AddReferencedObject(PreviewActor);
	Collector.AddReferencedObject(ActiveMaterial);
	Collector.AddReferencedObject(WedgeMaterial);
}

FInteractiveDecalPlacementResult FInteractiveDecalPlacementEdMode::MakeHoverPlacement(
	const FInteractiveDecalTangentFrame& Frame,
	const bool bCentered) const
{
	const UProWorkflowToolsSettings* Settings = GetDefault<UProWorkflowToolsSettings>();
	const float Aspect = GetActiveMaterialAspectRatio();

	const FInteractiveDecalTangentFrame RotatedFrame = InteractiveDecalPlacement::RotateFrameInPlane(Frame, PreviewRotationRad);

	FVector DecalSize;
	// Prefer session size (last place / Shift+Scroll / W+Scroll depth) so hover matches HUD.
	// bUseLastPlacedSize only gates whether click-stamps seed from a prior drag.
	if (bHasLastPlacedSize)
	{
		DecalSize = LastPlacedDecalSize;
	}
	else
	{
		// Local Y (Tangent) is the decal's vertical axis, local Z the horizontal one.
		DecalSize = FVector(
			Settings->DefaultProjectionDepth,
			Settings->PreviewPlaneExtent / Aspect,
			Settings->PreviewPlaneExtent);
	}

	// Corner-anchored unless centered: cursor at visual top-left.
	// Deferred decal UVs: U along local +Z, V along local +Y. Actor basis is X=-N, Y=Tangent,
	// Z=-Bitangent, so image down = +Tangent and image right = -Bitangent. Visual TL from
	// center is therefore -Tangent/+Bitangent; center = hit +T -B (half-extents).
	// That matches ComputePlacementFromDrag's +U/-V quadrant (natural screen down-right drag).
	// Centered keeps the hit as center so a center-scale drag starts with no jump.
	FVector Center = RotatedFrame.Position;
	if (!bCentered)
	{
		Center = RotatedFrame.Position
			+ RotatedFrame.Tangent * FMath::Abs(DecalSize.Y)
			- RotatedFrame.Bitangent * FMath::Abs(DecalSize.Z);
	}

	FInteractiveDecalPlacementResult Placement;
	Placement.ActorTransform = FTransform(
		InteractiveDecalPlacement::MakeDecalActorRotation(RotatedFrame.Normal, RotatedFrame.Tangent),
		Center);
	Placement.DecalSize = DecalSize;
	return Placement;
}

void FInteractiveDecalPlacementEdMode::UpdateHoverPreview(FEditorViewportClient* ViewportClient)
{
	if (!ActiveMaterial.IsValid())
	{
		return;
	}

	// Hidden while the cursor is over the HUD panel or the viewport is tracking a camera gesture.
	if (IsPointerOverHud() || bCameraTracking)
	{
		SetPreviewVisible(false);
		return;
	}

	ProWorkflowTools::FViewportSurfaceHit Hit;
	if (!ProWorkflowTools::TraceSurfaceUnderCursor(ViewportClient, Hit))
	{
		SetPreviewVisible(false);
		return;
	}

	const FVector ViewDirection = ViewportClient->GetViewRotation().Vector();
	const FInteractiveDecalTangentFrame HoverFrame = InteractiveDecalPlacement::MakeTangentFrameFromHit(Hit.Location, Hit.Normal, ViewDirection);
	HoverAnchorPoint = HoverFrame.Position;
	const FInteractiveDecalPlacementResult Flat = MakeHoverPlacement(HoverFrame, IsCenteredFor(ViewportClient));
	ApplyPreviewTransform(FitToSurfaceIfEnabled(ViewportClient, Flat, HoverFrame.Position));
}

FInteractiveDecalPlacementResult FInteractiveDecalPlacementEdMode::FitToSurfaceIfEnabled(
	FEditorViewportClient* ViewportClient,
	const FInteractiveDecalPlacementResult& Flat,
	const FVector& PinPoint)
{
	if (!IsFitSurfaceEnabled() || !ViewportClient || !ViewportClient->Viewport)
	{
		FitSurfaceSamples.Reset();
		return Flat;
	}

	// One view for all nine samples; each is traced at its own pixel so the surface test is the
	// same one the cursor uses (hit proxy picks the primitive, render triangles give the point).
	FSceneViewFamilyContext ViewFamily(FSceneViewFamily::ConstructionValues(
		ViewportClient->Viewport, ViewportClient->GetScene(), ViewportClient->EngineShowFlags)
		.SetRealtimeUpdate(ViewportClient->IsRealtime()));
	const FSceneView* View = ViewportClient->CalcSceneView(&ViewFamily);
	if (!View)
	{
		FitSurfaceSamples.Reset();
		return Flat;
	}

	TArray<FVector, TInlineAllocator<9>> Points;
	InteractiveDecalPlacement::GetPlacementSamplePoints(Flat, Points);

	TArray<InteractiveDecalPlacement::FSurfaceFitSample, TInlineAllocator<9>> Samples;
	for (const FVector& Point : Points)
	{
		FVector2D Pixel;
		ProWorkflowTools::FViewportSurfaceHit Hit;
		if (View->WorldToPixel(Point, Pixel)
			&& ProWorkflowTools::TraceSurfaceAtPixel(ViewportClient, *View, FIntPoint(FMath::RoundToInt(Pixel.X), FMath::RoundToInt(Pixel.Y)), Hit))
		{
			Samples.Add({ Hit.Location, Hit.Normal });
		}
	}

	return InteractiveDecalPlacement::FitPlacementToSurface(
		Flat,
		Samples,
		PinPoint,
		View->ViewMatrices.GetViewOrigin(),
		View->GetViewDirection(),
		View->IsPerspectiveProjection(),
		&FitSurfaceSamples);
}

void FInteractiveDecalPlacementEdMode::UpdateDragPreview(FEditorViewportClient* ViewportClient)
{
	if (!ActiveMaterial.IsValid() || !bHasAnchor || !ViewportClient || !ViewportClient->Viewport)
	{
		return;
	}

	// Until the mouse travels past a small threshold this is still a click; keep the
	// hover-size preview anchored at the click point so releasing just stamps it.
	if (!bDragConfirmed)
	{
		const FIntPoint MousePos(ViewportClient->Viewport->GetMouseX(), ViewportClient->Viewport->GetMouseY());
		const FIntPoint ScreenDelta = MousePos - DragStartScreenPos;
		const int32 ClickThresholdPixels = 5;
		if (FMath::Abs(ScreenDelta.X) <= ClickThresholdPixels && FMath::Abs(ScreenDelta.Y) <= ClickThresholdPixels)
		{
			// Keep the hover pose through the click threshold so a drag starts without a jump.
			ApplyPreviewTransform(FitToSurfaceIfEnabled(ViewportClient, MakeHoverPlacement(AnchorFrame, IsCenteredFor(ViewportClient)), AnchorFrame.Position));
			return;
		}
		bDragConfirmed = true;
	}

	FVector DragPlanePoint;
	if (!ProjectCursorOntoAnchorPlane(ViewportClient, DragPlanePoint))
	{
		return;
	}

	// Space-held panning (Adobe-style): freeze the decal's size and slide the whole
	// thing with the mouse; releasing Space resumes sizing from the new spot.
	// Works with center-scale too; Space temporarily pauses scaling for move.
	const bool bSpaceDown = IsSpaceHeld(ViewportClient);
	if (bSpaceDown)
	{
		if (!bSpacePanning)
		{
			bSpacePanning = true;
			SpacePanFrozenDragVector = LastDragPlanePoint - AnchorFrame.Position;
		}
		AnchorFrame.Position = DragPlanePoint - SpacePanFrozenDragVector;
	}
	else
	{
		bSpacePanning = false;
	}
	LastDragPlanePoint = DragPlanePoint;

	// Ctrl-held rotate around the anchor corner: the frame rotates with the mouse's angular
	// motion, which keeps the drag vector's direction fixed in the rotated frame — so the
	// shape's ratio at Ctrl-press is preserved and the size scales uniformly with distance.
	// Releasing Ctrl keeps the rotation and resumes free corner sizing.
	const FVector DragVector = DragPlanePoint - AnchorFrame.Position;
	const float MouseAngleRad = FMath::Atan2(
		FVector::DotProduct(DragVector, AnchorFrame.Bitangent),
		FVector::DotProduct(DragVector, AnchorFrame.Tangent));
	const bool bCtrlDown = ViewportClient->IsCtrlPressed() && DragVector.SizeSquared() > 1.0f;
	if (bCtrlDown)
	{
		if (!bCtrlRotating)
		{
			bCtrlRotating = true;
			CtrlStartMouseAngleRad = MouseAngleRad;
			RotationAtCtrlStartRad = DragRotationRad;
		}
		DragRotationRad = RotationAtCtrlStartRad + FMath::FindDeltaAngleRadians(CtrlStartMouseAngleRad, MouseAngleRad);
	}
	else
	{
		bCtrlRotating = false;
	}

	const FInteractiveDecalTangentFrame EffectiveFrame = InteractiveDecalPlacement::RotateFrameInPlane(AnchorFrame, DragRotationRad);

	// Tangent is the decal's vertical axis, so the Shift aspect lock needs height / width.
	const float TangentOverBitangentRatio = 1.0f / GetActiveMaterialAspectRatio();

	// While Space is held, keep the same scale mode (including center-scale) but with a
	// frozen drag vector so size stays put and only the position moves.
	const bool bCenterScale = IsCenteredFor(ViewportClient);

	bAspectLocked = ViewportClient->IsShiftPressed() && !bCtrlRotating && !bSpaceDown;

	const UProWorkflowToolsSettings* Settings = GetDefault<UProWorkflowToolsSettings>();
	const FInteractiveDecalPlacementResult Placement = InteractiveDecalPlacement::ComputePlacementFromDrag(
		EffectiveFrame,
		DragPlanePoint,
		bCenterScale,
		bAspectLocked,
		TangentOverBitangentRatio,
		GetActiveProjectionDepth(),
		Settings->MinDragExtent);

	// The point under the mouse: the center when center-scaling, else the corner opposite the anchor.
	const FVector PinPoint = bCenterScale
		? AnchorFrame.Position
		: Placement.ActorTransform.GetLocation() * 2.0 - AnchorFrame.Position;
	ApplyPreviewTransform(FitToSurfaceIfEnabled(ViewportClient, Placement, PinPoint));
}

bool FInteractiveDecalPlacementEdMode::IsSpaceHeld(const FEditorViewportClient* ViewportClient) const
{
	return ProWorkflowTools::IsSpaceKeyDown(ViewportClient->Viewport);
}

FVector FInteractiveDecalPlacementEdMode::ApplyFlipToDecalSize(const FVector& DecalSize) const
{
	FVector FlippedSize = DecalSize;
	// Deferred decal UV: U ~ local Z (horizontal), V ~ local Y (vertical).
	FlippedSize.Z = bFlipHorizontal ? -FMath::Abs(DecalSize.Z) : FMath::Abs(DecalSize.Z);
	FlippedSize.Y = bFlipVertical ? -FMath::Abs(DecalSize.Y) : FMath::Abs(DecalSize.Y);
	return FlippedSize;
}

void FInteractiveDecalPlacementEdMode::ApplyPreviewDecalProperties()
{
	if (IsEditingPlacedDecal())
	{
		WriteEditTarget(LOCTEXT("EditDecalPropertiesTransaction", "Edit Decal"), [this](ADecalActor&, UDecalComponent& Decal)
		{
			FLinearColor DecalColor = Decal.DecalColor;
			DecalColor.A = PreviewDecalColorAlpha;
			Decal.SetDecalColor(DecalColor);
			Decal.SetSortOrder(PreviewSortOrder);
		});
		LastAppliedDecalColorAlpha = PreviewDecalColorAlpha;
		LastAppliedSortOrder = PreviewSortOrder;
		return;
	}

	if (!PreviewActor.IsValid())
	{
		return;
	}

	if (UDecalComponent* DecalComponent = PreviewActor->GetDecal())
	{
		FLinearColor DecalColor = DecalComponent->DecalColor;
		DecalColor.A = PreviewDecalColorAlpha;
		DecalComponent->SetDecalColor(DecalColor);
		DecalComponent->SetSortOrder(PreviewSortOrder);
		DecalComponent->MarkRenderStateDirty();
	}

	LastAppliedDecalColorAlpha = PreviewDecalColorAlpha;
	LastAppliedSortOrder = PreviewSortOrder;
}

void FInteractiveDecalPlacementEdMode::ApplyPreviewTransform(const FInteractiveDecalPlacementResult& Placement)
{
	// Footprint and flips live in the actor scale; DecalSize stays at the engine default.
	const FVector FlippedSize = ApplyFlipToDecalSize(Placement.DecalSize);
	FTransform ActorTransform = Placement.ActorTransform;
	ActorTransform.SetScale3D(InteractiveDecalPlacement::MakeDecalScaleForHalfExtents(FlippedSize));

	if (IsEditingPlacedDecal())
	{
		// A decal that carried its footprint in DecalSize is normalized to the scale convention on first write.
		WriteEditTarget(LOCTEXT("EditDecalTransaction", "Edit Decal"), [&](ADecalActor& Target, UDecalComponent& Decal)
		{
			if (ActiveMaterial.IsValid() && Decal.GetDecalMaterial() != ActiveMaterial.Get())
			{
				Decal.SetDecalMaterial(ActiveMaterial.Get());
			}
			// SetDecalMaterial can reattach the component; the transform goes on after it.
			Target.SetActorTransform(ActorTransform);
			Decal.DecalSize = InteractiveDecalPlacement::DefaultDecalSize;
			FLinearColor DecalColor = Decal.DecalColor;
			DecalColor.A = PreviewDecalColorAlpha;
			Decal.SetDecalColor(DecalColor);
			Decal.SetSortOrder(PreviewSortOrder);
			Decal.UpdateComponentToWorld();
		});
		return;
	}

	EnsurePreviewActor();
	if (!PreviewActor.IsValid())
	{
		return;
	}

	if (bHasLastAppliedPreview
		&& LastAppliedActorTransform.Equals(ActorTransform)
		&& LastAppliedDecalSize.Equals(FlippedSize)
		&& FMath::IsNearlyEqual(LastAppliedDecalColorAlpha, PreviewDecalColorAlpha)
		&& LastAppliedSortOrder == PreviewSortOrder
		&& LastAppliedMaterial.Get() == ActiveMaterial.Get()
		&& LastAppliedFlipHorizontal == bFlipHorizontal
		&& LastAppliedFlipVertical == bFlipVertical)
	{
		SetPreviewVisible(true);
		return;
	}

	SetPreviewVisible(true);
	PreviewActor->SetActorTransform(ActorTransform);
	if (UDecalComponent* DecalComponent = PreviewActor->GetDecal())
	{
		DecalComponent->DecalSize = InteractiveDecalPlacement::DefaultDecalSize;
		DecalComponent->MarkRenderStateDirty();
	}

	ApplyPreviewDecalProperties();

	LastAppliedActorTransform = ActorTransform;
	LastAppliedDecalSize = FlippedSize;
	LastAppliedMaterial = ActiveMaterial;
	LastAppliedFlipHorizontal = bFlipHorizontal;
	LastAppliedFlipVertical = bFlipVertical;
	bHasLastAppliedPreview = true;
}

bool FInteractiveDecalPlacementEdMode::TryInheritFromSelectedDecal()
{
	// Only an unambiguous source: exactly one selected actor, and it carries a deferred decal.
	if (!GEditor || GEditor->GetSelectedActorCount() != 1)
	{
		return false;
	}

	const AActor* Actor = GEditor->GetSelectedActors()->GetTop<AActor>();
	if (!Actor || Actor->bIsEditorPreviewActor)
	{
		return false;
	}

	const ADecalActor* DecalActor = Cast<ADecalActor>(Actor);
	return InheritFromDecal(DecalActor ? DecalActor->GetDecal() : Actor->FindComponentByClass<UDecalComponent>());
}

bool FInteractiveDecalPlacementEdMode::InheritFromDecal(const UDecalComponent* SourceDecal)
{
	if (!SourceDecal || !InteractiveDecalPlacement::IsDecalMaterial(SourceDecal->GetDecalMaterial()))
	{
		return false;
	}

	UMaterialInterface* Material = SourceDecal->GetDecalMaterial();
	ActiveMaterial = Material;
	CachedAspectRatio = InteractiveDecalPlacement::GetMaterialAspectRatio(Material);

	// World footprint, whichever way the source expresses it (DecalSize, scale, or both).
	const FVector Size = InteractiveDecalPlacement::GetDecalSignedHalfExtents(*SourceDecal);
	bFlipHorizontal = Size.Z < 0.0f;
	bFlipVertical = Size.Y < 0.0f;
	LastPlacedDecalSize = Size.GetAbs();
	bHasLastPlacedSize = true;

	PreviewDecalColorAlpha = FMath::Clamp(SourceDecal->DecalColor.A, 0.0f, 1.0f);
	PreviewSortOrder = SourceDecal->SortOrder;
	PreviewRotationRad = 0.0f;
	bInheritedFromSelection = true;
	return true;
}

ADecalActor* FInteractiveDecalPlacementEdMode::FindSceneDecalUnderCursor(FEditorViewportClient* ViewportClient) const
{
	// A decal's editor sprite is the decal: the cursor on it picks that actor outright.
	if (FViewport* Viewport = ViewportClient ? ViewportClient->Viewport : nullptr)
	{
		const HActor* ActorProxy = HitProxyCast<HActor>(Viewport->GetHitProxy(Viewport->GetMouseX(), Viewport->GetMouseY()));
		ADecalActor* SpriteOwner = ActorProxy ? Cast<ADecalActor>(ActorProxy->Actor) : nullptr;
		if (SpriteOwner && SpriteOwner != PreviewActor.Get() && Cast<UBillboardComponent>(ActorProxy->PrimComponent.Get()))
		{
			return SpriteOwner;
		}
	}

	// Otherwise the surface the cursor is on is the nearest geometry, so a decal only counts if it
	// projects onto that exact point: nothing behind a wall, and a box that merely crosses the view
	// ray is not enough.
	ProWorkflowTools::FViewportSurfaceHit Hit;
	if (!ProWorkflowTools::TraceSurfaceUnderCursor(ViewportClient, Hit))
	{
		return nullptr;
	}

	// The surface sits on the box's X=0 plane; a little slack covers trace/decal placement offsets.
	// Compared in world cm (unscaled local frame vs. scaled half-extents) so scale does not skew it.
	constexpr double DepthSlackCm = 1.0;

	ADecalActor* Picked = nullptr;
	int32 PickedSortOrder = TNumericLimits<int32>::Min();
	double PickedVolume = TNumericLimits<double>::Max();

	for (const TWeakObjectPtr<ADecalActor>& WeakDecal : CachedSceneDecals)
	{
		ADecalActor* DecalActor = WeakDecal.Get();
		const UDecalComponent* DecalComponent = DecalActor ? DecalActor->GetDecal() : nullptr;
		if (!DecalComponent || DecalActor == PreviewActor.Get() || DecalActor->IsTemporarilyHiddenInEditor())
		{
			continue;
		}

		const FVector Local = DecalComponent->GetComponentTransform().InverseTransformPositionNoScale(Hit.Location).GetAbs();
		const FVector HalfExtent = InteractiveDecalPlacement::GetDecalSignedHalfExtents(*DecalComponent).GetAbs();
		if (Local.X > HalfExtent.X + DepthSlackCm || Local.Y > HalfExtent.Y || Local.Z > HalfExtent.Z)
		{
			continue;
		}

		// Higher SortOrder renders on top, so it is the one the user sees; among equals the smallest box.
		const double Volume = HalfExtent.X * HalfExtent.Y * HalfExtent.Z;
		if (DecalComponent->SortOrder > PickedSortOrder
			|| (DecalComponent->SortOrder == PickedSortOrder && Volume < PickedVolume))
		{
			Picked = DecalActor;
			PickedSortOrder = DecalComponent->SortOrder;
			PickedVolume = Volume;
		}
	}

	return Picked;
}

ADecalActor* FInteractiveDecalPlacementEdMode::GetPosedActor() const
{
	if (IsIdle())
	{
		return nullptr;
	}
	return IsEditingPlacedDecal() ? EditTarget.Get() : PreviewActor.Get();
}

ADecalActor* FInteractiveDecalPlacementEdMode::GetHandleDecal(const FEditorViewportClient* ViewportClient) const
{
	if (IsEditingPlacedDecal())
	{
		return EditTarget.Get();
	}

	// Game View shows only what is being placed or edited, as the engine hides its own selection visuals there.
	if (State != EInteractiveDecalPlacementState::Preview || !GEditor || GEditor->GetSelectedActorCount() != 1
		|| (ViewportClient && ViewportClient->IsInGameView()))
	{
		return nullptr;
	}

	// Only a decal Edit can take: one with a deferred decal material (what InheritFromDecal accepts).
	ADecalActor* Selected = Cast<ADecalActor>(GEditor->GetSelectedActors()->GetTop<AActor>());
	const UDecalComponent* Decal = (Selected && Selected != PreviewActor.Get()) ? Selected->GetDecal() : nullptr;
	return (Decal && InteractiveDecalPlacement::IsDecalMaterial(Decal->GetDecalMaterial())) ? Selected : nullptr;
}

FInteractiveDecalEditHandle FInteractiveDecalPlacementEdMode::FindHandleAtPixel(FEditorViewportClient* ViewportClient, const FIntPoint& Pixel) const
{
	const ADecalActor* Decal = GetHandleDecal(ViewportClient);
	const UDecalComponent* DecalComponent = Decal ? Decal->GetDecal() : nullptr;
	if (!DecalComponent || !ViewportClient || !ViewportClient->Viewport || Decal->IsTemporarilyHiddenInEditor())
	{
		return FInteractiveDecalEditHandle();
	}

	FSceneViewFamilyContext ViewFamily(FSceneViewFamily::ConstructionValues(
		ViewportClient->Viewport, ViewportClient->GetScene(), ViewportClient->EngineShowFlags)
		.SetRealtimeUpdate(ViewportClient->IsRealtime()));
	const FSceneView* View = ViewportClient->CalcSceneView(&ViewFamily);
	if (!View)
	{
		return FInteractiveDecalEditHandle();
	}

	// Corners in frame order (SignY, SignZ): (-,-) (+,-) (+,+) (-,+); the outline edges join neighbours.
	FVector Corners[4];
	if (!InteractiveDecalPlacement::BoundsTicks::GetOutsetInPlaneCorners(Decal, View, Corners[0], Corners[1], Corners[2], Corners[3]))
	{
		return FInteractiveDecalEditHandle();
	}
	static const FInteractiveDecalEditHandle CornerHandles[4] = { { -1, -1 }, { +1, -1 }, { +1, +1 }, { -1, +1 } };
	static const FInteractiveDecalEditHandle EdgeHandles[4] = { { 0, -1 }, { +1, 0 }, { 0, +1 }, { -1, 0 } };

	const FVector2D Cursor(Pixel.X, Pixel.Y);
	FVector2D CornerPx[4];
	bool bAllVisible = true;
	for (int32 Index = 0; Index < 4; ++Index)
	{
		bAllVisible &= View->WorldToPixel(Corners[Index], CornerPx[Index]);
	}
	if (!bAllVisible)
	{
		return FInteractiveDecalEditHandle();
	}

	int32 Best = INDEX_NONE;
	float BestDistance = CornerPickPx;
	for (int32 Index = 0; Index < 4; ++Index)
	{
		const float Distance = FVector2D::Distance(Cursor, CornerPx[Index]);
		if (Distance <= BestDistance)
		{
			Best = Index;
			BestDistance = Distance;
		}
	}
	if (Best != INDEX_NONE)
	{
		return CornerHandles[Best];
	}

	BestDistance = EdgePickPx;
	for (int32 Index = 0; Index < 4; ++Index)
	{
		const float Distance = PixelDistanceToSegment(Cursor, CornerPx[Index], CornerPx[(Index + 1) % 4]);
		if (Distance <= BestDistance)
		{
			Best = Index;
			BestDistance = Distance;
		}
	}
	if (Best != INDEX_NONE)
	{
		return EdgeHandles[Best];
	}

	// Space in Edit turns the face of the target into the move grab: inside the projected rectangle
	// (convex, so the cursor sits on one side of every edge) the press slides the decal without resizing.
	if (State == EInteractiveDecalPlacementState::Edit && IsSpaceHeld(ViewportClient))
	{
		bool bInside = true;
		int32 Side = 0;
		for (int32 Index = 0; Index < 4 && bInside; ++Index)
		{
			const FVector2D Edge = CornerPx[(Index + 1) % 4] - CornerPx[Index];
			const FVector2D ToCursor = Cursor - CornerPx[Index];
			const int32 ThisSide = static_cast<int32>(FMath::Sign(FVector2D::CrossProduct(Edge, ToCursor)));
			bInside = ThisSide != 0 && (Side == 0 || ThisSide == Side);
			Side = ThisSide;
		}
		if (bInside)
		{
			return FInteractiveDecalEditHandle::Body();
		}
	}
	return FInteractiveDecalEditHandle();
}

void FInteractiveDecalPlacementEdMode::UpdateHoveredHandle(FEditorViewportClient* ViewportClient)
{
	FInteractiveDecalEditHandle NewHovered;
	if (ViewportClient && ViewportClient->Viewport && !IsPointerOverHud() && !bCameraTracking)
	{
		NewHovered = FindHandleAtPixel(ViewportClient, FIntPoint(ViewportClient->Viewport->GetMouseX(), ViewportClient->Viewport->GetMouseY()));
	}

	if (NewHovered != HoveredHandle)
	{
		HoveredHandle = NewHovered;
		RequestViewportRefresh(ViewportClient);
	}
}

bool FInteractiveDecalPlacementEdMode::BeginStampDrag(FEditorViewportClient* ViewportClient, FViewport* Viewport)
{
	ProWorkflowTools::FViewportSurfaceHit Hit;
	if (!ProWorkflowTools::TraceSurfaceUnderCursor(ViewportClient, Hit))
	{
		return false;
	}

	// Begun without a ghost in hand (Edit or Idle), a press that never travels is a click into
	// Preview, not a stamp.
	const bool bNoGhostInHand = State != EInteractiveDecalPlacementState::Preview;
	if (State == EInteractiveDecalPlacementState::Edit)
	{
		LeaveEditMode(ViewportClient);
	}
	bStampDragFromEdit = bNoGhostInHand;

	const FVector ViewDirection = ViewportClient->GetViewRotation().Vector();
	AnchorFrame = InteractiveDecalPlacement::MakeTangentFrameFromHit(Hit.Location, Hit.Normal, ViewDirection);
	bHasAnchor = true;
	bDragConfirmed = false;
	bSpacePanning = false;
	bCtrlRotating = false;
	DragRotationRad = PreviewRotationRad;
	LastDragPlanePoint = AnchorFrame.Position;
	DragStartScreenPos = FIntPoint(Viewport->GetMouseX(), Viewport->GetMouseY());
	HoveredHandle = FInteractiveDecalEditHandle();
	SetState(EInteractiveDecalPlacementState::Dragging, ViewportClient);
	return true;
}

void FInteractiveDecalPlacementEdMode::ReleaseStampDrag(FEditorViewportClient* ViewportClient)
{
	if (State != EInteractiveDecalPlacementState::Dragging)
	{
		return;
	}

	// A press that began without a ghost in hand and never travelled is a click into Preview, not a stamp.
	if (bStampDragFromEdit && !bDragConfirmed)
	{
		AbandonStampDrag(ViewportClient);
		return;
	}
	CommitPlacement(ViewportClient);
}

void FInteractiveDecalPlacementEdMode::AbandonStampDrag(FEditorViewportClient* ViewportClient)
{
	EndStampDrag(ViewportClient);
	UpdateHoverPreview(ViewportClient);
}

void FInteractiveDecalPlacementEdMode::EndStampDrag(FEditorViewportClient* ViewportClient)
{
	bHasAnchor = false;
	bDragConfirmed = false;
	bSpacePanning = false;
	bCtrlRotating = false;
	bAspectLocked = false;
	bStampDragFromEdit = false;
	FitSurfaceSamples.Reset();
	SetState(EInteractiveDecalPlacementState::Preview, ViewportClient);
}

bool FInteractiveDecalPlacementEdMode::PickDecalUnderCursor(FEditorViewportClient* ViewportClient, FViewport* Viewport)
{
	ADecalActor* Source = FindSceneDecalUnderCursor(ViewportClient);
	if (!Source)
	{
		return false;
	}

	// The target is put down before the pick so its settings do not land on top of the picked ones.
	if (State == EInteractiveDecalPlacementState::Edit)
	{
		LeaveEditMode(ViewportClient);
	}
	if (!InheritFromDecal(Source->GetDecal()))
	{
		return false;
	}

	BeginPreview(ViewportClient);
	PingPreviewOutline();
	PickFlashActor = Source;
	PickFlashStartSeconds = FPlatformTime::Seconds();
	PickFlashPixel = FIntPoint(Viewport->GetMouseX(), Viewport->GetMouseY());
	FeedbackLabel.Show(
		FText::Format(LOCTEXT("DecalLabelPicked", "Picked {0}"), FText::FromString(GetActiveDecalLabel())),
		ProWorkflowTools::OverlayStyle::Highlight);
	return true;
}

bool FInteractiveDecalPlacementEdMode::EnterEditMode(ADecalActor* Target, FEditorViewportClient* ViewportClient)
{
	const UDecalComponent* TargetDecal = Target ? Target->GetDecal() : nullptr;
	if (!GEditor || !TargetDecal || !InteractiveDecalPlacement::IsDecalMaterial(TargetDecal->GetDecalMaterial()))
	{
		return false;
	}

	if (State == EInteractiveDecalPlacementState::EditDragging)
	{
		EndEditHandleDrag(/*bKeep=*/true);
	}

	// The next decal's settings are saved once, when editing begins; a retarget from Edit keeps them.
	if (!IsEditingPlacedDecal())
	{
		SessionBeforeEdit = SaveSessionSettings();
	}
	InheritFromDecal(TargetDecal);

	EditTarget = Target;
	SetState(EInteractiveDecalPlacementState::Edit, ViewportClient);
	SetPreviewVisible(false);
	FitSurfaceSamples.Reset();
	HoveredHandle = FInteractiveDecalEditHandle();
	// The ghost is re-posed from scratch when Edit ends.
	bHasLastAppliedPreview = false;

	// Selection follows the target; the event this raises is ours, not a user retarget.
	if (GEditor->GetSelectedActorCount() != 1 || !Target->IsSelected())
	{
		bSyncingSelection = true;
		GEditor->SelectNone(false, true, false);
		GEditor->SelectActor(Target, true, true, true);
		bSyncingSelection = false;
	}

	PingPreviewOutline();
	FeedbackLabel.Show(
		FText::Format(LOCTEXT("DecalLabelEditing", "Editing {0}"), FText::FromString(Target->GetActorLabel())),
		ProWorkflowTools::OverlayStyle::Highlight);
	RequestViewportRefresh(ViewportClient);
	return true;
}

void FInteractiveDecalPlacementEdMode::LeaveEditMode(FEditorViewportClient* ViewportClient)
{
	if (State == EInteractiveDecalPlacementState::EditDragging)
	{
		EndEditHandleDrag(/*bKeep=*/true);
	}

	EnterIdle(ViewportClient);
}

FInteractiveDecalPlacementEdMode::FSessionSettings FInteractiveDecalPlacementEdMode::SaveSessionSettings() const
{
	FSessionSettings Saved;
	Saved.Material = ActiveMaterial;
	Saved.AspectRatio = CachedAspectRatio;
	Saved.SourceMode = SourceMode;
	Saved.CollectionIndex = ActiveCollectionIndex;
	Saved.DecalIndex = ActiveDecalIndex;
	Saved.CollectionDecals = ActiveCollectionDecals;
	Saved.Size = LastPlacedDecalSize;
	Saved.bHasSize = bHasLastPlacedSize;
	Saved.bFlipHorizontal = bFlipHorizontal;
	Saved.bFlipVertical = bFlipVertical;
	Saved.ColorAlpha = PreviewDecalColorAlpha;
	Saved.SortOrder = PreviewSortOrder;
	Saved.RotationRad = PreviewRotationRad;
	Saved.bInheritedFromSelection = bInheritedFromSelection;
	return Saved;
}

void FInteractiveDecalPlacementEdMode::RestoreSessionSettings(const FSessionSettings& Saved)
{
	ActiveMaterial = Saved.Material;
	CachedAspectRatio = Saved.AspectRatio;
	SourceMode = Saved.SourceMode;
	ActiveCollectionIndex = Saved.CollectionIndex;
	ActiveDecalIndex = Saved.DecalIndex;
	ActiveCollectionDecals = Saved.CollectionDecals;
	LastPlacedDecalSize = Saved.Size;
	bHasLastPlacedSize = Saved.bHasSize;
	bFlipHorizontal = Saved.bFlipHorizontal;
	bFlipVertical = Saved.bFlipVertical;
	PreviewDecalColorAlpha = Saved.ColorAlpha;
	PreviewSortOrder = Saved.SortOrder;
	PreviewRotationRad = Saved.RotationRad;
	bInheritedFromSelection = Saved.bInheritedFromSelection;
	// Browsing while editing moved the remembered browse position with it; put that back too.
	PersistSessionBrowseSelection();
}

void FInteractiveDecalPlacementEdMode::EnterIdle(FEditorViewportClient* ViewportClient)
{
	if (State == EInteractiveDecalPlacementState::Inactive || IsIdle())
	{
		return;
	}

	// A drag in progress ends through its own end function, leaving the scene as it was: a stamp drag
	// is dropped, a handle drag springs back.
	if (State == EInteractiveDecalPlacementState::Dragging)
	{
		EndStampDrag(ViewportClient);
	}
	else if (State == EInteractiveDecalPlacementState::EditDragging)
	{
		EndEditHandleDrag(/*bKeep=*/false);
	}

	// The target is put down with what was done to it; the next decal comes back as it was before editing.
	if (State == EInteractiveDecalPlacementState::Edit)
	{
		if (SessionBeforeEdit.IsSet())
		{
			RestoreSessionSettings(SessionBeforeEdit.GetValue());
			SessionBeforeEdit.Reset();
		}
		EditTarget.Reset();
		bHasLastAppliedPreview = false;
	}
	HoveredHandle = FInteractiveDecalEditHandle();
	SetState(EInteractiveDecalPlacementState::Idle, ViewportClient);
	SetPreviewVisible(false);
	RequestViewportRefresh(ViewportClient ? ViewportClient : (Owner ? Owner->GetHoveredViewportClient() : nullptr));
}

void FInteractiveDecalPlacementEdMode::BeginPreview(FEditorViewportClient* ViewportClient)
{
	if (State == EInteractiveDecalPlacementState::Inactive || IsEditingPlacedDecal() || IsDraggingState())
	{
		return;
	}

	SetState(EInteractiveDecalPlacementState::Preview, ViewportClient);
	bHasAnchor = false;
	EnsurePreviewActor();

	if (!ViewportClient && Owner)
	{
		ViewportClient = Owner->GetHoveredViewportClient();
	}
	if (ViewportClient)
	{
		UpdateHoverPreview(ViewportClient);
		RequestViewportRefresh(ViewportClient);
	}
}

void FInteractiveDecalPlacementEdMode::WriteEditTarget(const FText& Description, TFunctionRef<void(ADecalActor&, UDecalComponent&)> Write)
{
	ADecalActor* Target = EditTarget.Get();
	UDecalComponent* Decal = Target ? Target->GetDecal() : nullptr;
	if (!Decal)
	{
		return;
	}

	TUniquePtr<FScopedTransaction> Transaction;
	if (EditDragTransactionIndex == INDEX_NONE)
	{
		Transaction = MakeUnique<FScopedTransaction>(Description);
	}
	Target->Modify();
	Decal->Modify();
	Write(*Target, *Decal);
	Decal->MarkRenderStateDirty();
}

void FInteractiveDecalPlacementEdMode::RewriteEditTargetPose()
{
	const ADecalActor* Target = EditTarget.Get();
	if (!Target)
	{
		return;
	}

	FInteractiveDecalPlacementResult Placement;
	Placement.ActorTransform = Target->GetActorTransform();
	Placement.DecalSize = GetCurrentInPlaneSize();
	ApplyPreviewTransform(Placement);
}

void FInteractiveDecalPlacementEdMode::RotateEditTarget(const float DeltaRad)
{
	const ADecalActor* Target = EditTarget.Get();
	if (!Target || FMath::IsNearlyZero(DeltaRad))
	{
		return;
	}

	PreviewRotationRad += DeltaRad;

	// A positive placement rotation turns Tangent toward Bitangent about the surface normal, which is the actor's -X.
	FInteractiveDecalPlacementResult Placement;
	Placement.ActorTransform = Target->GetActorTransform();
	const FVector ProjectionAxis = Placement.ActorTransform.GetUnitAxis(EAxis::X);
	Placement.ActorTransform.SetRotation(FQuat(ProjectionAxis, -DeltaRad) * Placement.ActorTransform.GetRotation());
	Placement.DecalSize = GetCurrentInPlaneSize();
	ApplyPreviewTransform(Placement);
}

void FInteractiveDecalPlacementEdMode::RefitEditTarget(FEditorViewportClient* ViewportClient)
{
	if (!ViewportClient && GEditor && GEditor->GetActiveViewport())
	{
		ViewportClient = static_cast<FEditorViewportClient*>(GEditor->GetActiveViewport()->GetClient());
	}

	const ADecalActor* Target = EditTarget.Get();
	if (!Target || !ViewportClient)
	{
		return;
	}

	FInteractiveDecalPlacementResult Flat;
	Flat.ActorTransform = Target->GetActorTransform();
	Flat.ActorTransform.SetScale3D(FVector::OneVector);
	Flat.DecalSize = GetCurrentInPlaneSize();
	ApplyPreviewTransform(FitToSurfaceIfEnabled(ViewportClient, Flat, Flat.ActorTransform.GetLocation()));
	PingPreviewOutline();
}

void FInteractiveDecalPlacementEdMode::BeginEditHandleDrag(const FInteractiveDecalEditHandle& Handle, FEditorViewportClient* ViewportClient)
{
	ADecalActor* Target = EditTarget.Get();
	UDecalComponent* Decal = Target ? Target->GetDecal() : nullptr;
	if (!Decal || !Handle.IsValid() || !GEditor || !ViewportClient || !ViewportClient->Viewport)
	{
		return;
	}

	// The decal's own frame as the placement math sees it: Tangent = +Y, Bitangent = -Z, Normal = -X,
	// positioned at the center so the cursor projects onto the decal's plane.
	const FTransform CompXform = Decal->GetComponentTransform();
	AnchorFrame.Position = CompXform.GetLocation();
	AnchorFrame.Normal = -CompXform.GetUnitAxis(EAxis::X);
	AnchorFrame.Tangent = CompXform.GetUnitAxis(EAxis::Y);
	AnchorFrame.Bitangent = -CompXform.GetUnitAxis(EAxis::Z);
	bHasAnchor = true;

	const FVector Half = InteractiveDecalPlacement::GetDecalSignedHalfExtents(*Decal).GetAbs();
	EditDragHalfExtents = FVector2D(Half.Y, Half.Z);
	EditDragHandle = Handle;
	EditDragPivot = AnchorFrame.Position;
	LastDragPlanePoint = AnchorFrame.Position;
	EditDragLastPlanePoint = AnchorFrame.Position;
	bSpacePanning = false;
	bAspectLocked = false;
	// Ctrl-rotate turns the target relative to the frame captured here; the HUD angle keeps counting from
	// the target's rotation at press.
	DragRotationRad = 0.0f;
	bCtrlRotating = false;
	EditDragBaseRotationRad = PreviewRotationRad;
	HoveredHandle = Handle;

	EditDragTransactionIndex = GEditor->BeginTransaction(Handle.IsBody()
		? LOCTEXT("MoveDecalTransaction", "Move Decal")
		: LOCTEXT("ResizeDecalTransaction", "Resize Decal"));
	Target->Modify();
	Decal->Modify();
	SetState(EInteractiveDecalPlacementState::EditDragging, ViewportClient);
}

void FInteractiveDecalPlacementEdMode::UpdateEditHandleDrag(FEditorViewportClient* ViewportClient)
{
	if (State != EInteractiveDecalPlacementState::EditDragging || !bHasAnchor || !ViewportClient || !ViewportClient->Viewport)
	{
		return;
	}

	FVector PlanePoint;
	if (!ProjectCursorOntoAnchorPlane(ViewportClient, PlanePoint))
	{
		return;
	}

	// Space slides the whole decal: the center follows the cursor's plane motion and the drag offsets
	// below stay where they were, so the size holds. Releasing Space resumes sizing from the new spot.
	// A body grab is a slide for its whole life: Space only had to be down at the press.
	const bool bMoving = EditDragHandle.IsBody() || IsSpaceHeld(ViewportClient);
	if (bMoving)
	{
		if (bSpacePanning)
		{
			AnchorFrame.Position += PlanePoint - EditDragLastPlanePoint;
		}
		bSpacePanning = true;
	}
	else
	{
		bSpacePanning = false;
	}
	EditDragLastPlanePoint = PlanePoint;

	// Corner pivot anchors at the corner across from the handle (an edge handle takes the -1 corner on
	// its free axis); center pivot anchors at the center. Alt after the press swaps the pivot, as in a stamp drag.
	// A body grab has no free axis, so it is centered and keeps both half-extents as pressed.
	const bool bCenter = EditDragHandle.IsBody() || IsCenteredFor(ViewportClient);
	const int32 AnchorY = bCenter ? 0 : (EditDragHandle.SignY != 0 ? -EditDragHandle.SignY : -1);
	const int32 AnchorZ = bCenter ? 0 : (EditDragHandle.SignZ != 0 ? -EditDragHandle.SignZ : -1);
	const int32 HandleY = EditDragHandle.SignY != 0 ? EditDragHandle.SignY : 1;
	const int32 HandleZ = EditDragHandle.SignZ != 0 ? EditDragHandle.SignZ : 1;

	EditDragPivot = AnchorFrame.Position
		+ AnchorFrame.Tangent * (AnchorY * EditDragHalfExtents.X)
		- AnchorFrame.Bitangent * (AnchorZ * EditDragHalfExtents.Y);

	// Ctrl on a corner rotates the decal about the pivot with the mouse's angular motion, as in a stamp
	// drag: the drag vector's direction is fixed in the rotated frame, so the proportions at Ctrl-press
	// hold and the size scales with distance. Releasing Ctrl keeps the rotation and resumes free sizing.
	const FVector Offset = PlanePoint - EditDragPivot;
	const float MouseAngleRad = FMath::Atan2(
		FVector::DotProduct(Offset, AnchorFrame.Bitangent),
		FVector::DotProduct(Offset, AnchorFrame.Tangent));
	const bool bCtrlDown = EditDragHandle.IsCorner() && ViewportClient->IsCtrlPressed() && Offset.SizeSquared() > 1.0f;
	if (bCtrlDown)
	{
		if (!bCtrlRotating)
		{
			bCtrlRotating = true;
			CtrlStartMouseAngleRad = MouseAngleRad;
			RotationAtCtrlStartRad = DragRotationRad;
		}
		DragRotationRad = RotationAtCtrlStartRad + FMath::FindDeltaAngleRadians(CtrlStartMouseAngleRad, MouseAngleRad);
	}
	else
	{
		bCtrlRotating = false;
	}
	PreviewRotationRad = EditDragBaseRotationRad + DragRotationRad;

	FInteractiveDecalTangentFrame Frame = InteractiveDecalPlacement::RotateFrameInPlane(AnchorFrame, DragRotationRad);
	Frame.Position = EditDragPivot;

	// The cursor's offset from the anchor in the frame (U along Tangent = local +Y, V along Bitangent =
	// local -Z). An edge handle keeps its cross axis at the span it had when pressed.
	double U = FVector::DotProduct(Offset, Frame.Tangent);
	double V = FVector::DotProduct(Offset, Frame.Bitangent);
	if (EditDragHandle.SignY == 0)
	{
		U = (HandleY - AnchorY) * EditDragHalfExtents.X;
	}
	if (EditDragHandle.SignZ == 0)
	{
		V = -(HandleZ - AnchorZ) * EditDragHalfExtents.Y;
	}
	const FVector DragPoint = Frame.Position + Frame.Tangent * U + Frame.Bitangent * V;
	LastDragPlanePoint = DragPoint;

	// Shift on a corner keeps the decal's own proportions (height over width at press).
	bAspectLocked = EditDragHandle.IsCorner() && ViewportClient->IsShiftPressed() && !bCtrlRotating;

	const UProWorkflowToolsSettings* Settings = GetDefault<UProWorkflowToolsSettings>();
	const FInteractiveDecalPlacementResult Placement = InteractiveDecalPlacement::ComputePlacementFromDrag(
		Frame,
		DragPoint,
		bCenter,
		bAspectLocked,
		EditDragHalfExtents.X / FMath::Max(EditDragHalfExtents.Y, KINDA_SMALL_NUMBER),
		GetActiveProjectionDepth(),
		Settings->MinDragExtent);

	const FVector PinPoint = bCenter
		? Frame.Position
		: Placement.ActorTransform.GetLocation() * 2.0 - Frame.Position;
	ApplyPreviewTransform(FitToSurfaceIfEnabled(ViewportClient, Placement, PinPoint));
}

void FInteractiveDecalPlacementEdMode::EndEditHandleDrag(const bool bKeep)
{
	if (State != EInteractiveDecalPlacementState::EditDragging)
	{
		return;
	}

	if (GEditor && EditDragTransactionIndex != INDEX_NONE)
	{
		if (bKeep)
		{
			GEditor->EndTransaction();
		}
		else
		{
			GEditor->CancelTransaction(EditDragTransactionIndex);
		}
	}
	EditDragTransactionIndex = INDEX_NONE;
	bHasAnchor = false;
	bAspectLocked = false;
	bSpacePanning = false;
	bCtrlRotating = false;
	FitSurfaceSamples.Reset();
	SetState(EInteractiveDecalPlacementState::Edit);
}

void FInteractiveDecalPlacementEdMode::OnEditorSelectionChanged(UObject* /*NewSelection*/)
{
	if (bSyncingSelection || !GEditor || !(IsEditingPlacedDecal() || IsIdle()))
	{
		return;
	}

	// The target follows the selection: a single selected decal is the target (from Idle this is how
	// a click on a decal starts editing it), anything else puts the target down.
	ADecalActor* Selected = GEditor->GetSelectedActorCount() == 1
		? Cast<ADecalActor>(GEditor->GetSelectedActors()->GetTop<AActor>())
		: nullptr;
	if (Selected == EditTarget.Get())
	{
		return;
	}

	FEditorViewportClient* ViewportClient = Owner ? Owner->GetHoveredViewportClient() : nullptr;
	if (!Selected || !EnterEditMode(Selected, ViewportClient))
	{
		if (IsEditingPlacedDecal())
		{
			LeaveEditMode(ViewportClient);
		}
	}
}

void FInteractiveDecalPlacementEdMode::ClearSelectionInherit(const bool bRestoreBrowseMaterial)
{
	if (!bInheritedFromSelection)
	{
		return;
	}

	bInheritedFromSelection = false;
	if (!bRestoreBrowseMaterial)
	{
		return;
	}

	if (SourceMode == EDecalSourceMode::Collection
		&& ActiveCollectionDecals.IsValidIndex(ActiveDecalIndex))
	{
		ActiveMaterial = LoadDecalMaterial(ActiveCollectionDecals[ActiveDecalIndex]);
		CachedAspectRatio = InteractiveDecalPlacement::GetMaterialAspectRatio(ActiveMaterial.Get());
	}
	else if (SourceMode == EDecalSourceMode::ContentBrowser
		&& InteractiveDecalPlacement::SessionBrowse::MaterialPath.IsValid())
	{
		if (UMaterialInterface* Material = Cast<UMaterialInterface>(
			InteractiveDecalPlacement::SessionBrowse::MaterialPath.TryLoad()))
		{
			if (InteractiveDecalPlacement::IsDecalMaterial(Material))
			{
				ActiveMaterial = Material;
				CachedAspectRatio = InteractiveDecalPlacement::GetMaterialAspectRatio(Material);
			}
		}
	}

	if (PreviewActor.IsValid() && ActiveMaterial.IsValid())
	{
		if (UDecalComponent* DecalComponent = PreviewActor->GetDecal())
		{
			DecalComponent->SetDecalMaterial(ActiveMaterial.Get());
		}
	}
}

bool FInteractiveDecalPlacementEdMode::TrySetMaterialFromContentBrowser()
{
	FContentBrowserModule& ContentBrowserModule = FModuleManager::LoadModuleChecked<FContentBrowserModule>("ContentBrowser");
	TArray<FAssetData> SelectedAssets;
	ContentBrowserModule.Get().GetSelectedAssets(SelectedAssets);

	for (const FAssetData& AssetData : SelectedAssets)
	{
		if (!InteractiveDecalPlacement::IsDecalMaterialAsset(AssetData))
		{
			continue;
		}

		if (UMaterialInterface* Material = Cast<UMaterialInterface>(AssetData.GetAsset()))
		{
			ActiveMaterial = Material;
			CachedAspectRatio = InteractiveDecalPlacement::GetMaterialAspectRatio(Material);
			return true;
		}
	}

	return false;
}

bool FInteractiveDecalPlacementEdMode::ActivateBrowseCategoryAtIndex(const int32 CategoryIndex)
{
	const TArray<InteractiveDecalPlacement::FDecalBrowseCategory>& BrowseCategories = InteractiveDecalPlacement::GetBrowseCategories();
	if (!BrowseCategories.IsValidIndex(CategoryIndex))
	{
		return false;
	}

	const InteractiveDecalPlacement::FDecalBrowseCategory& Category = BrowseCategories[CategoryIndex];
	ActiveCollectionIndex = CategoryIndex;
	ActiveCollectionDecals = InteractiveDecalPlacement::GetDecalMaterialsInCollection(Category.CollectionName);
	if (ActiveCollectionDecals.IsEmpty())
	{
		ActiveMaterial.Reset();
		ActiveDecalIndex = 0;
		SetPreviewVisible(false);
		return true;
	}

	ActiveDecalIndex = 0;
	if (const FSoftObjectPath* RememberedPath =
		InteractiveDecalPlacement::SessionBrowse::MaterialPathByCategory.Find(Category.DisplayName))
	{
		const int32 FoundIndex = InteractiveDecalPlacement::SessionBrowse::FindDecalIndex(
			ActiveCollectionDecals, *RememberedPath);
		if (FoundIndex != INDEX_NONE)
		{
			ActiveDecalIndex = FoundIndex;
		}
	}

	ActiveMaterial = LoadDecalMaterial(ActiveCollectionDecals[ActiveDecalIndex]);
	CachedAspectRatio = InteractiveDecalPlacement::GetMaterialAspectRatio(ActiveMaterial.Get());
	return ActiveMaterial.IsValid();
}

bool FInteractiveDecalPlacementEdMode::TryActivateFirstCollectionWithDecals()
{
	const TArray<InteractiveDecalPlacement::FDecalBrowseCategory>& BrowseCategories = InteractiveDecalPlacement::GetBrowseCategories();
	if (BrowseCategories.IsEmpty())
	{
		return false;
	}

	int32 PreferredIndex = InteractiveDecalPlacement::SessionBrowse::FindCategoryIndex(
		BrowseCategories, InteractiveDecalPlacement::SessionBrowse::CategoryName);
	if (PreferredIndex == INDEX_NONE)
	{
		PreferredIndex = BrowseCategories.IsValidIndex(ActiveCollectionIndex) ? ActiveCollectionIndex : 0;
	}

	for (int32 Offset = 0; Offset < BrowseCategories.Num(); ++Offset)
	{
		const int32 TryIndex = (PreferredIndex + Offset) % BrowseCategories.Num();
		if (ActivateBrowseCategoryAtIndex(TryIndex) && ActiveMaterial.IsValid())
		{
			return true;
		}
	}

	return false;
}

bool FInteractiveDecalPlacementEdMode::TryRestoreSessionBrowseSelection()
{
	using namespace InteractiveDecalPlacement::SessionBrowse;

	const TArray<InteractiveDecalPlacement::FDecalBrowseCategory>& BrowseCategories =
		InteractiveDecalPlacement::GetBrowseCategories();
	if (BrowseCategories.IsEmpty())
	{
		return false;
	}

	// Prefer the remembered category; if its material list no longer contains the
	// remembered asset (or the category vanished), fall back to first usable category.
	if (!CategoryName.IsNone())
	{
		const int32 CategoryIndex = FindCategoryIndex(BrowseCategories, CategoryName);
		if (CategoryIndex != INDEX_NONE)
		{
			if (MaterialPath.IsValid())
			{
				MaterialPathByCategory.Add(BrowseCategories[CategoryIndex].DisplayName, MaterialPath);
			}

			if (ActivateBrowseCategoryAtIndex(CategoryIndex) && ActiveMaterial.IsValid())
			{
				SourceMode = EDecalSourceMode::Collection;
				return true;
			}
		}
	}

	if (TryActivateFirstCollectionWithDecals() && ActiveMaterial.IsValid())
	{
		SourceMode = EDecalSourceMode::Collection;
		return true;
	}

	return false;
}

void FInteractiveDecalPlacementEdMode::RememberActiveDecalIndex()
{
	PersistSessionBrowseSelection();
}

void FInteractiveDecalPlacementEdMode::PersistSessionBrowseSelection()
{
	using namespace InteractiveDecalPlacement::SessionBrowse;

	if (SourceMode == EDecalSourceMode::Collection && ActiveCollectionIndex != INDEX_NONE)
	{
		const TArray<InteractiveDecalPlacement::FDecalBrowseCategory>& BrowseCategories =
			InteractiveDecalPlacement::GetBrowseCategories();
		if (!BrowseCategories.IsValidIndex(ActiveCollectionIndex))
		{
			return;
		}

		Source = ESource::Collection;
		CategoryName = BrowseCategories[ActiveCollectionIndex].DisplayName;

		if (ActiveCollectionDecals.IsValidIndex(ActiveDecalIndex))
		{
			MaterialPath = ActiveCollectionDecals[ActiveDecalIndex];
			MaterialPathByCategory.Add(CategoryName, MaterialPath);
		}
		else if (ActiveMaterial.IsValid())
		{
			MaterialPath = FSoftObjectPath(ActiveMaterial.Get());
			MaterialPathByCategory.Add(CategoryName, MaterialPath);
		}
		return;
	}

	if (SourceMode == EDecalSourceMode::ContentBrowser && ActiveMaterial.IsValid())
	{
		Source = ESource::ContentBrowser;
		CategoryName = NAME_None;
		MaterialPath = FSoftObjectPath(ActiveMaterial.Get());
	}
}

void FInteractiveDecalPlacementEdMode::CycleCollection(const int32 Delta)
{
	const TArray<InteractiveDecalPlacement::FDecalBrowseCategory>& BrowseCategories = InteractiveDecalPlacement::GetBrowseCategories();
	if (BrowseCategories.IsEmpty())
	{
		return;
	}

	// Leave selection-inherit; browse continues from the normal session category index.
	ClearSelectionInherit(/*bRestoreBrowseMaterial=*/false);

	RememberActiveDecalIndex();

	if (ActiveCollectionIndex == INDEX_NONE)
	{
		ActiveCollectionIndex = 0;
	}

	const int32 StartIndex = ActiveCollectionIndex;
	for (int32 Offset = 1; Offset <= BrowseCategories.Num(); ++Offset)
	{
		const int32 TryIndex = (StartIndex + Delta * Offset + BrowseCategories.Num() * Offset) % BrowseCategories.Num();
		if (ActivateBrowseCategoryAtIndex(TryIndex) && ActiveMaterial.IsValid())
		{
			PersistSessionBrowseSelection();
			EnsurePreviewActor();
			ShowBrowseLabel();
			return;
		}
	}
}

void FInteractiveDecalPlacementEdMode::CycleDecalInCollection(const int32 Delta)
{
	if (ActiveCollectionDecals.IsEmpty())
	{
		return;
	}

	// Next/prev is relative to the normal session decal index, not a selection-inherited one.
	const int32 Count = ActiveCollectionDecals.Num();
	SelectDecal(((ActiveDecalIndex + Delta) % Count + Count) % Count);
}

int32 FInteractiveDecalPlacementEdMode::GetHudCategoryIndex() const
{
	return SourceMode == EDecalSourceMode::Collection ? ActiveCollectionIndex : INDEX_NONE;
}

const TArray<FSoftObjectPath>& FInteractiveDecalPlacementEdMode::GetHudCollectionDecals() const
{
	static const TArray<FSoftObjectPath> Empty;
	return SourceMode == EDecalSourceMode::Collection ? ActiveCollectionDecals : Empty;
}

void FInteractiveDecalPlacementEdMode::SelectBrowseCategory(const int32 CategoryIndex)
{
	ClearSelectionInherit(/*bRestoreBrowseMaterial=*/false);
	RememberActiveDecalIndex();

	if (!ActivateBrowseCategoryAtIndex(CategoryIndex))
	{
		return;
	}

	SourceMode = EDecalSourceMode::Collection;
	PersistSessionBrowseSelection();
	EnsurePreviewActor();
	if (UDecalComponent* DecalComponent = PreviewActor.IsValid() ? PreviewActor->GetDecal() : nullptr)
	{
		DecalComponent->SetDecalMaterial(ActiveMaterial.Get());
	}
	if (IsEditingPlacedDecal())
	{
		RewriteEditTargetPose();
	}
	ShowBrowseLabel();
}

void FInteractiveDecalPlacementEdMode::SelectDecal(const int32 DecalIndex)
{
	if (!ActiveCollectionDecals.IsValidIndex(DecalIndex))
	{
		return;
	}

	ClearSelectionInherit(/*bRestoreBrowseMaterial=*/false);

	ActiveDecalIndex = DecalIndex;
	RememberActiveDecalIndex();
	ActiveMaterial = LoadDecalMaterial(ActiveCollectionDecals[ActiveDecalIndex]);
	CachedAspectRatio = InteractiveDecalPlacement::GetMaterialAspectRatio(ActiveMaterial.Get());
	EnsurePreviewActor();
	if (UDecalComponent* DecalComponent = PreviewActor.IsValid() ? PreviewActor->GetDecal() : nullptr)
	{
		DecalComponent->SetDecalMaterial(ActiveMaterial.Get());
	}
	if (IsEditingPlacedDecal())
	{
		RewriteEditTargetPose();
	}
	ShowBrowseLabel();
}

void FInteractiveDecalPlacementEdMode::CommitPlacement(FEditorViewportClient* ViewportClient)
{
	// Nothing to stamp: the drag ends as if it had been a click, the user sees why at the cursor and the
	// detail goes to the log.
	const auto NotPlaced = [this, ViewportClient](const TCHAR* Reason)
	{
		UE_LOG(LogDecalPlacement, Warning, TEXT("Decal not placed: %s."), Reason);
		AbandonStampDrag(ViewportClient);
		FeedbackLabel.Show(LOCTEXT("DecalLabelNotPlaced", "Decal not placed"), ProWorkflowTools::OverlayStyle::Erase);
	};

	if (!ActiveMaterial.IsValid())
	{
		NotPlaced(TEXT("the decal material is no longer loaded"));
		return;
	}
	if (!PreviewActor.IsValid())
	{
		NotPlaced(TEXT("the preview actor is gone"));
		return;
	}
	UWorld* World = GEditor ? GEditor->GetEditorWorldContext().World() : nullptr;
	if (!World)
	{
		NotPlaced(TEXT("there is no editor world"));
		return;
	}

	// The preview transform already carries the footprint and flips in its scale.
	const FTransform SpawnTransform = PreviewActor->GetActorTransform();
	const FVector HalfExtents = PreviewActor->GetDecal()
		? InteractiveDecalPlacement::GetDecalSignedHalfExtents(*PreviewActor->GetDecal()).GetAbs()
		: InteractiveDecalPlacement::DefaultDecalSize;

	FScopedTransaction Transaction(LOCTEXT("PlaceDecalTransaction", "Place Decal"));
	World->Modify();

	FActorSpawnParameters SpawnParams;
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	ADecalActor* NewDecal = World->SpawnActor<ADecalActor>(ADecalActor::StaticClass(), SpawnTransform, SpawnParams);
	if (!NewDecal)
	{
		Transaction.Cancel();
		NotPlaced(TEXT("SpawnActor returned null (is the level locked or read-only?)"));
		return;
	}

	NewDecal->Modify();
	if (UDecalComponent* DecalComponent = NewDecal->GetDecal())
	{
		DecalComponent->Modify();
		DecalComponent->SetDecalMaterial(ActiveMaterial.Get());
		DecalComponent->DecalSize = InteractiveDecalPlacement::DefaultDecalSize;

		FLinearColor DecalColor = DecalComponent->DecalColor;
		DecalColor.A = PreviewDecalColorAlpha;
		DecalComponent->SetDecalColor(DecalColor);
		DecalComponent->SetSortOrder(PreviewSortOrder);
	}

	// SetDecalMaterial can reattach the component; re-apply the committed transform so placement matches preview.
	NewDecal->SetActorTransform(SpawnTransform);
	if (UDecalComponent* DecalComponent = NewDecal->GetDecal())
	{
		DecalComponent->DecalSize = InteractiveDecalPlacement::DefaultDecalSize;

		FLinearColor DecalColor = DecalComponent->DecalColor;
		DecalColor.A = PreviewDecalColorAlpha;
		DecalComponent->SetDecalColor(DecalColor);
		DecalComponent->SetSortOrder(PreviewSortOrder);

		DecalComponent->UpdateComponentToWorld();
		DecalComponent->MarkRenderStateDirty();
	}

	StampFlashActor = NewDecal;
	StampFlashStartSeconds = FPlatformTime::Seconds();

	// Join the active Super Group edit session (same Place Decal transaction). Preview ghosts are
	// RF_Transient / hidden from the Outliner and are never passed through CommitPlacement.
	// OnLevelActorAdded may already have joined this actor; GroupActor::Add is idempotent.
	if (GetDefault<UProWorkflowToolsSettings>()->bEnableSuperGroups)
	{
		if (const USuperGroupSubsystem* SuperGroups = World->GetSubsystem<USuperGroupSubsystem>())
		{
			if (AGroupActor* EditingGroup = SuperGroups->GetEditingGroup())
			{
				EditingGroup->Add(*NewDecal);
			}
		}
	}

	// Prefer Decals/<category> nesting when enabled; group membership is independent of folder path.
	const FName FolderPath = GetPlacedDecalFolderPath();
	if (!FolderPath.IsNone())
	{
		NewDecal->SetFolderPath(FolderPath);
	}

	GEditor->SelectNone(false, true, false);
	GEditor->SelectActor(NewDecal, true, true, true);

	LastPlacedDecalSize = HalfExtents;
	bHasLastPlacedSize = true;

	EndStampDrag(ViewportClient);
	RefreshSceneDecalCache(true);
	EnsurePreviewActor();
	ApplyPostPlacementRotation();
}

float FInteractiveDecalPlacementEdMode::GetRotationIntervalRadians() const
{
	const UProWorkflowToolsSettings* Settings = GetDefault<UProWorkflowToolsSettings>();
	return FMath::DegreesToRadians(FMath::Max(Settings->RotationIntervalDegrees, 0.1f));
}

void FInteractiveDecalPlacementEdMode::ApplyPostPlacementRotation()
{
	if (!bRandomRotationEnabled)
	{
		return;
	}

	PreviewRotationRad = FMath::FRandRange(0.0f, 2.0f * PI);
}

void FInteractiveDecalPlacementEdMode::CancelPlacement()
{
	// The mode manager exits a deactivated mode on its next tick, and re-activates one still pending
	// without calling Enter(). So the tool goes dark now: nothing in hand, nothing visible, Inactive.
	// The frame in between shows nothing, and BeginPlacement starts from the same place either way.
	EnterIdle(nullptr);
	HideHudOverlay();
	DestroyPreviewActor();
	SetState(EInteractiveDecalPlacementState::Inactive);

	if (FEditorModeTools* ModeTools = GetModeManager())
	{
		ModeTools->DeactivateMode(EM_InteractiveDecalPlacement);
	}
}

void FInteractiveDecalPlacementEdMode::EnsurePreviewActor()
{
	if (!GEditor || !ActiveMaterial.IsValid())
	{
		return;
	}

	UWorld* World = GEditor->GetEditorWorldContext().World();
	if (!World)
	{
		return;
	}

	if (!PreviewActor.IsValid())
	{
		FActorSpawnParameters SpawnParams;
		SpawnParams.ObjectFlags = RF_Transient | RF_DuplicateTransient;
		SpawnParams.bTemporaryEditorActor = true;
		SpawnParams.bHideFromSceneOutliner = true;
		SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
		PreviewActor = World->SpawnActor<ADecalActor>(ADecalActor::StaticClass(), FTransform::Identity, SpawnParams);
		if (PreviewActor.IsValid())
		{
			// Keep the preview out of the transaction buffer (it lives outside undo entirely).
			PreviewActor->ClearFlags(RF_Transactional);
			PreviewActor->bIsEditorPreviewActor = true;
			PreviewActor->SetActorEnableCollision(false);
			// The ghost shows only while it is the thing in hand (Preview / Dragging).
			SetPreviewVisible(!IsEditingPlacedDecal() && !IsIdle());
#if WITH_EDITORONLY_DATA
			// The surface trace picks by hit proxy, and these draw one under the cursor.
			if (UArrowComponent* Arrow = PreviewActor->GetArrowComponent())
			{
				Arrow->SetVisibility(false);
			}
			if (UBillboardComponent* Sprite = PreviewActor->GetSpriteComponent())
			{
				Sprite->SetVisibility(false);
			}
#endif
			if (UDecalComponent* DecalComponent = PreviewActor->GetDecal())
			{
				// UDecalComponent is a USceneComponent (no primitive collision API); actor collision off is enough.
				DecalComponent->ClearFlags(RF_Transactional);
				DecalComponent->SetDecalMaterial(ActiveMaterial.Get());
			}
		}
	}
	else if (UDecalComponent* DecalComponent = PreviewActor->GetDecal())
	{
		if (DecalComponent->GetDecalMaterial() != ActiveMaterial.Get())
		{
			DecalComponent->SetDecalMaterial(ActiveMaterial.Get());
		}
	}

	// The hidden ghost keeps whatever it had while a placed decal is the subject; LeaveEditMode re-poses it.
	if (!IsEditingPlacedDecal())
	{
		ApplyPreviewDecalProperties();
	}
}

void FInteractiveDecalPlacementEdMode::DestroyPreviewActor()
{
	if (ADecalActor* Preview = PreviewActor.Get())
	{
		if (UWorld* World = Preview->GetWorld())
		{
			World->DestroyActor(Preview);
		}
	}
	PreviewActor.Reset();
	bHasLastAppliedPreview = false;
	LastAppliedMaterial.Reset();
}

void FInteractiveDecalPlacementEdMode::SetPreviewVisible(bool bVisible)
{
	if (ADecalActor* Preview = PreviewActor.Get())
	{
		if (Preview->IsTemporarilyHiddenInEditor() == bVisible)
		{
			Preview->SetIsTemporarilyHiddenInEditor(!bVisible);
		}
	}
}

float FInteractiveDecalPlacementEdMode::GetActiveMaterialAspectRatio() const
{
	return CachedAspectRatio > KINDA_SMALL_NUMBER ? CachedAspectRatio : 1.0f;
}

FString FInteractiveDecalPlacementEdMode::GetActiveCategoryLabel() const
{
	const TArray<InteractiveDecalPlacement::FDecalBrowseCategory>& BrowseCategories = InteractiveDecalPlacement::GetBrowseCategories();
	if (!BrowseCategories.IsValidIndex(ActiveCollectionIndex))
	{
		return TEXT("None");
	}

	return BrowseCategories[ActiveCollectionIndex].DisplayName.ToString();
}

FName FInteractiveDecalPlacementEdMode::GetPlacedDecalFolderPath() const
{
	const UProWorkflowToolsSettings* Settings = GetDefault<UProWorkflowToolsSettings>();
	if (!Settings || !Settings->bNestPlacedDecalsInCategoryFolders)
	{
		return NAME_None;
	}

	static const FString RootFolder = TEXT("Decals");

	if (SourceMode != EDecalSourceMode::Collection)
	{
		return FName(*RootFolder);
	}

	FString Category = GetActiveCategoryLabel();
	Category.TrimStartAndEndInline();
	if (Category.IsEmpty() || Category.Equals(TEXT("None"), ESearchCase::IgnoreCase))
	{
		return FName(*RootFolder);
	}

	// Collection names shouldn't introduce extra Outliner hierarchy via path separators.
	Category.ReplaceInline(TEXT("/"), TEXT("_"), ESearchCase::CaseSensitive);
	Category.ReplaceInline(TEXT("\\"), TEXT("_"), ESearchCase::CaseSensitive);

	return FName(*(RootFolder / Category));
}

FString FInteractiveDecalPlacementEdMode::GetActiveDecalLabel() const
{
	if (ActiveMaterial.IsValid())
	{
		return ActiveMaterial->GetName();
	}

	if (ActiveCollectionDecals.IsValidIndex(ActiveDecalIndex))
	{
		return ActiveCollectionDecals[ActiveDecalIndex].GetAssetName();
	}

	return TEXT("None");
}

UMaterialInterface* FInteractiveDecalPlacementEdMode::LoadDecalMaterial(const FSoftObjectPath& AssetPath) const
{
	return Cast<UMaterialInterface>(AssetPath.TryLoad());
}

void FInteractiveDecalPlacementEdMode::ShowHudOverlay()
{
	HudOverlay.Show([]()
	{
		return SNew(SInteractiveDecalPlacementHud);
	});
}

void FInteractiveDecalPlacementEdMode::HideHudOverlay()
{
	HudOverlay.Hide();
}

FString FInteractiveDecalPlacementEdMode::GetHudCategoryName() const
{
	if (SourceMode != EDecalSourceMode::Collection)
	{
		return FString();
	}

	return GetActiveCategoryLabel();
}

FString FInteractiveDecalPlacementEdMode::GetHudDecalName() const
{
	if (SourceMode == EDecalSourceMode::Collection && ActiveCollectionDecals.IsEmpty())
	{
		return TEXT("(no decal materials in collection)");
	}

	return GetActiveDecalLabel();
}

bool FInteractiveDecalPlacementEdMode::TryGetHudDecalIndex(int32& OutIndexOneBased, int32& OutCount) const
{
	if (SourceMode != EDecalSourceMode::Collection || ActiveCollectionDecals.IsEmpty())
	{
		return false;
	}

	OutIndexOneBased = ActiveDecalIndex + 1;
	OutCount = ActiveCollectionDecals.Num();
	return true;
}

float FInteractiveDecalPlacementEdMode::GetHudAngleDegrees() const
{
	const float AngleRad = (State == EInteractiveDecalPlacementState::Dragging)
		? DragRotationRad
		: PreviewRotationRad;
	return FMath::RadiansToDegrees(AngleRad);
}

float FInteractiveDecalPlacementEdMode::GetHudProjectionDepth() const
{
	return GetActiveProjectionDepth();
}

FVector FInteractiveDecalPlacementEdMode::GetHudInPlaneSize() const
{
	return GetCurrentInPlaneSize();
}

#undef LOCTEXT_NAMESPACE

