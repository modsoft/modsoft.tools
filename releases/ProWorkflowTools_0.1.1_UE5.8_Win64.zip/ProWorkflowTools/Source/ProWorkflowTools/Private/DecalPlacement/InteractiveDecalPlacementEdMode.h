// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "DecalPlacement/InteractiveDecalPlacementTypes.h"
#include "EdMode.h"
#include "ProWorkflowToolsEngineAdapter.h"
#include "UI/ProWorkflowToolHudOverlay.h"
#include "UI/ViewportCursorLabel.h"
#include "UObject/WeakObjectPtr.h"

class ADecalActor;
class FComponentVisualizer;
class FEditorViewportClient;
class FSceneView;
class FViewport;
class SInteractiveDecalPlacementHud;
class UDecalComponent;
class UMaterialInstanceDynamic;
class UMaterialInterface;

namespace InteractiveDecalPlacement
{
	struct FDecalBrowseCategory;

	namespace BoundsTicks
	{
		/**
		 * The decal's image rectangle, slightly outset and lifted toward the view. Corners are labelled by
		 * sign along the component's unit Y / Z axes: C00 (-,-), C10 (+,-), C11 (+,+), C01 (-,+), so a
		 * mirrored decal keeps the same labels for the same world corners as the drag math.
		 */
		bool GetOutsetInPlaneCorners(
			const ADecalActor* Decal,
			const FSceneView* View,
			FVector& OutC00,
			FVector& OutC10,
			FVector& OutC11,
			FVector& OutC01,
			float ExtraOutsetCm = 0.0f);
	}
}

class FInteractiveDecalPlacementEdMode : public FEdMode
{
public:
	static const FEditorModeID EM_InteractiveDecalPlacement;

	FInteractiveDecalPlacementEdMode() = default;

	virtual bool IsCompatibleWith(FEditorModeID OtherModeID) const override { return true; }
	virtual bool UsesToolkits() const override { return false; }
	virtual bool ShouldDrawWidget() const override { return false; }

	virtual void Enter() override;
	virtual void Exit() override;
	virtual void Tick(FEditorViewportClient* ViewportClient, float DeltaTime) override;
	virtual void Render(const FSceneView* View, FViewport* Viewport, FPrimitiveDrawInterface* PDI) override;
	virtual void DrawHUD(FEditorViewportClient* ViewportClient, FViewport* Viewport, const FSceneView* View, FCanvas* Canvas) override;

	virtual bool InputKey(FEditorViewportClient* ViewportClient, FViewport* Viewport, FKey Key, EInputEvent Event) override;
	/**
	 * The one place a viewport click is kept from the engine's actor selection: MMB without Alt is ours
	 * (target / pick), so it never reaches ClickActor. FEdMode::IsSelectionAllowed cannot do this; the
	 * mode manager ORs it with the Selection mode, which always says yes.
	 */
	virtual bool HandleClick(FEditorViewportClient* InViewportClient, HHitProxy* HitProxy, const FViewportClick& Click) override;
	virtual bool InputAxis(FEditorViewportClient* ViewportClient, FViewport* Viewport, int32 ControllerId, FKey Key, float Delta, float DeltaTime) override;
	virtual bool StartTracking(FEditorViewportClient* InViewportClient, FViewport* InViewport) override;
	virtual bool EndTracking(FEditorViewportClient* InViewportClient, FViewport* InViewport) override;
	virtual bool CapturedMouseMove(FEditorViewportClient* InViewportClient, FViewport* InViewport, int32 InMouseX, int32 InMouseY) override;
	virtual bool MouseMove(FEditorViewportClient* ViewportClient, FViewport* Viewport, int32 x, int32 y) override;
	virtual bool DisallowMouseDeltaTracking() const override;
	virtual bool GetCursor(EMouseCursor::Type& OutCursor) const override;

	virtual void AddReferencedObjects(FReferenceCollector& Collector) override;
	virtual FString GetReferencerName() const override { return TEXT("FInteractiveDecalPlacementEdMode"); }

	void BeginPlacement();
	/**
	 * The hotkey pressed while the mode is already on: leaves the tool from any resting state (J in,
	 * J out; Esc steps back). Ignored while a stamp or handle drag is in progress.
	 * False only if the mode is registered but has not begun, in which case the caller begins it.
	 */
	bool TogglePlacementOff();

	/** True while a placed decal (not the ghost) is the thing every setting writes to. */
	bool IsEditingPlacedDecal() const;
	/**
	 * True in Idle: the mode is on with nothing in hand. Reached by Esc from Preview, a drag or Edit, or by
	 * putting the target down; left by LMB (new decal), MMB (target or pick the ghost up) or Esc (exit).
	 */
	bool IsIdle() const;

	FString GetHudCategoryName() const;
	FString GetHudDecalName() const;
	bool TryGetHudDecalIndex(int32& OutIndexOneBased, int32& OutCount) const;
	float GetHudAngleDegrees() const;
	float GetHudProjectionDepth() const;
	float GetHudAlpha() const { return PreviewDecalColorAlpha; }
	int32 GetHudSortOrder() const { return PreviewSortOrder; }
	FVector GetHudInPlaneSize() const;

	bool IsRandomRotationEnabled() const { return bRandomRotationEnabled; }
	void SetRandomRotationEnabled(const bool bEnabled) { bRandomRotationEnabled = bEnabled; }

	/** Persisted per user (Alt tap toggles it). Alt pressed during a drag inverts it for that drag. */
	bool IsCenteredPlacementEnabled() const;
	void SetCenteredPlacementEnabled(bool bEnabled);

	/** Persisted per user (C toggles). Hover and drag poses are fitted to the surface under the footprint. */
	bool IsFitSurfaceEnabled() const;
	void SetFitSurfaceEnabled(bool bEnabled);

	//~ HUD value edits. Each goes through the same state its scroll binding writes; the next drag or scroll overrides it.
	/** Width and height in cm; HeightCm <= 0 derives the height from the material aspect. */
	void SetHudInPlaneSize(float WidthCm, float HeightCm);
	void SetHudAngleDegrees(float Degrees);
	void SetHudProjectionDepth(float DepthCm);
	void SetHudAlpha(float Alpha);
	void SetHudSortOrder(int32 SortOrder);

	/** Index into GetBrowseCategories(), or INDEX_NONE outside collection browsing. */
	int32 GetHudCategoryIndex() const;
	/** Switches to collection browsing at that browse category. */
	void SelectBrowseCategory(int32 CategoryIndex);
	/** Decals of the active category; empty outside collection browsing. */
	const TArray<FSoftObjectPath>& GetHudCollectionDecals() const;
	void SelectDecal(int32 DecalIndex);

	/** Session-only browse-category toggles for the HUD Collections popover (invalidates browse cache). */
	bool IsSessionCollectionEnabled(FName CollectionName) const;
	void SetSessionCollectionEnabled(FName CollectionName, bool bEnabled);
	/** Check/uncheck every session UI browse category (invalidates cache + restores selection). */
	void SetAllSessionCollectionsEnabled(bool bEnabled);
	/** Expanded browse categories for HUD checkboxes (includes subcategories; ignores session filter). */
	void GetSessionUiBrowseCategories(TArray<InteractiveDecalPlacement::FDecalBrowseCategory>& OutCategories) const;

	/**
	 * Session-only Bounds toggle: on, every scene ADecalActor wears a faint outline; off, only the selected
	 * or edited decal does. Game View hides both.
	 */
	bool IsShowSceneBounds() const;
	void SetShowSceneBounds(bool bEnabled);

	/** True when the cursor is over the visible Slate HUD panel (not empty overlay chrome). */
	bool IsPointerOverHud() const;

private:
	enum class EDecalSourceMode : uint8
	{
		ContentBrowser,
		Collection
	};

	bool ProjectCursorOntoAnchorPlane(FEditorViewportClient* ViewportClient, FVector& OutPlanePoint) const;

	void UpdateHoverPreview(FEditorViewportClient* ViewportClient);
	void UpdateDragPreview(FEditorViewportClient* ViewportClient);
	/** Writes a pose to the posed actor: the ghost in Preview / Dragging, the edit target in Edit / EditDragging. */
	void ApplyPreviewTransform(const FInteractiveDecalPlacementResult& Placement);
	/** Writes alpha / sort to the posed actor. */
	void ApplyPreviewDecalProperties();
	FVector ApplyFlipToDecalSize(const FVector& DecalSize) const;

	//~ Edit: a placed decal takes the ghost's place as the thing every setting writes to.
	/** The actor whose pose the session describes: the edit target while editing, else the ghost. */
	ADecalActor* GetPosedActor() const;
	/**
	 * Makes Target the thing every setting writes to: saves the next decal's settings (first entry only; a
	 * retarget keeps the saved set), loads the target's into the working fields, hides the ghost and selects
	 * the target. False if it has no decal material.
	 */
	bool EnterEditMode(ADecalActor* Target, FEditorViewportClient* ViewportClient);
	/** Puts the target down into Idle and brings the next decal's settings back; the ghost stays hidden. */
	void LeaveEditMode(FEditorViewportClient* ViewportClient);
	/**
	 * Puts everything down: a drag in progress ends without changing the scene (its own end function does
	 * that), the ghost hides, and the mode rests in Idle with the session's settings kept. ViewportClient
	 * may be null (Exit, selection change); the hovered viewport is refreshed then.
	 */
	void EnterIdle(FEditorViewportClient* ViewportClient);
	/** Picks the ghost up: Preview, posed under the cursor with the session's settings. */
	void BeginPreview(FEditorViewportClient* ViewportClient);
	/**
	 * The only writer of the edit target. A handle drag holds one transaction for its whole duration;
	 * every other edit (scroll, hotkey, HUD field) is its own undo step.
	 */
	void WriteEditTarget(const FText& Description, TFunctionRef<void(ADecalActor&, UDecalComponent&)> Write);
	/** Re-writes the target from its own rotation / center and the session size, flips, alpha, sort, material. */
	void RewriteEditTargetPose();
	/** Rotates the target in its own plane (Ctrl+Scroll / HUD angle); PreviewRotationRad accumulates the delta. */
	void RotateEditTarget(float DeltaRad);
	/** Fit Surface on the target where it sits, pinned at its center. */
	void RefitEditTarget(FEditorViewportClient* ViewportClient);
	/**
	 * The decal whose outline is grabbable in this viewport: the target in Edit; in Preview the single
	 * selected ADecalActor, outside Game View only (selection visuals follow the engine's gate).
	 */
	ADecalActor* GetHandleDecal(const FEditorViewportClient* ViewportClient) const;
	/**
	 * The grab site under a pixel, by screen distance: a corner within CornerPickPx is preferred, then an
	 * edge of the outline within EdgePickPx. Invalid when neither. Handles are picked here only (no hit proxies).
	 */
	FInteractiveDecalEditHandle FindHandleAtPixel(FEditorViewportClient* ViewportClient, const FIntPoint& Pixel) const;
	/** Re-reads the hovered grab site for the cursor; redraws when it changed. */
	void UpdateHoveredHandle(FEditorViewportClient* ViewportClient);
	/** Opposite-handle anchor frame + fixed cross-axis offsets for a handle drag on the target. */
	void BeginEditHandleDrag(const FInteractiveDecalEditHandle& Handle, FEditorViewportClient* ViewportClient);
	void UpdateEditHandleDrag(FEditorViewportClient* ViewportClient);
	/** Ends the handle drag; bKeep false cancels its transaction so the decal springs back. */
	void EndEditHandleDrag(bool bKeep);
	void OnEditorSelectionChanged(UObject* NewSelection);
	/**
	 * Begins a stamp drag at the cursor from Preview, Idle or Edit: anchors on the surface hit and enters
	 * Dragging. From Edit the press puts the target down first. Without a ghost in hand (Idle, Edit) a
	 * click that never travels ends in Preview without a stamp.
	 */
	bool BeginStampDrag(FEditorViewportClient* ViewportClient, FViewport* Viewport);
	/**
	 * LMB came up during a stamp drag (release, or capture lost with the button already up): a drag that
	 * travelled, or a click with the ghost in hand, stamps; a click without a ghost in hand lands in Preview.
	 */
	void ReleaseStampDrag(FEditorViewportClient* ViewportClient);
	/** The stamp drag ends without a decal (click from Idle / Edit, failed commit): back to Preview, ghost at the cursor. */
	void AbandonStampDrag(FEditorViewportClient* ViewportClient);
	/** The one exit from Dragging: clears the drag's state and rests in Preview. Called by commit and abandon only. */
	void EndStampDrag(FEditorViewportClient* ViewportClient);
	/** Shift+MMB: copies a scene decal's settings into the ghost (the Material Clipboard's pick gesture). */
	bool PickDecalUnderCursor(FEditorViewportClient* ViewportClient, FViewport* Viewport);
	/**
	 * The outline + corner-tick rectangle of one decal, which doubles as its resize widget when
	 * Interactive: the hovered / dragged corner fills to a wedge, the hovered / dragged edge thickens.
	 */
	void DrawDecalRect(const FSceneView* View, FPrimitiveDrawInterface* PDI, const ADecalActor* Decal,
		const FLinearColor& TickColor, const FLinearColor& OutlineColor, float OutlinePx, bool bInteractive) const;
	void EnsureWidgetMaterials();
	/** While J is active, our outline is the selected decal's visual: the engine's green box visualizer steps aside. */
	void SwapOutEngineDecalVisualizer();
	void RestoreEngineDecalVisualizer();

	bool TrySetMaterialFromContentBrowser();
	bool ActivateBrowseCategoryAtIndex(int32 CategoryIndex);
	bool TryActivateFirstCollectionWithDecals();
	bool TryRestoreSessionBrowseSelection();
	/**
	 * At placement start only: if exactly one scene decal is selected, seed material + size/alpha/sort/flip
	 * from it. Browse index stays at the normal session position so Scroll/Tab leave inheritance cleanly.
	 */
	bool TryInheritFromSelectedDecal();
	/** Seeds material + size/alpha/sort/flip from a scene decal; false if it has no decal material. */
	bool InheritFromDecal(const UDecalComponent* SourceDecal);
	/**
	 * The scene decal visible at the cursor: the surface point under the cursor (nearest geometry, so
	 * nothing behind a wall) must lie inside the decal's projection box. Of several, the one drawn on
	 * top is returned (highest SortOrder, then the smallest box). MMB targets it; Shift+MMB picks from it.
	 */
	ADecalActor* FindSceneDecalUnderCursor(FEditorViewportClient* ViewportClient) const;
	/** Clears selection-inherit; optionally restores ActiveMaterial from the browse baseline. */
	void ClearSelectionInherit(bool bRestoreBrowseMaterial);
	void RememberActiveDecalIndex();
	void PersistSessionBrowseSelection();
	void CycleCollection(int32 Delta);
	void CycleDecalInCollection(int32 Delta);

	/** Stamps the ghost as a new ADecalActor in one "Place Decal" transaction. When nothing can be placed the drag is abandoned with a label and a log line. */
	void CommitPlacement(FEditorViewportClient* ViewportClient);
	/**
	 * Leaves the tool: goes dark at once (the mode manager's deactivation is deferred to its next tick) and
	 * asks for the deactivation; Exit() then finishes the session teardown.
	 */
	void CancelPlacement();
	void EnsurePreviewActor();
	void DestroyPreviewActor();
	void SetPreviewVisible(bool bVisible);
	void ShowHudOverlay();
	void HideHudOverlay();
	bool HandleMouseWheelInput(FEditorViewportClient* ViewportClient, int32 WheelDelta);
	bool AdjustActiveDecalSize(int32 WheelDelta);
	bool AdjustProjectionDepth(int32 WheelDelta);
	void ResetPlacementTweaks();
	void ApplyPostPlacementRotation();
	float GetRotationIntervalRadians() const;
	float GetActiveProjectionDepth() const;
	bool IsSpaceHeld(const FEditorViewportClient* ViewportClient) const;
	bool IsCenteredFor(const FEditorViewportClient* ViewportClient) const;
	void RefreshSceneDecalCache(bool bForce = false);
	void DrawSceneDecalOutlines(const FSceneView* View, FPrimitiveDrawInterface* PDI) const;
	void DrawPreviewBounds(const FSceneView* View, FPrimitiveDrawInterface* PDI) const;
	void DrawStampFlash(const FSceneView* View, FPrimitiveDrawInterface* PDI) const;
	/** The decal Shift+MMB just picked from: Highlight corner ticks + outline settling back to nothing. */
	void DrawPickFlash(const FSceneView* View, FPrimitiveDrawInterface* PDI) const;
	/** Screen-space pick burst at the Shift+MMB click (the Material Clipboard's pick ring). */
	void DrawPickBurst(FCanvas* Canvas) const;
	/** Drag-modifier guides in the decal plane: Ctrl rotation arc, Shift aspect diagonal. */
	void DrawModifierGuides(const FSceneView* View, FPrimitiveDrawInterface* PDI) const;
	/** Screen-space Space-move glyph at the preview center. */
	void DrawMoveGlyph(const FSceneView* View, FCanvas* Canvas) const;

	/** Fading cursor label with the active decal name and its category / position. */
	void ShowBrowseLabel();
	/** Fading cursor label for a hotkey / scroll command result ("Flip H on", "Depth 128 cm"). */
	void ShowActionLabel(const FText& Text);
	/** The preview outline flashes Highlight and settles: a value changed that the pose alone doesn't show. */
	void PingPreviewOutline();
	/** A quick Alt press and release with nothing in between toggles Centered. Never consumes input. */
	void TrackAltTap(const FKey& Key, EInputEvent Event);

	float GetActiveMaterialAspectRatio() const;
	FString GetActiveCategoryLabel() const;
	FString GetActiveDecalLabel() const;
	FVector GetCurrentInPlaneSize() const;

	/** Outliner folder for the next stamp (Decals/<category> or Decals), or None when nesting is off. */
	FName GetPlacedDecalFolderPath() const;

	UMaterialInterface* LoadDecalMaterial(const FSoftObjectPath& AssetPath) const;
	bool TrySwitchToCollectionBrowsing();
	/**
	 * Hover / pre-threshold preview pose. Corner-anchored (cursor at visual top-left) unless
	 * bCentered, which centers it on the hit so a center-scale drag starts without a jump.
	 */
	FInteractiveDecalPlacementResult MakeHoverPlacement(const FInteractiveDecalTangentFrame& Frame, bool bCentered) const;

	/**
	 * Fit Surface post-pass on a flat hover / drag pose: samples the surface at the footprint's nine
	 * points and re-orients the pose to their mean (see FitPlacementToSurface). PinPoint is the rect
	 * point that must stay under the cursor. Returns Flat when the toggle is off.
	 */
	FInteractiveDecalPlacementResult FitToSurfaceIfEnabled(FEditorViewportClient* ViewportClient, const FInteractiveDecalPlacementResult& Flat, const FVector& PinPoint);

	/** Session size (the value click-stamps, Shift+Scroll and W+Scroll build on) and the preview with it. */
	void SetSessionSize(const FVector& Size);
	/** Re-poses the preview after a value edit, for whichever state is active. */
	void RefreshPreviewPose();

	/**
	 * The only writer of State. A drag (ghost or handle) owns every mouse button and the camera: entering
	 * it suspends the ITF camera interactions (dolly, fly keys, orbit...) and leaving it resumes them.
	 */
	void SetState(EInteractiveDecalPlacementState NewState, FEditorViewportClient* ViewportClient = nullptr);
	bool IsDraggingState() const;
	/** Idle, Preview or Edit: the mode is on and no drag is in progress. */
	bool IsRestingState() const;

	EInteractiveDecalPlacementState State = EInteractiveDecalPlacementState::Inactive;

	/** The placed decal being edited (Edit / EditDragging). Tick leaves Edit when it dies (delete, undo). */
	TWeakObjectPtr<ADecalActor> EditTarget;
	/**
	 * The next decal's settings as they were when Edit began. Edit works on the target through the same
	 * fields, so they are saved here and put back when the target is put down: nothing done while editing
	 * (handle drags, scroll, browse, HUD edits) reaches the next decal. Shift+MMB and J-with-selection are
	 * the only ways a scene decal's settings enter the session.
	 */
	struct FSessionSettings
	{
		TWeakObjectPtr<UMaterialInterface> Material;
		float AspectRatio = 1.0f;
		EDecalSourceMode SourceMode = EDecalSourceMode::ContentBrowser;
		int32 CollectionIndex = INDEX_NONE;
		int32 DecalIndex = 0;
		TArray<FSoftObjectPath> CollectionDecals;
		FVector Size = FVector::ZeroVector;
		bool bHasSize = false;
		bool bFlipHorizontal = false;
		bool bFlipVertical = false;
		float ColorAlpha = 1.0f;
		int32 SortOrder = 0;
		float RotationRad = 0.0f;
		bool bInheritedFromSelection = false;
	};
	TOptional<FSessionSettings> SessionBeforeEdit;
	FSessionSettings SaveSessionSettings() const;
	void RestoreSessionSettings(const FSessionSettings& Saved);
	FDelegateHandle SelectionChangedHandle;
	/** True while EnterEditMode selects its target, so the selection event does not re-enter. */
	bool bSyncingSelection = false;
	/** Handle drag: one transaction from press to release. */
	int32 EditDragTransactionIndex = INDEX_NONE;
	FInteractiveDecalEditHandle EditDragHandle;
	/**
	 * Target half extents (along unit Y, Z; cm) at press. With AnchorFrame (positioned at the decal
	 * center) these give the per-update anchor for either pivot mode and the span an edge handle keeps.
	 */
	FVector2D EditDragHalfExtents = FVector2D::ZeroVector;
	/** Raw cursor point on the decal plane last update; Space-move slides the center by its delta. */
	FVector EditDragLastPlanePoint = FVector::ZeroVector;
	/** The handle drag's fixed point (opposite corner, or the center): sizing and Ctrl-rotate pivot here. */
	FVector EditDragPivot = FVector::ZeroVector;
	/** PreviewRotationRad at press; DragRotationRad accumulates the Ctrl-rotate on top of it. */
	float EditDragBaseRotationRad = 0.0f;
	/** Grab site under the cursor in Preview / Edit (invalid = none). Drawn filled / thick, sets the cursor. */
	FInteractiveDecalEditHandle HoveredHandle;
	/** Space as last seen by Tick in Edit; its edge re-reads the hover so the body grab arms without mouse travel. */
	bool bEditSpaceHeldLastTick = false;
	/** A stamp drag begun without a ghost in hand (Edit or Idle): releasing without travel ends in Preview, not in a stamp. */
	bool bStampDragFromEdit = false;
	/** The engine's UDecalComponent visualizer, parked while the mode is active. */
	TSharedPtr<FComponentVisualizer> ParkedDecalVisualizer;
	/** Filled corner wedges (gizmo material tinted to the overlay colours). */
	TObjectPtr<UMaterialInstanceDynamic> WedgeMaterial = nullptr;
	ProWorkflowTools::FCameraInteractionsSuspension DragCameraSuspension;
	EDecalSourceMode SourceMode = EDecalSourceMode::ContentBrowser;

	int32 ActiveCollectionIndex = INDEX_NONE;
	int32 ActiveDecalIndex = 0;
	TArray<FSoftObjectPath> ActiveCollectionDecals;

	FInteractiveDecalTangentFrame AnchorFrame;
	bool bHasAnchor = false;

	/** Surface point under the cursor while hovering; the preview's corner or center sits here. */
	FVector HoverAnchorPoint = FVector::ZeroVector;

	ProWorkflowTools::CursorLabel::FFadingLabel FeedbackLabel;
	/** Alt press time while it can still count as a tap; reset by any other press. */
	double AltTapStartSeconds = -1.0;
	/** Shift aspect lock as applied by the last drag update. */
	bool bAspectLocked = false;
	TWeakObjectPtr<ADecalActor> StampFlashActor;
	double StampFlashStartSeconds = -1.0;
	/** Last W+Scroll depth edit; the depth guide highlights then settles from this time. */
	double DepthGuideHighlightStartSeconds = -1.0;
	/** Last flip / opacity / sort / reset / inherit; the preview outline highlights then settles from this time. */
	double PreviewPingStartSeconds = -1.0;
	/** Shift+MMB pick feedback: the picked decal and the click pixel, from PickFlashStartSeconds. */
	TWeakObjectPtr<ADecalActor> PickFlashActor;
	double PickFlashStartSeconds = -1.0;
	FIntPoint PickFlashPixel = FIntPoint::ZeroValue;

	/** Screen position where LMB went down; used to distinguish click from drag. */
	FIntPoint DragStartScreenPos = FIntPoint::ZeroValue;
	/** True once the mouse moved past the click threshold and drag-sizing began. */
	bool bDragConfirmed = false;

	/**
	 * Space-held move during a drag: the decal keeps its size and follows the mouse. Written only by the
	 * drag that owns it (begin clears, update follows Space, end clears).
	 */
	bool bSpacePanning = false;
	/** Stamp drag: anchor-to-cursor vector frozen when Space went down, so the size holds while the anchor slides. */
	FVector SpacePanFrozenDragVector = FVector::ZeroVector;
	/**
	 * The drag's end point in the decal plane, which the modifier guides draw from: the cursor's plane
	 * point in a stamp drag, the dragged handle's point in a handle drag (EditDragLastPlanePoint keeps
	 * the raw cursor point there).
	 */
	FVector LastDragPlanePoint = FVector::ZeroVector;

	/** Preview yielded tracking to the viewport (Alt orbit / dolly / track, RMB fly); the preview hides until it ends. */
	bool bCameraTracking = false;

	/** In-plane rotation applied to the hover preview / click stamps (Ctrl+Scroll). */
	float PreviewRotationRad = 0.0f;
	/** In-plane rotation of the current drag (seeded from PreviewRotationRad, changed by Ctrl-rotate). */
	float DragRotationRad = 0.0f;

	/** Ctrl-held rotate/uniform-scale around the anchor corner. */
	bool bCtrlRotating = false;
	float CtrlStartMouseAngleRad = 0.0f;
	float RotationAtCtrlStartRad = 0.0f;

	/** When enabled, each placement picks a new random in-plane rotation for the next stamp. */
	bool bRandomRotationEnabled = false;

	/** Horizontal flip (X; mirrors the actor's Z scale). */
	bool bFlipHorizontal = false;
	/** Vertical flip (Z; mirrors the actor's Y scale). */
	bool bFlipVertical = false;

	/** Tab held (consumed in InputKey). */
	bool bTabModifierHeld = false;

	/** W held (consumed in InputKey). */
	bool bWModifierHeld = false;

	/** Scene ADecalActors for the faint outlines and cursor targeting (refreshed periodically). */
	TArray<TWeakObjectPtr<ADecalActor>> CachedSceneDecals;
	double SceneDecalCacheTimeSeconds = 0.0;
	static constexpr float SceneDecalCacheRefreshInterval = 1.0f;
	static constexpr float ProjectionDepthScrollStepCm = 1.0f;

	/** Session-only: faint outlines on existing world decals (default ON). */
	bool bShowSceneBounds = true;

	/** Decal Color alpha for the next placement (0-1). */
	float PreviewDecalColorAlpha = 1.0f;

	/** Sort order for the next placement. */
	int32 PreviewSortOrder = 0;

	/**
	 * True while ActiveMaterial / size / alpha / sort came from the scene decal selected at placement start.
	 * Cleared on Backspace or when browsing (Scroll / Tab+Scroll).
	 */
	bool bInheritedFromSelection = false;

	/** Remembered half-extents (cm, unsigned) from the most recent placement for click-stamp reuse. */
	bool bHasLastPlacedSize = false;
	FVector LastPlacedDecalSize = FVector::ZeroVector;

	/** Surface points the last Fit Surface pass used; drawn while dragging. */
	TArray<FVector> FitSurfaceSamples;

	/** Skip redundant preview applies when hover/drag pose & props are unchanged. */
	bool bHasLastAppliedPreview = false;
	FTransform LastAppliedActorTransform = FTransform::Identity;
	FVector LastAppliedDecalSize = FVector::ZeroVector;
	float LastAppliedDecalColorAlpha = 1.0f;
	int32 LastAppliedSortOrder = 0;
	TWeakObjectPtr<UMaterialInterface> LastAppliedMaterial;
	bool LastAppliedFlipHorizontal = false;
	bool LastAppliedFlipVertical = false;

	/** True while this mode holds a shared transform-widget suppression. */
	bool bHoldingWidgetSuppression = false;

	static constexpr float DecalColorAlphaScrollStep = 0.0125f;

	TWeakObjectPtr<UMaterialInterface> ActiveMaterial;
	TWeakObjectPtr<ADecalActor> PreviewActor;
	TProWorkflowToolHudOverlay<SInteractiveDecalPlacementHud> HudOverlay;
	float CachedAspectRatio = 1.0f;
};

