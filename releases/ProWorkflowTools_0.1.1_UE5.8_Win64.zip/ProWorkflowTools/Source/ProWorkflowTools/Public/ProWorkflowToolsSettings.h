// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "Engine/DeveloperSettings.h"
#include "InputCoreTypes.h"
#include "ProWorkflowToolsSettings.generated.h"

/** One configured decal collection row for Interactive Decal Placement. */
USTRUCT()
struct FInteractiveDecalCollectionEntry
{
	GENERATED_BODY()

	UPROPERTY(config, EditAnywhere, Category = "Collection")
	bool bEnabled = true;

	UPROPERTY(config, EditAnywhere, Category = "Collection")
	FName CollectionName;

	/** Each child collection becomes its own Tab+Scroll category. */
	UPROPERTY(config, EditAnywhere, Category = "Collection", meta = (DisplayName = "Include Subcategories"))
	bool bIncludeChildCollections = false;
};

/** Editor Preferences → Plugins → Pro Workflow Tools. */
UCLASS(config = Editor, defaultconfig, meta = (DisplayName = "Pro Workflow Tools"))
class PROWORKFLOWTOOLS_API UProWorkflowToolsSettings : public UDeveloperSettings
{
	GENERATED_BODY()

public:
	UProWorkflowToolsSettings() = default;

	virtual bool SupportsAutoRegistration() const override { return false; }

	/** Writes the CDO to the project's DefaultEditor.ini (this class is defaultconfig). */
	void NotifyAndPersist(FProperty* Property = nullptr);

	//~ Viewport Controls

	UPROPERTY(config, EditAnywhere, Category = "Viewport Controls", meta = (DisplayName = "DCC Standard Control Scheme",
		ToolTip = "Marquee selection in the level viewport.\n\nDrag:\n  LMB — replace\n  Shift+LMB — add\n  Ctrl+LMB — remove\n  Ctrl+Shift+LMB — select similar (mesh/class)\n\nClick:\n  Ctrl+LMB on selected — deselect\n\nAlt / RMB / WASD camera controls are unchanged."))
	bool bEnableDccViewportControls = true;

	UPROPERTY(config, EditAnywhere, Category = "Viewport Controls", meta = (DisplayName = "Allow Re-selecting Actors",
		ToolTip = "Shift+LMB on an actor that is already selected makes it the last selected: the transform pivot moves to it and Ctrl+G group pivot options use it."))
	bool bShiftClickSetsActiveActor = true;

	UPROPERTY(config, EditAnywhere, Category = "Viewport Controls", meta = (DisplayName = "Select Similar Marquee Notification", EditCondition = "bEnableDccViewportControls",
		ToolTip = "The select-similar marquee (Ctrl+Shift+LMB) draws in the accent color and reports the match count at the cursor when it finishes."))
	bool bSelectSimilarFeedback = true;

	//~ Viewport Overlays

	UPROPERTY(config, EditAnywhere, Category = "Viewport Overlays", meta = (DisplayName = "Tools Accent Color", HideAlphaChannel,
		ToolTip = "Primary overlay color for Decal Placement, Actor Grid Paint, and Material Clipboard: bounds, previews, pulses, and cursor labels. Erase stays red."))
	FLinearColor OverlayAccentColor = FLinearColor(0.35f, 0.78f, 1.0f, 1.0f);

	//~ Per-Actor Origin Transform

	UPROPERTY(config, EditAnywhere, Category = "Per-Actor Origin Transform", meta = (DisplayName = "Enable Per-Actor Origin Scale / Rotate",
		ToolTip = "While the Scale or Rotate widget is up, hold the modifier to transform each selected actor about its own origin instead of the shared pivot."))
	bool bEnableLocalScaleModifier = true;

	UPROPERTY(config, EditAnywhere, Category = "Per-Actor Origin Transform", meta = (DisplayName = "Per-Actor Origin Modifier", EditCondition = "bEnableLocalScaleModifier",
		ToolTip = "Hold during a Scale or Rotate widget drag. Default Shift."))
	FKey LocalScaleModifierKey = EKeys::LeftShift;

	UPROPERTY(config, EditAnywhere, Category = "Per-Actor Origin Transform", meta = (DisplayName = "Show Origin Markers", EditCondition = "bEnableLocalScaleModifier",
		ToolTip = "While the modifier is held, mark each selected actor's origin with the hovered axis (ring for rotate, line for scale)."))
	bool bShowLocalScaleOriginHints = true;

	//~ Bounding Box Scale

	UPROPERTY(config, EditAnywhere, Category = "Bounding Box Scale", meta = (DisplayName = "Enable Bounding Box Scale",
		ToolTip = "Bounds cage while the Scale widget is active. B toggles the cage."))
	bool bEnableBoxScale = true;

	UPROPERTY(config, EditAnywhere, Category = "Bounding Box Scale", meta = (DisplayName = "Flat Axis Ratio", ClampMin = "0.0", ClampMax = "0.5", EditCondition = "bEnableBoxScale",
		ToolTip = "An axis thinner than this fraction of the longest side hides its face handles, and edge / corner drags leave it alone unless Ctrl (uniform) is held. 0 only treats a zero-thickness axis as flat."))
	float BoxScaleFlatAxisRatio = 0.05f;

	UPROPERTY(config, EditAnywhere, Category = "Bounding Box Scale", meta = (DisplayName = "Cage Color", EditCondition = "bEnableBoxScale"))
	FLinearColor BoxScaleCageColor = FLinearColor(1.0f, 1.0f, 1.0f, 0.28f);

	UPROPERTY(config, EditAnywhere, Category = "Bounding Box Scale", meta = (DisplayName = "Edge And Corner Handle Color", EditCondition = "bEnableBoxScale"))
	FLinearColor BoxScaleEdgeCornerHandleColor = FLinearColor(0.92f, 0.92f, 0.92f, 1.0f);

	UPROPERTY(config, EditAnywhere, Category = "Bounding Box Scale", meta = (DisplayName = "Handle Size", ClampMin = "4.0", ClampMax = "64.0", EditCondition = "bEnableBoxScale",
		ToolTip = "Screen-pixel diameter of face, edge, and corner handles. The click target is that same size."))
	float BoxScaleHandleSize = 12.0f;

	//~ Duplicate

	UPROPERTY(config, EditAnywhere, Category = "Duplicate", meta = (DisplayName = "Duplicate In Place",
		ToolTip = "Ctrl+D / Edit → Duplicate places the copy at the same transform (no grid nudge)."))
	bool bDuplicateInPlace = true;

	//~ Material Clipboard

	UPROPERTY(config, EditAnywhere, Category = "Material Clipboard", meta = (DisplayName = "Enable Material Clipboard",
		ToolTip = "Hold the clipboard key, then:\n  MMB — pick hovered slot\n  LMB — apply (double-click = all slots)\n  RMB — clear override (double-click = all slots)\n\nApply/clear use the hovered slot name across the selection."))
	bool bEnableMaterialClipboardTool = true;

	UPROPERTY(config, EditAnywhere, Category = "Material Clipboard", meta = (DisplayName = "Material Clipboard Hold Key", EditCondition = "bEnableMaterialClipboardTool",
		ToolTip = "Hold while picking / applying / clearing materials."))
	FKey MaterialClipboardHoldKey = EKeys::Tab;

	//~ Actor Grid Paint

	UPROPERTY(config, EditAnywhere, Category = "Actor Grid Paint", meta = (DisplayName = "Enable Actor Grid Paint",
		ToolTip = "With one static mesh or decal selected, paints edge-flush copies on its modular grid. Toggle from Keyboard Shortcuts (default T).\n\n  LMB — paint\n  Shift+LMB — erase\n  Ctrl+LMB — line fill\n  B — edit bounds\n  Esc — exit"))
	bool bEnableGridPaint = true;

	UPROPERTY(config, EditAnywhere, Category = "Actor Grid Paint", meta = (DisplayName = "Intersect Test Bounds Scale", EditCondition = "bEnableGridPaint", ClampMin = "0.25", ClampMax = "1.0",
		ToolTip = "How much of each cell is checked against other actors before painting. Lower values let copies overlap more before a cell is blocked."))
	float GridPaintOverlapBoundsScale = 0.85f;

	UPROPERTY(config, EditAnywhere, Category = "Actor Grid Paint", meta = (DisplayName = "Thin Axis Threshold", EditCondition = "bEnableGridPaint", ClampMin = "0.01", ClampMax = "50.0", Units = "cm",
		ToolTip = "A mesh side this short or shorter (cm) is treated as its flat side: copies are not stacked along it, and it faces the paint plane."))
	float GridPaintThinAxisThreshold = 12.5f;

	UPROPERTY(config, EditAnywhere, Category = "Actor Grid Paint", meta = (DisplayName = "Thin Axis Relative Ratio", EditCondition = "bEnableGridPaint", ClampMin = "0.01", ClampMax = "0.5",
		ToolTip = "Same rule by proportion: a side shorter than this fraction of the mesh's longest side is treated as its flat side."))
	float GridPaintThinAxisRelativeRatio = 0.12f;

	//~ Super Groups

	UPROPERTY(config, EditAnywhere, Category = "Super Groups", meta = (DisplayName = "Enable Super Groups"))
	bool bEnableSuperGroups = true;

	UPROPERTY(config, EditAnywhere, Category = "Super Groups|Group Creation", meta = (DisplayName = "Use Last Selected Actor As Group Pivot", EditCondition = "bEnableSuperGroups",
		ToolTip = "Ctrl+G pivots at the last selected non-group actor. With Allow Re-selecting Actors on, Shift+click a selected actor to set that reference."))
	bool bUseLastSelectedActorAsPivot = true;

	UPROPERTY(config, EditAnywhere, Category = "Super Groups|Group Creation", meta = (DisplayName = "Nest New Groups In Outliner Folder", EditCondition = "bEnableSuperGroups",
		ToolTip = "Put new groups (and members added while editing) in an Outliner folder."))
	bool bNestGroupInFolderOnCreate = false;

	UPROPERTY(config, EditAnywhere, Category = "Super Groups|Editing", meta = (DisplayName = "Visualize Group Editing", EditCondition = "bEnableSuperGroups",
		ToolTip = "Level Instance-like focus: while editing a group, everything outside it is dimmed."))
	bool bUseLevelInstanceEditingVisuals = true;

	UPROPERTY(config, EditAnywhere, Category = "Super Groups|Editing", meta = (DisplayName = "Restrict Selection While Editing", EditCondition = "bEnableSuperGroups",
		ToolTip = "While editing a group, only its members can be selected."))
	bool bRestrictSelectionWhileEditing = true;

	UPROPERTY(config, EditAnywhere, Category = "Super Groups|Editing", meta = (DisplayName = "Double-Click To Enter Groups", EditCondition = "bEnableSuperGroups",
		ToolTip = "Double-click a group member in the viewport to enter its group. Inside a group, double-click a nested group's member to enter that group."))
	bool bDoubleClickToEnterGroups = true;

	UPROPERTY(config, EditAnywhere, Category = "Super Groups|Visualization", meta = (EditCondition = "bEnableSuperGroups",
		ToolTip = "Empty Actor–style pivot sprites at group pivots. Hidden in Game View (G). Also gated by Show → Advanced → Group Pivot Icons."))
	bool bShowGroupPivotIcon = true;

	UPROPERTY(config, EditAnywhere, Category = "Super Groups|Visualization", meta = (EditCondition = "bEnableSuperGroups && bShowGroupPivotIcon",
		ToolTip = "Off: selected / editing group only. On: every group in the level."))
	bool bShowAllGroupPivotIcons = false;

	UPROPERTY(config, EditAnywhere, Category = "Super Groups|Visualization", meta = (EditCondition = "bEnableSuperGroups && bShowGroupPivotIcon"))
	FLinearColor GroupPivotIconColor = FLinearColor(1.0f, 1.0f, 1.0f, 1.0f);

	UPROPERTY(config, EditAnywhere, Category = "Super Groups|Visualization", meta = (EditCondition = "bEnableSuperGroups && bShowGroupPivotIcon", ClampMin = "2.5", ClampMax = "500.0", Units = "cm"))
	float GroupPivotIconWorldSize = 35.0f;

	//~ Interactive Decal Placement

	UPROPERTY(config, EditAnywhere, Category = "Decal Placement", meta = (DisplayName = "Enable Interactive Decal Placement",
		ToolTip = "Drag-place deferred decals. Toggle from Keyboard Shortcuts (default J)."))
	bool bEnableInteractiveDecalPlacement = true;

	UPROPERTY(config, EditAnywhere, Category = "Decal Placement", meta = (DisplayName = "Inherit Selected Decal On Enter", EditCondition = "bEnableInteractiveDecalPlacement",
		ToolTip = "When the tool starts with one scene decal selected, the next decal starts as a copy of it (material, size, flips, opacity, sort order). Off: the selected decal is still edited in place, but the next decal keeps the session's settings. Shift+MMB copies a decal at any time."))
	bool bInheritSelectedDecalOnEnter = true;

	UPROPERTY(config, EditAnywhere, Category = "Decal Placement", meta = (ClampMin = "1.0", Units = "cm", EditCondition = "bEnableInteractiveDecalPlacement",
		ToolTip = "Projection depth (cm) of new decals until W+Scroll changes it."))
	float DefaultProjectionDepth = 24.0f;

	UPROPERTY(config, EditAnywhere, Category = "Decal Placement", meta = (ClampMin = "0.1", Units = "cm", EditCondition = "bEnableInteractiveDecalPlacement",
		ToolTip = "Smallest half-size (cm) a drag or Shift+Scroll can size a decal to."))
	float MinDragExtent = 5.0f;

	UPROPERTY(config, EditAnywhere, Category = "Decal Placement", meta = (ClampMin = "1.0", Units = "cm", EditCondition = "bEnableInteractiveDecalPlacement",
		ToolTip = "Half-size (cm) of the hover preview and of click placements before any drag has set a size."))
	float PreviewPlaneExtent = 128.0f;

	UPROPERTY(config, EditAnywhere, Category = "Decal Placement", meta = (DisplayName = "Rotation Scroll Interval", ClampMin = "0.1", ClampMax = "90.0", Units = "deg", EditCondition = "bEnableInteractiveDecalPlacement",
		ToolTip = "Degrees per Ctrl+Scroll tick before / during hover."))
	float RotationIntervalDegrees = 5.0f;

	UPROPERTY(config, EditAnywhere, Category = "Decal Placement", meta = (DisplayName = "Size Scroll Interval", ClampMin = "0.1", Units = "cm", EditCondition = "bEnableInteractiveDecalPlacement",
		ToolTip = "In-plane half-extent (cm) per Shift+Scroll tick."))
	float SizeScrollInterval = 5.0f;

	UPROPERTY(config, EditAnywhere, Category = "Decal Placement", meta = (EditCondition = "bEnableInteractiveDecalPlacement",
		ToolTip = "Click placements reuse the size of the last drag-placed decal."))
	bool bUseLastPlacedSize = true;

	UPROPERTY(config, EditAnywhere, Category = "Decal Placement", meta = (DisplayName = "Nest Placed Decals In Category Folders", EditCondition = "bEnableInteractiveDecalPlacement",
		ToolTip = "Placed decals go in the Outliner folder Decals/<collection>. Content Browser picks go under Decals."))
	bool bNestPlacedDecalsInCategoryFolders = true;

	UPROPERTY(config, EditAnywhere, Category = "Decal Placement", meta = (DisplayName = "Scene Decal Outline Opacity", ClampMin = "0.0", ClampMax = "1.0", EditCondition = "bEnableInteractiveDecalPlacement",
		ToolTip = "Opacity of the faint outline drawn on other scene decals while the Bounds toggle is on (editor view only)."))
	float SceneDecalOutlineOpacity = 0.15f;

	UPROPERTY(config, EditAnywhere, Category = "Decal Placement", meta = (DisplayName = "Scene Decal Outline Thickness (px)", ClampMin = "0.0", ClampMax = "6.0", EditCondition = "bEnableInteractiveDecalPlacement",
		ToolTip = "Line thickness (px) of the outline on other scene decals. 0 draws a hairline."))
	float SceneDecalOutlineThickness = 0.0f;

	/** First-run seed only. Copied into per-user settings; not the live browse list. */
	UPROPERTY(config)
	TArray<FInteractiveDecalCollectionEntry> CollectionEntries;
};

/**
 * Choices made from tool UI (welcome splash, HUD checkboxes, decal collections).
 * Saved/Config/<Platform>/EditorPerProjectUserSettings.ini — per user, this project.
 */
UCLASS(config = EditorPerProjectUserSettings)
class PROWORKFLOWTOOLS_API UProWorkflowToolsUserSettings : public UObject
{
	GENERATED_BODY()

public:
#if WITH_EDITOR
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
	void NotifyAndPersist(FProperty* Property = nullptr);
#endif

	/** One-time copy of project DefaultEditor.ini CollectionEntries for this user. */
	void ImportProjectCollectionEntriesIfNeeded();

	UPROPERTY(config)
	bool bDontShowWelcomeSplashAgain = false;

	/** Welcome splash window geometry in Slate units (zero = not yet saved, use defaults). */
	UPROPERTY(config)
	FVector2D WelcomeSplashWindowSize = FVector2D::ZeroVector;

	UPROPERTY(config)
	FVector2D WelcomeSplashWindowPosition = FVector2D::ZeroVector;

	/** Bounding Box Scale HUD: face-center handles. */
	UPROPERTY(config)
	bool bBoxScaleShowFaceHandles = true;

	/** Bounding Box Scale HUD: edge-midpoint handles. */
	UPROPERTY(config)
	bool bBoxScaleShowEdgeHandles = false;

	/** Bounding Box Scale HUD: corner handles. */
	UPROPERTY(config)
	bool bBoxScaleShowCornerHandles = true;

	/** Actor Grid Paint HUD: skip cells where foreign collision clips the paint box. Same asset type is always blocked. */
	UPROPERTY(config)
	bool bPreventOverlappingPaint = false;

	/** Decal Placement HUD: place and drag-size from the center. Holding Alt inverts it. */
	UPROPERTY(config)
	bool bDecalPlaceCentered = false;

	/** Decal Placement HUD: orient the decal to the average of the surface under its footprint (C toggles). */
	UPROPERTY(config)
	bool bDecalFitSurface = false;

	/** Content Browser collections this user browses in Decal Placement. */
	UPROPERTY(config, EditAnywhere, Category = "Decal Placement|Collections", meta = (DisplayName = "Decal Collections", TitleProperty = "CollectionName",
		ToolTip = "Content Browser collections browsed with Scroll / Tab+Scroll while placing. Per user."))
	TArray<FInteractiveDecalCollectionEntry> CollectionEntries;

	UPROPERTY(config)
	bool bDecalCollectionEntriesInitialized = false;
};
