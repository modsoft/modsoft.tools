// Copyright © 2026 Trey McNair. All rights reserved.

#pragma once

#include "CoreMinimal.h"

// FInteractiveDecalCollectionEntry lives in ProWorkflowToolsSettings.h (merged settings page).

/**
 * Runtime placement state machine. Preview / Dragging pose the ghost; Edit / EditDragging pose a
 * placed decal instead (the ghost is hidden), with EditDragging a handle drag on it. Idle is Edit with
 * nothing in hand: no ghost, no target; the bindings are the same (LMB makes, MMB targets), Esc exits.
 */
enum class EInteractiveDecalPlacementState : uint8
{
	Inactive,
	Idle,
	Preview,
	Dragging,
	Edit,
	EditDragging
};

/**
 * A grab site on a placed decal's image rectangle: a corner (both signs set), an edge (one sign zero),
 * or the body (both zero, bBody set) which moves the decal without resizing it.
 * Signs are along the decal's unit Y / Z axes in world space, so a mirrored decal (negative scale)
 * labels the same world corner the same way the drag math sees it.
 */
struct FInteractiveDecalEditHandle
{
	int8 SignY = 0;
	int8 SignZ = 0;
	bool bBody = false;

	static FInteractiveDecalEditHandle Body() { FInteractiveDecalEditHandle Handle; Handle.bBody = true; return Handle; }

	bool IsValid() const { return bBody || SignY != 0 || SignZ != 0; }
	bool IsCorner() const { return SignY != 0 && SignZ != 0; }
	bool IsBody() const { return bBody; }
	bool operator==(const FInteractiveDecalEditHandle& Other) const { return SignY == Other.SignY && SignZ == Other.SignZ && bBody == Other.bBody; }
	bool operator!=(const FInteractiveDecalEditHandle& Other) const { return !(*this == Other); }
};

/** Stable tangent frame captured at anchor time. */
struct FInteractiveDecalTangentFrame
{
	FVector Position = FVector::ZeroVector;
	FVector Normal = FVector::UpVector;
	FVector Tangent = FVector::ForwardVector;
	FVector Bitangent = FVector::RightVector;
};

/** Computed decal transform and size from drag interaction. */
struct FInteractiveDecalPlacementResult
{
	/** Rotation and centre; the footprint is applied as scale from DecalSize when the preview is written. */
	FTransform ActorTransform = FTransform::Identity;
	/** Half-extents in cm (X depth, Y height, Z width), unsigned. */
	FVector DecalSize = FVector(128.0f, 256.0f, 256.0f);
};

